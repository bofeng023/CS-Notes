package cc.linkedme.dashboard.converter;

import cc.linkedme.dashboard.dao.user.UserPO;
import cc.linkedme.dashboard.model.UserInfo;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:31 2019-09-09
 * @:Description
 */
public class UserPoConverter {

    public static UserInfo po2Bo(UserPO userPO) {

        UserInfo userInfo = new UserInfo();
        BeanUtils.copyProperties(userPO, userInfo);
        userInfo.setUid(userPO.getId());
        userInfo.setActiveStatus(userPO.getActiveStatus() == null ? null : YesNoEnum.get(userPO.getActiveStatus()));
        userInfo.setAuditState(userPO.getAuditState() == null ? null : AuditState.get(userPO.getAuditState().intValue()));

        return userInfo;

    }
}
