package cc.linkedme.dashboard.service.impl;

import cc.linkedme.dashboard.converter.AppPoConverter;
import cc.linkedme.dashboard.dao.app.AppPO;
import cc.linkedme.dashboard.dao.app.AppPOExample;
import cc.linkedme.dashboard.dao.app.AppPOMapper;
import cc.linkedme.dashboard.errorcode.AppErrorCode;
import cc.linkedme.dashboard.exception.AppException;
import cc.linkedme.dashboard.model.AppInfo;
import cc.linkedme.dashboard.model.UserInfo;
import cc.linkedme.dashboard.service.AppInfoService;
import cc.linkedme.dashboard.service.UserInfoService;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author: liuyunmeng
 * @Date: Create in 17:02 2019-09-06
 * @:Description
 */
@Service("appInfoService")
public class AppInfoServiceImpl implements AppInfoService {

    private static final Logger logger = LoggerFactory.getLogger(AppInfoServiceImpl.class);

    @Resource
    private AppPOMapper appPOMapper;

    @Resource
    private UserInfoService userInfoService;

    @Override
    public AppInfo getAppInfo(String appKey) throws AppException {

        logger.info("getAppInfo, appKey:{}", appKey);

        AppPOExample appPOExample = new AppPOExample();
        AppPOExample.Criteria criteria = appPOExample.createCriteria();
        criteria.andAppKeyEqualTo(appKey);
        criteria.andValidStatusEqualTo((byte) 1);
        List<AppPO> appPOS = appPOMapper.selectByExample(appPOExample);
        if (CollectionUtils.isEmpty(appPOS)) {
            throw new AppException(AppErrorCode.APP_NOT_EXIST);
        }
        AppInfo appInfo = AppPoConverter.po2Bo(appPOS.get(0));
        UserInfo userInfo = userInfoService.getUserInfo(appInfo.getUid());
        appInfo.setPid(userInfo.getPid());

        logger.info("getAppInfo, appKey:{}, appInfo:{}", appKey, appInfo);
        return appInfo;
    }
}
