package cc.linkedme.dashboard.dao.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserPOExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public UserPOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andEmailIsNull() {
            addCriterion("email is null");
            return (Criteria) this;
        }

        public Criteria andEmailIsNotNull() {
            addCriterion("email is not null");
            return (Criteria) this;
        }

        public Criteria andEmailEqualTo(String value) {
            addCriterion("email =", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotEqualTo(String value) {
            addCriterion("email <>", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThan(String value) {
            addCriterion("email >", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThanOrEqualTo(String value) {
            addCriterion("email >=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThan(String value) {
            addCriterion("email <", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThanOrEqualTo(String value) {
            addCriterion("email <=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLike(String value) {
            addCriterion("email like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotLike(String value) {
            addCriterion("email not like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailIn(List<String> values) {
            addCriterion("email in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotIn(List<String> values) {
            addCriterion("email not in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailBetween(String value1, String value2) {
            addCriterion("email between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotBetween(String value1, String value2) {
            addCriterion("email not between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andPwdIsNull() {
            addCriterion("pwd is null");
            return (Criteria) this;
        }

        public Criteria andPwdIsNotNull() {
            addCriterion("pwd is not null");
            return (Criteria) this;
        }

        public Criteria andPwdEqualTo(String value) {
            addCriterion("pwd =", value, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdNotEqualTo(String value) {
            addCriterion("pwd <>", value, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdGreaterThan(String value) {
            addCriterion("pwd >", value, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdGreaterThanOrEqualTo(String value) {
            addCriterion("pwd >=", value, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdLessThan(String value) {
            addCriterion("pwd <", value, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdLessThanOrEqualTo(String value) {
            addCriterion("pwd <=", value, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdLike(String value) {
            addCriterion("pwd like", value, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdNotLike(String value) {
            addCriterion("pwd not like", value, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdIn(List<String> values) {
            addCriterion("pwd in", values, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdNotIn(List<String> values) {
            addCriterion("pwd not in", values, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdBetween(String value1, String value2) {
            addCriterion("pwd between", value1, value2, "pwd");
            return (Criteria) this;
        }

        public Criteria andPwdNotBetween(String value1, String value2) {
            addCriterion("pwd not between", value1, value2, "pwd");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberIsNull() {
            addCriterion("phone_number is null");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberIsNotNull() {
            addCriterion("phone_number is not null");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberEqualTo(String value) {
            addCriterion("phone_number =", value, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberNotEqualTo(String value) {
            addCriterion("phone_number <>", value, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberGreaterThan(String value) {
            addCriterion("phone_number >", value, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberGreaterThanOrEqualTo(String value) {
            addCriterion("phone_number >=", value, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberLessThan(String value) {
            addCriterion("phone_number <", value, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberLessThanOrEqualTo(String value) {
            addCriterion("phone_number <=", value, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberLike(String value) {
            addCriterion("phone_number like", value, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberNotLike(String value) {
            addCriterion("phone_number not like", value, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberIn(List<String> values) {
            addCriterion("phone_number in", values, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberNotIn(List<String> values) {
            addCriterion("phone_number not in", values, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberBetween(String value1, String value2) {
            addCriterion("phone_number between", value1, value2, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andPhoneNumberNotBetween(String value1, String value2) {
            addCriterion("phone_number not between", value1, value2, "phoneNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberIsNull() {
            addCriterion("QQ_number is null");
            return (Criteria) this;
        }

        public Criteria andQqNumberIsNotNull() {
            addCriterion("QQ_number is not null");
            return (Criteria) this;
        }

        public Criteria andQqNumberEqualTo(String value) {
            addCriterion("QQ_number =", value, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberNotEqualTo(String value) {
            addCriterion("QQ_number <>", value, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberGreaterThan(String value) {
            addCriterion("QQ_number >", value, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberGreaterThanOrEqualTo(String value) {
            addCriterion("QQ_number >=", value, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberLessThan(String value) {
            addCriterion("QQ_number <", value, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberLessThanOrEqualTo(String value) {
            addCriterion("QQ_number <=", value, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberLike(String value) {
            addCriterion("QQ_number like", value, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberNotLike(String value) {
            addCriterion("QQ_number not like", value, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberIn(List<String> values) {
            addCriterion("QQ_number in", values, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberNotIn(List<String> values) {
            addCriterion("QQ_number not in", values, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberBetween(String value1, String value2) {
            addCriterion("QQ_number between", value1, value2, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andQqNumberNotBetween(String value1, String value2) {
            addCriterion("QQ_number not between", value1, value2, "qqNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyIsNull() {
            addCriterion("company is null");
            return (Criteria) this;
        }

        public Criteria andCompanyIsNotNull() {
            addCriterion("company is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyEqualTo(String value) {
            addCriterion("company =", value, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyNotEqualTo(String value) {
            addCriterion("company <>", value, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyGreaterThan(String value) {
            addCriterion("company >", value, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyGreaterThanOrEqualTo(String value) {
            addCriterion("company >=", value, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyLessThan(String value) {
            addCriterion("company <", value, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyLessThanOrEqualTo(String value) {
            addCriterion("company <=", value, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyLike(String value) {
            addCriterion("company like", value, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyNotLike(String value) {
            addCriterion("company not like", value, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyIn(List<String> values) {
            addCriterion("company in", values, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyNotIn(List<String> values) {
            addCriterion("company not in", values, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyBetween(String value1, String value2) {
            addCriterion("company between", value1, value2, "company");
            return (Criteria) this;
        }

        public Criteria andCompanyNotBetween(String value1, String value2) {
            addCriterion("company not between", value1, value2, "company");
            return (Criteria) this;
        }

        public Criteria andRoleIdIsNull() {
            addCriterion("role_id is null");
            return (Criteria) this;
        }

        public Criteria andRoleIdIsNotNull() {
            addCriterion("role_id is not null");
            return (Criteria) this;
        }

        public Criteria andRoleIdEqualTo(Byte value) {
            addCriterion("role_id =", value, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdNotEqualTo(Byte value) {
            addCriterion("role_id <>", value, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdGreaterThan(Byte value) {
            addCriterion("role_id >", value, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdGreaterThanOrEqualTo(Byte value) {
            addCriterion("role_id >=", value, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdLessThan(Byte value) {
            addCriterion("role_id <", value, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdLessThanOrEqualTo(Byte value) {
            addCriterion("role_id <=", value, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdIn(List<Byte> values) {
            addCriterion("role_id in", values, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdNotIn(List<Byte> values) {
            addCriterion("role_id not in", values, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdBetween(Byte value1, Byte value2) {
            addCriterion("role_id between", value1, value2, "roleId");
            return (Criteria) this;
        }

        public Criteria andRoleIdNotBetween(Byte value1, Byte value2) {
            addCriterion("role_id not between", value1, value2, "roleId");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIsNull() {
            addCriterion("register_time is null");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIsNotNull() {
            addCriterion("register_time is not null");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeEqualTo(Date value) {
            addCriterion("register_time =", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotEqualTo(Date value) {
            addCriterion("register_time <>", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeGreaterThan(Date value) {
            addCriterion("register_time >", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("register_time >=", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeLessThan(Date value) {
            addCriterion("register_time <", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeLessThanOrEqualTo(Date value) {
            addCriterion("register_time <=", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIn(List<Date> values) {
            addCriterion("register_time in", values, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotIn(List<Date> values) {
            addCriterion("register_time not in", values, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeBetween(Date value1, Date value2) {
            addCriterion("register_time between", value1, value2, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotBetween(Date value1, Date value2) {
            addCriterion("register_time not between", value1, value2, "registerTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeIsNull() {
            addCriterion("last_login_time is null");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeIsNotNull() {
            addCriterion("last_login_time is not null");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeEqualTo(Date value) {
            addCriterion("last_login_time =", value, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeNotEqualTo(Date value) {
            addCriterion("last_login_time <>", value, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeGreaterThan(Date value) {
            addCriterion("last_login_time >", value, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("last_login_time >=", value, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeLessThan(Date value) {
            addCriterion("last_login_time <", value, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeLessThanOrEqualTo(Date value) {
            addCriterion("last_login_time <=", value, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeIn(List<Date> values) {
            addCriterion("last_login_time in", values, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeNotIn(List<Date> values) {
            addCriterion("last_login_time not in", values, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeBetween(Date value1, Date value2) {
            addCriterion("last_login_time between", value1, value2, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andLastLoginTimeNotBetween(Date value1, Date value2) {
            addCriterion("last_login_time not between", value1, value2, "lastLoginTime");
            return (Criteria) this;
        }

        public Criteria andValidStatusIsNull() {
            addCriterion("valid_status is null");
            return (Criteria) this;
        }

        public Criteria andValidStatusIsNotNull() {
            addCriterion("valid_status is not null");
            return (Criteria) this;
        }

        public Criteria andValidStatusEqualTo(Byte value) {
            addCriterion("valid_status =", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusNotEqualTo(Byte value) {
            addCriterion("valid_status <>", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusGreaterThan(Byte value) {
            addCriterion("valid_status >", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("valid_status >=", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusLessThan(Byte value) {
            addCriterion("valid_status <", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusLessThanOrEqualTo(Byte value) {
            addCriterion("valid_status <=", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusIn(List<Byte> values) {
            addCriterion("valid_status in", values, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusNotIn(List<Byte> values) {
            addCriterion("valid_status not in", values, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusBetween(Byte value1, Byte value2) {
            addCriterion("valid_status between", value1, value2, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("valid_status not between", value1, value2, "validStatus");
            return (Criteria) this;
        }

        public Criteria andTokenIsNull() {
            addCriterion("token is null");
            return (Criteria) this;
        }

        public Criteria andTokenIsNotNull() {
            addCriterion("token is not null");
            return (Criteria) this;
        }

        public Criteria andTokenEqualTo(String value) {
            addCriterion("token =", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotEqualTo(String value) {
            addCriterion("token <>", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenGreaterThan(String value) {
            addCriterion("token >", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenGreaterThanOrEqualTo(String value) {
            addCriterion("token >=", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLessThan(String value) {
            addCriterion("token <", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLessThanOrEqualTo(String value) {
            addCriterion("token <=", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenLike(String value) {
            addCriterion("token like", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotLike(String value) {
            addCriterion("token not like", value, "token");
            return (Criteria) this;
        }

        public Criteria andTokenIn(List<String> values) {
            addCriterion("token in", values, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotIn(List<String> values) {
            addCriterion("token not in", values, "token");
            return (Criteria) this;
        }

        public Criteria andTokenBetween(String value1, String value2) {
            addCriterion("token between", value1, value2, "token");
            return (Criteria) this;
        }

        public Criteria andTokenNotBetween(String value1, String value2) {
            addCriterion("token not between", value1, value2, "token");
            return (Criteria) this;
        }

        public Criteria andRandomCodeIsNull() {
            addCriterion("random_code is null");
            return (Criteria) this;
        }

        public Criteria andRandomCodeIsNotNull() {
            addCriterion("random_code is not null");
            return (Criteria) this;
        }

        public Criteria andRandomCodeEqualTo(String value) {
            addCriterion("random_code =", value, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeNotEqualTo(String value) {
            addCriterion("random_code <>", value, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeGreaterThan(String value) {
            addCriterion("random_code >", value, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeGreaterThanOrEqualTo(String value) {
            addCriterion("random_code >=", value, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeLessThan(String value) {
            addCriterion("random_code <", value, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeLessThanOrEqualTo(String value) {
            addCriterion("random_code <=", value, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeLike(String value) {
            addCriterion("random_code like", value, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeNotLike(String value) {
            addCriterion("random_code not like", value, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeIn(List<String> values) {
            addCriterion("random_code in", values, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeNotIn(List<String> values) {
            addCriterion("random_code not in", values, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeBetween(String value1, String value2) {
            addCriterion("random_code between", value1, value2, "randomCode");
            return (Criteria) this;
        }

        public Criteria andRandomCodeNotBetween(String value1, String value2) {
            addCriterion("random_code not between", value1, value2, "randomCode");
            return (Criteria) this;
        }

        public Criteria andPidIsNull() {
            addCriterion("pid is null");
            return (Criteria) this;
        }

        public Criteria andPidIsNotNull() {
            addCriterion("pid is not null");
            return (Criteria) this;
        }

        public Criteria andPidEqualTo(Integer value) {
            addCriterion("pid =", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotEqualTo(Integer value) {
            addCriterion("pid <>", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidGreaterThan(Integer value) {
            addCriterion("pid >", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidGreaterThanOrEqualTo(Integer value) {
            addCriterion("pid >=", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidLessThan(Integer value) {
            addCriterion("pid <", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidLessThanOrEqualTo(Integer value) {
            addCriterion("pid <=", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidIn(List<Integer> values) {
            addCriterion("pid in", values, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotIn(List<Integer> values) {
            addCriterion("pid not in", values, "pid");
            return (Criteria) this;
        }

        public Criteria andPidBetween(Integer value1, Integer value2) {
            addCriterion("pid between", value1, value2, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotBetween(Integer value1, Integer value2) {
            addCriterion("pid not between", value1, value2, "pid");
            return (Criteria) this;
        }

        public Criteria andNoteIsNull() {
            addCriterion("note is null");
            return (Criteria) this;
        }

        public Criteria andNoteIsNotNull() {
            addCriterion("note is not null");
            return (Criteria) this;
        }

        public Criteria andNoteEqualTo(String value) {
            addCriterion("note =", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotEqualTo(String value) {
            addCriterion("note <>", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThan(String value) {
            addCriterion("note >", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThanOrEqualTo(String value) {
            addCriterion("note >=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThan(String value) {
            addCriterion("note <", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThanOrEqualTo(String value) {
            addCriterion("note <=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLike(String value) {
            addCriterion("note like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotLike(String value) {
            addCriterion("note not like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteIn(List<String> values) {
            addCriterion("note in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotIn(List<String> values) {
            addCriterion("note not in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteBetween(String value1, String value2) {
            addCriterion("note between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotBetween(String value1, String value2) {
            addCriterion("note not between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andActiveStatusIsNull() {
            addCriterion("active_status is null");
            return (Criteria) this;
        }

        public Criteria andActiveStatusIsNotNull() {
            addCriterion("active_status is not null");
            return (Criteria) this;
        }

        public Criteria andActiveStatusEqualTo(Byte value) {
            addCriterion("active_status =", value, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusNotEqualTo(Byte value) {
            addCriterion("active_status <>", value, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusGreaterThan(Byte value) {
            addCriterion("active_status >", value, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("active_status >=", value, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusLessThan(Byte value) {
            addCriterion("active_status <", value, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusLessThanOrEqualTo(Byte value) {
            addCriterion("active_status <=", value, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusIn(List<Byte> values) {
            addCriterion("active_status in", values, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusNotIn(List<Byte> values) {
            addCriterion("active_status not in", values, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusBetween(Byte value1, Byte value2) {
            addCriterion("active_status between", value1, value2, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("active_status not between", value1, value2, "activeStatus");
            return (Criteria) this;
        }

        public Criteria andActiveTimeIsNull() {
            addCriterion("active_time is null");
            return (Criteria) this;
        }

        public Criteria andActiveTimeIsNotNull() {
            addCriterion("active_time is not null");
            return (Criteria) this;
        }

        public Criteria andActiveTimeEqualTo(Date value) {
            addCriterion("active_time =", value, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeNotEqualTo(Date value) {
            addCriterion("active_time <>", value, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeGreaterThan(Date value) {
            addCriterion("active_time >", value, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("active_time >=", value, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeLessThan(Date value) {
            addCriterion("active_time <", value, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeLessThanOrEqualTo(Date value) {
            addCriterion("active_time <=", value, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeIn(List<Date> values) {
            addCriterion("active_time in", values, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeNotIn(List<Date> values) {
            addCriterion("active_time not in", values, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeBetween(Date value1, Date value2) {
            addCriterion("active_time between", value1, value2, "activeTime");
            return (Criteria) this;
        }

        public Criteria andActiveTimeNotBetween(Date value1, Date value2) {
            addCriterion("active_time not between", value1, value2, "activeTime");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthIsNull() {
            addCriterion("link_active_auth is null");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthIsNotNull() {
            addCriterion("link_active_auth is not null");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthEqualTo(Integer value) {
            addCriterion("link_active_auth =", value, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthNotEqualTo(Integer value) {
            addCriterion("link_active_auth <>", value, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthGreaterThan(Integer value) {
            addCriterion("link_active_auth >", value, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthGreaterThanOrEqualTo(Integer value) {
            addCriterion("link_active_auth >=", value, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthLessThan(Integer value) {
            addCriterion("link_active_auth <", value, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthLessThanOrEqualTo(Integer value) {
            addCriterion("link_active_auth <=", value, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthIn(List<Integer> values) {
            addCriterion("link_active_auth in", values, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthNotIn(List<Integer> values) {
            addCriterion("link_active_auth not in", values, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthBetween(Integer value1, Integer value2) {
            addCriterion("link_active_auth between", value1, value2, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andLinkActiveAuthNotBetween(Integer value1, Integer value2) {
            addCriterion("link_active_auth not between", value1, value2, "linkActiveAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthIsNull() {
            addCriterion("dsp_auth is null");
            return (Criteria) this;
        }

        public Criteria andDspAuthIsNotNull() {
            addCriterion("dsp_auth is not null");
            return (Criteria) this;
        }

        public Criteria andDspAuthEqualTo(Integer value) {
            addCriterion("dsp_auth =", value, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthNotEqualTo(Integer value) {
            addCriterion("dsp_auth <>", value, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthGreaterThan(Integer value) {
            addCriterion("dsp_auth >", value, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthGreaterThanOrEqualTo(Integer value) {
            addCriterion("dsp_auth >=", value, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthLessThan(Integer value) {
            addCriterion("dsp_auth <", value, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthLessThanOrEqualTo(Integer value) {
            addCriterion("dsp_auth <=", value, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthIn(List<Integer> values) {
            addCriterion("dsp_auth in", values, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthNotIn(List<Integer> values) {
            addCriterion("dsp_auth not in", values, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthBetween(Integer value1, Integer value2) {
            addCriterion("dsp_auth between", value1, value2, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andDspAuthNotBetween(Integer value1, Integer value2) {
            addCriterion("dsp_auth not between", value1, value2, "dspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthIsNull() {
            addCriterion("ssp_auth is null");
            return (Criteria) this;
        }

        public Criteria andSspAuthIsNotNull() {
            addCriterion("ssp_auth is not null");
            return (Criteria) this;
        }

        public Criteria andSspAuthEqualTo(Integer value) {
            addCriterion("ssp_auth =", value, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthNotEqualTo(Integer value) {
            addCriterion("ssp_auth <>", value, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthGreaterThan(Integer value) {
            addCriterion("ssp_auth >", value, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthGreaterThanOrEqualTo(Integer value) {
            addCriterion("ssp_auth >=", value, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthLessThan(Integer value) {
            addCriterion("ssp_auth <", value, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthLessThanOrEqualTo(Integer value) {
            addCriterion("ssp_auth <=", value, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthIn(List<Integer> values) {
            addCriterion("ssp_auth in", values, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthNotIn(List<Integer> values) {
            addCriterion("ssp_auth not in", values, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthBetween(Integer value1, Integer value2) {
            addCriterion("ssp_auth between", value1, value2, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andSspAuthNotBetween(Integer value1, Integer value2) {
            addCriterion("ssp_auth not between", value1, value2, "sspAuth");
            return (Criteria) this;
        }

        public Criteria andIdentityIsNull() {
            addCriterion("identity is null");
            return (Criteria) this;
        }

        public Criteria andIdentityIsNotNull() {
            addCriterion("identity is not null");
            return (Criteria) this;
        }

        public Criteria andIdentityEqualTo(Byte value) {
            addCriterion("identity =", value, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityNotEqualTo(Byte value) {
            addCriterion("identity <>", value, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityGreaterThan(Byte value) {
            addCriterion("identity >", value, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityGreaterThanOrEqualTo(Byte value) {
            addCriterion("identity >=", value, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityLessThan(Byte value) {
            addCriterion("identity <", value, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityLessThanOrEqualTo(Byte value) {
            addCriterion("identity <=", value, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityIn(List<Byte> values) {
            addCriterion("identity in", values, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityNotIn(List<Byte> values) {
            addCriterion("identity not in", values, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityBetween(Byte value1, Byte value2) {
            addCriterion("identity between", value1, value2, "identity");
            return (Criteria) this;
        }

        public Criteria andIdentityNotBetween(Byte value1, Byte value2) {
            addCriterion("identity not between", value1, value2, "identity");
            return (Criteria) this;
        }

        public Criteria andAuditStateIsNull() {
            addCriterion("audit_state is null");
            return (Criteria) this;
        }

        public Criteria andAuditStateIsNotNull() {
            addCriterion("audit_state is not null");
            return (Criteria) this;
        }

        public Criteria andAuditStateEqualTo(Byte value) {
            addCriterion("audit_state =", value, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateNotEqualTo(Byte value) {
            addCriterion("audit_state <>", value, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateGreaterThan(Byte value) {
            addCriterion("audit_state >", value, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateGreaterThanOrEqualTo(Byte value) {
            addCriterion("audit_state >=", value, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateLessThan(Byte value) {
            addCriterion("audit_state <", value, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateLessThanOrEqualTo(Byte value) {
            addCriterion("audit_state <=", value, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateIn(List<Byte> values) {
            addCriterion("audit_state in", values, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateNotIn(List<Byte> values) {
            addCriterion("audit_state not in", values, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateBetween(Byte value1, Byte value2) {
            addCriterion("audit_state between", value1, value2, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuditStateNotBetween(Byte value1, Byte value2) {
            addCriterion("audit_state not between", value1, value2, "auditState");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameIsNull() {
            addCriterion("authentication_name is null");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameIsNotNull() {
            addCriterion("authentication_name is not null");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameEqualTo(String value) {
            addCriterion("authentication_name =", value, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameNotEqualTo(String value) {
            addCriterion("authentication_name <>", value, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameGreaterThan(String value) {
            addCriterion("authentication_name >", value, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameGreaterThanOrEqualTo(String value) {
            addCriterion("authentication_name >=", value, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameLessThan(String value) {
            addCriterion("authentication_name <", value, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameLessThanOrEqualTo(String value) {
            addCriterion("authentication_name <=", value, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameLike(String value) {
            addCriterion("authentication_name like", value, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameNotLike(String value) {
            addCriterion("authentication_name not like", value, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameIn(List<String> values) {
            addCriterion("authentication_name in", values, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameNotIn(List<String> values) {
            addCriterion("authentication_name not in", values, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameBetween(String value1, String value2) {
            addCriterion("authentication_name between", value1, value2, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationNameNotBetween(String value1, String value2) {
            addCriterion("authentication_name not between", value1, value2, "authenticationName");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailIsNull() {
            addCriterion("authentication_email is null");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailIsNotNull() {
            addCriterion("authentication_email is not null");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailEqualTo(String value) {
            addCriterion("authentication_email =", value, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailNotEqualTo(String value) {
            addCriterion("authentication_email <>", value, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailGreaterThan(String value) {
            addCriterion("authentication_email >", value, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailGreaterThanOrEqualTo(String value) {
            addCriterion("authentication_email >=", value, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailLessThan(String value) {
            addCriterion("authentication_email <", value, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailLessThanOrEqualTo(String value) {
            addCriterion("authentication_email <=", value, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailLike(String value) {
            addCriterion("authentication_email like", value, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailNotLike(String value) {
            addCriterion("authentication_email not like", value, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailIn(List<String> values) {
            addCriterion("authentication_email in", values, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailNotIn(List<String> values) {
            addCriterion("authentication_email not in", values, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailBetween(String value1, String value2) {
            addCriterion("authentication_email between", value1, value2, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationEmailNotBetween(String value1, String value2) {
            addCriterion("authentication_email not between", value1, value2, "authenticationEmail");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneIsNull() {
            addCriterion("authentication_phone is null");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneIsNotNull() {
            addCriterion("authentication_phone is not null");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneEqualTo(String value) {
            addCriterion("authentication_phone =", value, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneNotEqualTo(String value) {
            addCriterion("authentication_phone <>", value, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneGreaterThan(String value) {
            addCriterion("authentication_phone >", value, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("authentication_phone >=", value, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneLessThan(String value) {
            addCriterion("authentication_phone <", value, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneLessThanOrEqualTo(String value) {
            addCriterion("authentication_phone <=", value, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneLike(String value) {
            addCriterion("authentication_phone like", value, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneNotLike(String value) {
            addCriterion("authentication_phone not like", value, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneIn(List<String> values) {
            addCriterion("authentication_phone in", values, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneNotIn(List<String> values) {
            addCriterion("authentication_phone not in", values, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneBetween(String value1, String value2) {
            addCriterion("authentication_phone between", value1, value2, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andAuthenticationPhoneNotBetween(String value1, String value2) {
            addCriterion("authentication_phone not between", value1, value2, "authenticationPhone");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberIsNull() {
            addCriterion("identity_card_number is null");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberIsNotNull() {
            addCriterion("identity_card_number is not null");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberEqualTo(String value) {
            addCriterion("identity_card_number =", value, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberNotEqualTo(String value) {
            addCriterion("identity_card_number <>", value, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberGreaterThan(String value) {
            addCriterion("identity_card_number >", value, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberGreaterThanOrEqualTo(String value) {
            addCriterion("identity_card_number >=", value, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberLessThan(String value) {
            addCriterion("identity_card_number <", value, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberLessThanOrEqualTo(String value) {
            addCriterion("identity_card_number <=", value, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberLike(String value) {
            addCriterion("identity_card_number like", value, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberNotLike(String value) {
            addCriterion("identity_card_number not like", value, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberIn(List<String> values) {
            addCriterion("identity_card_number in", values, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberNotIn(List<String> values) {
            addCriterion("identity_card_number not in", values, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberBetween(String value1, String value2) {
            addCriterion("identity_card_number between", value1, value2, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardNumberNotBetween(String value1, String value2) {
            addCriterion("identity_card_number not between", value1, value2, "identityCardNumber");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontIsNull() {
            addCriterion("identity_card_front is null");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontIsNotNull() {
            addCriterion("identity_card_front is not null");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontEqualTo(String value) {
            addCriterion("identity_card_front =", value, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontNotEqualTo(String value) {
            addCriterion("identity_card_front <>", value, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontGreaterThan(String value) {
            addCriterion("identity_card_front >", value, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontGreaterThanOrEqualTo(String value) {
            addCriterion("identity_card_front >=", value, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontLessThan(String value) {
            addCriterion("identity_card_front <", value, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontLessThanOrEqualTo(String value) {
            addCriterion("identity_card_front <=", value, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontLike(String value) {
            addCriterion("identity_card_front like", value, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontNotLike(String value) {
            addCriterion("identity_card_front not like", value, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontIn(List<String> values) {
            addCriterion("identity_card_front in", values, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontNotIn(List<String> values) {
            addCriterion("identity_card_front not in", values, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontBetween(String value1, String value2) {
            addCriterion("identity_card_front between", value1, value2, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardFrontNotBetween(String value1, String value2) {
            addCriterion("identity_card_front not between", value1, value2, "identityCardFront");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackIsNull() {
            addCriterion("identity_card_back is null");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackIsNotNull() {
            addCriterion("identity_card_back is not null");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackEqualTo(String value) {
            addCriterion("identity_card_back =", value, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackNotEqualTo(String value) {
            addCriterion("identity_card_back <>", value, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackGreaterThan(String value) {
            addCriterion("identity_card_back >", value, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackGreaterThanOrEqualTo(String value) {
            addCriterion("identity_card_back >=", value, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackLessThan(String value) {
            addCriterion("identity_card_back <", value, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackLessThanOrEqualTo(String value) {
            addCriterion("identity_card_back <=", value, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackLike(String value) {
            addCriterion("identity_card_back like", value, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackNotLike(String value) {
            addCriterion("identity_card_back not like", value, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackIn(List<String> values) {
            addCriterion("identity_card_back in", values, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackNotIn(List<String> values) {
            addCriterion("identity_card_back not in", values, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackBetween(String value1, String value2) {
            addCriterion("identity_card_back between", value1, value2, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardBackNotBetween(String value1, String value2) {
            addCriterion("identity_card_back not between", value1, value2, "identityCardBack");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandIsNull() {
            addCriterion("identity_card_hand is null");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandIsNotNull() {
            addCriterion("identity_card_hand is not null");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandEqualTo(String value) {
            addCriterion("identity_card_hand =", value, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandNotEqualTo(String value) {
            addCriterion("identity_card_hand <>", value, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandGreaterThan(String value) {
            addCriterion("identity_card_hand >", value, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandGreaterThanOrEqualTo(String value) {
            addCriterion("identity_card_hand >=", value, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandLessThan(String value) {
            addCriterion("identity_card_hand <", value, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandLessThanOrEqualTo(String value) {
            addCriterion("identity_card_hand <=", value, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandLike(String value) {
            addCriterion("identity_card_hand like", value, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandNotLike(String value) {
            addCriterion("identity_card_hand not like", value, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandIn(List<String> values) {
            addCriterion("identity_card_hand in", values, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandNotIn(List<String> values) {
            addCriterion("identity_card_hand not in", values, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandBetween(String value1, String value2) {
            addCriterion("identity_card_hand between", value1, value2, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andIdentityCardHandNotBetween(String value1, String value2) {
            addCriterion("identity_card_hand not between", value1, value2, "identityCardHand");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeIsNull() {
            addCriterion("unified_business_code is null");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeIsNotNull() {
            addCriterion("unified_business_code is not null");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeEqualTo(String value) {
            addCriterion("unified_business_code =", value, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeNotEqualTo(String value) {
            addCriterion("unified_business_code <>", value, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeGreaterThan(String value) {
            addCriterion("unified_business_code >", value, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeGreaterThanOrEqualTo(String value) {
            addCriterion("unified_business_code >=", value, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeLessThan(String value) {
            addCriterion("unified_business_code <", value, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeLessThanOrEqualTo(String value) {
            addCriterion("unified_business_code <=", value, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeLike(String value) {
            addCriterion("unified_business_code like", value, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeNotLike(String value) {
            addCriterion("unified_business_code not like", value, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeIn(List<String> values) {
            addCriterion("unified_business_code in", values, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeNotIn(List<String> values) {
            addCriterion("unified_business_code not in", values, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeBetween(String value1, String value2) {
            addCriterion("unified_business_code between", value1, value2, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andUnifiedBusinessCodeNotBetween(String value1, String value2) {
            addCriterion("unified_business_code not between", value1, value2, "unifiedBusinessCode");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseIsNull() {
            addCriterion("company_license is null");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseIsNotNull() {
            addCriterion("company_license is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseEqualTo(String value) {
            addCriterion("company_license =", value, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseNotEqualTo(String value) {
            addCriterion("company_license <>", value, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseGreaterThan(String value) {
            addCriterion("company_license >", value, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseGreaterThanOrEqualTo(String value) {
            addCriterion("company_license >=", value, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseLessThan(String value) {
            addCriterion("company_license <", value, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseLessThanOrEqualTo(String value) {
            addCriterion("company_license <=", value, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseLike(String value) {
            addCriterion("company_license like", value, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseNotLike(String value) {
            addCriterion("company_license not like", value, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseIn(List<String> values) {
            addCriterion("company_license in", values, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseNotIn(List<String> values) {
            addCriterion("company_license not in", values, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseBetween(String value1, String value2) {
            addCriterion("company_license between", value1, value2, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andCompanyLicenseNotBetween(String value1, String value2) {
            addCriterion("company_license not between", value1, value2, "companyLicense");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeIsNull() {
            addCriterion("auth_initial_time is null");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeIsNotNull() {
            addCriterion("auth_initial_time is not null");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeEqualTo(Date value) {
            addCriterion("auth_initial_time =", value, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeNotEqualTo(Date value) {
            addCriterion("auth_initial_time <>", value, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeGreaterThan(Date value) {
            addCriterion("auth_initial_time >", value, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("auth_initial_time >=", value, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeLessThan(Date value) {
            addCriterion("auth_initial_time <", value, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeLessThanOrEqualTo(Date value) {
            addCriterion("auth_initial_time <=", value, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeIn(List<Date> values) {
            addCriterion("auth_initial_time in", values, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeNotIn(List<Date> values) {
            addCriterion("auth_initial_time not in", values, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeBetween(Date value1, Date value2) {
            addCriterion("auth_initial_time between", value1, value2, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthInitialTimeNotBetween(Date value1, Date value2) {
            addCriterion("auth_initial_time not between", value1, value2, "authInitialTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeIsNull() {
            addCriterion("auth_submit_time is null");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeIsNotNull() {
            addCriterion("auth_submit_time is not null");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeEqualTo(Date value) {
            addCriterion("auth_submit_time =", value, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeNotEqualTo(Date value) {
            addCriterion("auth_submit_time <>", value, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeGreaterThan(Date value) {
            addCriterion("auth_submit_time >", value, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("auth_submit_time >=", value, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeLessThan(Date value) {
            addCriterion("auth_submit_time <", value, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeLessThanOrEqualTo(Date value) {
            addCriterion("auth_submit_time <=", value, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeIn(List<Date> values) {
            addCriterion("auth_submit_time in", values, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeNotIn(List<Date> values) {
            addCriterion("auth_submit_time not in", values, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeBetween(Date value1, Date value2) {
            addCriterion("auth_submit_time between", value1, value2, "authSubmitTime");
            return (Criteria) this;
        }

        public Criteria andAuthSubmitTimeNotBetween(Date value1, Date value2) {
            addCriterion("auth_submit_time not between", value1, value2, "authSubmitTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}