package cc.linkedme.dashboard.dao.app;

import cc.linkedme.dashboard.dao.app.AppPO;
import cc.linkedme.dashboard.dao.app.AppPOExample;
import cc.linkedme.dashboard.dao.app.AppPOKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AppPOMapper {
    long countByExample(AppPOExample example);

    int deleteByExample(AppPOExample example);

    int deleteByPrimaryKey(AppPOKey key);

    int insert(AppPO record);

    int insertSelective(AppPO record);

    List<AppPO> selectByExample(AppPOExample example);

    AppPO selectByPrimaryKey(AppPOKey key);

    int updateByExampleSelective(@Param("record") AppPO record, @Param("example") AppPOExample example);

    int updateByExample(@Param("record") AppPO record, @Param("example") AppPOExample example);

    int updateByPrimaryKeySelective(AppPO record);

    int updateByPrimaryKey(AppPO record);
}