package cc.linkedme.dashboard.dao.app;

import java.util.Date;

public class AppPO extends AppPOKey {
    private Integer userId;

    private String appName;

    private String appLogo;

    private String type;

    private String appSecret;

    private String androidUriScheme;

    private String androidNotUrl;

    private String googlePlayUrl;

    private String androidCustomUrl;

    private String androidSearchOption;

    private String androidPackageName;

    private String androidSha256Fingerprints;

    private String iosUriScheme;

    private String iosNotUrl;

    private String iosStoreUrl;

    private String iosCustomUrl;

    private String iosAppPrefix;

    private String iosSearchOption;

    private String iosBundleId;

    private String iosTeamId;

    private Integer iosAndroidFlag;

    private Byte useDefaultLandingPage;

    private String customLandingPage;

    private String customMobileLandingPage;

    private Long deferredDeeplinkTime;

    private Date registerTime;

    private Date lastUpdateTime;

    private Byte validStatus;

    private Byte androidYybApplink;

    private String androidSignMd5;

    private Byte linkAccountAuditState;

    private Date linkAccountSubmitTime;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName == null ? null : appName.trim();
    }

    public String getAppLogo() {
        return appLogo;
    }

    public void setAppLogo(String appLogo) {
        this.appLogo = appLogo == null ? null : appLogo.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret == null ? null : appSecret.trim();
    }

    public String getAndroidUriScheme() {
        return androidUriScheme;
    }

    public void setAndroidUriScheme(String androidUriScheme) {
        this.androidUriScheme = androidUriScheme == null ? null : androidUriScheme.trim();
    }

    public String getAndroidNotUrl() {
        return androidNotUrl;
    }

    public void setAndroidNotUrl(String androidNotUrl) {
        this.androidNotUrl = androidNotUrl == null ? null : androidNotUrl.trim();
    }

    public String getGooglePlayUrl() {
        return googlePlayUrl;
    }

    public void setGooglePlayUrl(String googlePlayUrl) {
        this.googlePlayUrl = googlePlayUrl == null ? null : googlePlayUrl.trim();
    }

    public String getAndroidCustomUrl() {
        return androidCustomUrl;
    }

    public void setAndroidCustomUrl(String androidCustomUrl) {
        this.androidCustomUrl = androidCustomUrl == null ? null : androidCustomUrl.trim();
    }

    public String getAndroidSearchOption() {
        return androidSearchOption;
    }

    public void setAndroidSearchOption(String androidSearchOption) {
        this.androidSearchOption = androidSearchOption == null ? null : androidSearchOption.trim();
    }

    public String getAndroidPackageName() {
        return androidPackageName;
    }

    public void setAndroidPackageName(String androidPackageName) {
        this.androidPackageName = androidPackageName == null ? null : androidPackageName.trim();
    }

    public String getAndroidSha256Fingerprints() {
        return androidSha256Fingerprints;
    }

    public void setAndroidSha256Fingerprints(String androidSha256Fingerprints) {
        this.androidSha256Fingerprints = androidSha256Fingerprints == null ? null : androidSha256Fingerprints.trim();
    }

    public String getIosUriScheme() {
        return iosUriScheme;
    }

    public void setIosUriScheme(String iosUriScheme) {
        this.iosUriScheme = iosUriScheme == null ? null : iosUriScheme.trim();
    }

    public String getIosNotUrl() {
        return iosNotUrl;
    }

    public void setIosNotUrl(String iosNotUrl) {
        this.iosNotUrl = iosNotUrl == null ? null : iosNotUrl.trim();
    }

    public String getIosStoreUrl() {
        return iosStoreUrl;
    }

    public void setIosStoreUrl(String iosStoreUrl) {
        this.iosStoreUrl = iosStoreUrl == null ? null : iosStoreUrl.trim();
    }

    public String getIosCustomUrl() {
        return iosCustomUrl;
    }

    public void setIosCustomUrl(String iosCustomUrl) {
        this.iosCustomUrl = iosCustomUrl == null ? null : iosCustomUrl.trim();
    }

    public String getIosAppPrefix() {
        return iosAppPrefix;
    }

    public void setIosAppPrefix(String iosAppPrefix) {
        this.iosAppPrefix = iosAppPrefix == null ? null : iosAppPrefix.trim();
    }

    public String getIosSearchOption() {
        return iosSearchOption;
    }

    public void setIosSearchOption(String iosSearchOption) {
        this.iosSearchOption = iosSearchOption == null ? null : iosSearchOption.trim();
    }

    public String getIosBundleId() {
        return iosBundleId;
    }

    public void setIosBundleId(String iosBundleId) {
        this.iosBundleId = iosBundleId == null ? null : iosBundleId.trim();
    }

    public String getIosTeamId() {
        return iosTeamId;
    }

    public void setIosTeamId(String iosTeamId) {
        this.iosTeamId = iosTeamId == null ? null : iosTeamId.trim();
    }

    public Integer getIosAndroidFlag() {
        return iosAndroidFlag;
    }

    public void setIosAndroidFlag(Integer iosAndroidFlag) {
        this.iosAndroidFlag = iosAndroidFlag;
    }

    public Byte getUseDefaultLandingPage() {
        return useDefaultLandingPage;
    }

    public void setUseDefaultLandingPage(Byte useDefaultLandingPage) {
        this.useDefaultLandingPage = useDefaultLandingPage;
    }

    public String getCustomLandingPage() {
        return customLandingPage;
    }

    public void setCustomLandingPage(String customLandingPage) {
        this.customLandingPage = customLandingPage == null ? null : customLandingPage.trim();
    }

    public String getCustomMobileLandingPage() {
        return customMobileLandingPage;
    }

    public void setCustomMobileLandingPage(String customMobileLandingPage) {
        this.customMobileLandingPage = customMobileLandingPage == null ? null : customMobileLandingPage.trim();
    }

    public Long getDeferredDeeplinkTime() {
        return deferredDeeplinkTime;
    }

    public void setDeferredDeeplinkTime(Long deferredDeeplinkTime) {
        this.deferredDeeplinkTime = deferredDeeplinkTime;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public Date getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(Date lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public Byte getValidStatus() {
        return validStatus;
    }

    public void setValidStatus(Byte validStatus) {
        this.validStatus = validStatus;
    }

    public Byte getAndroidYybApplink() {
        return androidYybApplink;
    }

    public void setAndroidYybApplink(Byte androidYybApplink) {
        this.androidYybApplink = androidYybApplink;
    }

    public String getAndroidSignMd5() {
        return androidSignMd5;
    }

    public void setAndroidSignMd5(String androidSignMd5) {
        this.androidSignMd5 = androidSignMd5 == null ? null : androidSignMd5.trim();
    }

    public Byte getLinkAccountAuditState() {
        return linkAccountAuditState;
    }

    public void setLinkAccountAuditState(Byte linkAccountAuditState) {
        this.linkAccountAuditState = linkAccountAuditState;
    }

    public Date getLinkAccountSubmitTime() {
        return linkAccountSubmitTime;
    }

    public void setLinkAccountSubmitTime(Date linkAccountSubmitTime) {
        this.linkAccountSubmitTime = linkAccountSubmitTime;
    }
}