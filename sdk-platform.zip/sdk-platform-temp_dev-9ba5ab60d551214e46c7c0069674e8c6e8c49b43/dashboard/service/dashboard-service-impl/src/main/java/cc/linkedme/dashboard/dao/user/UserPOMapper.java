package cc.linkedme.dashboard.dao.user;

import cc.linkedme.dashboard.dao.user.UserPO;
import cc.linkedme.dashboard.dao.user.UserPOExample;
import cc.linkedme.dashboard.dao.user.UserPOWithBLOBs;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserPOMapper {
    long countByExample(UserPOExample example);

    int deleteByExample(UserPOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(UserPOWithBLOBs record);

    int insertSelective(UserPOWithBLOBs record);

    List<UserPOWithBLOBs> selectByExampleWithBLOBs(UserPOExample example);

    List<UserPO> selectByExample(UserPOExample example);

    UserPOWithBLOBs selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") UserPOWithBLOBs record, @Param("example") UserPOExample example);

    int updateByExampleWithBLOBs(@Param("record") UserPOWithBLOBs record, @Param("example") UserPOExample example);

    int updateByExample(@Param("record") UserPO record, @Param("example") UserPOExample example);

    int updateByPrimaryKeySelective(UserPOWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(UserPOWithBLOBs record);

    int updateByPrimaryKey(UserPO record);
}