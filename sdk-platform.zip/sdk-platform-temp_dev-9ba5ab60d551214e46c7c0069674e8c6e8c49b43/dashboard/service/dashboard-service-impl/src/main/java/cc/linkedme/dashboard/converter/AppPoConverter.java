package cc.linkedme.dashboard.converter;

import cc.linkedme.dashboard.dao.app.AppPO;
import cc.linkedme.dashboard.model.AppInfo;
import com.aliyun.oss.model.AppendObjectRequest;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:19 2019-09-09
 * @:Description
 */
public class AppPoConverter {

    public static AppInfo po2Bo(AppPO appPO) {

        AppInfo appInfo = new AppInfo();
        appInfo.setUid(appPO.getUserId());
        appInfo.setAppId(appPO.getId());
        appInfo.setAppName(appPO.getAppName());
        appInfo.setAppKey(appPO.getAppKey());
        appInfo.setAppSecret(appPO.getAppSecret());
        AppInfo.Android android = new AppInfo.Android();
        android.setPackageName(appPO.getAndroidPackageName());
        android.setSignMd5(appPO.getAndroidSignMd5());
        appInfo.setAndroid(android);
        AppInfo.Ios ios = new AppInfo.Ios();
        ios.setBundleId(appPO.getIosBundleId());
        appInfo.setIos(ios);

        return appInfo;

    }
}
