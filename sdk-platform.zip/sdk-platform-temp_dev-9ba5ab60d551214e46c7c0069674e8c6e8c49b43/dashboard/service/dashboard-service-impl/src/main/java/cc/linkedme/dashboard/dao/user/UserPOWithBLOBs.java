package cc.linkedme.dashboard.dao.user;

public class UserPOWithBLOBs extends UserPO {
    private String dspNote;

    private String sspNote;

    public String getDspNote() {
        return dspNote;
    }

    public void setDspNote(String dspNote) {
        this.dspNote = dspNote == null ? null : dspNote.trim();
    }

    public String getSspNote() {
        return sspNote;
    }

    public void setSspNote(String sspNote) {
        this.sspNote = sspNote == null ? null : sspNote.trim();
    }
}