package cc.linkedme.dashboard.service.impl;

import cc.linkedme.dashboard.converter.UserPoConverter;
import cc.linkedme.dashboard.dao.user.UserPOExample;
import cc.linkedme.dashboard.dao.user.UserPOMapper;
import cc.linkedme.dashboard.dao.user.UserPOWithBLOBs;
import cc.linkedme.dashboard.errorcode.UserErrorCode;
import cc.linkedme.dashboard.exception.UserException;
import cc.linkedme.dashboard.model.UserInfo;
import cc.linkedme.dashboard.service.UserInfoService;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:49 2019-09-09
 * @:Description
 */
@Service("userInfoService")
public class UserInfoServiceImpl implements UserInfoService {

    private static final Logger logger = LoggerFactory.getLogger(UserInfoServiceImpl.class);

    @Resource
    private UserPOMapper userPOMapper;

    @Override
    public UserInfo getUserInfo(Integer uid) {

        logger.info("getUserInfoByUid, uid:{}", uid);

        Preconditions.checkNotNull(uid, new UserException(UserErrorCode.ID_NULL_ERROR));

        UserPOExample userPOExample = new UserPOExample();
        UserPOExample.Criteria criteria = userPOExample.createCriteria();
        criteria.andIdEqualTo(uid);
        criteria.andValidStatusEqualTo((byte) 1);
        List<UserPOWithBLOBs> userPOWithBLOBs = userPOMapper.selectByExampleWithBLOBs(userPOExample);
        if (CollectionUtils.isEmpty(userPOWithBLOBs)) {
            throw new UserException(UserErrorCode.USER_NOT_EXIST);
        }

        UserInfo userInfo = UserPoConverter.po2Bo(userPOWithBLOBs.get(0));

        logger.info("getUserInfo, uid:{}, userInfo:{}", uid, userInfo);
        return userInfo;

    }
}
