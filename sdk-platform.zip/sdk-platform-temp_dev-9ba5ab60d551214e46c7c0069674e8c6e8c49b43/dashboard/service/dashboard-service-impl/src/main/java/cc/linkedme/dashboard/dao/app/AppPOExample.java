package cc.linkedme.dashboard.dao.app;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppPOExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public AppPOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andAppKeyIsNull() {
            addCriterion("app_key is null");
            return (Criteria) this;
        }

        public Criteria andAppKeyIsNotNull() {
            addCriterion("app_key is not null");
            return (Criteria) this;
        }

        public Criteria andAppKeyEqualTo(String value) {
            addCriterion("app_key =", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotEqualTo(String value) {
            addCriterion("app_key <>", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyGreaterThan(String value) {
            addCriterion("app_key >", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyGreaterThanOrEqualTo(String value) {
            addCriterion("app_key >=", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLessThan(String value) {
            addCriterion("app_key <", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLessThanOrEqualTo(String value) {
            addCriterion("app_key <=", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLike(String value) {
            addCriterion("app_key like", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotLike(String value) {
            addCriterion("app_key not like", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyIn(List<String> values) {
            addCriterion("app_key in", values, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotIn(List<String> values) {
            addCriterion("app_key not in", values, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyBetween(String value1, String value2) {
            addCriterion("app_key between", value1, value2, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotBetween(String value1, String value2) {
            addCriterion("app_key not between", value1, value2, "appKey");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Integer value) {
            addCriterion("user_id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Integer value) {
            addCriterion("user_id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Integer value) {
            addCriterion("user_id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("user_id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Integer value) {
            addCriterion("user_id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Integer value) {
            addCriterion("user_id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Integer> values) {
            addCriterion("user_id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Integer> values) {
            addCriterion("user_id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Integer value1, Integer value2) {
            addCriterion("user_id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Integer value1, Integer value2) {
            addCriterion("user_id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andAppNameIsNull() {
            addCriterion("app_name is null");
            return (Criteria) this;
        }

        public Criteria andAppNameIsNotNull() {
            addCriterion("app_name is not null");
            return (Criteria) this;
        }

        public Criteria andAppNameEqualTo(String value) {
            addCriterion("app_name =", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameNotEqualTo(String value) {
            addCriterion("app_name <>", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameGreaterThan(String value) {
            addCriterion("app_name >", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameGreaterThanOrEqualTo(String value) {
            addCriterion("app_name >=", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameLessThan(String value) {
            addCriterion("app_name <", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameLessThanOrEqualTo(String value) {
            addCriterion("app_name <=", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameLike(String value) {
            addCriterion("app_name like", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameNotLike(String value) {
            addCriterion("app_name not like", value, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameIn(List<String> values) {
            addCriterion("app_name in", values, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameNotIn(List<String> values) {
            addCriterion("app_name not in", values, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameBetween(String value1, String value2) {
            addCriterion("app_name between", value1, value2, "appName");
            return (Criteria) this;
        }

        public Criteria andAppNameNotBetween(String value1, String value2) {
            addCriterion("app_name not between", value1, value2, "appName");
            return (Criteria) this;
        }

        public Criteria andAppLogoIsNull() {
            addCriterion("app_logo is null");
            return (Criteria) this;
        }

        public Criteria andAppLogoIsNotNull() {
            addCriterion("app_logo is not null");
            return (Criteria) this;
        }

        public Criteria andAppLogoEqualTo(String value) {
            addCriterion("app_logo =", value, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoNotEqualTo(String value) {
            addCriterion("app_logo <>", value, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoGreaterThan(String value) {
            addCriterion("app_logo >", value, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoGreaterThanOrEqualTo(String value) {
            addCriterion("app_logo >=", value, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoLessThan(String value) {
            addCriterion("app_logo <", value, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoLessThanOrEqualTo(String value) {
            addCriterion("app_logo <=", value, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoLike(String value) {
            addCriterion("app_logo like", value, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoNotLike(String value) {
            addCriterion("app_logo not like", value, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoIn(List<String> values) {
            addCriterion("app_logo in", values, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoNotIn(List<String> values) {
            addCriterion("app_logo not in", values, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoBetween(String value1, String value2) {
            addCriterion("app_logo between", value1, value2, "appLogo");
            return (Criteria) this;
        }

        public Criteria andAppLogoNotBetween(String value1, String value2) {
            addCriterion("app_logo not between", value1, value2, "appLogo");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(String value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(String value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(String value) {
            addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(String value) {
            addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(String value) {
            addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(String value) {
            addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLike(String value) {
            addCriterion("type like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotLike(String value) {
            addCriterion("type not like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<String> values) {
            addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<String> values) {
            addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(String value1, String value2) {
            addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(String value1, String value2) {
            addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andAppSecretIsNull() {
            addCriterion("app_secret is null");
            return (Criteria) this;
        }

        public Criteria andAppSecretIsNotNull() {
            addCriterion("app_secret is not null");
            return (Criteria) this;
        }

        public Criteria andAppSecretEqualTo(String value) {
            addCriterion("app_secret =", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotEqualTo(String value) {
            addCriterion("app_secret <>", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretGreaterThan(String value) {
            addCriterion("app_secret >", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretGreaterThanOrEqualTo(String value) {
            addCriterion("app_secret >=", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLessThan(String value) {
            addCriterion("app_secret <", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLessThanOrEqualTo(String value) {
            addCriterion("app_secret <=", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLike(String value) {
            addCriterion("app_secret like", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotLike(String value) {
            addCriterion("app_secret not like", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretIn(List<String> values) {
            addCriterion("app_secret in", values, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotIn(List<String> values) {
            addCriterion("app_secret not in", values, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretBetween(String value1, String value2) {
            addCriterion("app_secret between", value1, value2, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotBetween(String value1, String value2) {
            addCriterion("app_secret not between", value1, value2, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeIsNull() {
            addCriterion("android_uri_scheme is null");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeIsNotNull() {
            addCriterion("android_uri_scheme is not null");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeEqualTo(String value) {
            addCriterion("android_uri_scheme =", value, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeNotEqualTo(String value) {
            addCriterion("android_uri_scheme <>", value, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeGreaterThan(String value) {
            addCriterion("android_uri_scheme >", value, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeGreaterThanOrEqualTo(String value) {
            addCriterion("android_uri_scheme >=", value, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeLessThan(String value) {
            addCriterion("android_uri_scheme <", value, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeLessThanOrEqualTo(String value) {
            addCriterion("android_uri_scheme <=", value, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeLike(String value) {
            addCriterion("android_uri_scheme like", value, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeNotLike(String value) {
            addCriterion("android_uri_scheme not like", value, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeIn(List<String> values) {
            addCriterion("android_uri_scheme in", values, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeNotIn(List<String> values) {
            addCriterion("android_uri_scheme not in", values, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeBetween(String value1, String value2) {
            addCriterion("android_uri_scheme between", value1, value2, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidUriSchemeNotBetween(String value1, String value2) {
            addCriterion("android_uri_scheme not between", value1, value2, "androidUriScheme");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlIsNull() {
            addCriterion("android_not_url is null");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlIsNotNull() {
            addCriterion("android_not_url is not null");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlEqualTo(String value) {
            addCriterion("android_not_url =", value, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlNotEqualTo(String value) {
            addCriterion("android_not_url <>", value, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlGreaterThan(String value) {
            addCriterion("android_not_url >", value, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlGreaterThanOrEqualTo(String value) {
            addCriterion("android_not_url >=", value, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlLessThan(String value) {
            addCriterion("android_not_url <", value, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlLessThanOrEqualTo(String value) {
            addCriterion("android_not_url <=", value, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlLike(String value) {
            addCriterion("android_not_url like", value, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlNotLike(String value) {
            addCriterion("android_not_url not like", value, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlIn(List<String> values) {
            addCriterion("android_not_url in", values, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlNotIn(List<String> values) {
            addCriterion("android_not_url not in", values, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlBetween(String value1, String value2) {
            addCriterion("android_not_url between", value1, value2, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidNotUrlNotBetween(String value1, String value2) {
            addCriterion("android_not_url not between", value1, value2, "androidNotUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlIsNull() {
            addCriterion("google_play_url is null");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlIsNotNull() {
            addCriterion("google_play_url is not null");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlEqualTo(String value) {
            addCriterion("google_play_url =", value, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlNotEqualTo(String value) {
            addCriterion("google_play_url <>", value, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlGreaterThan(String value) {
            addCriterion("google_play_url >", value, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlGreaterThanOrEqualTo(String value) {
            addCriterion("google_play_url >=", value, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlLessThan(String value) {
            addCriterion("google_play_url <", value, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlLessThanOrEqualTo(String value) {
            addCriterion("google_play_url <=", value, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlLike(String value) {
            addCriterion("google_play_url like", value, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlNotLike(String value) {
            addCriterion("google_play_url not like", value, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlIn(List<String> values) {
            addCriterion("google_play_url in", values, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlNotIn(List<String> values) {
            addCriterion("google_play_url not in", values, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlBetween(String value1, String value2) {
            addCriterion("google_play_url between", value1, value2, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andGooglePlayUrlNotBetween(String value1, String value2) {
            addCriterion("google_play_url not between", value1, value2, "googlePlayUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlIsNull() {
            addCriterion("android_custom_url is null");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlIsNotNull() {
            addCriterion("android_custom_url is not null");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlEqualTo(String value) {
            addCriterion("android_custom_url =", value, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlNotEqualTo(String value) {
            addCriterion("android_custom_url <>", value, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlGreaterThan(String value) {
            addCriterion("android_custom_url >", value, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlGreaterThanOrEqualTo(String value) {
            addCriterion("android_custom_url >=", value, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlLessThan(String value) {
            addCriterion("android_custom_url <", value, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlLessThanOrEqualTo(String value) {
            addCriterion("android_custom_url <=", value, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlLike(String value) {
            addCriterion("android_custom_url like", value, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlNotLike(String value) {
            addCriterion("android_custom_url not like", value, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlIn(List<String> values) {
            addCriterion("android_custom_url in", values, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlNotIn(List<String> values) {
            addCriterion("android_custom_url not in", values, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlBetween(String value1, String value2) {
            addCriterion("android_custom_url between", value1, value2, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidCustomUrlNotBetween(String value1, String value2) {
            addCriterion("android_custom_url not between", value1, value2, "androidCustomUrl");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionIsNull() {
            addCriterion("android_search_option is null");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionIsNotNull() {
            addCriterion("android_search_option is not null");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionEqualTo(String value) {
            addCriterion("android_search_option =", value, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionNotEqualTo(String value) {
            addCriterion("android_search_option <>", value, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionGreaterThan(String value) {
            addCriterion("android_search_option >", value, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionGreaterThanOrEqualTo(String value) {
            addCriterion("android_search_option >=", value, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionLessThan(String value) {
            addCriterion("android_search_option <", value, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionLessThanOrEqualTo(String value) {
            addCriterion("android_search_option <=", value, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionLike(String value) {
            addCriterion("android_search_option like", value, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionNotLike(String value) {
            addCriterion("android_search_option not like", value, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionIn(List<String> values) {
            addCriterion("android_search_option in", values, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionNotIn(List<String> values) {
            addCriterion("android_search_option not in", values, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionBetween(String value1, String value2) {
            addCriterion("android_search_option between", value1, value2, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidSearchOptionNotBetween(String value1, String value2) {
            addCriterion("android_search_option not between", value1, value2, "androidSearchOption");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameIsNull() {
            addCriterion("android_package_name is null");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameIsNotNull() {
            addCriterion("android_package_name is not null");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameEqualTo(String value) {
            addCriterion("android_package_name =", value, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameNotEqualTo(String value) {
            addCriterion("android_package_name <>", value, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameGreaterThan(String value) {
            addCriterion("android_package_name >", value, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameGreaterThanOrEqualTo(String value) {
            addCriterion("android_package_name >=", value, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameLessThan(String value) {
            addCriterion("android_package_name <", value, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameLessThanOrEqualTo(String value) {
            addCriterion("android_package_name <=", value, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameLike(String value) {
            addCriterion("android_package_name like", value, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameNotLike(String value) {
            addCriterion("android_package_name not like", value, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameIn(List<String> values) {
            addCriterion("android_package_name in", values, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameNotIn(List<String> values) {
            addCriterion("android_package_name not in", values, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameBetween(String value1, String value2) {
            addCriterion("android_package_name between", value1, value2, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidPackageNameNotBetween(String value1, String value2) {
            addCriterion("android_package_name not between", value1, value2, "androidPackageName");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsIsNull() {
            addCriterion("android_sha256_fingerprints is null");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsIsNotNull() {
            addCriterion("android_sha256_fingerprints is not null");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsEqualTo(String value) {
            addCriterion("android_sha256_fingerprints =", value, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsNotEqualTo(String value) {
            addCriterion("android_sha256_fingerprints <>", value, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsGreaterThan(String value) {
            addCriterion("android_sha256_fingerprints >", value, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsGreaterThanOrEqualTo(String value) {
            addCriterion("android_sha256_fingerprints >=", value, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsLessThan(String value) {
            addCriterion("android_sha256_fingerprints <", value, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsLessThanOrEqualTo(String value) {
            addCriterion("android_sha256_fingerprints <=", value, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsLike(String value) {
            addCriterion("android_sha256_fingerprints like", value, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsNotLike(String value) {
            addCriterion("android_sha256_fingerprints not like", value, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsIn(List<String> values) {
            addCriterion("android_sha256_fingerprints in", values, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsNotIn(List<String> values) {
            addCriterion("android_sha256_fingerprints not in", values, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsBetween(String value1, String value2) {
            addCriterion("android_sha256_fingerprints between", value1, value2, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andAndroidSha256FingerprintsNotBetween(String value1, String value2) {
            addCriterion("android_sha256_fingerprints not between", value1, value2, "androidSha256Fingerprints");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeIsNull() {
            addCriterion("ios_uri_scheme is null");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeIsNotNull() {
            addCriterion("ios_uri_scheme is not null");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeEqualTo(String value) {
            addCriterion("ios_uri_scheme =", value, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeNotEqualTo(String value) {
            addCriterion("ios_uri_scheme <>", value, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeGreaterThan(String value) {
            addCriterion("ios_uri_scheme >", value, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeGreaterThanOrEqualTo(String value) {
            addCriterion("ios_uri_scheme >=", value, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeLessThan(String value) {
            addCriterion("ios_uri_scheme <", value, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeLessThanOrEqualTo(String value) {
            addCriterion("ios_uri_scheme <=", value, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeLike(String value) {
            addCriterion("ios_uri_scheme like", value, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeNotLike(String value) {
            addCriterion("ios_uri_scheme not like", value, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeIn(List<String> values) {
            addCriterion("ios_uri_scheme in", values, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeNotIn(List<String> values) {
            addCriterion("ios_uri_scheme not in", values, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeBetween(String value1, String value2) {
            addCriterion("ios_uri_scheme between", value1, value2, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosUriSchemeNotBetween(String value1, String value2) {
            addCriterion("ios_uri_scheme not between", value1, value2, "iosUriScheme");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlIsNull() {
            addCriterion("ios_not_url is null");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlIsNotNull() {
            addCriterion("ios_not_url is not null");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlEqualTo(String value) {
            addCriterion("ios_not_url =", value, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlNotEqualTo(String value) {
            addCriterion("ios_not_url <>", value, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlGreaterThan(String value) {
            addCriterion("ios_not_url >", value, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlGreaterThanOrEqualTo(String value) {
            addCriterion("ios_not_url >=", value, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlLessThan(String value) {
            addCriterion("ios_not_url <", value, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlLessThanOrEqualTo(String value) {
            addCriterion("ios_not_url <=", value, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlLike(String value) {
            addCriterion("ios_not_url like", value, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlNotLike(String value) {
            addCriterion("ios_not_url not like", value, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlIn(List<String> values) {
            addCriterion("ios_not_url in", values, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlNotIn(List<String> values) {
            addCriterion("ios_not_url not in", values, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlBetween(String value1, String value2) {
            addCriterion("ios_not_url between", value1, value2, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosNotUrlNotBetween(String value1, String value2) {
            addCriterion("ios_not_url not between", value1, value2, "iosNotUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlIsNull() {
            addCriterion("ios_store_url is null");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlIsNotNull() {
            addCriterion("ios_store_url is not null");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlEqualTo(String value) {
            addCriterion("ios_store_url =", value, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlNotEqualTo(String value) {
            addCriterion("ios_store_url <>", value, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlGreaterThan(String value) {
            addCriterion("ios_store_url >", value, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlGreaterThanOrEqualTo(String value) {
            addCriterion("ios_store_url >=", value, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlLessThan(String value) {
            addCriterion("ios_store_url <", value, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlLessThanOrEqualTo(String value) {
            addCriterion("ios_store_url <=", value, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlLike(String value) {
            addCriterion("ios_store_url like", value, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlNotLike(String value) {
            addCriterion("ios_store_url not like", value, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlIn(List<String> values) {
            addCriterion("ios_store_url in", values, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlNotIn(List<String> values) {
            addCriterion("ios_store_url not in", values, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlBetween(String value1, String value2) {
            addCriterion("ios_store_url between", value1, value2, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosStoreUrlNotBetween(String value1, String value2) {
            addCriterion("ios_store_url not between", value1, value2, "iosStoreUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlIsNull() {
            addCriterion("ios_custom_url is null");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlIsNotNull() {
            addCriterion("ios_custom_url is not null");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlEqualTo(String value) {
            addCriterion("ios_custom_url =", value, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlNotEqualTo(String value) {
            addCriterion("ios_custom_url <>", value, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlGreaterThan(String value) {
            addCriterion("ios_custom_url >", value, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlGreaterThanOrEqualTo(String value) {
            addCriterion("ios_custom_url >=", value, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlLessThan(String value) {
            addCriterion("ios_custom_url <", value, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlLessThanOrEqualTo(String value) {
            addCriterion("ios_custom_url <=", value, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlLike(String value) {
            addCriterion("ios_custom_url like", value, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlNotLike(String value) {
            addCriterion("ios_custom_url not like", value, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlIn(List<String> values) {
            addCriterion("ios_custom_url in", values, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlNotIn(List<String> values) {
            addCriterion("ios_custom_url not in", values, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlBetween(String value1, String value2) {
            addCriterion("ios_custom_url between", value1, value2, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosCustomUrlNotBetween(String value1, String value2) {
            addCriterion("ios_custom_url not between", value1, value2, "iosCustomUrl");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixIsNull() {
            addCriterion("ios_app_prefix is null");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixIsNotNull() {
            addCriterion("ios_app_prefix is not null");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixEqualTo(String value) {
            addCriterion("ios_app_prefix =", value, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixNotEqualTo(String value) {
            addCriterion("ios_app_prefix <>", value, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixGreaterThan(String value) {
            addCriterion("ios_app_prefix >", value, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixGreaterThanOrEqualTo(String value) {
            addCriterion("ios_app_prefix >=", value, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixLessThan(String value) {
            addCriterion("ios_app_prefix <", value, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixLessThanOrEqualTo(String value) {
            addCriterion("ios_app_prefix <=", value, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixLike(String value) {
            addCriterion("ios_app_prefix like", value, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixNotLike(String value) {
            addCriterion("ios_app_prefix not like", value, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixIn(List<String> values) {
            addCriterion("ios_app_prefix in", values, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixNotIn(List<String> values) {
            addCriterion("ios_app_prefix not in", values, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixBetween(String value1, String value2) {
            addCriterion("ios_app_prefix between", value1, value2, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosAppPrefixNotBetween(String value1, String value2) {
            addCriterion("ios_app_prefix not between", value1, value2, "iosAppPrefix");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionIsNull() {
            addCriterion("ios_search_option is null");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionIsNotNull() {
            addCriterion("ios_search_option is not null");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionEqualTo(String value) {
            addCriterion("ios_search_option =", value, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionNotEqualTo(String value) {
            addCriterion("ios_search_option <>", value, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionGreaterThan(String value) {
            addCriterion("ios_search_option >", value, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionGreaterThanOrEqualTo(String value) {
            addCriterion("ios_search_option >=", value, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionLessThan(String value) {
            addCriterion("ios_search_option <", value, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionLessThanOrEqualTo(String value) {
            addCriterion("ios_search_option <=", value, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionLike(String value) {
            addCriterion("ios_search_option like", value, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionNotLike(String value) {
            addCriterion("ios_search_option not like", value, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionIn(List<String> values) {
            addCriterion("ios_search_option in", values, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionNotIn(List<String> values) {
            addCriterion("ios_search_option not in", values, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionBetween(String value1, String value2) {
            addCriterion("ios_search_option between", value1, value2, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosSearchOptionNotBetween(String value1, String value2) {
            addCriterion("ios_search_option not between", value1, value2, "iosSearchOption");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdIsNull() {
            addCriterion("ios_bundle_id is null");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdIsNotNull() {
            addCriterion("ios_bundle_id is not null");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdEqualTo(String value) {
            addCriterion("ios_bundle_id =", value, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdNotEqualTo(String value) {
            addCriterion("ios_bundle_id <>", value, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdGreaterThan(String value) {
            addCriterion("ios_bundle_id >", value, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdGreaterThanOrEqualTo(String value) {
            addCriterion("ios_bundle_id >=", value, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdLessThan(String value) {
            addCriterion("ios_bundle_id <", value, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdLessThanOrEqualTo(String value) {
            addCriterion("ios_bundle_id <=", value, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdLike(String value) {
            addCriterion("ios_bundle_id like", value, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdNotLike(String value) {
            addCriterion("ios_bundle_id not like", value, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdIn(List<String> values) {
            addCriterion("ios_bundle_id in", values, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdNotIn(List<String> values) {
            addCriterion("ios_bundle_id not in", values, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdBetween(String value1, String value2) {
            addCriterion("ios_bundle_id between", value1, value2, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosBundleIdNotBetween(String value1, String value2) {
            addCriterion("ios_bundle_id not between", value1, value2, "iosBundleId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdIsNull() {
            addCriterion("ios_team_id is null");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdIsNotNull() {
            addCriterion("ios_team_id is not null");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdEqualTo(String value) {
            addCriterion("ios_team_id =", value, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdNotEqualTo(String value) {
            addCriterion("ios_team_id <>", value, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdGreaterThan(String value) {
            addCriterion("ios_team_id >", value, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdGreaterThanOrEqualTo(String value) {
            addCriterion("ios_team_id >=", value, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdLessThan(String value) {
            addCriterion("ios_team_id <", value, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdLessThanOrEqualTo(String value) {
            addCriterion("ios_team_id <=", value, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdLike(String value) {
            addCriterion("ios_team_id like", value, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdNotLike(String value) {
            addCriterion("ios_team_id not like", value, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdIn(List<String> values) {
            addCriterion("ios_team_id in", values, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdNotIn(List<String> values) {
            addCriterion("ios_team_id not in", values, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdBetween(String value1, String value2) {
            addCriterion("ios_team_id between", value1, value2, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosTeamIdNotBetween(String value1, String value2) {
            addCriterion("ios_team_id not between", value1, value2, "iosTeamId");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagIsNull() {
            addCriterion("ios_android_flag is null");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagIsNotNull() {
            addCriterion("ios_android_flag is not null");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagEqualTo(Integer value) {
            addCriterion("ios_android_flag =", value, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagNotEqualTo(Integer value) {
            addCriterion("ios_android_flag <>", value, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagGreaterThan(Integer value) {
            addCriterion("ios_android_flag >", value, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagGreaterThanOrEqualTo(Integer value) {
            addCriterion("ios_android_flag >=", value, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagLessThan(Integer value) {
            addCriterion("ios_android_flag <", value, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagLessThanOrEqualTo(Integer value) {
            addCriterion("ios_android_flag <=", value, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagIn(List<Integer> values) {
            addCriterion("ios_android_flag in", values, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagNotIn(List<Integer> values) {
            addCriterion("ios_android_flag not in", values, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagBetween(Integer value1, Integer value2) {
            addCriterion("ios_android_flag between", value1, value2, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andIosAndroidFlagNotBetween(Integer value1, Integer value2) {
            addCriterion("ios_android_flag not between", value1, value2, "iosAndroidFlag");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageIsNull() {
            addCriterion("use_default_landing_page is null");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageIsNotNull() {
            addCriterion("use_default_landing_page is not null");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageEqualTo(Byte value) {
            addCriterion("use_default_landing_page =", value, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageNotEqualTo(Byte value) {
            addCriterion("use_default_landing_page <>", value, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageGreaterThan(Byte value) {
            addCriterion("use_default_landing_page >", value, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageGreaterThanOrEqualTo(Byte value) {
            addCriterion("use_default_landing_page >=", value, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageLessThan(Byte value) {
            addCriterion("use_default_landing_page <", value, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageLessThanOrEqualTo(Byte value) {
            addCriterion("use_default_landing_page <=", value, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageIn(List<Byte> values) {
            addCriterion("use_default_landing_page in", values, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageNotIn(List<Byte> values) {
            addCriterion("use_default_landing_page not in", values, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageBetween(Byte value1, Byte value2) {
            addCriterion("use_default_landing_page between", value1, value2, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andUseDefaultLandingPageNotBetween(Byte value1, Byte value2) {
            addCriterion("use_default_landing_page not between", value1, value2, "useDefaultLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageIsNull() {
            addCriterion("custom_landing_page is null");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageIsNotNull() {
            addCriterion("custom_landing_page is not null");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageEqualTo(String value) {
            addCriterion("custom_landing_page =", value, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageNotEqualTo(String value) {
            addCriterion("custom_landing_page <>", value, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageGreaterThan(String value) {
            addCriterion("custom_landing_page >", value, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageGreaterThanOrEqualTo(String value) {
            addCriterion("custom_landing_page >=", value, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageLessThan(String value) {
            addCriterion("custom_landing_page <", value, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageLessThanOrEqualTo(String value) {
            addCriterion("custom_landing_page <=", value, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageLike(String value) {
            addCriterion("custom_landing_page like", value, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageNotLike(String value) {
            addCriterion("custom_landing_page not like", value, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageIn(List<String> values) {
            addCriterion("custom_landing_page in", values, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageNotIn(List<String> values) {
            addCriterion("custom_landing_page not in", values, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageBetween(String value1, String value2) {
            addCriterion("custom_landing_page between", value1, value2, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomLandingPageNotBetween(String value1, String value2) {
            addCriterion("custom_landing_page not between", value1, value2, "customLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageIsNull() {
            addCriterion("custom_mobile_landing_page is null");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageIsNotNull() {
            addCriterion("custom_mobile_landing_page is not null");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageEqualTo(String value) {
            addCriterion("custom_mobile_landing_page =", value, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageNotEqualTo(String value) {
            addCriterion("custom_mobile_landing_page <>", value, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageGreaterThan(String value) {
            addCriterion("custom_mobile_landing_page >", value, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageGreaterThanOrEqualTo(String value) {
            addCriterion("custom_mobile_landing_page >=", value, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageLessThan(String value) {
            addCriterion("custom_mobile_landing_page <", value, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageLessThanOrEqualTo(String value) {
            addCriterion("custom_mobile_landing_page <=", value, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageLike(String value) {
            addCriterion("custom_mobile_landing_page like", value, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageNotLike(String value) {
            addCriterion("custom_mobile_landing_page not like", value, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageIn(List<String> values) {
            addCriterion("custom_mobile_landing_page in", values, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageNotIn(List<String> values) {
            addCriterion("custom_mobile_landing_page not in", values, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageBetween(String value1, String value2) {
            addCriterion("custom_mobile_landing_page between", value1, value2, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andCustomMobileLandingPageNotBetween(String value1, String value2) {
            addCriterion("custom_mobile_landing_page not between", value1, value2, "customMobileLandingPage");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeIsNull() {
            addCriterion("deferred_deeplink_time is null");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeIsNotNull() {
            addCriterion("deferred_deeplink_time is not null");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeEqualTo(Long value) {
            addCriterion("deferred_deeplink_time =", value, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeNotEqualTo(Long value) {
            addCriterion("deferred_deeplink_time <>", value, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeGreaterThan(Long value) {
            addCriterion("deferred_deeplink_time >", value, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeGreaterThanOrEqualTo(Long value) {
            addCriterion("deferred_deeplink_time >=", value, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeLessThan(Long value) {
            addCriterion("deferred_deeplink_time <", value, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeLessThanOrEqualTo(Long value) {
            addCriterion("deferred_deeplink_time <=", value, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeIn(List<Long> values) {
            addCriterion("deferred_deeplink_time in", values, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeNotIn(List<Long> values) {
            addCriterion("deferred_deeplink_time not in", values, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeBetween(Long value1, Long value2) {
            addCriterion("deferred_deeplink_time between", value1, value2, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andDeferredDeeplinkTimeNotBetween(Long value1, Long value2) {
            addCriterion("deferred_deeplink_time not between", value1, value2, "deferredDeeplinkTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIsNull() {
            addCriterion("register_time is null");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIsNotNull() {
            addCriterion("register_time is not null");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeEqualTo(Date value) {
            addCriterion("register_time =", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotEqualTo(Date value) {
            addCriterion("register_time <>", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeGreaterThan(Date value) {
            addCriterion("register_time >", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("register_time >=", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeLessThan(Date value) {
            addCriterion("register_time <", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeLessThanOrEqualTo(Date value) {
            addCriterion("register_time <=", value, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeIn(List<Date> values) {
            addCriterion("register_time in", values, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotIn(List<Date> values) {
            addCriterion("register_time not in", values, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeBetween(Date value1, Date value2) {
            addCriterion("register_time between", value1, value2, "registerTime");
            return (Criteria) this;
        }

        public Criteria andRegisterTimeNotBetween(Date value1, Date value2) {
            addCriterion("register_time not between", value1, value2, "registerTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeIsNull() {
            addCriterion("last_update_time is null");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeIsNotNull() {
            addCriterion("last_update_time is not null");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeEqualTo(Date value) {
            addCriterion("last_update_time =", value, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeNotEqualTo(Date value) {
            addCriterion("last_update_time <>", value, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeGreaterThan(Date value) {
            addCriterion("last_update_time >", value, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("last_update_time >=", value, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeLessThan(Date value) {
            addCriterion("last_update_time <", value, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("last_update_time <=", value, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeIn(List<Date> values) {
            addCriterion("last_update_time in", values, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeNotIn(List<Date> values) {
            addCriterion("last_update_time not in", values, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("last_update_time between", value1, value2, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andLastUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("last_update_time not between", value1, value2, "lastUpdateTime");
            return (Criteria) this;
        }

        public Criteria andValidStatusIsNull() {
            addCriterion("valid_status is null");
            return (Criteria) this;
        }

        public Criteria andValidStatusIsNotNull() {
            addCriterion("valid_status is not null");
            return (Criteria) this;
        }

        public Criteria andValidStatusEqualTo(Byte value) {
            addCriterion("valid_status =", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusNotEqualTo(Byte value) {
            addCriterion("valid_status <>", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusGreaterThan(Byte value) {
            addCriterion("valid_status >", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusGreaterThanOrEqualTo(Byte value) {
            addCriterion("valid_status >=", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusLessThan(Byte value) {
            addCriterion("valid_status <", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusLessThanOrEqualTo(Byte value) {
            addCriterion("valid_status <=", value, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusIn(List<Byte> values) {
            addCriterion("valid_status in", values, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusNotIn(List<Byte> values) {
            addCriterion("valid_status not in", values, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusBetween(Byte value1, Byte value2) {
            addCriterion("valid_status between", value1, value2, "validStatus");
            return (Criteria) this;
        }

        public Criteria andValidStatusNotBetween(Byte value1, Byte value2) {
            addCriterion("valid_status not between", value1, value2, "validStatus");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkIsNull() {
            addCriterion("android_yyb_applink is null");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkIsNotNull() {
            addCriterion("android_yyb_applink is not null");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkEqualTo(Byte value) {
            addCriterion("android_yyb_applink =", value, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkNotEqualTo(Byte value) {
            addCriterion("android_yyb_applink <>", value, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkGreaterThan(Byte value) {
            addCriterion("android_yyb_applink >", value, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkGreaterThanOrEqualTo(Byte value) {
            addCriterion("android_yyb_applink >=", value, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkLessThan(Byte value) {
            addCriterion("android_yyb_applink <", value, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkLessThanOrEqualTo(Byte value) {
            addCriterion("android_yyb_applink <=", value, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkIn(List<Byte> values) {
            addCriterion("android_yyb_applink in", values, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkNotIn(List<Byte> values) {
            addCriterion("android_yyb_applink not in", values, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkBetween(Byte value1, Byte value2) {
            addCriterion("android_yyb_applink between", value1, value2, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidYybApplinkNotBetween(Byte value1, Byte value2) {
            addCriterion("android_yyb_applink not between", value1, value2, "androidYybApplink");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5IsNull() {
            addCriterion("android_sign_md5 is null");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5IsNotNull() {
            addCriterion("android_sign_md5 is not null");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5EqualTo(String value) {
            addCriterion("android_sign_md5 =", value, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5NotEqualTo(String value) {
            addCriterion("android_sign_md5 <>", value, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5GreaterThan(String value) {
            addCriterion("android_sign_md5 >", value, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5GreaterThanOrEqualTo(String value) {
            addCriterion("android_sign_md5 >=", value, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5LessThan(String value) {
            addCriterion("android_sign_md5 <", value, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5LessThanOrEqualTo(String value) {
            addCriterion("android_sign_md5 <=", value, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5Like(String value) {
            addCriterion("android_sign_md5 like", value, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5NotLike(String value) {
            addCriterion("android_sign_md5 not like", value, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5In(List<String> values) {
            addCriterion("android_sign_md5 in", values, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5NotIn(List<String> values) {
            addCriterion("android_sign_md5 not in", values, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5Between(String value1, String value2) {
            addCriterion("android_sign_md5 between", value1, value2, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andAndroidSignMd5NotBetween(String value1, String value2) {
            addCriterion("android_sign_md5 not between", value1, value2, "androidSignMd5");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateIsNull() {
            addCriterion("link_account_audit_state is null");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateIsNotNull() {
            addCriterion("link_account_audit_state is not null");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateEqualTo(Byte value) {
            addCriterion("link_account_audit_state =", value, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateNotEqualTo(Byte value) {
            addCriterion("link_account_audit_state <>", value, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateGreaterThan(Byte value) {
            addCriterion("link_account_audit_state >", value, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateGreaterThanOrEqualTo(Byte value) {
            addCriterion("link_account_audit_state >=", value, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateLessThan(Byte value) {
            addCriterion("link_account_audit_state <", value, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateLessThanOrEqualTo(Byte value) {
            addCriterion("link_account_audit_state <=", value, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateIn(List<Byte> values) {
            addCriterion("link_account_audit_state in", values, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateNotIn(List<Byte> values) {
            addCriterion("link_account_audit_state not in", values, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateBetween(Byte value1, Byte value2) {
            addCriterion("link_account_audit_state between", value1, value2, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountAuditStateNotBetween(Byte value1, Byte value2) {
            addCriterion("link_account_audit_state not between", value1, value2, "linkAccountAuditState");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeIsNull() {
            addCriterion("link_account_submit_time is null");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeIsNotNull() {
            addCriterion("link_account_submit_time is not null");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeEqualTo(Date value) {
            addCriterion("link_account_submit_time =", value, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeNotEqualTo(Date value) {
            addCriterion("link_account_submit_time <>", value, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeGreaterThan(Date value) {
            addCriterion("link_account_submit_time >", value, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("link_account_submit_time >=", value, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeLessThan(Date value) {
            addCriterion("link_account_submit_time <", value, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeLessThanOrEqualTo(Date value) {
            addCriterion("link_account_submit_time <=", value, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeIn(List<Date> values) {
            addCriterion("link_account_submit_time in", values, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeNotIn(List<Date> values) {
            addCriterion("link_account_submit_time not in", values, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeBetween(Date value1, Date value2) {
            addCriterion("link_account_submit_time between", value1, value2, "linkAccountSubmitTime");
            return (Criteria) this;
        }

        public Criteria andLinkAccountSubmitTimeNotBetween(Date value1, Date value2) {
            addCriterion("link_account_submit_time not between", value1, value2, "linkAccountSubmitTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}