package cc.linkedme.dashboard.dao.user;

import java.util.Date;

public class UserPO {
    private Integer id;

    private String email;

    private String pwd;

    private String name;

    private String phoneNumber;

    private String qqNumber;

    private String company;

    private Byte roleId;

    private Date registerTime;

    private Date lastLoginTime;

    private Byte validStatus;

    private String token;

    private String randomCode;

    private Integer pid;

    private String note;

    private Byte activeStatus;

    private Date activeTime;

    private Integer linkActiveAuth;

    private Integer dspAuth;

    private Integer sspAuth;

    private Byte identity;

    private Byte auditState;

    private String authenticationName;

    private String authenticationEmail;

    private String authenticationPhone;

    private String identityCardNumber;

    private String identityCardFront;

    private String identityCardBack;

    private String identityCardHand;

    private String unifiedBusinessCode;

    private String companyLicense;

    private Date authInitialTime;

    private Date authSubmitTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd == null ? null : pwd.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber == null ? null : phoneNumber.trim();
    }

    public String getQqNumber() {
        return qqNumber;
    }

    public void setQqNumber(String qqNumber) {
        this.qqNumber = qqNumber == null ? null : qqNumber.trim();
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company == null ? null : company.trim();
    }

    public Byte getRoleId() {
        return roleId;
    }

    public void setRoleId(Byte roleId) {
        this.roleId = roleId;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public Date getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(Date lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public Byte getValidStatus() {
        return validStatus;
    }

    public void setValidStatus(Byte validStatus) {
        this.validStatus = validStatus;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token == null ? null : token.trim();
    }

    public String getRandomCode() {
        return randomCode;
    }

    public void setRandomCode(String randomCode) {
        this.randomCode = randomCode == null ? null : randomCode.trim();
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public Byte getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(Byte activeStatus) {
        this.activeStatus = activeStatus;
    }

    public Date getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(Date activeTime) {
        this.activeTime = activeTime;
    }

    public Integer getLinkActiveAuth() {
        return linkActiveAuth;
    }

    public void setLinkActiveAuth(Integer linkActiveAuth) {
        this.linkActiveAuth = linkActiveAuth;
    }

    public Integer getDspAuth() {
        return dspAuth;
    }

    public void setDspAuth(Integer dspAuth) {
        this.dspAuth = dspAuth;
    }

    public Integer getSspAuth() {
        return sspAuth;
    }

    public void setSspAuth(Integer sspAuth) {
        this.sspAuth = sspAuth;
    }

    public Byte getIdentity() {
        return identity;
    }

    public void setIdentity(Byte identity) {
        this.identity = identity;
    }

    public Byte getAuditState() {
        return auditState;
    }

    public void setAuditState(Byte auditState) {
        this.auditState = auditState;
    }

    public String getAuthenticationName() {
        return authenticationName;
    }

    public void setAuthenticationName(String authenticationName) {
        this.authenticationName = authenticationName == null ? null : authenticationName.trim();
    }

    public String getAuthenticationEmail() {
        return authenticationEmail;
    }

    public void setAuthenticationEmail(String authenticationEmail) {
        this.authenticationEmail = authenticationEmail == null ? null : authenticationEmail.trim();
    }

    public String getAuthenticationPhone() {
        return authenticationPhone;
    }

    public void setAuthenticationPhone(String authenticationPhone) {
        this.authenticationPhone = authenticationPhone == null ? null : authenticationPhone.trim();
    }

    public String getIdentityCardNumber() {
        return identityCardNumber;
    }

    public void setIdentityCardNumber(String identityCardNumber) {
        this.identityCardNumber = identityCardNumber == null ? null : identityCardNumber.trim();
    }

    public String getIdentityCardFront() {
        return identityCardFront;
    }

    public void setIdentityCardFront(String identityCardFront) {
        this.identityCardFront = identityCardFront == null ? null : identityCardFront.trim();
    }

    public String getIdentityCardBack() {
        return identityCardBack;
    }

    public void setIdentityCardBack(String identityCardBack) {
        this.identityCardBack = identityCardBack == null ? null : identityCardBack.trim();
    }

    public String getIdentityCardHand() {
        return identityCardHand;
    }

    public void setIdentityCardHand(String identityCardHand) {
        this.identityCardHand = identityCardHand == null ? null : identityCardHand.trim();
    }

    public String getUnifiedBusinessCode() {
        return unifiedBusinessCode;
    }

    public void setUnifiedBusinessCode(String unifiedBusinessCode) {
        this.unifiedBusinessCode = unifiedBusinessCode == null ? null : unifiedBusinessCode.trim();
    }

    public String getCompanyLicense() {
        return companyLicense;
    }

    public void setCompanyLicense(String companyLicense) {
        this.companyLicense = companyLicense == null ? null : companyLicense.trim();
    }

    public Date getAuthInitialTime() {
        return authInitialTime;
    }

    public void setAuthInitialTime(Date authInitialTime) {
        this.authInitialTime = authInitialTime;
    }

    public Date getAuthSubmitTime() {
        return authSubmitTime;
    }

    public void setAuthSubmitTime(Date authSubmitTime) {
        this.authSubmitTime = authSubmitTime;
    }
}