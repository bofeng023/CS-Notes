package cc.linkedme.dashboard.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

/**
 * @Author: liuyunmeng
 * @Date: Create in 21:06 2019-09-18
 * @:Description
 */
public interface UserErrorCode extends BaseErrorCode {

    ErrorCode USER_NOT_EXIST = new ErrorCode(50001, "用户不存在");

}
