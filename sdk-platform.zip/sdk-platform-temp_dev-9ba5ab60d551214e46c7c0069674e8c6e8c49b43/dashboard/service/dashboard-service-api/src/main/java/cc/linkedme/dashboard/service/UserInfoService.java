package cc.linkedme.dashboard.service;

import cc.linkedme.dashboard.model.UserInfo;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:48 2019-09-09
 * @:Description
 */
public interface UserInfoService {

    UserInfo getUserInfo(Integer uid);

}
