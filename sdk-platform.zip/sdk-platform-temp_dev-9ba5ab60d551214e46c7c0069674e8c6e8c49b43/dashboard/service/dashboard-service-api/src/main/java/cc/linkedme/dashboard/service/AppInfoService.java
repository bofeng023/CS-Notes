package cc.linkedme.dashboard.service;

import cc.linkedme.dashboard.exception.AppException;
import cc.linkedme.dashboard.model.AppInfo;

/**
 * @Author: liuyunmeng
 * @Date: Create in 16:51 2019-09-06
 * @:Description
 */
public interface AppInfoService {


    /**
     * 通过appKey 获取appinfo 信息
     * @param appKey
     * @return
     */
    AppInfo getAppInfo(String appKey) throws AppException;


}
