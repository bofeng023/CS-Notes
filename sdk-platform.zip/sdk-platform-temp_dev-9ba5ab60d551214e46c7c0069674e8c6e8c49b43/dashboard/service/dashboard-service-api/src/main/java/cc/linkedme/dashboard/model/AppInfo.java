package cc.linkedme.dashboard.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * @Author: liuyunmeng
 * @Date: Create in 16:52 2019-09-06
 * @:Description
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppInfo {

    private Integer appId;
    private Integer uid;
    private Integer pid;
    private String appKey;
    private String appName;
    private String appSecret;
    private Android android;
    private Ios ios;
    @Data
    public static class Android {

        private String packageName;

        private String signMd5;

    }

    @Data
    public static class Ios {

        private String bundleId;
    }

}
