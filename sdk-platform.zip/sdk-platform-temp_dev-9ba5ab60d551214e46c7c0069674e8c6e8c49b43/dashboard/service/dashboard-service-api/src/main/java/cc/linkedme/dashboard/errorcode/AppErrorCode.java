package cc.linkedme.dashboard.errorcode;


import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:14 2019-09-10
 * @:Description
 */
public interface AppErrorCode extends BaseErrorCode {

    ErrorCode APP_NOT_EXIST = new ErrorCode(30001, "app 不存在");
}
