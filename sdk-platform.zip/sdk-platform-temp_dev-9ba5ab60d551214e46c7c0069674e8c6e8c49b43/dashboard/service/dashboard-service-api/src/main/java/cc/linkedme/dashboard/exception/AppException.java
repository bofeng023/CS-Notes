package cc.linkedme.dashboard.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:13 2019-09-10
 * @:Description
 */
public class AppException extends BusinessException {

    public AppException(ErrorCode errorCode) {
        super(errorCode);
    }
}
