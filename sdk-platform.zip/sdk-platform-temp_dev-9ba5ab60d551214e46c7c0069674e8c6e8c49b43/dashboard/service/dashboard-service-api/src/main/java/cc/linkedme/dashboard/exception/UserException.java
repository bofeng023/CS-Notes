package cc.linkedme.dashboard.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @Author: liuyunmeng
 * @Date: Create in 21:05 2019-09-18
 * @:Description
 */
public class UserException extends BusinessException {

    public UserException(ErrorCode errorCode) {
        super(errorCode);
    }
}
