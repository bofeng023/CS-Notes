package cc.linkedme.content.dao.statistics;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ContentStatisticsPOMapper {
    long countByExample(ContentStatisticsPOExample example);

    int deleteByExample(ContentStatisticsPOExample example);

    int deleteByPrimaryKey(ContentStatisticsPOKey key);

    int insert(ContentStatisticsPO record);

    int insertSelective(ContentStatisticsPO record);

    List<ContentStatisticsPO> selectByExample(ContentStatisticsPOExample example);

    ContentStatisticsPO selectByPrimaryKey(ContentStatisticsPOKey key);

    int updateByExampleSelective(@Param("record") ContentStatisticsPO record, @Param("example") ContentStatisticsPOExample example);

    int updateByExample(@Param("record") ContentStatisticsPO record, @Param("example") ContentStatisticsPOExample example);

    int updateByPrimaryKeySelective(ContentStatisticsPO record);

    int updateByPrimaryKey(ContentStatisticsPO record);

    List<ContentStatisticsPO> selectByExampleWithLimit(@Param("example") ContentStatisticsPOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);
}