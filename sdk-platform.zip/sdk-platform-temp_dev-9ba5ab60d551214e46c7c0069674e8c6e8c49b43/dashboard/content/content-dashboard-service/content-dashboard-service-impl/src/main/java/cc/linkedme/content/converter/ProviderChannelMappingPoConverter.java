package cc.linkedme.content.converter;

import cc.linkedme.content.dao.channel.ProviderChannelMappingPO;
import cc.linkedme.content.model.ProviderChannelMappingInfo;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 15:49 2019-09-08
 * @:Description
 */
public class ProviderChannelMappingPoConverter {

    public static ProviderChannelMappingInfo po2Bo(ProviderChannelMappingPO providerChannelMappingPO) {

        ProviderChannelMappingInfo providerChannelMappingInfo = new ProviderChannelMappingInfo();
        BeanUtils.copyProperties(providerChannelMappingPO, providerChannelMappingInfo);

        return providerChannelMappingInfo;
    }
}
