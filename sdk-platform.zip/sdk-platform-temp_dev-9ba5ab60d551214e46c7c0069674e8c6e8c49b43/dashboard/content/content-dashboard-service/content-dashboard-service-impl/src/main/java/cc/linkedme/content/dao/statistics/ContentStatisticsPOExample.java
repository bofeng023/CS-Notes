package cc.linkedme.content.dao.statistics;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class ContentStatisticsPOExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ContentStatisticsPOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andAppIdIsNull() {
            addCriterion("app_id is null");
            return (Criteria) this;
        }

        public Criteria andAppIdIsNotNull() {
            addCriterion("app_id is not null");
            return (Criteria) this;
        }

        public Criteria andAppIdEqualTo(Integer value) {
            addCriterion("app_id =", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdNotEqualTo(Integer value) {
            addCriterion("app_id <>", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdGreaterThan(Integer value) {
            addCriterion("app_id >", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("app_id >=", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdLessThan(Integer value) {
            addCriterion("app_id <", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdLessThanOrEqualTo(Integer value) {
            addCriterion("app_id <=", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdIn(List<Integer> values) {
            addCriterion("app_id in", values, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdNotIn(List<Integer> values) {
            addCriterion("app_id not in", values, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdBetween(Integer value1, Integer value2) {
            addCriterion("app_id between", value1, value2, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdNotBetween(Integer value1, Integer value2) {
            addCriterion("app_id not between", value1, value2, "appId");
            return (Criteria) this;
        }

        public Criteria andDateIsNull() {
            addCriterion("date is null");
            return (Criteria) this;
        }

        public Criteria andDateIsNotNull() {
            addCriterion("date is not null");
            return (Criteria) this;
        }

        public Criteria andDateEqualTo(Date value) {
            addCriterionForJDBCDate("date =", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateNotEqualTo(Date value) {
            addCriterionForJDBCDate("date <>", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateGreaterThan(Date value) {
            addCriterionForJDBCDate("date >", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("date >=", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateLessThan(Date value) {
            addCriterionForJDBCDate("date <", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("date <=", value, "date");
            return (Criteria) this;
        }

        public Criteria andDateIn(List<Date> values) {
            addCriterionForJDBCDate("date in", values, "date");
            return (Criteria) this;
        }

        public Criteria andDateNotIn(List<Date> values) {
            addCriterionForJDBCDate("date not in", values, "date");
            return (Criteria) this;
        }

        public Criteria andDateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("date between", value1, value2, "date");
            return (Criteria) this;
        }

        public Criteria andDateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("date not between", value1, value2, "date");
            return (Criteria) this;
        }

        public Criteria andClickIsNull() {
            addCriterion("click is null");
            return (Criteria) this;
        }

        public Criteria andClickIsNotNull() {
            addCriterion("click is not null");
            return (Criteria) this;
        }

        public Criteria andClickEqualTo(Long value) {
            addCriterion("click =", value, "click");
            return (Criteria) this;
        }

        public Criteria andClickNotEqualTo(Long value) {
            addCriterion("click <>", value, "click");
            return (Criteria) this;
        }

        public Criteria andClickGreaterThan(Long value) {
            addCriterion("click >", value, "click");
            return (Criteria) this;
        }

        public Criteria andClickGreaterThanOrEqualTo(Long value) {
            addCriterion("click >=", value, "click");
            return (Criteria) this;
        }

        public Criteria andClickLessThan(Long value) {
            addCriterion("click <", value, "click");
            return (Criteria) this;
        }

        public Criteria andClickLessThanOrEqualTo(Long value) {
            addCriterion("click <=", value, "click");
            return (Criteria) this;
        }

        public Criteria andClickIn(List<Long> values) {
            addCriterion("click in", values, "click");
            return (Criteria) this;
        }

        public Criteria andClickNotIn(List<Long> values) {
            addCriterion("click not in", values, "click");
            return (Criteria) this;
        }

        public Criteria andClickBetween(Long value1, Long value2) {
            addCriterion("click between", value1, value2, "click");
            return (Criteria) this;
        }

        public Criteria andClickNotBetween(Long value1, Long value2) {
            addCriterion("click not between", value1, value2, "click");
            return (Criteria) this;
        }

        public Criteria andExposureIsNull() {
            addCriterion("exposure is null");
            return (Criteria) this;
        }

        public Criteria andExposureIsNotNull() {
            addCriterion("exposure is not null");
            return (Criteria) this;
        }

        public Criteria andExposureEqualTo(Long value) {
            addCriterion("exposure =", value, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureNotEqualTo(Long value) {
            addCriterion("exposure <>", value, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureGreaterThan(Long value) {
            addCriterion("exposure >", value, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureGreaterThanOrEqualTo(Long value) {
            addCriterion("exposure >=", value, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureLessThan(Long value) {
            addCriterion("exposure <", value, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureLessThanOrEqualTo(Long value) {
            addCriterion("exposure <=", value, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureIn(List<Long> values) {
            addCriterion("exposure in", values, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureNotIn(List<Long> values) {
            addCriterion("exposure not in", values, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureBetween(Long value1, Long value2) {
            addCriterion("exposure between", value1, value2, "exposure");
            return (Criteria) this;
        }

        public Criteria andExposureNotBetween(Long value1, Long value2) {
            addCriterion("exposure not between", value1, value2, "exposure");
            return (Criteria) this;
        }

        public Criteria andActiveUserIsNull() {
            addCriterion("active_user is null");
            return (Criteria) this;
        }

        public Criteria andActiveUserIsNotNull() {
            addCriterion("active_user is not null");
            return (Criteria) this;
        }

        public Criteria andActiveUserEqualTo(Integer value) {
            addCriterion("active_user =", value, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserNotEqualTo(Integer value) {
            addCriterion("active_user <>", value, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserGreaterThan(Integer value) {
            addCriterion("active_user >", value, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserGreaterThanOrEqualTo(Integer value) {
            addCriterion("active_user >=", value, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserLessThan(Integer value) {
            addCriterion("active_user <", value, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserLessThanOrEqualTo(Integer value) {
            addCriterion("active_user <=", value, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserIn(List<Integer> values) {
            addCriterion("active_user in", values, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserNotIn(List<Integer> values) {
            addCriterion("active_user not in", values, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserBetween(Integer value1, Integer value2) {
            addCriterion("active_user between", value1, value2, "activeUser");
            return (Criteria) this;
        }

        public Criteria andActiveUserNotBetween(Integer value1, Integer value2) {
            addCriterion("active_user not between", value1, value2, "activeUser");
            return (Criteria) this;
        }

        public Criteria andNewUserIsNull() {
            addCriterion("new_user is null");
            return (Criteria) this;
        }

        public Criteria andNewUserIsNotNull() {
            addCriterion("new_user is not null");
            return (Criteria) this;
        }

        public Criteria andNewUserEqualTo(Integer value) {
            addCriterion("new_user =", value, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserNotEqualTo(Integer value) {
            addCriterion("new_user <>", value, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserGreaterThan(Integer value) {
            addCriterion("new_user >", value, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserGreaterThanOrEqualTo(Integer value) {
            addCriterion("new_user >=", value, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserLessThan(Integer value) {
            addCriterion("new_user <", value, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserLessThanOrEqualTo(Integer value) {
            addCriterion("new_user <=", value, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserIn(List<Integer> values) {
            addCriterion("new_user in", values, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserNotIn(List<Integer> values) {
            addCriterion("new_user not in", values, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserBetween(Integer value1, Integer value2) {
            addCriterion("new_user between", value1, value2, "newUser");
            return (Criteria) this;
        }

        public Criteria andNewUserNotBetween(Integer value1, Integer value2) {
            addCriterion("new_user not between", value1, value2, "newUser");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeIsNull() {
            addCriterion("avg_read_time is null");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeIsNotNull() {
            addCriterion("avg_read_time is not null");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeEqualTo(Long value) {
            addCriterion("avg_read_time =", value, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeNotEqualTo(Long value) {
            addCriterion("avg_read_time <>", value, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeGreaterThan(Long value) {
            addCriterion("avg_read_time >", value, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeGreaterThanOrEqualTo(Long value) {
            addCriterion("avg_read_time >=", value, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeLessThan(Long value) {
            addCriterion("avg_read_time <", value, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeLessThanOrEqualTo(Long value) {
            addCriterion("avg_read_time <=", value, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeIn(List<Long> values) {
            addCriterion("avg_read_time in", values, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeNotIn(List<Long> values) {
            addCriterion("avg_read_time not in", values, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeBetween(Long value1, Long value2) {
            addCriterion("avg_read_time between", value1, value2, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadTimeNotBetween(Long value1, Long value2) {
            addCriterion("avg_read_time not between", value1, value2, "avgReadTime");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleIsNull() {
            addCriterion("avg_read_article is null");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleIsNotNull() {
            addCriterion("avg_read_article is not null");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleEqualTo(Long value) {
            addCriterion("avg_read_article =", value, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleNotEqualTo(Long value) {
            addCriterion("avg_read_article <>", value, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleGreaterThan(Long value) {
            addCriterion("avg_read_article >", value, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleGreaterThanOrEqualTo(Long value) {
            addCriterion("avg_read_article >=", value, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleLessThan(Long value) {
            addCriterion("avg_read_article <", value, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleLessThanOrEqualTo(Long value) {
            addCriterion("avg_read_article <=", value, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleIn(List<Long> values) {
            addCriterion("avg_read_article in", values, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleNotIn(List<Long> values) {
            addCriterion("avg_read_article not in", values, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleBetween(Long value1, Long value2) {
            addCriterion("avg_read_article between", value1, value2, "avgReadArticle");
            return (Criteria) this;
        }

        public Criteria andAvgReadArticleNotBetween(Long value1, Long value2) {
            addCriterion("avg_read_article not between", value1, value2, "avgReadArticle");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}