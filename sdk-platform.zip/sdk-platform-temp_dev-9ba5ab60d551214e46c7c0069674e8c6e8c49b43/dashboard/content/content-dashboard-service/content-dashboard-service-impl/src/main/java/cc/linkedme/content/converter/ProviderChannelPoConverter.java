package cc.linkedme.content.converter;

import cc.linkedme.content.dao.channel.ProviderChannelPO;
import cc.linkedme.content.model.ProviderChannelInfo;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 16:15 2019-09-08
 * @:Description
 */
public class ProviderChannelPoConverter {

    public static ProviderChannelInfo po2Vo(ProviderChannelPO providerChannelPO) {

        ProviderChannelInfo providerChannelInfo = new ProviderChannelInfo();
        BeanUtils.copyProperties(providerChannelPO, providerChannelInfo);

        return providerChannelInfo;
    }
}
