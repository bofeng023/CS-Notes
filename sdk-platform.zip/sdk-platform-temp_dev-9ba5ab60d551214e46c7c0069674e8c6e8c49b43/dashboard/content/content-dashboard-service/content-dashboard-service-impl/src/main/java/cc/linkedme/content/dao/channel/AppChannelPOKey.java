package cc.linkedme.content.dao.channel;

public class AppChannelPOKey {
    private Integer appId;

    private Integer channelId;

    public Integer getAppId() {
        return appId;
    }

    public void setAppId(Integer appId) {
        this.appId = appId;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }
}