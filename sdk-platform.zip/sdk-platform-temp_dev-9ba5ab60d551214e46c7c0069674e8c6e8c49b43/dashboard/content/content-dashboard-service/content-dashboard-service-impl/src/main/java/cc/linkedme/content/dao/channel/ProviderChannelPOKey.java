package cc.linkedme.content.dao.channel;

public class ProviderChannelPOKey {
    private Integer providerId;

    private String id;

    public Integer getProviderId() {
        return providerId;
    }

    public void setProviderId(Integer providerId) {
        this.providerId = providerId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }
}