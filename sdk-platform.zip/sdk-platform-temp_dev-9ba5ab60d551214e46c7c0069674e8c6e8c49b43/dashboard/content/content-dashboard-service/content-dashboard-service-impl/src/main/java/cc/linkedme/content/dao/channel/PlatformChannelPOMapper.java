package cc.linkedme.content.dao.channel;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PlatformChannelPOMapper {
    long countByExample(PlatformChannelPOExample example);

    int deleteByExample(PlatformChannelPOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(PlatformChannelPO record);

    int insertSelective(PlatformChannelPO record);

    List<PlatformChannelPO> selectByExample(PlatformChannelPOExample example);

    PlatformChannelPO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") PlatformChannelPO record, @Param("example") PlatformChannelPOExample example);

    int updateByExample(@Param("record") PlatformChannelPO record, @Param("example") PlatformChannelPOExample example);

    int updateByPrimaryKeySelective(PlatformChannelPO record);

    int updateByPrimaryKey(PlatformChannelPO record);
}