package cc.linkedme.content.converter;

import cc.linkedme.content.dao.channel.PlatformChannelPO;
import cc.linkedme.content.model.PlatformChannelInfo;
import org.springframework.beans.BeanUtils;

/**
 * @Author kangdi
 * @Date 2019-09-11
 * @Decription
 */
public class PlatformChannelPoConverter {
    public static PlatformChannelInfo po2Bo(PlatformChannelPO platformChannelPO) {
        if (null == platformChannelPO) {
            return null;
        }

        PlatformChannelInfo platformChannelInfo = new PlatformChannelInfo();
        BeanUtils.copyProperties(platformChannelPO, platformChannelInfo);

        return platformChannelInfo;
    }
}
