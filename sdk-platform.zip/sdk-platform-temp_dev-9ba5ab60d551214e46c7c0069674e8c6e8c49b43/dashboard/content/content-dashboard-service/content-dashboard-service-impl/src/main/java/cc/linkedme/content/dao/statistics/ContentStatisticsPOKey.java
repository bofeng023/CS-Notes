package cc.linkedme.content.dao.statistics;

import java.util.Date;

public class ContentStatisticsPOKey {
    private Integer appId;

    private Date date;

    public Integer getAppId() {
        return appId;
    }

    public void setAppId(Integer appId) {
        this.appId = appId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}