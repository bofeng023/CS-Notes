package cc.linkedme.content.dao.channel;

public class ProviderChannelMappingPOKey {
    private Integer channelId;

    private Integer providerId;

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public Integer getProviderId() {
        return providerId;
    }

    public void setProviderId(Integer providerId) {
        this.providerId = providerId;
    }
}