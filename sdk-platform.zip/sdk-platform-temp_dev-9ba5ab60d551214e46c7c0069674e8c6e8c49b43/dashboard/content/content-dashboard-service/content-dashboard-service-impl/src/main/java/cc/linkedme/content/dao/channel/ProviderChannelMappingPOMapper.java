package cc.linkedme.content.dao.channel;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProviderChannelMappingPOMapper {
    long countByExample(ProviderChannelMappingPOExample example);

    int deleteByExample(ProviderChannelMappingPOExample example);

    int deleteByPrimaryKey(ProviderChannelMappingPOKey key);

    int insert(ProviderChannelMappingPO record);

    int insertSelective(ProviderChannelMappingPO record);

    List<ProviderChannelMappingPO> selectByExample(ProviderChannelMappingPOExample example);

    ProviderChannelMappingPO selectByPrimaryKey(ProviderChannelMappingPOKey key);

    int updateByExampleSelective(@Param("record") ProviderChannelMappingPO record, @Param("example") ProviderChannelMappingPOExample example);

    int updateByExample(@Param("record") ProviderChannelMappingPO record, @Param("example") ProviderChannelMappingPOExample example);

    int updateByPrimaryKeySelective(ProviderChannelMappingPO record);

    int updateByPrimaryKey(ProviderChannelMappingPO record);
}