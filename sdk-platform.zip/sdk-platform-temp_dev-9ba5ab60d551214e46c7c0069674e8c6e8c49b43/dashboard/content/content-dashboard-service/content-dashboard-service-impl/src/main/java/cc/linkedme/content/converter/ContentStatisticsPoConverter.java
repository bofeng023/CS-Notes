package cc.linkedme.content.converter;

import cc.linkedme.constant.DateFormatConstant;
import cc.linkedme.content.dao.statistics.ContentStatisticsPO;
import cc.linkedme.content.errorcode.StatisticsErrorCode;
import cc.linkedme.content.exception.StatisticsException;
import cc.linkedme.content.model.ContentStatisticsInfo;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.BeanUtils;

import java.text.ParseException;

/**
 * @Author: liuyunmeng
 * @Date: Create in 14:13 2019-09-06
 * @:Description
 */
public class ContentStatisticsPoConverter {


    public static ContentStatisticsPO bo2Po(ContentStatisticsInfo contentStatisticsInfo) {

        ContentStatisticsPO contentStatisticsPO = new ContentStatisticsPO();
        BeanUtils.copyProperties(contentStatisticsInfo, contentStatisticsPO);
        contentStatisticsPO.setClick(contentStatisticsInfo.getContentClick());
        contentStatisticsPO.setExposure(contentStatisticsInfo.getContentExposure());
        try {
            contentStatisticsPO.setDate(DateUtils.parseDate(contentStatisticsInfo.getDate(), DateFormatConstant.STANDARD_DATE_FORMAT));
        } catch (ParseException e) {
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);
        }

        return contentStatisticsPO;
    }

    public static ContentStatisticsInfo po2Bo(ContentStatisticsPO contentStatisticsPO) {

        ContentStatisticsInfo contentStatisticsInfo = new ContentStatisticsInfo();
        BeanUtils.copyProperties(contentStatisticsPO, contentStatisticsInfo);
        contentStatisticsInfo.setDate(contentStatisticsPO.getDate() == null ? null :DateFormatUtils.format(contentStatisticsPO.getDate(), DateFormatConstant.STANDARD_DATE_FORMAT));
        contentStatisticsInfo.setContentClick(contentStatisticsPO.getClick());
        contentStatisticsInfo.setContentExposure(contentStatisticsPO.getExposure());

        return contentStatisticsInfo;
    }

}
