package cc.linkedme.content.dao.channel;

import java.util.Date;

public class ProviderChannelMappingPO extends ProviderChannelMappingPOKey {
    private String providerChannelId;

    private Date gmtCreated;

    private Date gmtModified;

    public String getProviderChannelId() {
        return providerChannelId;
    }

    public void setProviderChannelId(String providerChannelId) {
        this.providerChannelId = providerChannelId == null ? null : providerChannelId.trim();
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}