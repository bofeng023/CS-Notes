package cc.linkedme.content.service.impl;

import cc.linkedme.constant.DateFormatConstant;
import cc.linkedme.content.converter.ContentStatisticsPoConverter;
import cc.linkedme.content.dao.statistics.AdIncomePO;
import cc.linkedme.content.dao.statistics.AdIncomePOExample;
import cc.linkedme.content.dao.statistics.AdIncomePOMapper;
import cc.linkedme.content.dao.statistics.ContentStatisticsPO;
import cc.linkedme.content.dao.statistics.ContentStatisticsPOExample;
import cc.linkedme.content.dao.statistics.ContentStatisticsPOKey;
import cc.linkedme.content.dao.statistics.ContentStatisticsPOMapper;
import cc.linkedme.content.errorcode.StatisticsErrorCode;
import cc.linkedme.content.exception.StatisticsException;
import cc.linkedme.content.model.AdIncomeInfo;
import cc.linkedme.content.model.ContentStatisticsInfo;
import cc.linkedme.content.model.PagingParam;
import cc.linkedme.content.service.StatisticsService;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.punctuation.Punctuation;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:18 2019-09-06
 * @:Description
 */
@Service("statisticsService")
public class StatisticsServiceImpl implements StatisticsService {

    private static final Logger logger = LoggerFactory.getLogger(StatisticsServiceImpl.class);

    @Resource
    private ContentStatisticsPOMapper contentStatisticsPOMapper;
    @Resource
    private AdIncomePOMapper adIncomePOMapper;

    private static final int DEFAULT_PAGE = 1;
    private static final int DEFAULT_SIZE = 10;
    private static final String ERROR_PATTERN = "-.--";
    private static String PLATFORM_ONLINE_DATE = "2019-09-21";
    private static final String RATIO_PATTERN = "#.00";
    private static final String ZERO_RATIO = "+0.00%";
    private static Date platformOnlineDate;

    static {
        try {
            platformOnlineDate = DateUtils.parseDate(PLATFORM_ONLINE_DATE, DateFormatConstant.STANDARD_DATE_FORMAT);
        } catch (ParseException e) {
            logger.error("date format error", e);
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);
        }
    }

    @Override
    public void saveStatisticsInfo(ContentStatisticsInfo contentStatisticsInfo) {

        logger.info("saveStatisticsInfo, contentStatisticsInfo:{}", contentStatisticsInfo);

        Preconditions.checkNotNull(contentStatisticsInfo, new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(contentStatisticsInfo.getDate(), new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(contentStatisticsInfo.getAppId(), new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));

        ContentStatisticsPO contentStatisticsPO = ContentStatisticsPoConverter.bo2Po(contentStatisticsInfo);
        int count = contentStatisticsPOMapper.insertSelective(contentStatisticsPO);

        logger.info("saveStatisticsInfo, contentStatisticsInfo:{}, contentStatisticsPO:{}", contentStatisticsInfo, contentStatisticsPO, count);
    }

    @Override
    public ContentStatisticsInfo getStatisticsInfo(Integer appId, String date) throws StatisticsException {

        logger.info("getStatisticsInfo, appId:{}, date:{}", appId, date);

        Preconditions.checkNotNull(appId, new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(date, new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));

        ContentStatisticsPOKey contentStatisticsPOKey = new ContentStatisticsPOKey();
        contentStatisticsPOKey.setAppId(appId);
        Date parseDate = null;
        try {
            parseDate = DateUtils.parseDate(date, DateFormatConstant.STANDARD_DATE_FORMAT);
        } catch (ParseException e) {
            logger.info("getStatisticsInfo, appId:{}, date:{}", appId, date, e);
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);
        }
        contentStatisticsPOKey.setDate(parseDate);
        ContentStatisticsPO contentStatisticsPO = contentStatisticsPOMapper.selectByPrimaryKey(contentStatisticsPOKey);
        contentStatisticsPOKey.setDate(DateUtils.addDays(parseDate, -1));
        ContentStatisticsPO contentStatisticsPOBefore = contentStatisticsPOMapper.selectByPrimaryKey(contentStatisticsPOKey);
        ContentStatisticsPOExample contentStatisticsPOExample = new ContentStatisticsPOExample();
        ContentStatisticsPOExample.Criteria criteria = contentStatisticsPOExample.createCriteria();
        criteria.andAppIdEqualTo(appId);
        List<ContentStatisticsPO> contentStatisticsPOS = contentStatisticsPOMapper.selectByExample(contentStatisticsPOExample);
        long totalUsers = 0L;
        if (!CollectionUtils.isEmpty(contentStatisticsPOS)) {
            for (ContentStatisticsPO statisticsPO : contentStatisticsPOS) {
                totalUsers += statisticsPO.getNewUser();
            }
        }
        if (null == contentStatisticsPO) {
            ContentStatisticsInfo contentStatisticsInfo = new ContentStatisticsInfo();
            contentStatisticsInfo.setNewUser(0);
            contentStatisticsInfo.setActiveUser(0);
            contentStatisticsInfo.setContentExposure(0L);
            contentStatisticsInfo.setContentClick(0L);
            contentStatisticsInfo.setAvgReadTime(0L);
            contentStatisticsInfo.setAvgReadArticle(0L);
            contentStatisticsInfo.setActiveUserD2DRatio(ERROR_PATTERN);
            contentStatisticsInfo.setArticleClickD2DRatio(ERROR_PATTERN);
            contentStatisticsInfo.setArticleExposureD2DRatio(ERROR_PATTERN);
            contentStatisticsInfo.setAvgReadTimeD2DRatio(ERROR_PATTERN);
            contentStatisticsInfo.setTotalUsers(totalUsers);
            return contentStatisticsInfo;
        }

        ContentStatisticsInfo contentStatisticsInfo = ContentStatisticsPoConverter.po2Bo(contentStatisticsPO);
        contentStatisticsInfo.setTotalUsers(totalUsers);
        if (contentStatisticsPOBefore == null) {
            contentStatisticsInfo.setActiveUserD2DRatio(ERROR_PATTERN);
            contentStatisticsInfo.setArticleClickD2DRatio(ERROR_PATTERN);
            contentStatisticsInfo.setArticleExposureD2DRatio(ERROR_PATTERN);
            contentStatisticsInfo.setAvgReadTimeD2DRatio(ERROR_PATTERN);
        } else {
            contentStatisticsInfo.setActiveUserD2DRatio(calculateD2DRatio(contentStatisticsPO.getActiveUser(), contentStatisticsPOBefore.getActiveUser()));
            contentStatisticsInfo.setArticleClickD2DRatio(calculateD2DRatio(contentStatisticsPO.getClick().intValue(), contentStatisticsPOBefore.getClick().intValue()));
            contentStatisticsInfo.setArticleExposureD2DRatio(calculateD2DRatio(contentStatisticsPO.getExposure().intValue(), contentStatisticsPOBefore.getExposure().intValue()));
            contentStatisticsInfo.setAvgReadTimeD2DRatio(calculateD2DRatio(contentStatisticsPO.getAvgReadTime().intValue(), contentStatisticsPOBefore.getAvgReadTime().intValue()));
        }


        logger.info("getStatisticsInfo, appId:{}, date:{}, contentStatisticsPO:{}, contentStatisticsInfo:{}", appId, date, contentStatisticsPO, contentStatisticsInfo);
        return contentStatisticsInfo;
    }

    @Override
    public List<ContentStatisticsInfo> getStatisticsList(PagingParam pagingParam) throws StatisticsException {

        logger.info("getStatisticsList, pagingParam:{}", pagingParam);

        Preconditions.checkNotNull(pagingParam, new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));

        ContentStatisticsPOExample contentStatisticsPOExample = new ContentStatisticsPOExample();
        ContentStatisticsPOExample.Criteria criteria = contentStatisticsPOExample.createCriteria();
        criteria.andAppIdEqualTo(pagingParam.getAppId());
        criteria.andDateGreaterThanOrEqualTo(pagingParam.getStartDate());
        criteria.andDateLessThanOrEqualTo(pagingParam.getEndDate());
        contentStatisticsPOExample.setOrderByClause("date DESC");
        List<ContentStatisticsPO> contentStatisticsPOS = contentStatisticsPOMapper.selectByExampleWithLimit(contentStatisticsPOExample, pagingParam.getOffset(), pagingParam.getSize());
        if (CollectionUtils.isEmpty(contentStatisticsPOS)) {
            return Collections.EMPTY_LIST;
        }

        List<ContentStatisticsInfo> contentStatisticsInfos = contentStatisticsPOS.stream().map(contentStatisticsPO -> ContentStatisticsPoConverter.po2Bo(contentStatisticsPO)).collect(Collectors.toList());

        logger.debug("getStatisticsList, searchParam:{}, contentStatisticsInfos:{}", pagingParam, contentStatisticsInfos);
        return contentStatisticsInfos;
    }

    @Override
    public Long countStatisticContent(PagingParam pagingParam) throws StatisticsException {

        logger.info("countStatisticContent, pagingParam:{}", pagingParam);

        Preconditions.checkNotNull(pagingParam, new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));

        ContentStatisticsPOExample contentStatisticsPOExample = new ContentStatisticsPOExample();
        ContentStatisticsPOExample.Criteria criteria = contentStatisticsPOExample.createCriteria();
        criteria.andAppIdEqualTo(pagingParam.getAppId());
        criteria.andDateGreaterThanOrEqualTo(pagingParam.getStartDate());
        criteria.andDateLessThanOrEqualTo(pagingParam.getEndDate());
        long count = contentStatisticsPOMapper.countByExample(contentStatisticsPOExample);

        logger.info("countStatisticContent, pagingParam:{}, count:{}", pagingParam, count);
        return count;
    }

    @Override
    public AdIncomeInfo getTotalAdIncome(Integer appId) {
        logger.info("getAdIncomeInfo, appId:{}", appId);

        Preconditions.checkNotEmpty(appId, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        Date yesterday = DateUtils.addDays(new Date(), -1);

        AdIncomePOExample adIncomePOExample = new AdIncomePOExample();
        adIncomePOExample.createCriteria().andAppIdEqualTo(appId).andDateBetween(platformOnlineDate, yesterday);
        List<AdIncomePO> adIncomePOS = adIncomePOMapper.selectByExample(adIncomePOExample);
        if (CollectionUtils.isEmpty(adIncomePOS)) {
            AdIncomeInfo adIncomeInfo = new AdIncomeInfo();
            adIncomeInfo.setExposure(0l);
            adIncomeInfo.setIncome(0l);
            return adIncomeInfo;
        }
        Preconditions.checkNotEmpty(adIncomePOS, new StatisticsException(StatisticsErrorCode.PARAM_NOT_EXIST.setMessage("没有收益数据")));

        long income = 0;
        long exposure = 0;
        for (AdIncomePO adIncomePO : adIncomePOS) {
            Preconditions.checkNotEmpty(adIncomePO, new StatisticsException(StatisticsErrorCode.INCOME_NOT_EXIST_ERROR));
            income += adIncomePO.getIncome();
            exposure += adIncomePO.getExposure();
        }

        AdIncomeInfo adIncomeInfo = new AdIncomeInfo();
        adIncomeInfo.setIncome(income);
        adIncomeInfo.setExposure(exposure);

        return adIncomeInfo;
    }

    @Override
    public List<AdIncomeInfo> getAdIncomeInfos(Integer appId, PagingParam pagingParam) {
        logger.info("getAdIncomeInfos, appId:{}, pagingParam:{}", appId, pagingParam);

        Preconditions.checkNotEmpty(appId, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        Date startDate = pagingParam.getStartDate();
        Date endDate = pagingParam.getEndDate();

        if (endDate.before(startDate)) {
            logger.warn("getAdIncomeInfos, appId:{}", appId, "开始时间晚于结束时间");
            throw new StatisticsException(StatisticsErrorCode.DATE_ERROR);
        }
        if (startDate.before(platformOnlineDate)) {
//            logger.warn("getAdIncomeInfos, appId:{}", appId, "开始时间早于平台上线时间");
//            throw new StatisticsException(StatisticsErrorCode.DATE_ERROR.setMessage("开始时间早于平台上线时间"));
            startDate = platformOnlineDate;
        }
        Date yesterday = DateUtils.addDays(new Date(), -1);
        if (endDate.after(yesterday)) {
//            logger.warn("getAdIncomeInfos, appId:{}", appId, "结束时间晚于昨天");
//            throw new StatisticsException(StatisticsErrorCode.DATE_ERROR.setMessage("结束时间晚于昨天"));
            endDate = yesterday;
        }

        AdIncomePOExample adIncomePOExample = new AdIncomePOExample();
        adIncomePOExample.createCriteria().andAppIdEqualTo(appId).andDateBetween(startDate, endDate);
        adIncomePOExample.setOrderByClause("date DESC");

        if (null == pagingParam.getPage())
            pagingParam.setPage(DEFAULT_PAGE);
        if (pagingParam.getPage() < 1) {
            logger.warn("getAdIncomeInfos, appId:{}", appId, "page小于1");
            throw new StatisticsException(StatisticsErrorCode.PARAM_INVALID_ERROR.setMessage("page小于1"));
        }
        if (null == pagingParam.getSize())
            pagingParam.setSize(DEFAULT_SIZE);

        List<AdIncomePO> adIncomePOS = adIncomePOMapper.selectByExampleWithLimit(adIncomePOExample,
                (pagingParam.getPage() - 1) * pagingParam.getSize(), pagingParam.getSize());
        if (CollectionUtils.isEmpty(adIncomePOS)) {
            return Collections.EMPTY_LIST;
        }

        List<AdIncomeInfo> adIncomeInfos = adIncomePOS.stream().map(adIncomePO -> {
            AdIncomeInfo adIncomeInfo = new AdIncomeInfo();
            adIncomeInfo.setIncome(adIncomePO.getIncome());
            adIncomeInfo.setExposure(adIncomePO.getExposure());
            adIncomeInfo.setDate(adIncomePO.getDate());
            return adIncomeInfo;
        }).collect(Collectors.toList());

        logger.debug("getAdIncomeInfos, appId:{}, pagingParam:{}, adIncomeInfos:{}", appId, pagingParam, adIncomeInfos);
        return adIncomeInfos;
    }

    @Override
    public List<AdIncomeInfo> getAdIncomeInfos(Integer appId) {
        logger.info("getAdIncomeInfos, appId:{}", appId);

        Preconditions.checkNotEmpty(appId, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        Date yesterday = DateUtils.addDays(new Date(), -1);
        AdIncomePOExample adIncomePOExample = new AdIncomePOExample();
        adIncomePOExample.createCriteria().andAppIdEqualTo(appId).andDateBetween(platformOnlineDate, yesterday);

        List<AdIncomePO> adIncomePOS = adIncomePOMapper.selectByExample(adIncomePOExample);
        Preconditions.checkNotEmpty(adIncomePOS, new StatisticsException(StatisticsErrorCode.PARAM_NOT_EXIST.setMessage("没有收益数据")));

        List<AdIncomeInfo> adIncomeInfos = adIncomePOS.stream().map(adIncomePO -> {
            AdIncomeInfo adIncomeInfo = new AdIncomeInfo();
            adIncomeInfo.setIncome(adIncomePO.getIncome());
            adIncomeInfo.setExposure(adIncomePO.getExposure());
            adIncomeInfo.setDate(adIncomePO.getDate());
            adIncomeInfo.setQid(adIncomePO.getQid());
            return adIncomeInfo;
        }).collect(Collectors.toList());

        logger.debug("getAdIncomeInfos, appId:{}, adIncomeInfos:{}", appId, adIncomeInfos);
        return adIncomeInfos;
    }

    @Override
    public Long countAdIncome(Integer appId, String start, String end) {
        logger.info("countAdIncome, appId:{}, start:{}, end:{}", appId, start, end);

        Date startDate, endDate;
        try {
            startDate = DateUtils.parseDate(start, DateFormatConstant.STANDARD_DATE_FORMAT);
            endDate = DateUtils.parseDate(end, DateFormatConstant.STANDARD_DATE_FORMAT);
        } catch (ParseException e) {
            logger.warn("countAdIncome, appId:{}", appId, e);
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);
        }

        if (endDate.before(startDate)) {
            logger.warn("countAdIncome, appId:{}", appId, "开始日期晚于结束日期");
            throw new StatisticsException(StatisticsErrorCode.DATE_ERROR);
        }
        if (startDate.before(platformOnlineDate)) {
//            logger.warn("countAdIncome, appId:{}", appId, "开始时间早于平台上线时间");
//            throw new StatisticsException(StatisticsErrorCode.DATE_ERROR.setMessage("开始时间早于平台上线时间"));
            startDate = platformOnlineDate;
        }
        Date yesterday = DateUtils.addDays(new Date(), -1);
        if (endDate.after(yesterday)) {
//            logger.warn("countAdIncome, appId:{}", appId, "结束时间晚于昨天");
//            throw new StatisticsException(StatisticsErrorCode.DATE_ERROR.setMessage("结束时间晚于昨天"));
            endDate = yesterday;
        }

        AdIncomePOExample adIncomePOExample = new AdIncomePOExample();
        adIncomePOExample.createCriteria().andAppIdEqualTo(appId).andDateBetween(startDate, endDate);
        long count = adIncomePOMapper.countByExample(adIncomePOExample);

        logger.info("countAdIncome, appId:{}, count:{}", appId, count);
        return count;
    }

    private  String calculateD2DRatio(Integer minuend, Integer subtrahend) {

        if (minuend == 0 || subtrahend == 0) {
            return ERROR_PATTERN;
        }

        if (minuend.equals(subtrahend)) {
            return ZERO_RATIO;
        }

        StringBuilder percentage = new StringBuilder();

        DecimalFormat decimalFormat = new DecimalFormat(RATIO_PATTERN);

        String format = decimalFormat.format((minuend * 1.0 - subtrahend) / subtrahend * 100);

        String d2DRatio = percentage.append(format).append(Punctuation.PERCENTILE).toString();

        return d2DRatio;

    }
}
