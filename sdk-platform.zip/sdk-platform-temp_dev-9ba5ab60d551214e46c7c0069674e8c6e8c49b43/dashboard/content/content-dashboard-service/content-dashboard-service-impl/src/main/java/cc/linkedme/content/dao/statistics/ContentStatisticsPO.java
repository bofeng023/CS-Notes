package cc.linkedme.content.dao.statistics;

public class ContentStatisticsPO extends ContentStatisticsPOKey {
    private Long click;

    private Long exposure;

    private Integer activeUser;

    private Integer newUser;

    private Long avgReadTime;

    private Long avgReadArticle;

    public Long getClick() {
        return click;
    }

    public void setClick(Long click) {
        this.click = click;
    }

    public Long getExposure() {
        return exposure;
    }

    public void setExposure(Long exposure) {
        this.exposure = exposure;
    }

    public Integer getActiveUser() {
        return activeUser;
    }

    public void setActiveUser(Integer activeUser) {
        this.activeUser = activeUser;
    }

    public Integer getNewUser() {
        return newUser;
    }

    public void setNewUser(Integer newUser) {
        this.newUser = newUser;
    }

    public Long getAvgReadTime() {
        return avgReadTime;
    }

    public void setAvgReadTime(Long avgReadTime) {
        this.avgReadTime = avgReadTime;
    }

    public Long getAvgReadArticle() {
        return avgReadArticle;
    }

    public void setAvgReadArticle(Long avgReadArticle) {
        this.avgReadArticle = avgReadArticle;
    }
}