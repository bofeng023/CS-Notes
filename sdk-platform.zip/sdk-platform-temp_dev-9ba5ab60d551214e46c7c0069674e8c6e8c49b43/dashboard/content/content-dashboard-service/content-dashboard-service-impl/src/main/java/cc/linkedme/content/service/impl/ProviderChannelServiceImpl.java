package cc.linkedme.content.service.impl;

import cc.linkedme.content.converter.ProviderChannelPoConverter;
import cc.linkedme.content.dao.channel.ProviderChannelPO;
import cc.linkedme.content.dao.channel.ProviderChannelPOExample;
import cc.linkedme.content.dao.channel.ProviderChannelPOMapper;
import cc.linkedme.content.errorcode.ProviderChannelErrorCode;
import cc.linkedme.content.exception.ProviderChannelException;
import cc.linkedme.content.model.ProviderChannelInfo;
import cc.linkedme.content.service.ProviderChannelService;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author: liuyunmeng
 * @Date: Create in 16:05 2019-09-08
 * @:Description
 */
@Service("providerChannelService")
public class ProviderChannelServiceImpl implements ProviderChannelService {

    private static final Logger logger = LoggerFactory.getLogger(ProviderChannelServiceImpl.class);

    @Resource
    private ProviderChannelPOMapper providerChannelPOMapper;

    @Override
    public ProviderChannelInfo getProviderChannelInfo(Integer providerId, String providerChannelId) {

        logger.info("getProviderChannelInfo, providerId:{}, providerChannelId:{}", providerId, providerChannelId);

        ProviderChannelPOExample providerChannelPOExample = new ProviderChannelPOExample();
        ProviderChannelPOExample.Criteria criteria = providerChannelPOExample.createCriteria();
        criteria.andIdEqualTo(providerChannelId).andProviderIdEqualTo(providerId).andIsDeletedEqualTo(false);
        List<ProviderChannelPO> providerChannelPOS = providerChannelPOMapper.selectByExample(providerChannelPOExample);
        if (CollectionUtils.isEmpty(providerChannelPOS)) {
            throw new ProviderChannelException(ProviderChannelErrorCode.DATA_NOT_EXIST_ERROR);
        }
        ProviderChannelInfo providerChannelInfo = ProviderChannelPoConverter.po2Vo(providerChannelPOS.get(0));

        logger.info("getProviderChannelInfo, providerId:{}, providerChannelId:{}, providerChannelInfo:{}", providerId, providerChannelId, providerChannelInfo);
        return providerChannelInfo;
    }
}
