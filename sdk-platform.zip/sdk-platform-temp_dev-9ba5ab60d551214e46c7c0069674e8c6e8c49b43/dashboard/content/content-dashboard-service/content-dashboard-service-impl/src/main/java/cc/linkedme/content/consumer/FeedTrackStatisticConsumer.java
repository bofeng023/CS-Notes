package cc.linkedme.content.consumer;

import cc.linkedme.content.model.ContentStatisticsInfo;
import cc.linkedme.content.service.StatisticsService;
import cc.linkedme.json.JsonConverter;
import cc.linkedme.kafka.consumer.AbstractKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

/**
 * @Author: liuyunmeng
 * @Date: Create in 13:36 2019-09-15
 * @:Description
 */
public class FeedTrackStatisticConsumer extends AbstractKafkaConsumer {


    private static final Logger logger = LoggerFactory.getLogger(FeedTrackStatisticConsumer.class);

    @Resource
    private StatisticsService statisticsService;

    @Override
    protected void process(Object statistic) {

        logger.info("process, statistic:{}", statistic);

        ContentStatisticsInfo contentStatisticsInfo = JsonConverter.parse((String)statistic, ContentStatisticsInfo.class);
        statisticsService.saveStatisticsInfo(contentStatisticsInfo);

        logger.info("process, statistic:{}, contentStatisticsInfo:{}", statistic, contentStatisticsInfo);
    }
}
