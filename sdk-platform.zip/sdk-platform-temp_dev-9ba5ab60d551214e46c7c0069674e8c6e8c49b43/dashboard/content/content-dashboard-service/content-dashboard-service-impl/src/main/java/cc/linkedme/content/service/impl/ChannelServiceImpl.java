package cc.linkedme.content.service.impl;

import cc.linkedme.content.converter.AppChannelPoConverter;
import cc.linkedme.content.converter.PlatformChannelPoConverter;
import cc.linkedme.content.dao.channel.*;
import cc.linkedme.content.model.AppChannelInfo;
import cc.linkedme.content.model.PlatformChannelInfo;
import cc.linkedme.content.service.ChannelService;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author kangdi
 * @Date 2019-09-05
 * @Decription
 */
@Service("channelService")
public class ChannelServiceImpl implements ChannelService {
    private static final Logger logger = LoggerFactory.getLogger(ChannelServiceImpl.class);

    private static final int RECOMMEND_CHANNEL_ID = 1000;
    private static final String RECOMMEND_CHANNEL_NAME = "推荐";
    private static final int MAX_CHANNEL_NUM = 10;
    private static final int MAX_ALIAS_SIZE = 12;
    private static final String QID = "test";
    private static final String QKEY = "4d038755758f3a3a";

    @Resource
    private AppChannelPOMapper appChannelPOMapper;
    @Resource
    private PlatformChannelPOMapper platformChannelPOMapper;
    @Resource
    private ProviderChannelMappingPOMapper providerChannelMappingPOMapper;

    @Override
    public List<AppChannelInfo> getAppChannels(Integer appId) {
        logger.info("getAppChannels, appId:{}", appId);

        AppChannelPOExample example = new AppChannelPOExample();
        //将appId和是否删除作为查询条件
        example.createCriteria().andAppIdEqualTo(appId).andIsDeletedEqualTo(false);
        example.setOrderByClause("sort");
        List<AppChannelPO> appChannelPOs = appChannelPOMapper.selectByExample(example);

        if (CollectionUtils.isEmpty(appChannelPOs)) {
            List<AppChannelInfo> appChannelInfos = new LinkedList<>();
            AppChannelInfo appChannelInfo = new AppChannelInfo();
            appChannelInfo.setChannelId(RECOMMEND_CHANNEL_ID);
            appChannelInfo.setChannelAlias(RECOMMEND_CHANNEL_NAME);
            appChannelInfo.setChannelName(RECOMMEND_CHANNEL_NAME);
            appChannelInfos.add(appChannelInfo);
            return appChannelInfos;
        }

        List<AppChannelInfo> appChannelInfos = appChannelPOs.stream()
                .map(appChannelPO -> {
                    PlatformChannelPO platformChannelPO = platformChannelPOMapper.selectByPrimaryKey(appChannelPO.getChannelId());
                    String channelName = platformChannelPO.getName();
                    return AppChannelPoConverter.po2Bo(appChannelPO, channelName);
                })
                .collect(Collectors.toList());

        logger.debug("getAppChannels, appId:{}, appChannelInfos:{}", appId, appChannelInfos);
        return appChannelInfos;
    }

    @Override
    public List<PlatformChannelInfo> getPlatformChannels() {
        logger.info("getPlatformChannels");

        PlatformChannelPOExample example = new PlatformChannelPOExample();
        example.createCriteria().andIsDeletedEqualTo(false);
        List<PlatformChannelPO> platformChannelPOs = platformChannelPOMapper.selectByExample(example);

        if (CollectionUtils.isEmpty(platformChannelPOs)) {
            return null;
        }

        List<PlatformChannelInfo> platformChannelInfos = platformChannelPOs.stream()
                .map(platformChannelPO -> PlatformChannelPoConverter.po2Bo(platformChannelPO))
                .collect(Collectors.toList());

        logger.debug("getPlatformChannels, platformChannelInfos:{}", platformChannelInfos);
        return platformChannelInfos;
    }

    /**
     * 添加app频道
     *
     * @param appChannels
     */
    @Override
    public void addAppChannels(List<AppChannelInfo> appChannels) {
        logger.info("addAppChannels, appChannels:{}", appChannels);

        Preconditions.checkNotEmpty(appChannels, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        if (appChannels.size() > MAX_CHANNEL_NUM) {
            logger.warn("addAppChannels, appChannels:{}", appChannels, "添加频道数超过10");
            throw new BusinessException(BaseErrorCode.PARAM_INVALID_ERROR.setMessage("添加频道数超过10"));
        }

        //通过Set集合大小判断集合元素重复
        Set<Integer> channelIds = new HashSet<>();
        //全删前校验
        List<ProviderChannelMappingPO> providerChannelMappingPOS = null;
        for (AppChannelInfo appChannelInfo : appChannels) {
            Preconditions.checkNotEmpty(appChannelInfo.getChannelId(), new BusinessException(
                    BaseErrorCode.PARAM_NULL_ERROR.setMessage("频道id为空")));
            if (appChannelInfo.getChannelAlias().getBytes().length > MAX_ALIAS_SIZE) {
                logger.warn("addAppChannels, appChannels:{}", appChannels, "别名超过大小限制");
                throw new BusinessException(BaseErrorCode.PARAM_INVALID_ERROR.setMessage("别名超过大小限制"));
            }

            //根据channelId查providerId
            ProviderChannelMappingPOExample example = new ProviderChannelMappingPOExample();
            example.createCriteria().andChannelIdEqualTo(appChannelInfo.getChannelId());
            providerChannelMappingPOS = providerChannelMappingPOMapper.selectByExample(example);
            if (CollectionUtils.isEmpty(providerChannelMappingPOS)) {
                logger.warn("addAppChannels, appChannels:{}", appChannels, "channel_id不存在");
                throw new BusinessException(BaseErrorCode.PARAM_NOT_EXIST.setMessage("channel_id不存在"));
            }
            channelIds.add(appChannelInfo.getChannelId());
        }
        if (channelIds.size() < appChannels.size()) {
            logger.warn("addAppChannels, appChannels:{}", appChannels, "channel_id重复");
            throw new BusinessException(BaseErrorCode.PARAM_INVALID_ERROR.setMessage("channel_id重复"));
        }

        AppChannelPOExample appChannelPOExample = new AppChannelPOExample();
        //ChannelVosConverter已移除空对象，不再需要非空校验
        appChannelPOExample.createCriteria().andAppIdEqualTo(appChannels.get(0).getAppId());
        appChannelPOMapper.deleteByExample(appChannelPOExample);

        int initSort = 1;
        for (AppChannelInfo appChannelInfo : appChannels) {
            AppChannelPO po = new AppChannelPO();
            po.setAppId(appChannelInfo.getAppId());
            po.setChannelId(appChannelInfo.getChannelId());
            if (StringUtils.isBlank(appChannelInfo.getChannelAlias())) {
                PlatformChannelPO platformChannelPO = platformChannelPOMapper.selectByPrimaryKey(appChannelInfo.getChannelId());
                po.setChannelAlias(platformChannelPO.getName());
            } else {
                po.setChannelAlias(appChannelInfo.getChannelAlias());
            }
            po.setSort(initSort++);
            //TODO 写死
            po.setProviderId(providerChannelMappingPOS.get(0).getProviderId());
            po.setIsDeleted(false);
            Date date = new Date();
            po.setGmtCreated(date);
            po.setGmtModified(date);
            po.setQid(QID);
            po.setQkey(QKEY);
            appChannelPOMapper.insertSelective(po);
        }

        logger.debug("addAppChannels, appChannels:{}", appChannels);
    }

    @Override
    public AppChannelInfo getAppChannel(Integer appId, Integer channelId) {

        logger.info("getAppChannel, appId:{}, channelId:{}", appId, channelId);

        AppChannelPOKey appChannelPOKey = new AppChannelPOKey();
        appChannelPOKey.setAppId(appId);
        appChannelPOKey.setChannelId(channelId);
        AppChannelPO appChannelPO = appChannelPOMapper.selectByPrimaryKey(appChannelPOKey);
        AppChannelInfo appChannelInfo = AppChannelPoConverter.po2Bo(appChannelPO);

        logger.info("getAppChannel, appId:{}, channelId:{}, appChannelInfo:{}", appId, channelId, appChannelInfo);
        return appChannelInfo;
    }
}
