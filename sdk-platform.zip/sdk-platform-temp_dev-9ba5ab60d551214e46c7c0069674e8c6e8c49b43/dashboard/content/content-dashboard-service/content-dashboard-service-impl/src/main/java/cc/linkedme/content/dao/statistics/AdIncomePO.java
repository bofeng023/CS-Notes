package cc.linkedme.content.dao.statistics;

public class AdIncomePO extends AdIncomePOKey {
    private Long income;

    private Long exposure;

    private String qid;

    public Long getIncome() {
        return income;
    }

    public void setIncome(Long income) {
        this.income = income;
    }

    public Long getExposure() {
        return exposure;
    }

    public void setExposure(Long exposure) {
        this.exposure = exposure;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid == null ? null : qid.trim();
    }
}