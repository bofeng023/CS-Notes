package cc.linkedme.content.dao.channel;

import cc.linkedme.content.dao.channel.AppChannelPO;
import cc.linkedme.content.dao.channel.AppChannelPOExample;
import cc.linkedme.content.dao.channel.AppChannelPOKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AppChannelPOMapper {
    long countByExample(AppChannelPOExample example);

    int deleteByExample(AppChannelPOExample example);

    int deleteByPrimaryKey(AppChannelPOKey key);

    int insert(AppChannelPO record);

    int insertSelective(AppChannelPO record);

    List<AppChannelPO> selectByExample(AppChannelPOExample example);

    AppChannelPO selectByPrimaryKey(AppChannelPOKey key);

    int updateByExampleSelective(@Param("record") AppChannelPO record, @Param("example") AppChannelPOExample example);

    int updateByExample(@Param("record") AppChannelPO record, @Param("example") AppChannelPOExample example);

    int updateByPrimaryKeySelective(AppChannelPO record);

    int updateByPrimaryKey(AppChannelPO record);
}