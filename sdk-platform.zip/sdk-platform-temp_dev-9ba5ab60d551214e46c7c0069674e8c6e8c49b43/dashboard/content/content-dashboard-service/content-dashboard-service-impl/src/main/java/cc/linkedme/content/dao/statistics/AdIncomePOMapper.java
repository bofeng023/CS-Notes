package cc.linkedme.content.dao.statistics;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AdIncomePOMapper {
    long countByExample(AdIncomePOExample example);

    int deleteByExample(AdIncomePOExample example);

    int deleteByPrimaryKey(AdIncomePOKey key);

    int insert(AdIncomePO record);

    int insertSelective(AdIncomePO record);

    List<AdIncomePO> selectByExample(AdIncomePOExample example);

    AdIncomePO selectByPrimaryKey(AdIncomePOKey key);

    int updateByExampleSelective(@Param("record") AdIncomePO record, @Param("example") AdIncomePOExample example);

    int updateByExample(@Param("record") AdIncomePO record, @Param("example") AdIncomePOExample example);

    int updateByPrimaryKeySelective(AdIncomePO record);

    int updateByPrimaryKey(AdIncomePO record);

    List<AdIncomePO> selectByExampleWithLimit(@Param("example") AdIncomePOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);
}