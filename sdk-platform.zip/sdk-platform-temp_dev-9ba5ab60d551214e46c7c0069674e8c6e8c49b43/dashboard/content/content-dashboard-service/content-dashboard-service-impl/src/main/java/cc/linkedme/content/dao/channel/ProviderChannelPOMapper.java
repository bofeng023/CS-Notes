package cc.linkedme.content.dao.channel;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProviderChannelPOMapper {
    long countByExample(ProviderChannelPOExample example);

    int deleteByExample(ProviderChannelPOExample example);

    int deleteByPrimaryKey(ProviderChannelPOKey key);

    int insert(ProviderChannelPO record);

    int insertSelective(ProviderChannelPO record);

    List<ProviderChannelPO> selectByExample(ProviderChannelPOExample example);

    ProviderChannelPO selectByPrimaryKey(ProviderChannelPOKey key);

    int updateByExampleSelective(@Param("record") ProviderChannelPO record, @Param("example") ProviderChannelPOExample example);

    int updateByExample(@Param("record") ProviderChannelPO record, @Param("example") ProviderChannelPOExample example);

    int updateByPrimaryKeySelective(ProviderChannelPO record);

    int updateByPrimaryKey(ProviderChannelPO record);
}