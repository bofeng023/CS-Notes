package cc.linkedme.content.converter;

import cc.linkedme.content.dao.channel.AppChannelPO;
import cc.linkedme.content.model.AppChannelInfo;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 21:14 2019-09-07
 * @:Description
 */
public class AppChannelPoConverter {
    public static AppChannelInfo po2Bo(AppChannelPO appChannelPO) {
        if (null == appChannelPO) {
            return null;
        }

        AppChannelInfo appChannelInfo = new AppChannelInfo();
        BeanUtils.copyProperties(appChannelPO, appChannelInfo);

        return appChannelInfo;
    }

    public static AppChannelInfo po2Bo(AppChannelPO appChannelPO, String channelName) {
        if (null == appChannelPO) {
            return null;
        }

        AppChannelInfo appChannelInfo = new AppChannelInfo();
        BeanUtils.copyProperties(appChannelPO, appChannelInfo);
        appChannelInfo.setChannelName(channelName);

        return appChannelInfo;
    }
}
