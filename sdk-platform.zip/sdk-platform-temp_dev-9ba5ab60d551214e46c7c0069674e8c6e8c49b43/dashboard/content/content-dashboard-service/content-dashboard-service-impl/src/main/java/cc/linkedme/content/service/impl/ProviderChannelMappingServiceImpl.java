package cc.linkedme.content.service.impl;

import cc.linkedme.content.converter.ProviderChannelMappingPoConverter;
import cc.linkedme.content.dao.channel.ProviderChannelMappingPO;
import cc.linkedme.content.dao.channel.ProviderChannelMappingPOKey;
import cc.linkedme.content.dao.channel.ProviderChannelMappingPOMapper;
import cc.linkedme.content.model.ProviderChannelMappingInfo;
import cc.linkedme.content.service.ProviderChannelMappingService;
import cc.linkedme.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Author: liuyunmeng
 * @Date: Create in 15:44 2019-09-08
 * @:Description
 */
@Service("providerChannelMappingService")
public class ProviderChannelMappingServiceImpl implements ProviderChannelMappingService {

    private static final Logger logger = LoggerFactory.getLogger(ProviderChannelMappingServiceImpl.class);

    @Resource
    private ProviderChannelMappingPOMapper providerChannelMappingPOMapper;

    @Override
    public ProviderChannelMappingInfo getProviderChannelMappingInfo(Integer channelId, Integer providerId) throws BusinessException {

        logger.info("getProviderChannelMappingInfo, channelId:{}, providerId:{}", channelId, providerId);

        ProviderChannelMappingPOKey providerChannelMappingPOKey = new ProviderChannelMappingPOKey();
        providerChannelMappingPOKey.setChannelId(channelId);
        providerChannelMappingPOKey.setProviderId(providerId);
        ProviderChannelMappingPO providerChannelMappingPO = providerChannelMappingPOMapper.selectByPrimaryKey(providerChannelMappingPOKey);
        ProviderChannelMappingInfo providerChannelMappingInfo = ProviderChannelMappingPoConverter.po2Bo(providerChannelMappingPO);

        logger.info("getProviderChannelMappingInfo, channelId:{}, providerId:{}, providerChannelMappingInfo", channelId, providerId, providerChannelMappingInfo);
        return providerChannelMappingInfo;
    }
}
