package cc.linkedme.content.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @Author: liuyunmeng
 * @Date: Create in 17:48 2019-09-16
 * @:Description
 */
public class ProviderChannelException extends BusinessException {

    public ProviderChannelException(ErrorCode errorCode) {
        super(errorCode);
    }
}
