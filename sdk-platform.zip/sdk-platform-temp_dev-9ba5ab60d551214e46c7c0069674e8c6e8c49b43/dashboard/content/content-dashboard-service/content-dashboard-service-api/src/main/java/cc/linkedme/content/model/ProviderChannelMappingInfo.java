package cc.linkedme.content.model;

import lombok.Data;

import java.util.Date;

/**
 * @Author: liuyunmeng
 * @Date: Create in 13:54 2019-09-08
 * @:Description
 */
@Data
public class ProviderChannelMappingInfo {

    private Integer channelId;
    private Integer providerId;
    private String providerChannelId;
    private Date gmtCreated;
    private Date gmtModified;
}
