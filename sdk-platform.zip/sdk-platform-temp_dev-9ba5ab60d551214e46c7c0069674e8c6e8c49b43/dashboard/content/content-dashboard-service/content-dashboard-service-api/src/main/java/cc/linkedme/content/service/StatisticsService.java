package cc.linkedme.content.service;

import cc.linkedme.content.exception.StatisticsException;
import cc.linkedme.content.model.AdIncomeInfo;
import cc.linkedme.content.model.ContentStatisticsInfo;
import cc.linkedme.content.model.PagingParam;

import java.util.List;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:16 2019-09-06
 * @:Description
 */
public interface StatisticsService {

    void saveStatisticsInfo(ContentStatisticsInfo contentStatisticsInfo);
    /**
     * 获取单条统计信息
     * @param appId
     * @param date
     * @return
     * @throws StatisticsException
     */
    ContentStatisticsInfo getStatisticsInfo(Integer appId, String date) throws StatisticsException;

    /**
     * 批量获取统计信息
     * @param searchParam
     * @return
     */
    List<ContentStatisticsInfo> getStatisticsList(PagingParam searchParam) throws StatisticsException;

    Long countStatisticContent(PagingParam searchParam) throws StatisticsException;

    /**
     * 获取广告累计收益
     * @param appId
     * @return
     */
    AdIncomeInfo getTotalAdIncome(Integer appId) throws StatisticsException;

    /**
     * 分页获取广告收益列表
     * @param appId
     * @param pagingParam 分页参数
     * @return
     */
    List<AdIncomeInfo> getAdIncomeInfos(Integer appId, PagingParam pagingParam) throws StatisticsException;

    /**
     * 获取广告收益列表（导出文档用）
     * @param appId
     * @return
     */
    List<AdIncomeInfo> getAdIncomeInfos(Integer appId) throws StatisticsException;

    /**
     * 获取广告收益记录条数
     * @param appId
     * @param start
     * @param end
     * @return
     */
    Long countAdIncome(Integer appId, String start, String end) throws StatisticsException;
}
