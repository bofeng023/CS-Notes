package cc.linkedme.content.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author kangdi
 * @Date 2019-09-05
 * @Decription
 */
@Data
public class AppChannelInfo implements Serializable {

    private Integer appId;

    private Integer channelId;

    private Integer providerId;

    private String channelAlias;

    private String channelName;

    private String qid;        //渠道号

    private String qkey;        //渠道方申请获取接口的token

    private Integer sort;

}
