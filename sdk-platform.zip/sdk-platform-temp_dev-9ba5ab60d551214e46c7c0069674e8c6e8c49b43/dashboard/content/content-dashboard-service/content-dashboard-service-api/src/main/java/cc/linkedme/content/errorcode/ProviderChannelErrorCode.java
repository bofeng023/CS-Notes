package cc.linkedme.content.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

/**
 * @Author: liuyunmeng
 * @Date: Create in 17:46 2019-09-16
 * @:Description
 */
public interface ProviderChannelErrorCode extends BaseErrorCode {


    ErrorCode DATA_NOT_EXIST_ERROR = new ErrorCode(40001, "数据不存在");

}
