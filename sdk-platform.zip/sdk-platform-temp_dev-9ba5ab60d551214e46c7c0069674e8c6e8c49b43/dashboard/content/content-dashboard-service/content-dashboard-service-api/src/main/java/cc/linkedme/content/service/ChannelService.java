package cc.linkedme.content.service;

import cc.linkedme.content.model.AppChannelInfo;
import cc.linkedme.content.model.PlatformChannelInfo;
import cc.linkedme.exception.BusinessException;

import java.util.List;

/**
 * @Author kangdi
 * @Date 2019-09-05
 * @Decription
 */
public interface ChannelService {
    /**
     * 根据appId查询app频道
     * @param appId
     * @return
     */
    List<AppChannelInfo> getAppChannels(Integer appId) throws BusinessException;

    /**
     * 查询平台频道
     * @return
     */
    List<PlatformChannelInfo> getPlatformChannels() throws BusinessException;

    /**
     * 添加app频道
     * @param appChannels
     */
    void addAppChannels(List<AppChannelInfo> appChannels) throws BusinessException;

    AppChannelInfo getAppChannel(Integer appId, Integer channelId) throws BusinessException;
}
