package cc.linkedme.content.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:11 2019-09-06
 * @:Description
 */
public class StatisticsException extends BusinessException {


    public StatisticsException(ErrorCode errorCode) {
        super(errorCode);
    }
}
