package cc.linkedme.content.model;

import lombok.Data;

import java.util.Date;

/**
 * @Author: liuyunmeng
 * @Date: Create in 15:57 2019-09-08
 * @:Description
 */
@Data
public class ProviderChannelInfo {

    private Integer providerId;
    private String id;
    private String name;
    private String providerName;
    private Boolean isDeleted;
    private Date gmtCreated;
    private Date gmtModified;
}
