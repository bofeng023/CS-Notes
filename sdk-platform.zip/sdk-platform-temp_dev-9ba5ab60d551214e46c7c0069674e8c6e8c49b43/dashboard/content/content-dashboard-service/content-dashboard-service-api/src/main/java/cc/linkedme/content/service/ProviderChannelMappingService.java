package cc.linkedme.content.service;

import cc.linkedme.content.model.ProviderChannelMappingInfo;
import cc.linkedme.exception.BusinessException;

/**
 * @Author: liuyunmeng
 * @Date: Create in 13:51 2019-09-08
 * @:Description
 */
public interface ProviderChannelMappingService {

    ProviderChannelMappingInfo getProviderChannelMappingInfo(Integer channelId, Integer providerId) throws BusinessException;


}
