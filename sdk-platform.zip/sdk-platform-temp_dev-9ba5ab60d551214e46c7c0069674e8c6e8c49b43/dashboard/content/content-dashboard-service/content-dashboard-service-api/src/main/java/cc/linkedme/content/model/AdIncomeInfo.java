package cc.linkedme.content.model;

import lombok.Data;

import java.util.Date;

/**
 * @Author kangdi
 * @Date 2019-09-11
 * @Decription
 */
@Data
public class AdIncomeInfo {
    private Integer appId;

    private Date date;

    private Long income;

    private Long exposure;

    private String qid;
}
