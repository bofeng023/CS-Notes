package cc.linkedme.content.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;
import lombok.Data;

@Data
/**
 * @author zhanghaowei
 */
public class UserInfoException extends BusinessException {

    public UserInfoException(ErrorCode errorCode) {
        super(errorCode);
    }
}
