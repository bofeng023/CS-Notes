package cc.linkedme.content.service;

import cc.linkedme.content.model.ProviderChannelInfo;
import cc.linkedme.exception.BusinessException;

/**
 * @Author: liuyunmeng
 * @Date: Create in 15:57 2019-09-08
 * @:Description
 */
public interface ProviderChannelService {

    ProviderChannelInfo getProviderChannelInfo(Integer providerId, String providerChannelId) throws BusinessException;
}
