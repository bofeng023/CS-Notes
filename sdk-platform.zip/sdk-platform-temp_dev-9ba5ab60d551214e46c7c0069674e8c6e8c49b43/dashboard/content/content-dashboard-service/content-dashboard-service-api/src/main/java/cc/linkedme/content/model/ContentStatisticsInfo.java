package cc.linkedme.content.model;

import lombok.Data;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:15 2019-09-06
 * @:Description
 */
@Data
public class ContentStatisticsInfo {

    /**
     * appId
     */
    private Integer appId;
    /**
     * appKey
     */
    private String appKey;
    /**
     * yyyy-MM-dd 格式
     */
    private String date;
    /**
     * 每日新增人数（去重之后的数据）
     */
    private Integer newUser;
    /**
     * 每日活跃人数
     */
    private Integer activeUser;
    /**
     * 内容的曝光量
     */
    private Long contentExposure;
    /**
     * 内容的点击量
     */
    private Long contentClick;
    /**
     * 平均阅读时长
     */
    private Long avgReadTime;
    /**
     * 平均阅读文章数
     */
    private Long avgReadArticle;
    /**
     * 每个app下的总人数（去重）
     */
    private Long totalUsers;
    /**
     * 活跃人数日环比
     */
    private String activeUserD2DRatio;
    /**
     * 文章曝光量日环比
     */
    private String articleExposureD2DRatio;
    /**
     * 文章点击量日环比
     */
    private String articleClickD2DRatio;
    /**
     * 平均阅读时长日环比
     */
    private String avgReadTimeD2DRatio;

}
