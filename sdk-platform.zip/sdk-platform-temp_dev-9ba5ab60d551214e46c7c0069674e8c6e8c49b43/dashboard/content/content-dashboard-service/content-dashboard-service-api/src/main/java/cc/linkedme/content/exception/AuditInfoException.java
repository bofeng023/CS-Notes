package cc.linkedme.content.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;
import lombok.Data;

@Data
/**
 * @author zhanghaowei
 */
public class AuditInfoException extends BusinessException {

    public AuditInfoException(ErrorCode errorCode) {
        super(errorCode);
    }
}
