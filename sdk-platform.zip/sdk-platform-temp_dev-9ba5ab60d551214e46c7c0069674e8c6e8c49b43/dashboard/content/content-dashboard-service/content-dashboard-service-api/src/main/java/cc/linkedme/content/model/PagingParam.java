package cc.linkedme.content.model;

import lombok.Data;

import java.util.Date;

/**
 * @Author: liuyunmeng
 * @Date: Create in 12:45 2019-09-06
 * @:Description
 */
@Data
public class PagingParam {

    private Integer uid;
    private Integer appId;
    private Date startDate;
    private Date endDate;
    private Integer page;
    private Integer size;
    public Integer getOffset() {return (getPage() - 1) * getSize();}

}
