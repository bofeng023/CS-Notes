package cc.linkedme.content.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface CmsLoginErrorCode extends BaseErrorCode {

    ErrorCode TOO_MANY_LOGINS_FAIL = new ErrorCode(900001, "登录失败次数过多，请5分钟后在重新登录");

    ErrorCode USER_NOT_EXIST = new ErrorCode(900002, "用户不存在");

    ErrorCode USER_PASSWORD_ERROR = new ErrorCode(900003, "用户名或密码有误！");

    ErrorCode USER_LOGOUT_FAIL = new ErrorCode(900004, "登出失败！");

    ErrorCode EMAIL_NOT_EMPTY = new ErrorCode(900005, "登录账号不能为空！");

    ErrorCode PASSWORD_NOT_EMPTY = new ErrorCode(900006, "密码不能为空！");

    ErrorCode LOGIN_FAIL = new ErrorCode(900007, "登录失败！");

    ErrorCode TOKEN_NOT_VALID = new ErrorCode(900008, "token 失效");


}