package cc.linkedme.content.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author kangdi
 * @Date 2019-09-05
 * @Decription
 */
@Data
public class PlatformChannelInfo implements Serializable {
    private Integer id;
    private String name;

}
