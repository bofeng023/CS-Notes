package cc.linkedme.content.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:08 2019-09-06
 * @:Description
 */
public interface StatisticsErrorCode extends BaseErrorCode {

    ErrorCode TIME_NULL_ERROR = new ErrorCode(100001, "时间不能为空");

    ErrorCode START_TIME_NULL_ERROR = new ErrorCode(100002, "开始时间不能为空");

    ErrorCode END_TIME_NULL_ERROR = new ErrorCode(100003, "结束时间不能为空");

    ErrorCode DATE_ERROR = new ErrorCode(100004, "start_date应该在end_date之前");

    ErrorCode APP_NOT_EXIST_ERROR = new ErrorCode(10005, "app不存在");

    ErrorCode INCOME_NOT_EXIST_ERROR = new ErrorCode(10006, "收益不存在");

    ErrorCode DATA_NOT_EXIST_ERROR = new ErrorCode(10007, "统计信息不存在");
}
