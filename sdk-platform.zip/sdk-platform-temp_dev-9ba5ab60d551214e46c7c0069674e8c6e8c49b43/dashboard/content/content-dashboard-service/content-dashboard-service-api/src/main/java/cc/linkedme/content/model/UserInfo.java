package cc.linkedme.content.model;

import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import cc.linkedme.enums.YesNoEnum;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:51 2019-09-09
 * @:Description
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class UserInfo implements Serializable {

    private Integer uid;

    private String name;

    private BizType bizType;

    private Integer appId;

    private String appName;

    private String email;

    private String company;

    private String phoneNumber;

    private String qqNumber;

    private AuditState auditState;

    private YesNoEnum activeStatus;

    private Integer pid;

    private String productIdentity;

    private String unifiedBusinessCode;

    private String identityCardNumber;

    private String authSubmitTime;

    private String companyLicense;

    private String authenticationName;

    private String authenticationEmail;

    private String authenticationPhone;

    private String linkAccountSubmitTime;

    private String androidPackageName;

    private String iosBundleId;

    private String androidSignMd5;

    private String identityCardFront;

    private String identityCardBack;

    private String identityCardHand;

    private Integer identity;

    private String auditRemark;

    private LinkAccount linkAccount;

    @Data
    public class LinkAccount {

        @JsonProperty("has_ios")
        private Boolean hasIos;

        @JsonProperty("has_android")
        private Boolean hasAndroid;

        @JsonProperty("audit_state")
        private Integer auditState;
    }
}