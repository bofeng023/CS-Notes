package cc.linkedme.content.interceptor;

import cc.linkedme.content.exception.AuthException;
import cc.linkedme.dashboard.model.AppInfo;
import cc.linkedme.dashboard.model.UserInfo;
import cc.linkedme.dashboard.service.AppInfoService;
import cc.linkedme.dashboard.service.UserInfoService;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;

@NoArgsConstructor
public class AuthInterceptor extends HandlerInterceptorAdapter {

    private static final Logger logger = LoggerFactory.getLogger(AuthInterceptor.class);

    private static final String defaultLoginUrl = "https://www.linkedme.cc/dashboard/index.html#/access/signin";

    @Resource
    private UserInfoService userInfoService;
    @Resource
    private AppInfoService appInfoService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        HandlerMethod handlerMethod = (HandlerMethod) handler;
        Method method = handlerMethod.getMethod();

        RequiredLogin requiredLogin = AnnotationUtils.findAnnotation(method, RequiredLogin.class);
        if (requiredLogin == null) {
            return true;
        }

        String authInfo = request.getHeader("Authorization");
        if (StringUtils.isEmpty(authInfo)) {
            response.sendRedirect(defaultLoginUrl);
            return false;
        }

        String[] authInfoArray = StringUtils.split(authInfo, ":");
        if (authInfoArray.length != 2 || authInfoArray[0] == null || authInfoArray[1] == null) {
            response.sendRedirect(defaultLoginUrl);
            return false;
        }

        String[] authInfoContent = authInfoArray[1].trim().split(" ");
        if (authInfoContent.length != 2 || authInfoContent[0] == null || authInfoContent[1] == null) {
            response.sendRedirect(defaultLoginUrl);
            return false;
        }

        String authMethod = authInfoArray[0];
        String token = authInfoContent[0];
        String uid = authInfoContent[1];

        if (authMethod.trim().equals("Token")) {
            if (checkToken(uid, token, request)) {
                return true;
            } else {
                throw new AuthException(BaseErrorCode.AUTH_FAIL);
            }
        } else {
            response.sendRedirect(defaultLoginUrl);
            return false;
        }

    }

    private boolean checkToken(String uid, String token, HttpServletRequest request) {
        logger.info("checkToken, uid:{}, token:{}",uid,token);

        String appKey = request.getParameter("app_key");
        if (StringUtils.isNotBlank(appKey)) {
            AppInfo appInfo = appInfoService.getAppInfo(appKey);
            Preconditions.checkNotEmpty(appInfo, new BusinessException(
                    BaseErrorCode.PARAM_NOT_EXIST.setMessage("app_key不存在")));
            Integer oldUid = appInfo.getUid();
            if (!oldUid.equals(Integer.parseInt(uid))) {
                throw new BusinessException(BaseErrorCode.SIGN_ERROR.setMessage("权限不足"));
            }
        }

        UserInfo userInfo = userInfoService.getUserInfo(Integer.parseInt(uid));
        String oldToken = userInfo.getToken();
        if (token.equals(oldToken)) {
            return true;
        }
        return false;
    }

}
