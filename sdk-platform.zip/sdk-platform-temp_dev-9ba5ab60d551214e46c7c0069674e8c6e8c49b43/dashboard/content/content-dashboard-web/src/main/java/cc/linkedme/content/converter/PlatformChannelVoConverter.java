package cc.linkedme.content.converter;

import cc.linkedme.content.model.PlatformChannelInfo;
import cc.linkedme.content.model.response.PlatformChannelResponse;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;

import java.util.LinkedList;
import java.util.List;

/**
 * @Author kangdi
 * @Date 2019-09-09
 * @Decription
 */
public class PlatformChannelVoConverter {
    public static PlatformChannelResponse bo2Vo(PlatformChannelInfo platformChannelInfo) {
        if (null == platformChannelInfo) {
            return null;
        }

        PlatformChannelResponse platformChannelResponse = new PlatformChannelResponse();
        BeanUtils.copyProperties(platformChannelInfo, platformChannelResponse);

        return platformChannelResponse;
    }

    public static List<PlatformChannelResponse> bos2Vos(List<PlatformChannelInfo> platformChannelInfos) {
        if (CollectionUtils.isEmpty(platformChannelInfos)) {
            return null;
        }

        List<PlatformChannelResponse> platformChannelResponses = new LinkedList<>();
        for (PlatformChannelInfo platformChannelInfo : platformChannelInfos) {
            if (null != platformChannelInfo) {
                PlatformChannelResponse platformChannelResponse = new PlatformChannelResponse();
                BeanUtils.copyProperties(platformChannelInfo, platformChannelResponse);
                platformChannelResponses.add(platformChannelResponse);
            }
        }

        return platformChannelResponses;
    }
}
