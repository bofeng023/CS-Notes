package cc.linkedme.content.converter;

import cc.linkedme.constant.DateFormatConstant;
import cc.linkedme.content.model.AdIncomeInfo;
import cc.linkedme.content.model.response.AdIncomeResponse;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;

import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;

/**
 * @Author kangdi
 * @Date 2019-09-11
 * @Decription
 */
public class AdIncomeConverter {
    public static AdIncomeResponse bo2Vo(AdIncomeInfo adIncomeInfo) {
        if (null == adIncomeInfo) {
            return null;
        }

        AdIncomeResponse adIncomeResponse = new AdIncomeResponse();
        BeanUtils.copyProperties(adIncomeInfo, adIncomeResponse);

        return adIncomeResponse;
    }

    public static List<AdIncomeResponse> bos2Vos(List<AdIncomeInfo> adIncomeInfos) {
        if (CollectionUtils.isEmpty(adIncomeInfos)) {
            return null;
        }

        List<AdIncomeResponse> adIncomeResponses = new LinkedList<>();
        for (AdIncomeInfo adIncomeInfo : adIncomeInfos) {
            if (null != adIncomeInfo) {
                AdIncomeResponse adIncomeResponse = new AdIncomeResponse();
                BeanUtils.copyProperties(adIncomeInfo, adIncomeResponse);
                String date = new SimpleDateFormat(DateFormatConstant.STANDARD_DATE_FORMAT).format(adIncomeInfo.getDate());
                adIncomeResponse.setDate(date);
                adIncomeResponses.add(adIncomeResponse);
            }
        }

        return adIncomeResponses;
    }
}
