package cc.linkedme.content.web;

import cc.linkedme.content.converter.ChannelVoConverter;
import cc.linkedme.content.converter.PlatformChannelVoConverter;
import cc.linkedme.content.interceptor.RequiredLogin;
import cc.linkedme.content.model.AppChannelInfo;
import cc.linkedme.content.model.FrameResp;
import cc.linkedme.content.model.PlatformChannelInfo;
import cc.linkedme.content.model.request.AppChannelRequest;
import cc.linkedme.content.model.response.AppChannelResponse;
import cc.linkedme.content.model.response.PlatformChannelResponse;
import cc.linkedme.content.service.ChannelService;
import cc.linkedme.util.Preconditions;
import cc.linkedme.dashboard.model.AppInfo;
import cc.linkedme.dashboard.service.AppInfoService;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author kangdi
 * @Date 2019-09-05
 * @Decription 频道配置
 */
@RestController
@RequestMapping("linkcontent/channel")
public class ChannelController extends BaseController {
    private static final Logger logger = LoggerFactory.getLogger(ChannelController.class);

    @Resource
    private ChannelService channelService;
    @Resource
    private AppInfoService appInfoService;

    /**
     * 根据appId查询app频道
     *
     * @param appKey
     * @return
     */
    @RequiredLogin
    @GetMapping("/app/list")
    public FrameResp getAppChannels(@RequestParam("app_key") String appKey) {
        logger.info("getAppChannels, appKey:{}", appKey);

        Preconditions.checkNotEmpty(appKey, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR.setMessage("appKey为空")));

        AppInfo appInfo = appInfoService.getAppInfo(appKey);
        Preconditions.checkNotEmpty(appInfo, new BusinessException(BaseErrorCode.PARAM_NOT_EXIST.setMessage("appKey不存在")));

        List<AppChannelInfo> appChannelInfos = channelService.getAppChannels(appInfo.getAppId());
        List<AppChannelResponse> appChannelResponses = ChannelVoConverter.bos2Vos(appChannelInfos, appKey);

        logger.info("getAppChannels, appKey:{}, appChannelResponses:{}", appKey, appChannelResponses);
        return buildSuccessResp(appChannelResponses);
    }

    /**
     * 查询平台全部频道
     *
     * @return
     */
    @RequiredLogin
    @GetMapping("/platform")
    public FrameResp getPlatformChannels() {
        logger.info("getPlatformChannels");

        List<PlatformChannelInfo> platformChannelInfos = channelService.getPlatformChannels();
        List<PlatformChannelResponse> platformChannelResponses = PlatformChannelVoConverter.bos2Vos(platformChannelInfos);

        logger.info("getPlatformChannels, platformChannelResponses:{}", platformChannelResponses);
        return buildSuccessResp(platformChannelResponses);
    }

    /**
     * 用户发布频道
     *
     * @param appChannelRequests app频道列表
     * @return
     */
    @RequiredLogin
    @PostMapping("/app/publish")
    public FrameResp publishAppChannel(@RequestBody List<AppChannelRequest> appChannelRequests) {
        logger.info("publishAppChannel, appChannelRequests:{}", appChannelRequests);

        Preconditions.checkNotEmpty(appChannelRequests, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));

        String appKey = appChannelRequests.get(0).getAppKey();
        Preconditions.checkNotEmpty(appKey, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR.setMessage("appKey为空")));

        AppInfo appInfo = appInfoService.getAppInfo(appKey);
        Preconditions.checkNotEmpty(appInfo, new BusinessException(BaseErrorCode.PARAM_NOT_EXIST.setMessage("appKey不存在")));

        List<AppChannelInfo> appChannelInfos = ChannelVoConverter.vos2Bos(appChannelRequests, appInfo.getAppId());
        channelService.addAppChannels(appChannelInfos);

        logger.info("publishAppChannel, appChannelRequests:{}", appChannelRequests);
        return buildSuccessResp();
    }
}
