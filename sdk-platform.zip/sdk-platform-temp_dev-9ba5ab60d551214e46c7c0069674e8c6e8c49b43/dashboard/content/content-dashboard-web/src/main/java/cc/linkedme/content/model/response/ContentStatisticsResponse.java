package cc.linkedme.content.model.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:30 2019-09-06
 * @:Description content 统计信息
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ContentStatisticsResponse {

    private String appKey;

    /**
     * yyyy-MM-dd 格式
     */
    private String date;

    private Integer newUser;

    private Integer activeUser;

    private Long contentExposure;

    private Long contentClick;

    private Long avgReadTime;

    private Long avgReadArticle;

    private Long totalUsers;

    private String activeUserD2DRatio;

    private String articleExposureD2DRatio;

    private String articleClickD2DRatio;

    private String avgReadTimeD2DRatio;
}
