package cc.linkedme.content.converter;

import cc.linkedme.content.model.AppChannelInfo;
import cc.linkedme.content.model.request.AppChannelRequest;
import cc.linkedme.content.model.response.AppChannelResponse;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;

import java.util.LinkedList;
import java.util.List;

/**
 * @Author kangdi
 * @Date 2019-09-07
 * @Decription
 */
public class ChannelVoConverter {
    public static AppChannelInfo vo2Bo(AppChannelRequest appChannelRequest) {
        if (null == appChannelRequest) {
            return null;
        }

        AppChannelInfo appChannelInfo = new AppChannelInfo();
        BeanUtils.copyProperties(appChannelRequest, appChannelInfo);

        return appChannelInfo;
    }

    public static List<AppChannelInfo> vos2Bos(List<AppChannelRequest> appChannelRequests, Integer appId) {
        if (CollectionUtils.isEmpty(appChannelRequests)) {
            return null;
        }

        List<AppChannelInfo> appChannelInfos = new LinkedList<>();
        for (AppChannelRequest appChannelRequest : appChannelRequests) {
            if (null != appChannelRequest) {
                AppChannelInfo appChannelInfo = new AppChannelInfo();
                appChannelInfo.setAppId(appId);
                appChannelInfo.setChannelId(appChannelRequest.getChannelId());
                appChannelInfo.setChannelAlias(appChannelRequest.getChannelAlias());
                appChannelInfos.add(appChannelInfo);
            }
        }

        return appChannelInfos;
    }


    public static List<AppChannelResponse> bos2Vos(List<AppChannelInfo> appChannelInfos, String appKey) {
        if (CollectionUtils.isEmpty(appChannelInfos)) {
            return null;
        }

        List<AppChannelResponse> appChannelResponses = new LinkedList<>();
        for (AppChannelInfo appChannelInfo : appChannelInfos) {
            if (null != appChannelInfo) {
                AppChannelResponse appChannelResponse = new AppChannelResponse();
                BeanUtils.copyProperties(appChannelInfo, appChannelResponse);
                appChannelResponse.setAppKey(appKey);
                appChannelResponses.add(appChannelResponse);
            }
        }

        return appChannelResponses;
    }

    public static AppChannelResponse bo2Vo(AppChannelInfo appChannelInfo) {
        if (null == appChannelInfo) {
            return null;
        }

        AppChannelResponse appChannelResponse = new AppChannelResponse();
        BeanUtils.copyProperties(appChannelInfo, appChannelResponse);

        return appChannelResponse;
    }
}
