package cc.linkedme.content.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:52 2019-09-06
 * @:Description
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class PagingRequest {

    private Integer uid;

    private String appKey;

    private String startDate;

    private String endDate;

    private Integer page;

    private Integer size;


}
