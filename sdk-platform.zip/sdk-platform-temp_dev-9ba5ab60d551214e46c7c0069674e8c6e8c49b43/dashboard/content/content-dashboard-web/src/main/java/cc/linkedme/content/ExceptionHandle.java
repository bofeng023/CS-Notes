package cc.linkedme.content;

import cc.linkedme.content.model.FrameResp;
import cc.linkedme.content.model.ResponseBuilder;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@RestControllerAdvice
public class ExceptionHandle {

    Logger logger = LoggerFactory.getLogger(ExceptionHandle.class);

    /**
     * 处理请求参数格式错误 @RequestBody上validate失败后抛出的异常
     * @param exception
     * @return
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public FrameResp handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        BindingResult bindingResult = exception.getBindingResult();
        if (bindingResult.hasErrors()) {
            ObjectError fieldError = bindingResult.getAllErrors().get(0);
            return new ResponseBuilder().success(false).alert(BaseErrorCode.PARAM_NOT_VALID.isAlert()).code(BaseErrorCode.PARAM_NOT_VALID.getCode())
                    .message(fieldError.getDefaultMessage()).build();
        }
        return null;

    }


    /**
     * 处理请求参数格式错误 @RequestParam上validate失败后抛出的异常
     * @param exception
     * @return
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public FrameResp handleConstraintViolationException(ConstraintViolationException exception) {
        StringBuilder errorInfo = new StringBuilder();
        String errorMessage;

        Set<ConstraintViolation<?>> violations = exception.getConstraintViolations();
        for (ConstraintViolation<?> item : violations) {
            errorInfo.append(item.getMessage());
            break;
        }
        errorMessage = errorInfo.toString().substring(0, errorInfo.toString().length()-1);

        return new ResponseBuilder().success(false).alert(BaseErrorCode.PARAM_NOT_VALID.isAlert()).code(BaseErrorCode.PARAM_NOT_VALID.getCode())
                .message(errorMessage).build();
    }

    @ExceptionHandler(value = Exception.class)
    public FrameResp handleException(Exception ex) {
        logger.error("handleException, ex:{}", ex);

        if (ex instanceof MissingServletRequestParameterException) {

            //缺少请求参数
            return new ResponseBuilder().success(false).alert(true).code(BaseErrorCode.LACK_OF_PARAM_ERROR.getCode()).message(BaseErrorCode.LACK_OF_PARAM_ERROR.getMessage()).build();

        } else if (ex instanceof BindException) {

            //数据绑定异常
            return new ResponseBuilder().success(false).alert(true).code(BaseErrorCode.PARAM_BINDING_ERROR.getCode()).message(BaseErrorCode.PARAM_BINDING_ERROR.getMessage()).build();
        } else if (ex instanceof NumberFormatException || ex instanceof MethodArgumentTypeMismatchException) {

            //参数类型错误
            return new ResponseBuilder().success(false).alert(true).code(BaseErrorCode.PARAM_TYPE_ERROR.getCode()).message(BaseErrorCode.PARAM_TYPE_ERROR.getMessage()).build();
        } else if (ex instanceof BusinessException) {

            //业务异常处理
            BusinessException businessException = (BusinessException) ex;
            return new ResponseBuilder().success(false).alert(businessException.getErrorCode().isAlert()).code(businessException.getErrorCode().getCode())
                    .message(businessException.getErrorCode().getMessage()).build();

        } else {

            //其它未知异常
            return new ResponseBuilder().success(false).alert(true).code(BaseErrorCode.SYSTEM_EXCEPTION.getCode()).message(BaseErrorCode.SYSTEM_EXCEPTION.getMessage()).build();
        }
    }
}
