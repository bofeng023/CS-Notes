package cc.linkedme.content.model;

import lombok.Data;

@Data
public class FrameResp {

    private Header header;

    private Object body;

    @Data
    public static class Header {

        private int code;

        private String msg;

        private boolean success = false;

        private boolean alert = true;

        private long time = System.currentTimeMillis();
    }

    public Header getHeader() {
        if (null == header) {
            header = new Header();
        }
        return header;
    }

}
