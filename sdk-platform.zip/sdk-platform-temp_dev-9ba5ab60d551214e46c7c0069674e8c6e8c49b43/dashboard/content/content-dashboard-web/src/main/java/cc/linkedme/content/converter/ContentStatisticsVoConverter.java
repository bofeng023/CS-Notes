package cc.linkedme.content.converter;

import cc.linkedme.content.model.ContentStatisticsInfo;
import cc.linkedme.content.model.response.ContentStatisticsResponse;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:24 2019-09-06
 * @:Description
 */
public class ContentStatisticsVoConverter {

    public static ContentStatisticsResponse bo2Vo(ContentStatisticsInfo contentStatisticsInfo) {

        if (contentStatisticsInfo == null) {
            return null;
        }

        ContentStatisticsResponse contentStatisticsResponse = new ContentStatisticsResponse();
        BeanUtils.copyProperties(contentStatisticsInfo, contentStatisticsResponse);

        return contentStatisticsResponse;
    }
}
