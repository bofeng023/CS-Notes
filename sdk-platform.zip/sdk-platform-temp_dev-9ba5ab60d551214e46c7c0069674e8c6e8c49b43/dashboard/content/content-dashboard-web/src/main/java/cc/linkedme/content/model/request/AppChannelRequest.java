package cc.linkedme.content.model.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

/**
 * @Author kangdi
 * @Date 2019-09-05
 * @Decription
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class AppChannelRequest {
    /**
     * appKey
     */
    private String appKey;

    /**
     * 平台频道Id
     */
    private Integer channelId;

    /**
     * 频道别名
     */
    private String channelAlias;
}
