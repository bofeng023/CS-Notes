package cc.linkedme.content.web;

import cc.linkedme.constant.DateFormatConstant;
import cc.linkedme.content.converter.AdIncomeConverter;
import cc.linkedme.content.converter.ContentStatisticsVoConverter;
import cc.linkedme.content.errorcode.StatisticsErrorCode;
import cc.linkedme.content.exception.StatisticsException;
import cc.linkedme.content.interceptor.RequiredLogin;
import cc.linkedme.content.model.AdIncomeInfo;
import cc.linkedme.content.model.ContentStatisticsInfo;
import cc.linkedme.content.model.FrameResp;
import cc.linkedme.content.model.PagingParam;
import cc.linkedme.content.model.PagingRequest;
import cc.linkedme.content.model.response.AdIncomeResponse;
import cc.linkedme.content.model.response.ContentStatisticsResponse;
import cc.linkedme.content.service.StatisticsService;
import cc.linkedme.dashboard.model.AppInfo;
import cc.linkedme.dashboard.service.AppInfoService;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.FileUtil;
import cc.linkedme.util.Preconditions;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:32 2019-09-06
 * @:Description
 */
@RestController
@RequestMapping("linkcontent/statistic")
public class StatisticController extends BaseController {


    private static final Logger logger = LoggerFactory.getLogger(StatisticController.class);

    @Resource
    private StatisticsService statisticsService;

    @Resource
    private AppInfoService appInfoService;

    @RequiredLogin
    @GetMapping("get")
    public FrameResp getStatistics(@RequestParam String appKey, @RequestParam String date) {

        logger.info("getStatistics, appKey:{}, date:{}", appKey, date);

        Preconditions.checkNotNull(appKey, new StatisticsException(StatisticsErrorCode.APP_KEY_NULL_ERROR));
        Preconditions.checkNotNull(date, new StatisticsException(StatisticsErrorCode.TIME_NULL_ERROR));
        AppInfo appInfo = appInfoService.getAppInfo(appKey);
        Preconditions.checkNotNull(appInfo, new StatisticsException(StatisticsErrorCode.APP_NOT_EXIST_ERROR));
        ContentStatisticsInfo statisticsInfo = statisticsService.getStatisticsInfo(appInfo.getAppId(), date);
        statisticsInfo.setAppKey(appKey);
        ContentStatisticsResponse contentStatisticsResponse = ContentStatisticsVoConverter.bo2Vo(statisticsInfo);
        logger.info("getStatistics, appKey:{}, date:{}, statisticsInfo:{}, contentStatisticsResponse:{}", appKey, date, statisticsInfo, contentStatisticsResponse);
        return buildSuccessResp(contentStatisticsResponse);
    }

    @RequiredLogin
    @PostMapping("list")
    public FrameResp listStatistics(@RequestBody PagingRequest pagingRequest) {

        logger.info("listStatistics, pagingRequest:{}", pagingRequest);


        Preconditions.checkNotNull(pagingRequest, new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(pagingRequest.getAppKey(), new StatisticsException(StatisticsErrorCode.APP_KEY_NULL_ERROR));
        Preconditions.checkNotNull(pagingRequest.getStartDate(), new StatisticsException(StatisticsErrorCode.START_TIME_NULL_ERROR));
        Preconditions.checkNotNull(pagingRequest.getEndDate(), new StatisticsException(StatisticsErrorCode.END_TIME_NULL_ERROR));
        AppInfo appInfo = appInfoService.getAppInfo(pagingRequest.getAppKey());
        Preconditions.checkNotNull(appInfo, new StatisticsException(StatisticsErrorCode.APP_NOT_EXIST_ERROR));

        Date parsedStartDate = null;
        Date parsedEndDate = null;

        try {
            parsedStartDate = DateUtils.parseDate(pagingRequest.getStartDate(), DateFormatConstant.STANDARD_DATE_FORMAT);
        } catch (ParseException e) {
            logger.warn("listStatistics, date convert fail, pagingRequest:{}", pagingRequest, e);
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);

        }

        try {
            parsedEndDate = DateUtils.parseDate(pagingRequest.getEndDate(), DateFormatConstant.STANDARD_DATE_FORMAT);
        } catch (ParseException e) {
            logger.warn("listStatistics, pagingRequest:{}", pagingRequest, e);
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);
        }

        if (!parsedEndDate.after(parsedStartDate)) {
            logger.warn("listStatistics, pagingRequest:{}", pagingRequest, "end_date早于start_date");
            throw new StatisticsException(StatisticsErrorCode.DATE_ERROR);
        }


        PagingParam pagingParam = new PagingParam();
        pagingParam.setAppId(appInfo.getAppId());
        BeanUtils.copyProperties(pagingRequest, pagingParam);
        pagingParam.setStartDate(parsedStartDate);
        pagingParam.setEndDate(parsedEndDate);

        List<ContentStatisticsInfo> statisticsList = statisticsService.getStatisticsList(pagingParam);
        List<ContentStatisticsResponse> contentStatisticsResponses = statisticsList.stream().map(contentStatisticsInfo -> {
            contentStatisticsInfo.setAppKey(pagingRequest.getAppKey());
            return ContentStatisticsVoConverter.bo2Vo(contentStatisticsInfo);
        }).collect(Collectors.toList());

        logger.debug("listStatistics, pagingParam:{}, statisticsList:{}", pagingParam, statisticsList);
        return buildSuccessResp(contentStatisticsResponses);
    }

    @RequiredLogin
    @PostMapping("count")
    public FrameResp count(@RequestBody PagingRequest pagingRequest) {

        logger.info("count, pagingRequest:{}", pagingRequest);

        Preconditions.checkNotNull(pagingRequest, new StatisticsException(StatisticsErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(pagingRequest.getAppKey(), new StatisticsException(StatisticsErrorCode.APP_KEY_NULL_ERROR));
        Preconditions.checkNotNull(pagingRequest.getStartDate(), new StatisticsException(StatisticsErrorCode.START_TIME_NULL_ERROR));
        Preconditions.checkNotNull(pagingRequest.getEndDate(), new StatisticsException(StatisticsErrorCode.END_TIME_NULL_ERROR));
        AppInfo appInfo = appInfoService.getAppInfo(pagingRequest.getAppKey());
        Preconditions.checkNotNull(appInfo, new StatisticsException(StatisticsErrorCode.APP_NOT_EXIST_ERROR));

        Date parsedStartDate = null;
        Date parsedEndDate = null;

        try {
            parsedStartDate = DateUtils.parseDate(pagingRequest.getStartDate(), DateFormatConstant.STANDARD_DATE_FORMAT);
        } catch (ParseException e) {
            logger.warn("count, pagingRequest:{}", pagingRequest, e);
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);
        }

        try {
            parsedEndDate = DateUtils.parseDate(pagingRequest.getEndDate(), DateFormatConstant.STANDARD_DATE_FORMAT);
        } catch (ParseException e) {
            logger.warn("count, pagingRequest:{}", pagingRequest, e);
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);
        }

        if (!parsedEndDate.after(parsedStartDate)) {
            logger.warn("count, pagingRequest:{}", pagingRequest, "end_date早于start_date");
            throw new StatisticsException(StatisticsErrorCode.DATE_ERROR);
        }


        PagingParam pagingParam = new PagingParam();
        pagingParam.setAppId(appInfo.getAppId());
        BeanUtils.copyProperties(pagingRequest, pagingParam);
        pagingParam.setStartDate(parsedStartDate);
        pagingParam.setEndDate(parsedEndDate);
        Long count = statisticsService.countStatisticContent(pagingParam);

        logger.info("count, pagingRequest:{}, pagingParam:{}, count:{}", pagingRequest, pagingParam, count);
        return buildSuccessResp(count);
    }

    /**
     * 分页查询某段日期的收益列表
     *
     * @param pagingRequest
     * @return
     */
    @RequiredLogin
    @PostMapping("/income/specific")
    public FrameResp getAdIncome(@RequestBody PagingRequest pagingRequest) {
        logger.info("getAdIncome, pagingRequest:{}", pagingRequest);

        Preconditions.checkNotEmpty(pagingRequest.getAppKey(), new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        AppInfo appInfo = appInfoService.getAppInfo(pagingRequest.getAppKey());
        Preconditions.checkNotEmpty(appInfo, new StatisticsException(StatisticsErrorCode.APP_NOT_EXIST_ERROR));

        PagingParam pagingParam = new PagingParam();
        pagingParam.setAppId(appInfo.getAppId());
        BeanUtils.copyProperties(pagingRequest, pagingParam);
        Date parsedStartDate, parsedEndDate;
        try {
            parsedStartDate = DateUtils.parseDate(pagingRequest.getStartDate(), DateFormatConstant.STANDARD_DATE_FORMAT);
            parsedEndDate = DateUtils.parseDate(pagingRequest.getEndDate(), DateFormatConstant.STANDARD_DATE_FORMAT);
        } catch (ParseException e) {
            logger.warn("getAdIncome, pagingRequest:{}", pagingRequest, e);
            throw new StatisticsException(StatisticsErrorCode.DATE_FORMAT_ERROR);
        }
        pagingParam.setStartDate(parsedStartDate);
        pagingParam.setEndDate(parsedEndDate);
        List<AdIncomeInfo> adIncomeInfos = statisticsService.getAdIncomeInfos(appInfo.getAppId(), pagingParam);
        List<AdIncomeResponse> adIncomeResponses = AdIncomeConverter.bos2Vos(adIncomeInfos);

        logger.debug("getAdIncome, pagingRequest:{}, adIncomeResponses:{}", pagingRequest, adIncomeResponses);
        return buildSuccessResp(adIncomeResponses);
    }

    /**
     * 查询累计收益
     *
     * @param appKey
     * @return
     */
    @RequiredLogin
    @GetMapping("/income/total")
    public FrameResp getAdIncome(@RequestParam("app_key") String appKey) {
        logger.info("getAdIncome, appKey:{}", appKey);

        Preconditions.checkNotEmpty(appKey, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        AppInfo appInfo = appInfoService.getAppInfo(appKey);
        Preconditions.checkNotEmpty(appInfo, new StatisticsException(StatisticsErrorCode.APP_NOT_EXIST_ERROR));

        AdIncomeInfo adIncomeInfo = statisticsService.getTotalAdIncome(appInfo.getAppId());
        AdIncomeResponse adIncomeResponse = AdIncomeConverter.bo2Vo(adIncomeInfo);

        logger.info("getAdIncome, appKey:{}, adIncomeResponse:{}", appKey, adIncomeResponse);
        return buildSuccessResp(adIncomeResponse);
    }

    /**
     * 收益分页查询总记录数
     *
     * @param pagingRequest
     * @return
     */
    @RequiredLogin
    @PostMapping("/income/count")
    public FrameResp countAdIncome(@RequestBody PagingRequest pagingRequest) {
        logger.info("getAdIncome, pagingRequest:{}", pagingRequest);

        Preconditions.checkNotEmpty(pagingRequest.getAppKey(), new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        AppInfo appInfo = appInfoService.getAppInfo(pagingRequest.getAppKey());
        Preconditions.checkNotEmpty(appInfo, new StatisticsException(StatisticsErrorCode.APP_NOT_EXIST_ERROR));

        Long count = statisticsService.countAdIncome(appInfo.getAppId(), pagingRequest.getStartDate(), pagingRequest.getEndDate());

        logger.info("getAdIncome, pagingRequest:{}, count:{}", pagingRequest, count);
        return buildSuccessResp(count);
    }

    /**
     * 导出app收益文档.xls
     *
     * @param appKey
     * @param request
     * @param response
     * @return
     */
    @RequiredLogin
    @GetMapping("/income/export")
    public FrameResp exportXls(@RequestParam("app_key") String appKey, HttpServletRequest request, HttpServletResponse response) {
        logger.info("exportXls, appKey:{}", appKey);

        Preconditions.checkNotEmpty(appKey, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        AppInfo appInfo = appInfoService.getAppInfo(appKey);
        Preconditions.checkNotEmpty(appInfo, new StatisticsException(StatisticsErrorCode.APP_NOT_EXIST_ERROR));
        List<AdIncomeInfo> adIncomeInfos = statisticsService.getAdIncomeInfos(appInfo.getAppId());

        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet("APP收益数据");
        HSSFRow row0 = sheet.createRow(0);
        row0.createCell(0).setCellValue("收益（单位：分）");
        row0.createCell(1).setCellValue("曝光量");
        row0.createCell(2).setCellValue("日期");
        row0.createCell(3).setCellValue("渠道号");
        SimpleDateFormat dateFormat = new SimpleDateFormat(DateFormatConstant.STANDARD_DATE_FORMAT);
        for (AdIncomeInfo adIncomeInfo : adIncomeInfos) {
            HSSFRow row = sheet.createRow(sheet.getLastRowNum() + 1);
            row.createCell(0).setCellValue(adIncomeInfo.getIncome());
            row.createCell(1).setCellValue(adIncomeInfo.getExposure());
            row.createCell(2).setCellValue(dateFormat.format(adIncomeInfo.getDate()));
            row.createCell(3).setCellValue(adIncomeInfo.getQid());
        }

        String filename = "APP收益数据.xls";
        String mimeType = request.getServletContext().getMimeType(filename);
        response.setContentType(mimeType);
        String userAgent = request.getHeader("User-Agent");
        ServletOutputStream outputStream;
        try {
            filename = FileUtil.encodeDownloadFilename(filename, userAgent);
            response.setHeader("content-disposition", "attchment;filename=" + filename);
            outputStream = response.getOutputStream();
            workbook.write(outputStream);
        } catch (IOException e) {
            logger.warn("exportXls, appKey:{}", appKey, e);
            throw new StatisticsException(StatisticsErrorCode.SYSTEM_EXCEPTION.setMessage("IO异常"));
        }

        logger.info("exportXls, appKey:{}", appKey);
        return buildSuccessResp();
    }
}
