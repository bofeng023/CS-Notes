package cc.linkedme.content.model.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

/**
 * @Author kangdi
 * @Date 2019-09-11
 * @Decription
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class AdIncomeResponse {
    private Long income;

    private Long exposure;

    private String date;
}
