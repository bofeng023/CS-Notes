package cc.linkedme.content.model.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

/**
 * @Author kangdi
 * @Date 2019-09-09
 * @Decription
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class PlatformChannelResponse {
    private Integer id;

    private String name;
}
