package cc.linkedme.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanghaowei
 * @date 2019-7-4 17:30
 * @description 现金流日志标识
 **/
public enum BizType {

    ACCOUNT_AUTHENTICATION(0,"账号认证"),
    SIGN(1,"签名"),
    SMS_TEMPLATE(2,"短信模板"),
    INVOINCE(3,"发票"),
    TOP_UP(4,"账户充值"),
    ACCOUNT_OPENING(5,"LinkAccount开通"),

    QUICK_LOGIN(6, "一键登录"),
    NUMBER_VERIFY(7, "号码认证"),
    TEXT_SMS(8, "文本短信"),
    VOICE_SMS(9, "语音短信"),
    GLOBAL_SMS(10, "国际短信"),
    OTHER(100,"其它");

    BizType(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    private Integer type;

    private String name;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    private static final Map<Integer, BizType> lookup = new HashMap<>();
    static {
        for (BizType s : EnumSet.allOf(BizType.class)) {
            lookup.put(s.getType(), s);
        }
    }

    public static BizType get(Integer type) {
        return lookup.get(type);
    }

}
