package cc.linkedme.kafka.producer;

import cc.linkedme.kafka.MqEntity;

public interface Producer {

    void init();

    void send(MqEntity mqEntry);
}
