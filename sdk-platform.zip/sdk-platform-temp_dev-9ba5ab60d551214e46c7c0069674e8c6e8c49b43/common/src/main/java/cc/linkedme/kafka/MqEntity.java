package cc.linkedme.kafka;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author yangpeng
 * @date 2019-07-17 16:00
 * @description
 **/
@Getter
@ToString
@NoArgsConstructor
public class MqEntity implements Serializable {

    @Setter
    public String topic;
    /** MQ消息的包体信息，需要实现Serializable接口 */
    @Setter
    public Object body;
    /** 消息体产生时间，用来给业务方控制异步时序 */
    public Long produceTime;

    @Setter
    public Integer retryTime = 1;

    public MqEntity(String topic, Object body) {
        this.topic = topic;
        this.body = body;
        this.produceTime = System.currentTimeMillis();
    }

}
