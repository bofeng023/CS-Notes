package cc.linkedme.punctuation;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:13 2019-07-19
 * @:Description
 */
public class Punctuation {

    public static final String SLASH = "/";

    public static final String COLON = ":";

    public static final String UNDERLINE = "_";

    public static final String POUNG_KEY = "#";

    public static final String AT_MARK = "@";

    public static final String COMMA = ",";

    public static final String PERCENTILE = "%";
}
