package cc.linkedme.util.base64;

import sun.misc.BASE64Decoder;
import sun.misc.CEFormatException;
import sun.misc.CEStreamExhausted;
import sun.misc.CharacterDecoder;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PushbackInputStream;

/**
 * Created by LinkedME01 on 05/06/2017.
 */
public class Base64Decoder extends CharacterDecoder {
    private static final char[] pem_array = new char[] {'o', 'M', 'q', '_', 'r', 'c', '1', 'f', 'u', 'E', 'b', 't', 'X', 'g', 'B', 'O', 'k',
            'K', 'l', 'I', 'x', 'y', 'z', 'N', 'F', 'Y', 'd', '2', 'J', 's', '0', 'D', '-', 'T', 'v', '8', '4', '9', '5', 'A', '6', 'i',
            'h', 'e', 'C', 'p', 'W', 'S', '3', 'Q', 'G', 'U', 'a', 'm', 'w', 'V', 'j', 'R', 'H', '7', 'n', 'L', 'P', 'Z'};
    private static final byte[] pem_convert_array = new byte[256];
    byte[] decode_buffer = new byte[4];

    protected int bytesPerAtom() {
        return 4;
    }

    protected int bytesPerLine() {
        return 72;
    }

    protected void decodeAtom(PushbackInputStream var1, OutputStream var2, int var3) throws IOException {
        byte var5 = -1;
        byte var6 = -1;
        byte var7 = -1;
        byte var8 = -1;
        if (var3 < 2) {
            throw new CEFormatException("BASE64Decoder: Not enough bytes for an atom.");
        } else {
            int var4;
            do {
                var4 = var1.read();
                if (var4 == -1) {
                    throw new CEStreamExhausted();
                }
            } while (var4 == 10 || var4 == 13);

            this.decode_buffer[0] = (byte) var4;
            var4 = this.readFully(var1, this.decode_buffer, 1, var3 - 1);
            if (var4 == -1) {
                throw new CEStreamExhausted();
            } else {
                if (var3 > 3 && this.decode_buffer[3] == 61) {
                    var3 = 3;
                }

                if (var3 > 2 && this.decode_buffer[2] == 61) {
                    var3 = 2;
                }

                switch (var3) {
                    case 4:
                        var8 = pem_convert_array[this.decode_buffer[3] & 255];
                    case 3:
                        var7 = pem_convert_array[this.decode_buffer[2] & 255];
                    case 2:
                        var6 = pem_convert_array[this.decode_buffer[1] & 255];
                        var5 = pem_convert_array[this.decode_buffer[0] & 255];
                    default:
                        switch (var3) {
                            case 2:
                                var2.write((byte) (var5 << 2 & 252 | var6 >>> 4 & 3));
                                break;
                            case 3:
                                var2.write((byte) (var5 << 2 & 252 | var6 >>> 4 & 3));
                                var2.write((byte) (var6 << 4 & 240 | var7 >>> 2 & 15));
                                break;
                            case 4:
                                var2.write((byte) (var5 << 2 & 252 | var6 >>> 4 & 3));
                                var2.write((byte) (var6 << 4 & 240 | var7 >>> 2 & 15));
                                var2.write((byte) (var7 << 6 & 192 | var8 & 63));
                        }

                }
            }
        }
    }

    public static String base64Decode(String s) {
        if (s == null) {
            return null;
        }
        BASE64Decoder decoder = new BASE64Decoder();
        try {
            byte[] b = decoder.decodeBuffer(s);
            return new String(b);
        } catch (Exception e) {
            return null;
        }
    }

    static {
        int var0;
        for (var0 = 0; var0 < 255; ++var0) {
            pem_convert_array[var0] = -1;
        }

        for (var0 = 0; var0 < pem_array.length; ++var0) {
            pem_convert_array[pem_array[var0]] = (byte) var0;
        }

    }

    public static void main(String[] args) {
        try {
            String s =
                    "sid=11a75b962bc12e22&src_id=2381061&ad_id=&creative_id=&cpm=250&ip=61.129.119.185&ts=1464768697&ck=29bd2e6dd81dd66759cdd7a58d308f59c9539b39";
            System.out.println(new Base64Encoder().encode(s.getBytes()));
            System.out.println(new String(new Base64Decoder().decodeBuffer(
                    "Jw94OIrQFIJmF84wX5E8XIE9X8u5JVE8Nw94OIuUB_r3g8r5FzKDdzkLE5gGYzcadNY9Nw94OlY8J1aLX8x3E593OIFQt8rGBljQXI4WXI-mEAKUOIrag8kVg8-wBIJ5FwCLX89vY_E9g5K4B_c4Y_FwgUxRFwK4gwrmB1kUX_T5gI98BIxUBzuUBk==")));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
