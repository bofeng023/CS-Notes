package cc.linkedme.kafka.producer;

import cc.linkedme.kafka.MqEntity;
import lombok.Setter;
import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author yangpeng
 * @date 2019-07-17 16:08
 * @description
 **/
public class MqProducer implements Producer{

    private static final Logger logger = LoggerFactory.getLogger(MqProducer.class);

    @Setter
    private KafkaProducerConfig kafkaProducerConfig;
    private static KafkaProducer<String, MqEntity> producer;

    @Override
    public void init() {

        logger.info("mq producer init begin, bootstrapServers:{}", kafkaProducerConfig);
        if (StringUtils.isBlank(kafkaProducerConfig.getBootstrapServers())) {
            throw new IllegalArgumentException("mq producer bootstrapServers config is null!");
        }
        producer = new KafkaProducer<>(kafkaProducerConfig.getProperties());
    }

    @Override
    public void send(MqEntity mqEntry) {

        logger.debug("send, mqEntry:{}", mqEntry);
        ProducerRecord<String, MqEntity> record = new ProducerRecord<>(mqEntry.getTopic(), mqEntry);
        producer.send(record, (metadata, exception) -> {
            if (exception != null) {
                logger.error("mq producer send failed, mqEntry:{}", mqEntry, exception);
            }
        });
    }
}
