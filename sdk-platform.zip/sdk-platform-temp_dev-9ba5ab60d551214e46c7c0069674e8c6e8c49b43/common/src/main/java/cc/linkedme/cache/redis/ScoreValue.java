package cc.linkedme.cache.redis;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author yangpeng
 * @date 2019-07-05 17:51
 * @description
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ScoreValue {

    private String element;

    private Double score;
}
