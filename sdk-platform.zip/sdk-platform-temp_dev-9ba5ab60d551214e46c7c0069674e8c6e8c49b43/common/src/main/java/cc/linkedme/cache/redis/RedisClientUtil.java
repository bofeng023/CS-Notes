package cc.linkedme.cache.redis;

import cc.linkedme.json.JsonConverter;
import io.lettuce.core.KeyValue;
import io.lettuce.core.Limit;
import io.lettuce.core.Range;
import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.ScoredValue;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.support.ConnectionPoolSupport;
import lombok.Setter;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author yangpeng
 * @date 2019-06-27 16:01
 * @description
 **/
@Setter
public class RedisClientUtil implements RedisOperation {

    private final static Logger logger = LoggerFactory.getLogger(RedisClient.class);

    private RedisURI redisURI;
    private GenericObjectPoolConfig poolConfig;
    private GenericObjectPool<StatefulRedisConnection<String, String>> lettucePool;

    private String password;
    private String host;
    private Integer port;

    private int maxIdle = 80;
    private int minIdle = 20;
    private int maxWaitMillis = 300;
    private int maxTotal = 800;
    private int timeBetweenEvictionRunsMillis = 2 * 60 * 1000;
    private int numTestsPerEvictionRun = -5;
    private int softMinEvictableIdleTimeMillis = 3600 * 1000;
    private int minEvictableIdleTimeMillis = -1;
    private boolean blockWhenExhausted = true;
    private boolean testWhileIdle = true;

    public void init() {

        logger.info("redis client init start, host:{}, port:{}, maxIdle:{}, minIdle:{}, maxWaitMillis:{}, maxTotal:{}",
                host, port, maxIdle, minIdle, maxWaitMillis, maxTotal);
        if (password == null) {
            logger.warn("redis client init warn, redis need to set a password.");
        }

        initRedisURI();
        initPoolConfig();
        initLettuceClientConnectionPool();

        logger.info("redis client init success, host:{}, port:{}", host, port);

    }

    /** ============================================ init ======================================== */

    private void initRedisURI() {

        logger.debug("initRedisURI, host:{}, port:{}", host, port);
        RedisURI redisURI = RedisURI.create(host, port);
        if (password != null) {
            redisURI.setPassword(password);
        }

        this.redisURI = redisURI;
    }

    private void initPoolConfig() {

        logger.debug("initPoolConfig, maxIdle:{}, minIdle:{}, maxWaitMillis:{}, maxTotal:{}", maxIdle, minIdle, maxWaitMillis, maxTotal);
        GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
        poolConfig.setMaxIdle(maxIdle);
        poolConfig.setMinIdle(minIdle);
        poolConfig.setMaxWaitMillis(maxWaitMillis);
        poolConfig.setMaxTotal(maxTotal);

        poolConfig.setNumTestsPerEvictionRun(numTestsPerEvictionRun);
        poolConfig.setTestWhileIdle(testWhileIdle);
        poolConfig.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);
        poolConfig.setSoftMinEvictableIdleTimeMillis(softMinEvictableIdleTimeMillis);
        poolConfig.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);
        poolConfig.setBlockWhenExhausted(blockWhenExhausted);

        this.poolConfig = poolConfig;
    }

    private void initLettuceClientConnectionPool() {
        RedisClient lettuceRedisClient = RedisClient.create(redisURI);
        GenericObjectPool<StatefulRedisConnection<String, String>> pool = ConnectionPoolSupport
                .createGenericObjectPool(() -> lettuceRedisClient.connect(), poolConfig);

        this.lettucePool = pool;
    }

    /** ========================================= connection ================================= */

    private StatefulRedisConnection<String, String> getConnection() {
        try {
            return lettucePool.borrowObject();
        } catch (Exception e) {
            logger.warn("getConnection failed. ", e);
            throw new RuntimeException(e);
        }
    }

    private void releaseConnection(StatefulRedisConnection<String, String> connection) {
        lettucePool.returnObject(connection);
    }

    /** =========================================== key ===================================== */

    @Override
    public long del(String... keys) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().del(keys);
        } catch(Exception e) {
            logger.warn("redis client del failed, keys:{}", keys, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Boolean expireAt(String key, Date date) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().expireat(key, date);
        } catch(Exception e) {
            logger.warn("redis client expireAt failed, key:{}, date:{}", key, date, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Boolean expire(String key, int seconds) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().expire(key, seconds);
        } catch(Exception e) {
            logger.warn("redis client expire failed, key:{}, seconds:{}", key, seconds, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public void rename(String oldKey, String newKey) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            connection.sync().rename(oldKey, newKey);
        } catch(Exception e) {
            logger.warn("redis client expireAt failed, oldKey:{}, newKey:{}", oldKey, newKey, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }



    /** ============================================ kv ========================================== */

    @Override
    public void set(String key, Object value) {
        set(key, JsonConverter.format(value));
    }

    @Override
    public void set(String key, String value) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            connection.sync().set(key, value);
        } catch(Exception e) {
            logger.warn("redis client set failed, key:{}, value:{}", key, value, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }

    }

    @Override
    public <T> T get(String key, Class<T> classz) {
        return JsonConverter.parse(get(key), classz);
    }

    @Override
    public String get(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().get(key);
        } catch(Exception e) {
            logger.warn("redis client get failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public void mset(Map<String, String> kvMap) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            connection.sync().mset(kvMap);
        } catch(Exception e) {
            logger.warn("redis client mset failed, kvMap:{}", kvMap, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }

    }

    @Override
    public <T> Map<String, Object> mget(Class<T> classz, String... keys) {
        Map<String, String> kvMap = mget(keys);
        Map<String, Object> kvObjectMap = new LinkedHashMap<>();
        if (!kvMap.isEmpty()) {
            for (Map.Entry<String, String> kv : kvMap.entrySet()) {
                kvObjectMap.put(kv.getKey(), JsonConverter.parse(kv.getValue(), classz));
            }
        }

        return kvObjectMap;
    }

    @Override
    public Map<String, String> mget(String... keys) {
        StatefulRedisConnection<String, String> connection = getConnection();
        Map<String, String> kvMap = new LinkedHashMap<>();
        try {
            List<KeyValue<String, String>> kvList = connection.sync().mget(keys);
            if (CollectionUtils.isNotEmpty(kvList)) {
                for (KeyValue<String, String> keyValue : kvList) {
                    kvMap.put(keyValue.getKey(), keyValue.getValue());
                }
            }
            return kvMap;
        } catch(Exception e) {
            logger.warn("redis client mget failed, keys:{}", keys, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Boolean setnx(String key, String value) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().setnx(key, value);
        } catch(Exception e) {
            logger.warn("redis client setnx failed, key:{}, value:{}", key, value, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public void setex(String key, String value, int seconds) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            connection.sync().setex(key, seconds, value);
        } catch(Exception e) {
            logger.warn("redis client setex failed, key:{}, value:{}, seconds:{}", key, value, seconds, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long incrBy(String key, long delta) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().incrby(key, delta);
        } catch(Exception e) {
            logger.warn("redis client incrBy failed, key:{}, delta:{}", key, delta, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long decrBy(String key, long delta) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().decrby(key, delta);
        } catch(Exception e) {
            logger.warn("redis client decrBy failed, key:{}, delta:{}", key, -delta, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long incr(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().incr(key);
        } catch(Exception e) {
            logger.warn("redis client incr failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long decr(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().decr(key);
        } catch(Exception e) {
            logger.warn("redis client decr failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Object getSet(String key, String value) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().getset(key, value);
        } catch(Exception e) {
            logger.warn("redis client getSet failed, key:{}, value:{}", key, value, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    /** ===================================== hash ==================================== */

    @Override
    public void hset(String key, String field, String value) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            connection.sync().hset(key, field, value);
        } catch(Exception e) {
            logger.warn("redis client hset failed, key:{}, field:{}, value:{}", key, field, value, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public String hget(String key, String field) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().hget(key, field);
        } catch(Exception e) {
            logger.warn("redis client hget failed, key:{}, field:{}", key, field, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Map<String, String> hmget(String key, String... fields) {
        StatefulRedisConnection<String, String> connection = getConnection();
        Map<String, String> kvMap = new LinkedHashMap<>();
        try {
            List<KeyValue<String, String>> kvList = connection.sync().hmget(key, fields);
            if (CollectionUtils.isNotEmpty(kvList)) {
                for (KeyValue<String, String> kv : kvList) {
                    kvMap.put(kv.getKey(), kv.getValue());
                }
            }
            return kvMap;
        } catch(Exception e) {
            logger.warn("redis client hmget failed, key:{}, fields:{}", key, fields, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Map<String, String> hgetAll(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        Map<String, String> kvMap;
        try {
            kvMap = connection.sync().hgetall(key);
            return kvMap;
        } catch(Exception e) {
            logger.warn("redis client hgetAll failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<String> hkeys(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().hkeys(key);
        } catch(Exception e) {
            logger.warn("redis client hkeys failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Boolean hexists(String key, String field) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().hexists(key, field);
        } catch(Exception e) {
            logger.warn("redis client hset failed, key:{}, field:{}", key, field, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long hdel(String key, String... field) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().hdel(key, field);
        } catch(Exception e) {
            logger.warn("redis client hdel failed, key:{}, field:{}", key, field, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long hlen(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().hlen(key);
        } catch(Exception e) {
            logger.warn("redis client hlen failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long hincrBy(String key, String field, long delta) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().hincrby(key, field, delta);
        } catch(Exception e) {
            logger.warn("redis client hincrBy failed, key:{}, field:{}, delta:{}", key, field, delta, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    /** ======================================= list ====================================== */

    @Override
    public List<String> lrange(String key, long start, long end) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().lrange(key, start, end);
        } catch(Exception e) {
            logger.warn("redis client lrange failed, key:{}, start:{}, end:{}", key, start, end, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public long lpush(String key, String... values) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().lpush(key, values);
        } catch(Exception e) {
            logger.warn("redis client lpush failed, key:{}, values:{}", key, values, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public long rpush(String key, String... values) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().rpush(key, values);
        } catch(Exception e) {
            logger.warn("redis client rpush failed, key:{}, values:{}", key, values, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public String lpop(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().lpop(key);
        } catch(Exception e) {
            logger.warn("redis client lpop failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public String rpop(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().rpop(key);
        } catch(Exception e) {
            logger.warn("redis client rpop failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public long llen(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().llen(key);
        } catch(Exception e) {
            logger.warn("redis client llen failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public long lrem(String key, long count, String value) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().lrem(key, count, value);
        } catch(Exception e) {
            logger.warn("redis client lrem failed, key:{}, count:{}, value:{}", key, count, value, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    /** ============================================= set ============================================= */

    @Override
    public long sadd(String key, String... element) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().sadd(key, element);
        } catch(Exception e) {
            logger.warn("redis client sadd failed, key:{}, element:{}", key, element, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public long srem(String key, String... element) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().srem(key, element);
        } catch(Exception e) {
            logger.warn("redis client srem failed, key:{}, element:{}", key, element, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public boolean sismember(String key, String element) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().sismember(key, element);
        } catch(Exception e) {
            logger.warn("redis client sismember failed, key:{}, element:{}", key, element, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Set<String> smembers(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().smembers(key);
        } catch(Exception e) {
            logger.warn("redis client smembers failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long scard(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().scard(key);
        } catch(Exception e) {
            logger.warn("redis client scard failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    /** ================================================ zset =========================================== */

    @Override
    public Long zadd(String key, double score, String member) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zadd(key, score, member);
        } catch(Exception e) {
            logger.warn("redis client zadd failed, key:{}, score:{}, member:{}", key, score, member, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long zadd(String key, ScoreValue... scoreValues) {
        StatefulRedisConnection<String, String> connection = getConnection();
        Object[] lettuceScoredValue = new Object[scoreValues.length];
        for (int i = 0; i < scoreValues.length; i ++) {
            ScoreValue scoreValue = scoreValues[i];
            lettuceScoredValue[i] = ScoredValue.just(scoreValue.getScore(), scoreValue.getElement());
        }
        try {
            return connection.sync().zadd(key, lettuceScoredValue);
        } catch(Exception e) {
            logger.warn("redis client zadd failed, key:{}, scoreMembers:{}", key, scoreValues, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long zrem(String key, String... members) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrem(key, members);
        } catch(Exception e) {
            logger.warn("redis client zrem failed, key:{}, member:{}", key, members, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long zremrangeByRank(String key, int start, int end) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zremrangebyrank(key, start, end);
        } catch(Exception e) {
            logger.warn("redis client zremrangeByRank failed, key:{}, start:{}, end:{}", key, start, end, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long zremrangeByScore(String key, double start, boolean includeStart, double end, boolean includeEnd) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zremrangebyscore(key, buildRange(start, includeStart, end, includeEnd));
        } catch(Exception e) {
            logger.warn("redis client zremrangeByScore failed, key:{}, start:{}, end:{}", key, start, end, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Double zincrby(String key, double delta, String member) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zincrby(key, delta, member);
        } catch(Exception e) {
            logger.warn("redis client zincrby failed, key:{}, delta:{}, member:{}", key, delta, member, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long zrank(String key, String member) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrank(key, member);
        } catch(Exception e) {
            logger.warn("redis client zrank failed, key:{}, member:{}", key, member, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long zrevrank(String key, String member) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrevrank(key, member);
        } catch(Exception e) {
            logger.warn("redis client zrevrank failed, key:{}, member:{}", key, member, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<String> zrange(String key, int start, int end) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrange(key, start, end);
        } catch(Exception e) {
            logger.warn("redis client zrange failed, key:{}, start:{}, end:{}", key, start, end, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<ScoreValue> zrangeWithScores(String key, int start, int end) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            List<ScoredValue<String>> scoredValueList = connection.sync().zrangeWithScores(key, start, end);
            return convertScoreValue(scoredValueList);
        } catch(Exception e) {
            logger.warn("redis client zrangeWithScores failed, key:{}, start:{}, end:{}", key, start, end, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<String> zrangeByScore(String key, double min, boolean includeMin, double max, boolean includeMax) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrangebyscore(key, buildRange(min, includeMin, max, includeMax));
        } catch(Exception e) {
            logger.warn("redis client zrangeByScore failed, key:{}, min:{}, max:{}", key, min, max, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<ScoreValue> zrangeByScoreWithScores(String key, double min, boolean includeMin, double max, boolean includeMax) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            List<ScoredValue<String>> scoredValueList = connection.sync().zrangebyscoreWithScores(key, buildRange(min, includeMin, max, includeMax));
            return convertScoreValue(scoredValueList);
        } catch(Exception e) {
            logger.warn("redis client zrangeByScoreWithScores failed, key:{}, min:{}, max:{}", key, min, max, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<String> zrangeByScore(String key, double min, boolean includeMin, double max, boolean includeMax, int offset, int count) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrangebyscore(key, buildRange(min, includeMin, max, includeMax), Limit.create(offset, count));
        } catch(Exception e) {
            logger.warn("redis client zrangeByScore failed, key:{}, min:{}, max:{}, offset:{}, count:{}", key, min, max, offset, count, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<ScoreValue> zrangeByScoreWithScores(String key, double min, boolean includeMin, double max, boolean includeMax, int offset, int count) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            List<ScoredValue<String>> scoredValueList = connection.sync().zrangebyscoreWithScores(key, buildRange(min, includeMin, max, includeMax), Limit.create(offset, count));
            return convertScoreValue(scoredValueList);
        } catch(Exception e) {
            logger.warn("redis client zrangeByScoreWithScores failed, key:{}, min:{}, max:{}, offset:{}, count:{}", key, min, max, offset, count, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<String> zrevrange(String key, int start, int end) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrevrange(key, start, end);
        } catch(Exception e) {
            logger.warn("redis client zrevrange failed, key:{}, start:{}, end:{}", key, start, end, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<ScoreValue> zrevrangeWithScores(String key, int start, int end) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            List<ScoredValue<String>> scoredValueList = connection.sync().zrevrangeWithScores(key, start, end);
            return convertScoreValue(scoredValueList);
        } catch(Exception e) {
            logger.warn("redis client zrevrangeWithScores failed, key:{}, start:{}, end:{}", key, start, end, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<String> zrevrangeByScore(String key, double min, boolean includeMin, double max, boolean includeMax) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrevrangebyscore(key, buildRange(min, includeMin, max, includeMax));
        } catch(Exception e) {
            logger.warn("redis client zrevrangeByScore failed, key:{}, min:{}, max:{}", key, min, max, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<ScoreValue> zrevrangeByScoreWithScores(String key, double min, boolean includeMin, double max, boolean includeMax) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            List<ScoredValue<String>> scoredValueList = connection.sync().zrevrangebyscoreWithScores(key, buildRange(min, includeMin, max, includeMax));
            return convertScoreValue(scoredValueList);
        } catch(Exception e) {
            logger.warn("redis client zrevrangeByScoreWithScores failed, key:{}, min:{}, max:{}", key, min, max, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<String> zrevrangeByScore(String key, double min, boolean includeMin, double max, boolean includeMax, int offset, int count) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zrevrangebyscore(key, buildRange(min, includeMin, max, includeMax), Limit.create(offset, count));
        } catch(Exception e) {
            logger.warn("redis client zrevrangeByScore failed, key:{}, min:{}, max:{}, offset:{}, count:{}", key, min, max, offset, count, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public List<ScoreValue> zrevrangeByScoreWithScores(String key, double min, boolean includeMin, double max, boolean includeMax, int offset, int count) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            List<ScoredValue<String>> scoredValueList = connection.sync().zrevrangebyscoreWithScores(key, buildRange(min, includeMin, max, includeMax), Limit.create(offset, count));
            return convertScoreValue(scoredValueList);
        } catch(Exception e) {
            logger.warn("redis client zrevrangeByScoreWithScores failed, key:{}, min:{}, max:{}, offset:{}, count:{}", key, min, max, offset, count, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long zcard(String key) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zcard(key);
        } catch(Exception e) {
            logger.warn("redis client zcard failed, key:{}", key, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Long zcount(String key, double min, boolean includeMin, double max, boolean includeMax) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zcount(key, buildRange(min, includeMin, max, includeMax));
        } catch(Exception e) {
            logger.warn("redis client zcount failed, key:{}, min:{}, max:{}", key, min, max, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    @Override
    public Double zscore(String key, String member) {
        StatefulRedisConnection<String, String> connection = getConnection();
        try {
            return connection.sync().zscore(key, member);
        } catch(Exception e) {
            logger.warn("redis client zscore failed, key:{}, member:{}", key, member, e);
            throw e;
        } finally {
            releaseConnection(connection);
        }
    }

    private List<ScoreValue> convertScoreValue(List<ScoredValue<String>> scoredValueList) {
        List<ScoreValue> convertedList = new LinkedList<>();
        for (ScoredValue<String> scoredValue : scoredValueList) {
            convertedList.add(new ScoreValue(scoredValue.getValue(), scoredValue.getScore()));
        }
        return convertedList;
    }

    private Range<Double> buildRange(double min, boolean includeMin, double max, boolean includeMax) {

        Range<Double> range;
        Range.Boundary<Double> lower;
        Range.Boundary<Double> upper;
        lower = includeMin ? Range.Boundary.including(min) : Range.Boundary.excluding(min);
        upper = includeMax ? Range.Boundary.including(max) : Range.Boundary.excluding(max);
        range = Range.from(lower, upper);

        return range;
    }

}
