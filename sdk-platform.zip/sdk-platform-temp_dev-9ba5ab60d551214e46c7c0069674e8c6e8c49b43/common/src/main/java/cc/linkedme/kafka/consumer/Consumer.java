package cc.linkedme.kafka.consumer;

/**
 *
 * kafka消费端接口
 *
 * @author TianJunfeng(junfeng@linkedme.cc)
 * @create 2017-12-07 上午10:08
 */
public interface Consumer extends Runnable {

    /**
     * 初始化消费者：
     * 1. 读取配置文件，生成KafkaConsumer实例
     */
    void init();


    /**
     * 启动消费端，开始消费kafka中数据
     */
    void start();


    /**
     * 关闭消费端，停止消费kafka中数据
     */
    void stop();

}