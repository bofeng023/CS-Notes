package cc.linkedme.util;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;
import org.apache.commons.lang.StringUtils;

import java.lang.reflect.Constructor;
import java.util.Collection;
import java.util.Map;

public class Preconditions {

    private Preconditions() {}


    /**
     * Ensures that an object reference passed as a parameter|Collection|Map to the calling method is not empty.
     *
     * @param reference an object reference
     * @param exception the exception that expect to throw
     * @return the non-null reference that was validated
     * @throws BusinessException if {@code reference} is null
     */
    public static <T> T checkNotEmpty(T reference, BusinessException exception) {

        if (reference == null) {
            throw exception;
        } else if (reference instanceof Collection && ((Collection) reference).isEmpty()) {
            throw exception;
        } else if (reference instanceof Map && ((Map) reference).isEmpty()) {
            throw exception;
        } else if (StringUtils.isBlank(reference.toString())) {
            throw exception;
        }
        return reference;
    }

    /**
     * Ensures that an object reference passed as a parameter to the calling method is not null.
     *
     * @param reference an object reference
     * @param exception the exception that expect to throw
     * @return the non-null reference that was validated
     * @throws BusinessException if {@code reference} is null
     */
    public static <T> T checkNotNull(T reference, BusinessException exception) {

        if (reference == null) {
            throw exception;
        }
        return reference;
    }

    /**
     * Ensures that an object reference passed as a parameter to the calling method is null.
     *
     * @param reference an object reference
     * @param exception the exception that expect to throw
     * @return the null reference that was validated
     */
    public static <T> T checkNull(T reference, BusinessException exception) {

        if (reference != null) {
            throw exception;
        }
        return null;
    }

    /**
     * Ensures that #reference EQUALS #compare.
     *
     * @param reference an object reference
     * @param compare an object to compare
     * @param exception the exception that expect to throw
     */
    public static <T> void checkEquals(T reference, T compare, BusinessException exception) {

        if (reference != compare) {

            // 如果其中一个是null则肯定不相等
            // 如果class不一致也必然不相等
            if (reference == null || compare == null || reference.getClass() != compare.getClass()) {
                throw exception;
            }

            // 目前只支持Comparable子类型的compare，其他类型地址不一致则认为不相等
            if (reference instanceof Comparable) {
                Comparable ref = (Comparable) reference;

                // 验证值是否一致
                if (ref.compareTo(compare) != 0) {
                    throw exception;
                }
            } else {
                throw exception;
            }
        }
    }

    /**
     * Ensures that #reference NOT EQUALS #compare.
     *
     * @param reference an object reference
     * @param compare an object to compare
     * @param exception the exception that expect to throw
     */
    public static <T> void checkNotEquals(T reference, T compare, BusinessException exception) {

        // 都是null则肯定相等
        if (reference == null && compare == null) {
            throw exception;
        }

        // 两个不都为空时如果地址相同则两个都不为空
        if (reference == compare) {

            if (reference instanceof Comparable) {
                Comparable r = (Comparable) reference;

                if (r.compareTo(compare) == 0) {
                    throw exception;
                }
            } else {
                throw exception;
            }
        }
    }

    /**
     * 通过反射实例化Exception对象并进行throw（性能不好，还是别用了）
     *
     * @param exceptionClazz
     * @param errorCode
     */
    @Deprecated
    private static void doThrow(Class<? extends BusinessException> exceptionClazz, ErrorCode errorCode) {
        try {
            Constructor constructor = exceptionClazz.getDeclaredConstructor(ErrorCode.class);
            Object newInstance = constructor.newInstance(errorCode);
            if (newInstance instanceof BusinessException) {
                throw (BusinessException) constructor.newInstance(errorCode);
            }
        } catch (Exception e) {
            throw new BusinessException(errorCode);
        }
    }

    /**
     * condition check
     * make your code clear & nice :)
     *
     * @param condition if condition == false, do throw
     * @param exception a business exception
     */
    public static void check(Boolean condition, BusinessException exception) {
        if (!condition) {
            throw exception;
        }
    }

    /**
     * 这里function的意义在于可以定制不同的比较模板（闭包）来进行扩展和复用
     * 如果只是简单的比较，且通用性不强，建议使用上面的condition check
     *
     * @param reference
     * @param compare
     * @param function if function returns a false, do throw
     * @param exception a business exception
     */
    public static <R, C> void checkEquals(R reference, C compare, CheckFunction<R, C> function, BusinessException exception) {
        if (!function.check(reference, compare)) {
            throw exception;
        }
    }

    @FunctionalInterface
    public interface CheckFunction<R, C> {
        boolean check(R r, C c);
    }
}
