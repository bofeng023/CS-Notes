package cc.linkedme.kafka;

/**
 * @author zhanghaowei
 * @date 2019-7-18 10:24
 * @description
 **/
public class Topics {

    /**
     * 待发送短信请求topic
     */
    public static final String SMS_SEND = "sms_send";

    /**
     * 异步回调短信状态报告topic
     */
    public static final String SMS_CALLBACK = "sms_callback";

    /**
     * account 消费统计 consumer topic
     */
    public static final String USER_BEHAVIOR_STATISTICS = "user_behavior_statistics";

    /**
     * 语音短信topic
     */
    public static final String VOICE_SMS_SEND = "voice_sms_send";

    /**
     * 异步回调语音通知费用报告topic
     */
    public static final String VOICE_SMS_CALLBACK = "voice_sms_callback";


}
