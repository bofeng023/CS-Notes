package cc.linkedme.kafka.serialization;

import cc.linkedme.serialization.Hessian;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Serializer;

import java.util.Map;

/**
 * @author yangpeng
 * @date 2019-07-30 19:11
 * @description
 **/
public class MqSerializer implements Serializer<Object> {

    @Override
    public void configure(Map configs, boolean isKey) {
    }

    @Override
    public byte[] serialize(String topic, Object data) {
        try {
            return Hessian.serialize(data);
        }
        catch (Exception e) {
            throw new SerializationException(topic + " JsonConverter serializer error", e);
        }
    }

    @Override
    public void close() {
    }

}
