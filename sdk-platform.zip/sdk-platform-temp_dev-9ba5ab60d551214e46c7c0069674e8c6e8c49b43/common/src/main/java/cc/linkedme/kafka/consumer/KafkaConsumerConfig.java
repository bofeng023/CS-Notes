package cc.linkedme.kafka.consumer;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.Properties;

/**
 * @author yangpeng
 * @date 2019-07-16 17:53
 * @description
 **/
@Setter
@Getter
@ToString
public class KafkaConsumerConfig {

    private Properties properties;

    private static final String BOOTSTRAP_SERVERS_CONFIG = "bootstrap.servers";
    private static final String GROUP_ID_CONFIG = "group.id";
    private static final String SESSION_TIMEOUT_MS_CONFIG = "session.timeout.ms";
    private static final String HEARTBEAT_INTERVAL_MS_CONFIG = "heartbeat.interval.ms";
    private static final String ENABLE_AUTO_COMMIT_CONFIG = "enable.auto.commit";
    private static final String AUTO_COMMIT_INTERVAL_MS_CONFIG = "auto.commit.interval.ms";
    private static final String AUTO_OFFSET_RESET_CONFIG = "auto.offset.reset";
    private static final String FETCH_MIN_BYTES_CONFIG = "fetch.min.bytes";
    private static final String FETCH_MAX_WAIT_MS_CONFIG = "fetch.max.wait.ms";
    private static final String METADATA_MAX_AGE_CONFIG = "metadata.max.age.ms";
    private static final String MAX_PARTITION_FETCH_BYTES_CONFIG = "max.partition.fetch.bytes";
    private static final String SEND_BUFFER_CONFIG = "send.buffer.bytes";
    private static final String RECEIVE_BUFFER_CONFIG = "receive.buffer.bytes";
    private static final String CLIENT_ID_CONFIG = "client.id";
    private static final String RECONNECT_BACKOFF_MS_CONFIG = "reconnect.backoff.ms";
    private static final String RETRY_BACKOFF_MS_CONFIG = "retry.backoff.ms";
    private static final String METRICS_SAMPLE_WINDOW_MS_CONFIG = "metrics.sample.window.ms";
    private static final String METRICS_NUM_SAMPLES_CONFIG = "metrics.num.samples";
    private static final String METRIC_REPORTER_CLASSES_CONFIG = "metric.reporters";
    private static final String CHECK_CRCS_CONFIG = "check.crcs";
    private static final String CONNECTIONS_MAX_IDLE_MS_CONFIG = "connections.max.idle.ms";
    private static final String REQUEST_TIMEOUT_MS_CONFIG = "request.timeout.ms";
    private static final String KEY_DESERIALIZER_CLASS_CONFIG = "key.deserializer";
    private static final String VALUE_DESERIALIZER_CLASS_CONFIG = "value.deserializer";

    private static final String COMMIT_INTERVAL_CONFIG = "commit_interval";
    private static final String CONSUMER_TIMEOUT_CONFIG = "consumer_timeout";
    private static final String RESUB_TIME_CONFIG = "resub_time";
    private static final String RESUB_INTERVAL_CONFIG = "resub_interval";

    private String bootstrapServers;
    private String groupId;
    private String value_deserializer = "cc.linkedme.kafka.serialization.MqDeserializer";

    /** offset批量提交个数 */
    private int commitInterval = 1;
    /** consumer超时时间，单位毫秒 */
    private long consumerTimeout = 100;
    /** subscribe重试次数 */
    private int resubTime = 1;
    /** subscribe重试间隔，单位毫秒 */
    private long resubInterval = 1000;

    private int sessionTimeoutMs = 30000;
    private int heartbeatIntervalMs = 10000;
    private boolean enableAutoCommit = false;
    private int autoCommitIntervalMs = 1000;
    private String autoOffsetReset = "latest";
    private int fetchMinBytes = 1;
    private int fetchMaxWaitMs = 500;
    private long metadataMaxAgeMs = 300000;
    private int maxPartitionFetchBytes = 1048576;
    private int sendBufferBytes = 131072;
    private int receiveBufferBytes = 32768;
    private String clientId = "";
    private long reconnectBackoffMs = 50L;
    private long retryBackoffMs = 100L;
    private long metricsSampleWindowMs = 30000;
    private int metricsNumSamples = 2;
    private String metricReporters = "";
    private boolean checkCrcs = true;
    private long connectionsMaxIdleMs = 540000;
    private int requestTimeoutMs = 40000;

    public void init() {

        properties = new Properties();

        properties.put(BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        properties.put(GROUP_ID_CONFIG, groupId);
        properties.put(SESSION_TIMEOUT_MS_CONFIG, sessionTimeoutMs);
        properties.put(HEARTBEAT_INTERVAL_MS_CONFIG, heartbeatIntervalMs);
        properties.put(ENABLE_AUTO_COMMIT_CONFIG, enableAutoCommit);
        properties.put(AUTO_COMMIT_INTERVAL_MS_CONFIG, autoCommitIntervalMs);
        properties.put(AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
        properties.put(FETCH_MIN_BYTES_CONFIG, fetchMinBytes);
        properties.put(FETCH_MAX_WAIT_MS_CONFIG, fetchMaxWaitMs);
        properties.put(METADATA_MAX_AGE_CONFIG, metadataMaxAgeMs);
        properties.put(MAX_PARTITION_FETCH_BYTES_CONFIG, maxPartitionFetchBytes);
        properties.put(SEND_BUFFER_CONFIG, sendBufferBytes);
        properties.put(RECEIVE_BUFFER_CONFIG, receiveBufferBytes);
        properties.put(CLIENT_ID_CONFIG, clientId);
        properties.put(RECONNECT_BACKOFF_MS_CONFIG, reconnectBackoffMs);
        properties.put(RETRY_BACKOFF_MS_CONFIG, retryBackoffMs);
        properties.put(METRICS_SAMPLE_WINDOW_MS_CONFIG, metricsSampleWindowMs);
        properties.put(METRICS_NUM_SAMPLES_CONFIG, metricsNumSamples);
        properties.put(METRIC_REPORTER_CLASSES_CONFIG, metricReporters);
        properties.put(CHECK_CRCS_CONFIG, checkCrcs);
        properties.put(CONNECTIONS_MAX_IDLE_MS_CONFIG, connectionsMaxIdleMs);
        properties.put(REQUEST_TIMEOUT_MS_CONFIG, requestTimeoutMs);
        properties.put(KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        properties.put(VALUE_DESERIALIZER_CLASS_CONFIG, value_deserializer);

        properties.put(COMMIT_INTERVAL_CONFIG, commitInterval);
        properties.put(CONSUMER_TIMEOUT_CONFIG, consumerTimeout);
        properties.put(RESUB_TIME_CONFIG, resubTime);
        properties.put(RESUB_INTERVAL_CONFIG, resubInterval);
    }

    public static void main(String[] args) {
        System.out.println(StringDeserializer.class.getName());
    }

}
