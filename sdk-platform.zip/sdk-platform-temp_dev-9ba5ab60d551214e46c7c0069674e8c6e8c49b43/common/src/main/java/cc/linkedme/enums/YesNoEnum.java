package cc.linkedme.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:35 2019-09-04
 * @:Description
 */
public enum YesNoEnum {

    NO((byte) 0, "否"), YES((byte) 1, "是");

    private Byte index;
    private String desc;

    private static final Map<Byte, YesNoEnum> lookup = new HashMap<Byte, YesNoEnum>();

    static {
        for (YesNoEnum s : EnumSet.allOf(YesNoEnum.class)) {
            lookup.put(s.getIndex(), s);
        }
    }

    public static YesNoEnum get(Byte index) {
        return lookup.get(index);
    }

    YesNoEnum(Byte index, String desc) {
        this.index = index;
        this.desc = desc;
    }

    public Byte getIndex() {
        return this.index;
    }

    public String getDesc() {
        return desc;
    }
}
