package cc.linkedme.kafka.consumer;

import lombok.Setter;
import org.apache.commons.lang.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRebalanceListener;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * @author yangpeng
 * @date 2019-07-16 18:17
 * @description kafak consumer抽象基类，由具体业务方继承实现process处理方法；每个topic单独consumer，避免互相影响消费能力
 **/
public abstract class AbstractKafkaConsumer implements Consumer {

    private static final Logger logger = LoggerFactory.getLogger(AbstractKafkaConsumer.class);

    @Setter
    private KafkaConsumerConfig kafkaConsumerConfig;
    @Setter
    private String topic;

    /**
     * 默认不启动就消费，可以配置成启动就消费
     */
    @Setter
    private Boolean initStartConsuming = false;
    private Boolean isConsuming = false;
    private KafkaConsumer<String, Object> consumer;
    private Map<TopicPartition, OffsetAndMetadata> currentOffsets = new ConcurrentHashMap<>();

    @Override
    public void init() {

        logger.info("consumer consumer begin init, topic:{}, kafkaConsumerConfig:{]", topic, kafkaConsumerConfig);

        if (kafkaConsumerConfig == null) {
            this.kafkaConsumerConfig = new KafkaConsumerConfig();
        }
        if (StringUtils.isBlank(kafkaConsumerConfig.getBootstrapServers())) {
            throw new IllegalArgumentException("consumer consumer bootstrapServers config is null!");
        }
        if (StringUtils.isBlank(kafkaConsumerConfig.getGroupId())) {
            throw new IllegalArgumentException("consumer consumer groupId config is null!");
        }
        if (StringUtils.isBlank(topic)) {
            throw new IllegalArgumentException("consumer consumer topic config is null!");
        }
        initConsumer();
        if (initStartConsuming) {
            start();
        }
    }

    private void initConsumer() {

        logger.info("initConsumer, topic:{}, initStartConsuming:{}, config:{}", topic, initStartConsuming, kafkaConsumerConfig);
        consumer = new KafkaConsumer<>(kafkaConsumerConfig.getProperties());
        consumer.subscribe(Arrays.asList(topic), new ConsumerRebalanceListener() {
            @Override
            public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
                logger.info("consumer partition rebalancing, commit current offset, topic:{}, currentOffsets:{}", topic, currentOffsets);
                consumer.commitSync(currentOffsets);
            }

            @Override
            public void onPartitionsAssigned(Collection<TopicPartition> partitions) {

            }
        });
    }

    @Override
    public void start() {
        if (!isConsuming) {
            isConsuming = true;
            new Thread(this, buildThreadName()).start();
        }
    }

    @Override
    public void stop() {
        consumer.wakeup();
        isConsuming = false;
    }

    @Override
    public void run() {

        while (isConsuming) {
            ConsumerRecords<String, Object> records = null;
            try {
                records = consumer.poll(kafkaConsumerConfig.getConsumerTimeout());
            } catch (WakeupException e) {
                logger.warn("consumer consumer poll records failed, no wakeup, topic:{}, kafkaConsumerConfig:{}", topic, kafkaConsumerConfig, e);
                try {
                    consumer.commitSync(currentOffsets);
                    currentOffsets.clear();
                } finally {
                    consumer.close();
                    isConsuming = false;
                }
            } catch (Exception e) {
                logger.warn("consumer consumer poll records failed, topic:{}, kafkaConsumerConfig:{}", topic, kafkaConsumerConfig, e);
                try {
                    TimeUnit.MILLISECONDS.sleep(kafkaConsumerConfig.getConsumerTimeout());
                } catch (InterruptedException ex) {
                    logger.warn("consumer consumer poll records failed, sleep error, topic:{}, kafkaConsumerConfig:{}", topic, kafkaConsumerConfig, ex);
                }
            }

            if (records == null || records.isEmpty()) {
                continue;
            }

            for (ConsumerRecord<String, Object> record : records) {
                try {
                    logger.debug("consumer record:{}", record);
                    process(record.value());
                    currentOffsets.put(new TopicPartition(record.topic(), record.partition()), new OffsetAndMetadata(record.offset() + 1, "no metadata"));
                    boolean isCommit = currentOffsets.size() >= kafkaConsumerConfig.getCommitInterval() && !kafkaConsumerConfig.isEnableAutoCommit();
                    if (isCommit) {
                        consumer.commitSync(currentOffsets);
                        currentOffsets.clear();
                    }
                } catch (Exception e) {
                    logger.warn("consumer consumer process record failed, topic:{}, record:{}, kafkaConsumerConfig:{}", topic, record, kafkaConsumerConfig, e);

                    /**
                     * 提交已成功消费消息的offset,避免重复消费
                     */
                    consumer.commitSync(currentOffsets);
                    currentOffsets.clear();
                }
            }

        }
    }

    private String buildThreadName() {
        return "KafkaConsumer_" + kafkaConsumerConfig.getBootstrapServers() + "_" + topic + "_" + kafkaConsumerConfig.getGroupId();
    }

    /** 实现类不要catch异常，正常抛出 */
    protected abstract void  process(Object mqEntry);

}
