package cc.linkedme.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * 审核状态
 */
public enum AuditState {
//    NOT_AUDITED(0,"未审核"),
    TO_BE_AUDITED(1,"待审核"),
    AUDITING(2,"审核中"),
    AUDIT_PASS(3,"审核通过"),
    AUDIT_FAIL(4,"审核不通过"),
    SEND_OUT(5,"已寄出"),
    CANCEL(6,"已取消"),
    ANROID_PROCESSED(7,"已处理Android"),
    IOS_PROCESSED(8,"已处理iOS"),
    IOS_ANDROID_PROCESSED(9,"已处理两平台");


    AuditState(int type, String name) {
        this.type = type;
        this.name = name;
    }

    private Integer type;

    private String name;

    public Integer getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    private static final Map<Integer, AuditState> lookup = new HashMap<>();
    static {
        for (AuditState s : EnumSet.allOf(AuditState.class)) {
            lookup.put(s.getType(), s);
        }
    }

    public static AuditState get(Integer type) {
        return lookup.get(type);
    }

}
