package cc.linkedme.cache.redis;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

interface RedisOperation {

    /** =========================================== key ========================================== */

    long del(String... keys);

    Boolean expireAt(String key, Date date);

    Boolean expire(String key, int seconds);

    void rename(String oldKey, String newKey);

    /** =========================================== kv ========================================== */

    void set(String key, Object value);

    void set(String key, String value);

    <T> T get(String key, Class<T> classz);

    String get(String key);

    void mset(final Map<String, String> kvMap);

    <T> Map<String, Object> mget(Class<T> classz, final String... keys);

    Map<String, String> mget(final String... keys);

    /**
     * Set the string value as value of the key. The string can't be longer than 1073741824 bytes (1 GB).
     *
     * @param key
     * @param value
     *        NX|XX, NX -- Only set the key if it does not already exist. XX -- Only set the key if it already exist.
     *        EX|PX, expire time units: EX = seconds; PX = milliseconds
     *        expire time in the units of {@param #expx}
     * @return Status code reply
     */
    Boolean setnx(String key, String value);

    void setex(String key, String value, int seconds);

    Long incrBy(final String key, final long delta);

    Long decrBy(final String key, final long delta);

    Long incr(final String key);

    Long decr(String key);

    Object getSet(String key, String value);

    /** =========================================== zset ========================================== */

    Long zadd(String key, double score, String member);

    Long zadd(String key, ScoreValue... scoreValues);

    Long zrem(String key, String... members);

    Long zremrangeByRank(String key, int start, int end);

    Long zremrangeByScore(String key, double start, boolean includeStart, double end, boolean includeEnd);

    Double zincrby(String key, double score, String member);

    Long zrank(String key, String member);

    Long zrevrank(String key, String member);

    List<String> zrange(String key, int start, int end);

    List<ScoreValue> zrangeWithScores(String key, int start, int end);

    List<String> zrangeByScore(String key, double min, boolean includeMin, double max, boolean includeMax);

    List<ScoreValue> zrangeByScoreWithScores(String key, double min, boolean includeMin, double max, boolean includeMax);

    List<String> zrangeByScore(String key, double min, boolean includeMin, double max, boolean includeMax, int offset, int count);

    List<ScoreValue> zrangeByScoreWithScores(String key, double min, boolean includeMin, double max, boolean includeMax, int offset, int count);

    List<String> zrevrange(String key, int start, int end);

    List<ScoreValue> zrevrangeWithScores(String key, int start, int end);

    List<String> zrevrangeByScore(String key, double min, boolean includeMin, double max, boolean includeMax);

    List<ScoreValue> zrevrangeByScoreWithScores(String key, double min, boolean includeMin, double max, boolean includeMax);

    List<String> zrevrangeByScore(String key, double min, boolean includeMin, double max, boolean includeMax, int offset, int count);

    List<ScoreValue> zrevrangeByScoreWithScores(String key, double min, boolean includeMin, double max, boolean includeMax, int offset, int count);

    Long zcard(String key);

    Long zcount(String key, double min, boolean includeMin, double max, boolean includeMax);

    Double zscore(String key, String member);

    /** =========================================== hash ========================================== */

    void hset(final String key, final String field, final String value);

    String hget(final String key, final String field);

    Map<String, String> hmget(final String key, final String... fields);

    Map<String, String> hgetAll(final String key);

    List<String> hkeys(final String key);

    Boolean hexists(final String key, final String field);

    Long hdel(final String key, final String... field);

    Long hlen(final String key);

    Long hincrBy(final String key, final String field, final long delta);

    /** =========================================== list ========================================== */

    List<String> lrange(String key, long start, long end);

    long lpush(String key, String... values);

    long rpush(String key, String... values);

    String lpop(String key);

    String rpop(String key);

    long llen(String key);

    long lrem(String key, long count, String value);

    /** =========================================== set ========================================== */

    long sadd(String key, String... element);

    long srem(String key, String... element);

    boolean sismember(String key, String element);

    Set<String> smembers(String key);

    Long scard(String key);
}
