package cc.linkedme.kafka.serialization;

import cc.linkedme.kafka.MqEntity;
import cc.linkedme.serialization.Hessian;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Deserializer;

import java.util.Map;

/**
 * @author yangpeng
 * @date 2019-07-30 19:11
 * @description
 **/
public class MqDeserializer implements Deserializer<MqEntity> {

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {
    }


    @Override
    public MqEntity deserialize(String topic, byte[] data) {
        try {
            return Hessian.deserialize(data, MqEntity.class);
        }
        catch (Exception e) {
            throw new SerializationException(topic + " JsonConverter deserializer error", e);
        }
    }

    @Override
    public void close() {

    }
}
