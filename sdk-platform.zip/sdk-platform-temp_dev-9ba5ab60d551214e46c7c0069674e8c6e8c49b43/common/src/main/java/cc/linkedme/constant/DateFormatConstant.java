package cc.linkedme.constant;

/**
 * @Author: liuyunmeng
 * @Date: Create in 16:56 2019-09-20
 * @:Description
 */
public class DateFormatConstant {


    public static final String STANDARD_DATE_FORMAT = "yyyy-MM-dd";

    public static final String STANDARD_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
