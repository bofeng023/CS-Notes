package cc.linkedme.exception;

import cc.linkedme.errorcode.ErrorCode;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BusinessException extends RuntimeException {

    private final ErrorCode errorCode;

    public BusinessException(int errorCode, Object errorMessage) {

        this.errorCode = new ErrorCode(errorCode, errorMessage == null ? null : errorMessage.toString());
    }

}
