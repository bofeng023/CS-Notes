/**
 *
 */
package cc.linkedme.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicBoolean;

public class CommonUtil {

    private static final Logger log = LoggerFactory.getLogger("api");
    /**
     * count debug
     */
    public static AtomicBoolean commonDebug = new AtomicBoolean(false);

    public static boolean isDebugEnabled() {
        return log.isDebugEnabled() && commonDebug.get();
    }

}
