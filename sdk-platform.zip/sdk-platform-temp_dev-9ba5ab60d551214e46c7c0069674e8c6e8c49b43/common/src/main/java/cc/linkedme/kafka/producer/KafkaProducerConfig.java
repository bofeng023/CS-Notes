package cc.linkedme.kafka.producer;

import cc.linkedme.kafka.serialization.MqSerializer;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

/**
 * @author yangpeng
 * @date 2019-07-17 16:59
 * @description
 **/
@Setter
@Getter
@ToString
public class KafkaProducerConfig {

    Properties properties;

    private String bootstrapServers;
    private long bufferMemory = 33554432;
    private String acks = "all";
    private int maxBlockMs = 60000;
    private String compressionType = "none";
    private int retry = 1;
    private int retryBackoffMs = 100;
    private int batchSize = 16384;
    private int lingerMs = 0;
    private int maxInFlightRequestsPerConnection = 5;
    private int maxRequestSize = 1048576;

    public void init () {

        properties = new Properties();

        properties.setProperty("bootstrap.servers", bootstrapServers);
        /** 序列化方式一定要和consumer配置一直 */
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", MqSerializer.class.getName());
        properties.setProperty("acks", acks);
        properties.setProperty("buffer.memory", String.valueOf(bufferMemory));
        properties.setProperty("max.block.ms", String.valueOf(maxBlockMs));
        properties.setProperty("compression.type", compressionType);
        properties.setProperty("retries", String.valueOf(retry));
        properties.setProperty("retry.backoff.ms", String.valueOf(retryBackoffMs));
        properties.setProperty("batch.size", String.valueOf(batchSize));
        properties.setProperty("linger.ms", String.valueOf(lingerMs));
        properties.setProperty("max.in.flight.requests.per.connection", String.valueOf(maxInFlightRequestsPerConnection));
        properties.setProperty("max.request.size", String.valueOf(maxRequestSize));
    }

}
