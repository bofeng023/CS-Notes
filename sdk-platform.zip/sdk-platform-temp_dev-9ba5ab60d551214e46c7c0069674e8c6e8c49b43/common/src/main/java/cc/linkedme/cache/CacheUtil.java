package cc.linkedme.cache;

import com.google.common.collect.Lists;
import org.apache.commons.lang.StringUtils;

import java.util.Date;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * @author yangpeng
 * @date 2019-06-26 11:16
 * @description
 **/
public abstract class CacheUtil {

    private static final String SEPARATOR = "_";

    public static String genKey(Object... factors) {
        return StringUtils.join(Lists.transform(Lists.newArrayList(factors), factor -> {
            checkNotNull(factor);
            if (factor instanceof Date) {
                return ((Date) factor).getTime();
            }
            return factor;
        }).toArray(), SEPARATOR);
    }

    /**
     * 先从cache中取值, 如果cache中有, 直接返回, 如果没有, 再从db或者其它地方(数据真实存在的地方)取值, 并处理 该值, 如更新cache中的内容
     *
     * @param key
     * @param cacheFactory
     * @param persistFactory
     * @param flushCache
     * @param <K>
     * @param <V>
     * @return
     */
    public static <K, V> V getValue(K key, ObjectFactory<K, V> cacheFactory, ObjectFactory<K, V> persistFactory,
                                    FlushCacheCallback<V>  flushCache) {
        V obj = cacheFactory.get(key);
        if (obj == null) {
            obj = persistFactory.get(key);
            if (obj != null) {
                flushCache.flush(obj);
            }
            return obj;

        }
        return obj;
    }

    /**
     * 对象查询工厂, 缓存或者持久化
     *
     * @param <K> 查询key值
     * @param <V> 查询结果
     */
    @FunctionalInterface
    public interface ObjectFactory<K, V> {
        V get(K key);
    }

    /**
     * 从持久化存储中回种到cache中
     *
     * @param <V> 最新对象
     */
    @FunctionalInterface
    public interface FlushCacheCallback<V> {
        void flush(V obj);
    }

}
