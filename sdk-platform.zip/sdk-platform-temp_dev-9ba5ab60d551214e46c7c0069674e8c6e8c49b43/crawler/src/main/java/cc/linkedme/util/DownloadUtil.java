package cc.linkedme.util;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;


/**
 * @Author: liuyunmeng
 * @Date: Create in 10:58 2019-09-17
 * @:Description
 */
public class DownloadUtil {

    private static final Logger logger = LoggerFactory.getLogger(DownloadUtil.class);

    public static void download(String fileUrl, String storagePath)  {

        logger.info("download, fileUrl:{}, storagePath:{}", fileUrl, storagePath);

        Preconditions.checkNotNull(fileUrl, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(storagePath, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));

        DataInputStream in = null;
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(storagePath);
            URL url = new URL(fileUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(10000);
            int code = conn.getResponseCode();
            /**
             * 下载出现域名转换问题，301错误，重定向到其他网页
             */
            if (code == HttpURLConnection.HTTP_MOVED_PERM) {
                String redirectUrl = conn.getHeaderField("Location");
                url = new URL(redirectUrl);
                conn = (HttpURLConnection) url.openConnection();
            }
            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new Exception("下载失败"); // todo
            }
            // 读文件流
            in = new DataInputStream(conn.getInputStream());
            byte[] buffer = new byte[2048];
            int count = 0;
            while ((count = in.read(buffer)) > 0) {
                out.write(buffer, 0, count);
            }
            in.close();
        } catch (Exception e) {
            logger.error("Fail to download, fileUrl:{}", fileUrl, e);
        } finally {
            try {
                if (null != out) {
                    out.close();
                }
                if (null != in) {
                    in.close();
                }
            } catch (Exception e) {
                logger.error("close fail , fileUrl:{}", fileUrl, e);
            }
        }
    }
}
