package cc.linkedme.service;

import cc.linkedme.crawler.AppCrawler;
import cc.linkedme.json.JsonConverter;
import cc.linkedme.task.DownloadTask;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:38 2019-09-17
 * @:Description
 */
public class DownloadService {


    private static final Logger logger = LoggerFactory.getLogger(DownloadService.class);
    /**
     * 固定10条线程
     */
    private static final Integer nThreads = 10;

    private static ExecutorService executorService = Executors.newFixedThreadPool(nThreads);

    public static void download(String fileUrl, String storagePath) {

        logger.info("download, fileUrl:{}", fileUrl);

        DownloadTask downloadWorker = new DownloadTask(fileUrl, storagePath);
        executorService.submit(downloadWorker);
    }

    public static void main(String[] args) {

        File file = new File("/data1/crawler/FuZhuGongJu.log");
        try {
            FileInputStream fis = new FileInputStream(file);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            String line = null;
            while ((line = br.readLine()) != null) {
                AppCrawler.AppInfo appInfo = JsonConverter.parse(line, AppCrawler.AppInfo.class);
                String downloadUrl = appInfo.getDownloadUrl();
                if (StringUtils.isNotBlank(downloadUrl)) {
                    downloadUrl = downloadUrl.replace("http", "https");
                    download(downloadUrl, "/data1/crawler/FuZhuGongJu/"+appInfo.getAppName()+"-"+appInfo.getAppPackageName()+".apk");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
