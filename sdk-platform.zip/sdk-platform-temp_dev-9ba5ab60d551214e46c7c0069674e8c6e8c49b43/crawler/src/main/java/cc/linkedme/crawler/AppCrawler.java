package cc.linkedme.crawler;

import cc.linkedme.json.JsonConverter;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author yangpeng
 * @date 2019-09-16 20:36
 * @description
 **/
public class AppCrawler {

    private static final Logger logger = LoggerFactory.getLogger(AppCrawler.class);
    private static CloseableHttpClient httpclient = HttpClients.custom().build();
    private static ObjectMapper objectMapper = new ObjectMapper();

    public static void main(String[] args) throws IOException {

        List<String> categoryList = new ArrayList<>(20);
        categoryList.add("考试学习:5026:KaoShiXueXi");
        categoryList.add("网上购物:5017:WangShangGouWu");
        categoryList.add("金融理财:5023:JinRongLiCai");
        categoryList.add("生活休闲:5020:ShengHuoXiuXian");
        categoryList.add("旅行出游:5021:LvXingChuYou");
        categoryList.add("健康运动:5028:JianKangYunDong");
        categoryList.add("办公商务:5022:BanGongShangWu");
        categoryList.add("育儿亲子:5027:YuErQinZi");
        categoryList.add("休闲益智:6001:XiuXianYiZhi");
        categoryList.add("跑酷竞速:6003:PaoKuJingSu");
        categoryList.add("扑克棋牌:6008:PuKeQiPai");
        categoryList.add("动作冒险:6004:DongZuoMaoXian");
        categoryList.add("飞行射击:6002:FeiXingSheJi");
        categoryList.add("经营策略:6007:JingYingCeLue");
        categoryList.add("网络游戏:6009:WangLuoYouXi");
        categoryList.add("体育竞技:6005:TiYuJingJi");
        categoryList.add("角色扮演:6006:JueSeBanYan");
        categoryList.add("辅助工具:5015:FuZhuGongJu");
        for (String desc : categoryList) {
            String[] detail = StringUtils.split(desc,":");
            List<AppInfo> appList = getAppList(detail[1], detail[0]);
            FileWriter fw=new FileWriter (new File("/Users/linkedme/crawler/"+detail[2]+".log"), true);
            BufferedWriter bw= new BufferedWriter(fw);
            for (AppInfo appInfo : appList) {
                appInfo = getAppDetail(appInfo);
                bw.write(JsonConverter.format(appInfo));
                bw.newLine();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println(appList.size());
            bw.close();
        }






    }


    private static AppInfo getAppDetail(AppInfo appInfo) {

        logger.info("getAppDetail start, appInfo:{}", appInfo);
        String appDetailUrlPrefix = "https://www.wandoujia.com/apps/";
        String appDetailUrl = appDetailUrlPrefix + appInfo.getAppId();

        Connection connection = Jsoup.connect(appDetailUrl)
                .timeout(5000)
                .header("Accept", "text/html, */*; q=0.01")
                .header("Accept-Encoding", "gzip, deflate")
                .header("Accept-Language", "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3")
                .header("Content-Type", "application/json; charset=utf-8")
                .header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36")
                .ignoreContentType(true);
        Document document = null;
        try {
            int statusCode = connection.response().statusCode();
            if (0 != statusCode) {
                logger.info("fetch fail, appId:{}, appName:{}, categoryId:{}, categoryName:{}, statusCode:{}", appInfo.getAppId(), appInfo.getAppName(), appInfo.getCategoryId(), appInfo.getCategoryName(), statusCode);
                return appInfo;
            }
            document = connection.get();
        } catch (Exception e) {
            logger.error("getAppDetail, appInfo:{}", appInfo, e);
            return appInfo;
        }
        Elements detailWrapElements = document.select("div.container")
                .select("div.detail-wrap");
        Elements downloadElements = detailWrapElements.select("a.normal-dl-btn");
        String appDownloadUrl = downloadElements.attr("href");
        appInfo.setDownloadUrl(appDownloadUrl);

        Elements developerElements = detailWrapElements.select("span.dev-sites");
        Element element = developerElements.first();
        if (element != null) {
            String developerName = element.text();
            appInfo.setDeveloperName(developerName);
        }
        logger.info("getAppDetail end, appInfo:{}", appInfo);
        return appInfo;
    }

    private static List<AppInfo> getAppList(String categoryId, String categoryName) throws IOException {

        logger.info("getAppList, categoryId:{}, categoryName:{}", categoryId, categoryName);
        List<AppInfo> appInfoList = new LinkedList<>();
        String appCategoryUrlPrefix = "https://www.wandoujia.com/wdjweb/api/category/more?catId=" + categoryId + "&subCatId=0&page=";

        int page = 0;
        while (true) {

            page ++;
            String appCategoryUrl = appCategoryUrlPrefix + page;
            logger.info("getAppList, categoryId:{}, appCategoryUrl:{}", categoryId, appCategoryUrl);

            String appListResponse = requestHttp(appCategoryUrl);
            logger.info("getAppList, categoryId:{}, appListResponse:{}", categoryId, appListResponse);
            Map<String, Map<String, Object>> appListResponseMap = objectMapper.readValue(appListResponse, Map.class);
            Map<String, Object> dataMap = appListResponseMap.get("data");
            Integer currPage = (int) dataMap.get("currPage");
            String content = (String) dataMap.get("content");
            if (currPage == -1) {
                break;
            }

            Element element = Jsoup.parse(content);
            Elements liElements = element.getElementsByTag("li");
            for (Element liElement : liElements) {
                Elements aElements = liElement.select("a.detail-check-btn");
                String appId = aElements.attr("data-app-id");
                String appName = aElements.attr("data-app-name");
                String appPackageName = aElements.attr("data-app-pname");
                String appVersion = aElements.attr("data-app-vname");
                AppInfo appInfo = new AppInfo();
                appInfo.setAppId(appId);
                appInfo.setAppName(appName);
                appInfo.setAppPackageName(appPackageName);
                appInfo.setAppVersion(appVersion);

                appInfo.setCategoryId(categoryId);
                appInfo.setCategoryName(categoryName);
                appInfo.setCategoryPageNo(page);
                appInfo.setCategoryResponsePageNo(currPage);

                appInfoList.add(appInfo);
            }

        }

        return appInfoList;
    }

    private static String requestHttp(String url) throws IOException {
        HttpGet httpGet = new HttpGet(url);
        try (CloseableHttpResponse response = httpclient.execute(httpGet)) {
            return EntityUtils.toString(response.getEntity(), "gb2312");
        }
    }

    @Data
    public static class AppInfo {

        private String categoryId;
        private String categoryName;
        private Integer categoryPageNo;
        private Integer categoryResponsePageNo;

        private String appId;
        private String appName;
        private String appPackageName;
        private String appVersion;

        private String downloadUrl;
        private String developerName;
    }

}

