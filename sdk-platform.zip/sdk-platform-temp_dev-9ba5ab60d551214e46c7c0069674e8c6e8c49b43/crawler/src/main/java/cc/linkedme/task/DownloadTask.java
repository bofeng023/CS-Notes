package cc.linkedme.task;

import cc.linkedme.util.DownloadUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @Author: liuyunmeng
 * @Date: Create in 12:25 2019-09-17
 * @:Description
 */
public class DownloadTask implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(DownloadTask.class);
    private String fileUrl;
    private String storagePath;

    public DownloadTask(String url, String storagePath) {
        this.fileUrl = url;
        this.storagePath = storagePath;
    }

    @Override
    public void run() {
        logger.info("run, fileUrl:{}, path:{}", fileUrl, storagePath);
        DownloadUtil.download(fileUrl, storagePath);
    }
}
