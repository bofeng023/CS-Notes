package cc.linkedme.account.service.impl;

import cc.linkedme.account.common.http.CloseableHttpClientUtil;
import cc.linkedme.json.JsonConverter;
import cc.linkedme.account.common.punctuation.Punctuation;
import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.enums.provider.sms.SmsCallbackStatus;
import cc.linkedme.account.enums.provider.sms.SmsResponseCode;
import cc.linkedme.account.enums.provider.sms.VoiceSmsCallbackStatus;
import cc.linkedme.account.enums.provider.sms.huawei.HuaweiSmsCallbackStatus;
import cc.linkedme.account.errorcode.SmsErrorCode;
import cc.linkedme.account.exception.AccountBalanceException;
import cc.linkedme.account.exception.SmsException;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.model.callback.SmsCallbackRequest;
import cc.linkedme.account.model.callback.VoiceSmsCallbackRequest;
import cc.linkedme.account.model.sms.SmsCallbackInfo;
import cc.linkedme.account.model.sms.SmsExtend;
import cc.linkedme.account.model.sms.SmsFrequencyInfo;
import cc.linkedme.account.model.sms.SmsInfo;
import cc.linkedme.account.model.sms.SmsTextKey;
import cc.linkedme.account.model.sms.VoiceSmsCallbackInfo;
import cc.linkedme.account.model.sms.VoiceSmsInfo;
import cc.linkedme.account.service.AccountBalanceService;
import cc.linkedme.account.service.SmsFrequencyService;
import cc.linkedme.account.service.SmsService;
import cc.linkedme.cache.CacheUtil;
import cc.linkedme.cache.redis.RedisClientUtil;
import cc.linkedme.enums.BizType;
import cc.linkedme.kafka.MqEntity;
import cc.linkedme.kafka.Topics;
import cc.linkedme.kafka.producer.MqProducer;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * 短信服务
 *
 * @author yangpeng
 * @date 2019-06-25 16:25
 **/

@Service
public class SmsServiceImpl implements SmsService {

    static Logger logger = LoggerFactory.getLogger(SmsServiceImpl.class);

    private static final String HEADER_CONTENT_TYPE = "application/json";

    /**
     * sms redis 过期时间
     */
    private static final int SMS_EXPIRE_HOUR = (int) TimeUnit.HOURS.toSeconds(6L);

    /**
     * http response 状态码
     */
    private static final int HTTP_RESPONSE_SUCCESS_STATUS_CODE = 200;

    private static final int EXPIRE_MINUTE = (int) TimeUnit.MINUTES.toSeconds(1L);
    private static final int EXPIRE_HOUR = (int) TimeUnit.HOURS.toSeconds(1L);
    private static final int EXPIRE_DAY = (int) TimeUnit.DAYS.toSeconds(1L);

    /**
     * 计费规则：短信字数<=70个字数，按照70个字数一条短信计算；短信字数>70个字数，即为长短信，按照67个字数记为一条短信计算，不区分中英文
     */
    private static final int SINGLE_SMS_LENGTH = 70;
    private static final int MULTI_SMS_LENGTH = 67;

    @Resource
    private RedisClientUtil smsDbRedisClient;

    @Resource
    private AccountBalanceService accountBalanceService;

    @Resource
    private MqProducer mqProducer;

    @Resource
    private SmsFrequencyService smsFrequencyService;

    @Resource
    private CloseableHttpClientUtil closeableHttpClientUtil;

    private void addTextToMessageQueue(SmsInfo smsInfo) {
        logger.info("addTextToMessageQueue, smsInfo:{}", smsInfo);

        MqEntity mqEntry = new MqEntity(Topics.SMS_SEND, smsInfo);
        mqProducer.send(mqEntry);
    }

    @Override
    public void asyncHandleProviderTextCallback(SmsCallbackInfo smsCallbackInfo) throws SmsException {
        logger.info("asyncHandleProviderTextCallback, smsCallbackInfo:{}", smsCallbackInfo);

        MqEntity mqEntry = new MqEntity(Topics.SMS_CALLBACK, smsCallbackInfo);
        mqProducer.send(mqEntry);
    }

    @Override
    public void asyncHandleProviderVoiceCallback(VoiceSmsCallbackInfo voiceSmsCallbackInfo) throws SmsException {

        logger.info("asyncHandleProviderVoiceCallback, voiceSmsCallbackInfo:{}", voiceSmsCallbackInfo);

        MqEntity mqEntry = new MqEntity(Topics.VOICE_SMS_CALLBACK, voiceSmsCallbackInfo);
        mqProducer.send(mqEntry);
    }

    @Override
    public boolean sendVoiceCallback(VoiceSmsCallbackInfo voiceSmsCallbackInfo) throws SmsException {

        logger.info("sendVoiceCallback, voiceSmsCallbackInfo:{}", voiceSmsCallbackInfo);

        VoiceSmsCallbackRequest voiceSmsCallbackRequest = new VoiceSmsCallbackRequest();
        BeanUtils.copyProperties(voiceSmsCallbackInfo, voiceSmsCallbackRequest);

        SmsExtend smsExtend = SmsExtend.parse(voiceSmsCallbackInfo.getExtend());
        String key = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getContractId(), voiceSmsCallbackInfo.getRecipient());
        //替换msgId
        String msgIdKey = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getSessionId(), voiceSmsCallbackInfo.getRecipient());
        String platformSmsMsgId = smsDbRedisClient.get(msgIdKey);
        voiceSmsCallbackRequest.setMsgId(platformSmsMsgId);

        // 退款
        if (voiceSmsCallbackInfo.getCallOutAnswerTime() == null) {
            refund(key, 1, String.valueOf(smsExtend.getUid()), BizType.VOICE_SMS);
        }

        // 解析华为短信状态为平台短信状态
        parseVoiceSmsCallBackStatus(voiceSmsCallbackInfo, voiceSmsCallbackRequest);

        SmsTextKey smsTextKey = smsDbRedisClient.get(key, SmsTextKey.class);

        // 回调地址

        String callbackUrl = smsTextKey.getCallback();
        logger.info("sendVoiceCallback, voiceSmsCallbackInfo:{}, platformSmsMsgId:{}, huaweiMsgId:{}, callbackUrl:{}", voiceSmsCallbackInfo, platformSmsMsgId, voiceSmsCallbackInfo.getMsgId(), callbackUrl);
        if (!StringUtils.isNotBlank(callbackUrl)) {
            return true;
        }

        // 扩展字段值
        String oldExtend = smsTextKey.getExtend();
        voiceSmsCallbackRequest.setExtend(oldExtend != null ? oldExtend : "");

        Integer statusCode = 0;
        try {
            String body = JsonConverter.format(voiceSmsCallbackRequest);
            logger.info("sendVoiceCallback, voiceSmsCallbackInfo:{}, callbackUrl:{}, body:{}", voiceSmsCallbackInfo, callbackUrl, body);

            Map<String, String> headerMap = new HashMap<>(1);
            headerMap.put(HttpHeaders.CONTENT_TYPE, HEADER_CONTENT_TYPE);

            HttpResponse response = closeableHttpClientUtil.httpPost(callbackUrl, headerMap, body);
            statusCode = response.getStatusLine().getStatusCode();

        } catch (Exception e) {
            logger.error("sendVoiceCallback, voiceSmsCallbackInfo:{}, callbackUrl:{}, statusCode:{}", voiceSmsCallbackInfo, callbackUrl, statusCode, e);

            throw new SmsException(SmsErrorCode.VOICE_SMS_CALLBACK_REQUEST_FAIL);
        }

        logger.error("sendVoiceCallback, voiceCallbackInfo:{}, callbackUrl:{}, statusCode:{}", voiceSmsCallbackInfo, callbackUrl, statusCode);
        return statusCode == HTTP_RESPONSE_SUCCESS_STATUS_CODE;
    }


    @Override
    public boolean sendTextCallback(SmsCallbackInfo smsCallbackInfo) throws SmsException {
        logger.info("sendTextCallback, smsCallbackInfo:{}", smsCallbackInfo);

        SmsExtend smsExtend = SmsExtend.parse(smsCallbackInfo.getExtend());

        String key = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getContractId(), smsCallbackInfo.getRecipient());
        //替换msgId
        String msgIdKey = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getSessionId(), smsCallbackInfo.getRecipient());

        //退款
        if (!HuaweiSmsCallbackStatus.get(smsCallbackInfo.getStatus()).equals(HuaweiSmsCallbackStatus.DELIVRD)
                && !HuaweiSmsCallbackStatus.get(smsCallbackInfo.getStatus()).equals(HuaweiSmsCallbackStatus.ACCEPTD)) {
            refund(key, 1, String.valueOf(smsExtend.getUid()), BizType.TEXT_SMS);
        }

        String platformSmsMsgId = smsDbRedisClient.get(msgIdKey);
        smsCallbackInfo.setMsgId(platformSmsMsgId);

        //解析华为短信状态为平台短信状态
        parseSmsCallbackStatus(smsCallbackInfo);

        SmsTextKey smsTextKey = smsDbRedisClient.get(key, SmsTextKey.class);
        //回调地址
        String callbackUrl = smsTextKey.getCallback();
        logger.info("sendTextCallback, smsCallBackInfo:{}, platformSmsMsgId:{}, huaweiSmsMsgId:{}, callbackUrl:{}", smsCallbackInfo, platformSmsMsgId, smsCallbackInfo.getMsgId(), callbackUrl);
        //扩展字段值
        String oldExtend = smsTextKey.getExtend();
        smsCallbackInfo.setExtend(oldExtend != null ? oldExtend : "");

        SmsCallbackRequest smsCallbackRequest = new SmsCallbackRequest();
        BeanUtils.copyProperties(smsCallbackInfo, smsCallbackRequest);

        Integer statusCode = 0;
        try {

            String body = JsonConverter.format(smsCallbackRequest);
            logger.info("sendTextCallback, smsCallbackRequest:{}, callBackUrl:{}, body:{}", smsCallbackRequest, callbackUrl, body);

            Map<String, String> headerMap = new HashMap<>(1);
            headerMap.put(HttpHeaders.CONTENT_TYPE, HEADER_CONTENT_TYPE);

            if (StringUtils.isNotEmpty(callbackUrl)) {
                HttpResponse response = closeableHttpClientUtil.httpPost(callbackUrl, headerMap, body);
                statusCode = response.getStatusLine().getStatusCode();
            } else {
                statusCode = HTTP_RESPONSE_SUCCESS_STATUS_CODE;
            }

        } catch (Exception e) {
            logger.error("sendTextCallback, smsCallbackInfo:{}, callBackUrl:{}, statusCode:{}", smsCallbackInfo, callbackUrl, statusCode, e);
            throw new SmsException(SmsErrorCode.SMS_CALLBACK_REQUEST_FAIL);
        }

        logger.info("sendTextCallback, smsCallbackInfo:{}, callBackUrl:{}, statusCode:{}", smsCallbackInfo, callbackUrl, statusCode);

        return statusCode == HTTP_RESPONSE_SUCCESS_STATUS_CODE;
    }

    /**
     * 解析华为短信回调状态
     *
     * @param smsCallbackInfo 短信回调报告信息
     */
    private void parseSmsCallbackStatus(SmsCallbackInfo smsCallbackInfo) {
        switch (HuaweiSmsCallbackStatus.get(smsCallbackInfo.getStatus())) {
            case DELIVRD:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.DELIVRD.getCode(), SmsCallbackStatus.DELIVRD.getMsg());
                break;
            case EXPIRED:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.EXPIRED.getCode(), SmsCallbackStatus.EXPIRED.getMsg());
                break;
            case DELETED:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.DELETED.getCode(), SmsCallbackStatus.DELETED.getMsg());
                break;
            case UNDELIV:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.UNDELIV.getCode(), SmsCallbackStatus.UNDELIV.getMsg());
                break;
            case ACCEPTD:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.ACCEPTD.getCode(), SmsCallbackStatus.ACCEPTD.getMsg());
                break;
            case REJECTD:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.REJECTD.getCode(), SmsCallbackStatus.REJECTD.getMsg());
                break;
            case RTE_ERR:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.RTE_ERR.getCode(), SmsCallbackStatus.RTE_ERR.getMsg());
                break;
            case MILIMIT:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.MILIMIT.getCode(), SmsCallbackStatus.MILIMIT.getMsg());
                break;
            case LIMIT:
            case BEYONDN:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.LIMIT.getCode(), SmsCallbackStatus.LIMIT.getMsg());
                break;
            case KEYWORD:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.KEYWORD.getCode(), SmsCallbackStatus.KEYWORD.getMsg());
                break;
            case BLACK:
            case MBBLACK:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.BLACK.getCode(), SmsCallbackStatus.BLACK.getMsg());
                break;
            case PHONE_INVALID:
            case PHONE_INCORRECT:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.PHONE_INVALID.getCode(), SmsCallbackStatus.PHONE_INVALID.getMsg());
                break;
            default:
                smsCallbackInfo.setStatusMsg(SmsCallbackStatus.FAIL.getCode(), SmsCallbackStatus.FAIL.getMsg());
                break;
        }
    }

    /**
     * 解析华为语音通知费用回调状态
     *
     * @param voiceSmsCallbackInfo
     * @param voiceSmsCallbackRequest
     */
    private void parseVoiceSmsCallBackStatus(VoiceSmsCallbackInfo voiceSmsCallbackInfo, VoiceSmsCallbackRequest voiceSmsCallbackRequest) {
        switch (voiceSmsCallbackInfo.getHuaweiVoiceSmsCallBackStatus()) {
            case SUCCESS:
                voiceSmsCallbackRequest.setStatus(VoiceSmsCallbackStatus.SUCCESS.getStatus());
                break;
            case CALLING_TIMEOUT:
            case RINGING_TIMEOUT:
            case LOCAL_USER_ACTIVE_CANCEL:
                voiceSmsCallbackRequest.setStatus(VoiceSmsCallbackStatus.NO_ANSWER.getStatus());
                break;
            default:
                voiceSmsCallbackRequest.setStatus(VoiceSmsCallbackStatus.OTHER.getStatus());
                break;
        }
    }


    /**
     * 发送短信/语音短信失败退款
     *
     * @param key     缓存key
     * @param count   短信条数
     * @param uid     用户ID
     * @param bizType 业务类型
     */
    @Override
        public void refund(String key, int count, String uid, BizType bizType) {
        logger.info("refund, key:{}, count:{}, uid:{}, bizType:{}", key, count, uid, bizType);

        try {
            SmsTextKey smsTextKey = smsDbRedisClient.get(key, SmsTextKey.class);
            BalanceUnitPrice balanceUnitPrice = smsTextKey.getBalanceUnitPrice();
            accountBalanceService.refund(Integer.parseInt(uid), bizType, balanceUnitPrice, Channel.SMS_HUAWEI, count);

            logger.info("refund, key:{}, count:{}, uid:{}, bizType:{}, balanceUnitPrice:{}", key, count, uid, bizType, balanceUnitPrice);
        } catch (Exception e) {
            logger.error("refund, key:{}, count:{}, uid:{}, bizType:{}", key, count, uid, bizType, e);
            throw new SmsException(SmsErrorCode.SMS_REFUND_AMOUNT_FAIL);
        }
    }


    @Override
    public void asyncSendVoice(VoiceSmsInfo voiceSmsInfo) throws SmsException {
        logger.info("asyncSendVoice, voiceSmsInfo:{}", voiceSmsInfo);

        //扣费按1次
        BalanceUnitPrice balanceUnitPrice = accountBalanceService.consume(voiceSmsInfo.getUid(), BizType.VOICE_SMS, Channel.SMS_HUAWEI, 1);
        voiceSmsInfo.setContractId(balanceUnitPrice.getContractId());
        logger.info("asyncSendVoice, voiceSmsInfo:{}, balanceUnitPrice:{}", voiceSmsInfo, balanceUnitPrice);

        //设置语音短信回调信息
        addVoiceCallbackInfo(voiceSmsInfo, balanceUnitPrice);

        //扩展字段
        SmsExtend smsExtend = new SmsExtend();
        smsExtend.setUid(voiceSmsInfo.getUid());
        smsExtend.setAppId(voiceSmsInfo.getAppId());
        smsExtend.setContractId(voiceSmsInfo.getContractId());
        smsExtend.setSessionId(voiceSmsInfo.getSessionId());
        voiceSmsInfo.setExtend(smsExtend.toString());
        logger.info("asyncSendVoice, voiceSmsInfo:{}, smsExtend:{}", voiceSmsInfo, smsExtend);

        addVoiceToMessageQueue(voiceSmsInfo);
    }

    private void addVoiceToMessageQueue(VoiceSmsInfo voiceSmsInfo) throws SmsException {
        logger.info("addVoiceToMessageQueue, voiceSmsInfo:{}", voiceSmsInfo);

        MqEntity mqEntry = new MqEntity(Topics.VOICE_SMS_SEND, voiceSmsInfo);
        mqProducer.send(mqEntry);
    }

    private void addVoiceCallbackInfo(VoiceSmsInfo voiceSmsInfo, BalanceUnitPrice balanceUnitPrice) {
        logger.info("setVoiceCallbackInfo, voiceSmsInfo:{}, balanceUnitPrice:{}", voiceSmsInfo, balanceUnitPrice);

        String recipient = voiceSmsInfo.getRecipient();
        String key = CacheUtil.genKey(voiceSmsInfo.getAppId(), voiceSmsInfo.getContractId(), recipient);
        try {
            SmsTextKey smsTextKey = new SmsTextKey();
            smsTextKey.setBalanceUnitPrice(balanceUnitPrice);
            smsTextKey.setCallback(voiceSmsInfo.getStatusCallbackUrl());
            smsTextKey.setExtend(voiceSmsInfo.getExtend());
            smsDbRedisClient.setex(key, JsonConverter.format(smsTextKey), SMS_EXPIRE_HOUR);

            //发号器
            String sessionId = UUID.randomUUID().toString();
            String msgIdKey = CacheUtil.genKey(voiceSmsInfo.getAppId(), sessionId, recipient);
            smsDbRedisClient.setex(msgIdKey, sessionId, SMS_EXPIRE_HOUR);

            logger.info("setVoiceCallbackInfo, voiceSmsInfo:{}, sessionId:{}, key:{}, msgIdKey:{}, extend:{}", voiceSmsInfo, sessionId, key, msgIdKey, voiceSmsInfo.getExtend());
            voiceSmsInfo.setSessionId(sessionId);
        } catch (Exception e) {
            logger.error("addVoiceCallbackInfo, voiceSmsInfo:{}, extend:{}", voiceSmsInfo, voiceSmsInfo.getExtend(), e);
            refund(key, 1, String.valueOf(voiceSmsInfo.getUid()), BizType.VOICE_SMS);
            throw new SmsException(SmsErrorCode.VOICE_SMS_SET_INFO_FAIL);
        }
    }

    /**
     * 扣费并发送短信
     *
     * @param smsInfo 用户请求信息
     * @return
     */
    @Override
    public void asyncSendText(SmsInfo smsInfo) {
        logger.info("asyncSendText, smsInfo:{}", smsInfo);

        int textContentCount = 1;
        if (smsInfo.getContent().length() > SINGLE_SMS_LENGTH) {
            textContentCount = smsInfo.getContent().length() / MULTI_SMS_LENGTH + (smsInfo.getContent().length() % MULTI_SMS_LENGTH > 0 ? 1 : 0);
        }
        String[] recipientArr = StringUtils.split(smsInfo.getRecipient(), Punctuation.COMMA);
        int recipientArrLength = recipientArr.length;

        Map<Integer, BalanceUnitPrice> splitContract = consumeText(smsInfo.getUid(), recipientArrLength, textContentCount);

        List<SmsInfo.SendResult> result = new ArrayList<>();

        Map<String, String> recipientMap = new HashMap<>();
        // 全部短信扣费成功后才开始发送短信
        String sessionId = UUID.randomUUID().toString();
        Iterator<Map.Entry<Integer, BalanceUnitPrice>> iterator = splitContract.entrySet().iterator();
        Map.Entry<Integer, BalanceUnitPrice> startEntry = null;
        Map.Entry<Integer, BalanceUnitPrice> nextEntry = null;
        int endExclusive = recipientArrLength;
        while (iterator.hasNext()) {
            if (startEntry == null) {
                startEntry = iterator.next();
            } else if (nextEntry != null) {
                startEntry = nextEntry;
            }
            if (iterator.hasNext()) {
                nextEntry = iterator.next();
                endExclusive = nextEntry.getKey();
            }
            prepareSendText(sessionId, smsInfo.getUid(), smsInfo.getAppId(), smsInfo, textContentCount, startEntry.getKey(), endExclusive, startEntry.getValue(), result, recipientMap);
        }
        if (nextEntry != null) {
            prepareSendText(sessionId, smsInfo.getUid(), smsInfo.getAppId(), smsInfo, textContentCount, endExclusive, recipientArrLength, nextEntry.getValue(), result, recipientMap);
        }
        smsInfo.setResult(result);

        logger.info("sendText result, smsInfo:{}, result:{}", smsInfo, result);
    }

    /**
     * 扣费，如果同一次请求被多个合同消费，则返回消费的Map对象
     *
     * @param uid                用户id
     * @param recipientArrLength 要发送的手机号数量
     * @param textContentCount   单次短信的发送条数
     * @return Map对象，key：消费该合同的号码在用户号码串中的起始索引 value：被消费的合同对象
     */
    private Map<Integer, BalanceUnitPrice> consumeText(int uid, int recipientArrLength, int textContentCount) {
        logger.info("consumeText, uid:{}, recipientArrLength:{}, textContentCount:{}", uid, recipientArrLength, textContentCount);

        int currentContractId = -1;
        Map<Integer, BalanceUnitPrice> splitContract = new TreeMap<>();
        for (int i = 0; i < recipientArrLength; i++) {
            try {
                BalanceUnitPrice balanceUnitPrice = accountBalanceService.consume(uid, BizType.TEXT_SMS, Channel.SMS_HUAWEI, textContentCount);
                if (currentContractId == -1) {
                    currentContractId = balanceUnitPrice.getContractId();
                    splitContract.put(0, balanceUnitPrice);
                }
                // 之前的合同id与现在的合同id不同，已经从不同的合同中开始扣费
                if (balanceUnitPrice.getContractId() != currentContractId) {
                    splitContract.put(i, balanceUnitPrice);
                }
            } catch (AccountBalanceException ex) {
                logger.info("sms consume not quotas, refund quotas that has consumed on this request, splitContract:{}", splitContract);

                // 一次请求中如果扣费异常，则返还之前所扣金额，不会发送任何一条短信
                Iterator<Map.Entry<Integer, BalanceUnitPrice>> iterator = splitContract.entrySet().iterator();
                Map.Entry<Integer, BalanceUnitPrice> startEntry = null;
                Map.Entry<Integer, BalanceUnitPrice> nextEntry = null;
                int endIndex = i;
                while (iterator.hasNext()) {
                    if (startEntry == null) {
                        startEntry = iterator.next();
                    } else if (nextEntry != null) {
                        startEntry = nextEntry;
                    }
                    if (iterator.hasNext()) {
                        nextEntry = iterator.next();
                        endIndex = nextEntry.getKey();
                    }
                    if (endIndex - startEntry.getKey() > 0) {
                        accountBalanceService.refund(uid, BizType.TEXT_SMS,
                                startEntry.getValue(), Channel.SMS_HUAWEI, (endIndex - startEntry.getKey()) * textContentCount);
                    }
                }
                if (nextEntry != null) {
                    if (i - endIndex > 0) {
                        accountBalanceService.refund(uid, BizType.TEXT_SMS,
                                nextEntry.getValue(), Channel.SMS_HUAWEI, (i - endIndex) * textContentCount);
                    }
                }

                throw new SmsException(SmsErrorCode.NO_QUOTAS);
            }
        }

        logger.info("consumeText result, uid:{}, recipientArrLength:{}, textContentCount:{}, splitContract:{}", uid, recipientArrLength, textContentCount, splitContract);

        return splitContract;
    }

    /**
     * 异步发送短信
     *
     * @param sessionId        会话id
     * @param uid
     * @param appId
     * @param smsRequest
     * @param textContentCount
     * @param startInclusive
     * @param endExclusive
     * @param balanceUnitPrice
     * @param result
     * @param recipientMap
     */
    private void prepareSendText(String sessionId, int uid, int appId, SmsInfo smsRequest,
                                 int textContentCount, int startInclusive, int endExclusive, BalanceUnitPrice balanceUnitPrice,
                                 List<SmsInfo.SendResult> result, Map<String, String> recipientMap) {
        logger.info("asyncSendText, sessionId:{}, uid:{}, appId:{}, smsRequest:{}, textContentCount:{}, startInclusive:{}, endExclusive:{}, balanceUnitPrice:{}, result:{}, recipientMap:{}", sessionId, uid, appId, smsRequest, textContentCount, startInclusive, endExclusive, balanceUnitPrice, result, recipientMap);

        SmsInfo smsInfoBatch = new SmsInfo();
        BeanUtils.copyProperties(smsRequest, smsInfoBatch);
        String[] recipientArr = StringUtils.split(smsRequest.getRecipient(), Punctuation.COMMA);
        smsInfoBatch.setRecipient(StringUtils.join(ArrayUtils.subarray(recipientArr, startInclusive, endExclusive), Punctuation.COMMA));

        SmsFrequencyInfo smsFrequencyInfo = smsFrequencyService.getSmsFrequency(null, uid);


        StringBuilder recipientBuilder = new StringBuilder();
        for (int i = startInclusive; i < endExclusive; i++) {

            SmsInfo.SendResult smsResult = new SmsInfo.SendResult();
            String status = SmsResponseCode.SUCCESS.getCode();

            smsResult.setOriginTo(recipientArr[i]);
            smsResult.setCreateTime(System.currentTimeMillis());
            String msgId = UUID.randomUUID().toString();
            smsResult.setSmsMsgId(msgId);

            String phone = recipientArr[i];
            String frequencyMinuteKey = CacheUtil.genKey(appId, smsInfoBatch.getSignId(), phone, "minute");
            String frequencyHourKey = CacheUtil.genKey(appId, smsInfoBatch.getSignId(), phone, "hour");
            String frequencyDayKey = CacheUtil.genKey(appId, smsInfoBatch.getSignId(), phone, "day");

            // 校验重复手机号
            if (recipientMap.containsKey(phone)) {
                logger.info("sms text recipient repeat, sessionId:{}, uid:{}, appId:{}, balanceUnitPrice:{}, textContentCount:{}", sessionId, uid, appId, balanceUnitPrice, textContentCount);
                // 重复手机号
                status = SmsResponseCode.SEND_FREQUENCY_DAY_LIMIT.getCode();
            } else {
                recipientMap.put(phone, StringUtils.EMPTY);
                String verifyTextFrequencyStatus = verifyTextFrequency(smsFrequencyInfo, status, frequencyDayKey, frequencyHourKey, frequencyMinuteKey);
                if (verifyTextFrequencyStatus.equals(status)) {
                    recipientBuilder.append(phone);
                    recipientBuilder.append(Punctuation.COMMA);
                } else {
                    status = verifyTextFrequencyStatus;
                }
            }

            smsResult.setStatus(status);


            if (status.equals(SmsResponseCode.SUCCESS.getCode())) {
                updateTextCache(appId, sessionId, msgId, balanceUnitPrice, smsInfoBatch.getStatusCallbackUrl(), smsInfoBatch.getExtend(), recipientArr[i], textContentCount, frequencyDayKey, frequencyHourKey, frequencyMinuteKey);
            } else {
                accountBalanceService.refund(uid, BizType.TEXT_SMS, balanceUnitPrice, Channel.SMS_HUAWEI, textContentCount);
            }
            result.add(smsResult);

        }
        String validRecipient = recipientBuilder.toString();
        if (validRecipient.length() > 0) {
            smsInfoBatch.setRecipient(validRecipient.substring(0, validRecipient.length() - 1));
            // 借用用户的extend参数，在发送短信的服务中取出透传给华为
            SmsExtend smsExtend = new SmsExtend();
            smsExtend.setUid(uid);
            smsExtend.setAppId(appId);
            smsExtend.setContractId(balanceUnitPrice.getContractId());
            smsExtend.setSessionId(sessionId);

            smsInfoBatch.setExtend(smsExtend.toString());
            addTextToMessageQueue(smsInfoBatch);
        }

        logger.info("asyncSendText result, sessionId:{}, uid:{}, appId:{}, smsRequest:{}, textContentCount:{}, startInclusive:{}, endExclusive:{}, balanceUnitPrice:{}, result:{}, recipientMap:{}, smsRequestInfoBatch:{}", sessionId, uid, appId, smsRequest, textContentCount, startInclusive, endExclusive, balanceUnitPrice, result, recipientMap, smsInfoBatch);
    }

    /**
     * 校验频次
     *
     * @param smsFrequencyInfo
     * @param status
     * @param frequencyDayKey
     * @param frequencyHourKey
     * @param frequencyMinuteKey
     * @return 返回校验结果，未超过频次限制则返回传入的status
     */
    private String verifyTextFrequency(SmsFrequencyInfo smsFrequencyInfo, String status, String frequencyDayKey, String frequencyHourKey, String frequencyMinuteKey) {
        logger.info("verifyTextFrequency, smsFrequencyInfo:{}, status:{}, frequencyDayKey:{}, frequencyHourKey:{}, frequencyMinuteKey:{}", smsFrequencyInfo, status, frequencyDayKey, frequencyHourKey, frequencyMinuteKey);

        int countPerDay = smsFrequencyInfo.getCountPerDay();
        int countPerHour = smsFrequencyInfo.getCountPerHour();
        int countPerMinute = smsFrequencyInfo.getCountPerMinute();

        String frequencyDayValue = smsDbRedisClient.get(frequencyDayKey);
        String frequencyHourValue = smsDbRedisClient.get(frequencyHourKey);
        String frequencyMinuteValue = smsDbRedisClient.get(frequencyMinuteKey);

        int frequencyDay = frequencyDayValue == null ? 0 : Integer.parseInt(frequencyDayValue);
        int frequencyHour = frequencyHourValue == null ? 0 : Integer.parseInt(frequencyHourValue);
        int frequencyMinute = frequencyMinuteValue == null ? 0 : Integer.parseInt(frequencyMinuteValue);

        if (frequencyDay >= countPerDay) {
            status = SmsResponseCode.SEND_FREQUENCY_DAY_LIMIT.getCode();
        } else if (frequencyHour >= countPerHour) {
            status = SmsResponseCode.SEND_FREQUENCY_HOUR_LIMIT.getCode();
        } else if (frequencyMinute >= countPerMinute) {
            status = SmsResponseCode.SEND_FREQUENCY_MINUTE_LIMIT.getCode();
        }
        logger.info("verifyTextFrequency result, smsFrequencyInfo:{}, status:{}, frequencyDayKey:{}, frequencyHourKey:{}, frequencyMinuteKey:{}", smsFrequencyInfo, status, frequencyDayKey, frequencyHourKey, frequencyMinuteKey);
        return status;
    }

    /**
     * 更新文本短信缓存数据
     * 此处存了两个key，不能合为一个key，第一key解决的是同一个请求相同手机号不同扣费的问题，
     * 第二个key解决同一次请求likedme生成的msgId与华为msgId绑定的问题
     *
     * @param appId
     * @param sessionId
     * @param msgId
     * @param balanceUnitPrice
     * @param statusCallbackUrl
     * @param extend
     * @param recipient
     * @param textContentCount
     * @param frequencyDayKey
     * @param frequencyHourKey
     * @param frequencyMinuteKey
     */
    private void updateTextCache(int appId, String sessionId, String msgId, BalanceUnitPrice balanceUnitPrice, String statusCallbackUrl, String extend, String recipient, int textContentCount, String frequencyDayKey, String frequencyHourKey, String frequencyMinuteKey) {
        logger.info("updateTextCache, appId:{}, sessionId:{}, msgId:{}, balanceUnitPrice:{}, statusCallbackUrl:{}, extend:{}, recipient:{}, textContentCount:{}, frequencyDayKey:{}, frequencyHourKey:{}, frequencyMinuteKey:{}", appId, sessionId, msgId, balanceUnitPrice, statusCallbackUrl, extend, recipient, textContentCount, frequencyDayKey, frequencyHourKey, frequencyMinuteKey);

        String key = CacheUtil.genKey(appId, balanceUnitPrice.getContractId(), recipient);
        SmsTextKey smsTextKey = new SmsTextKey();
        smsTextKey.setCallback(statusCallbackUrl);
        smsTextKey.setBalanceUnitPrice(balanceUnitPrice);
        smsTextKey.setContentCount(textContentCount);
        smsTextKey.setUnitPrice(balanceUnitPrice.getTextSmsUnitPrice());
        smsTextKey.setExtend(extend);
        smsDbRedisClient.setex(key, JsonConverter.format(smsTextKey), SMS_EXPIRE_HOUR);
        String msgIdKey = CacheUtil.genKey(appId, sessionId, recipient);
        smsDbRedisClient.setex(msgIdKey, msgId, SMS_EXPIRE_HOUR);

        long incrResult;
        incrResult = smsDbRedisClient.incr(frequencyMinuteKey);
        if (incrResult == 1L) {
            // 新增key，设置过期时间
            smsDbRedisClient.expire(frequencyMinuteKey, EXPIRE_MINUTE);
        }
        incrResult = smsDbRedisClient.incr(frequencyHourKey);
        if (incrResult == 1L) {
            smsDbRedisClient.expire(frequencyMinuteKey, EXPIRE_HOUR);
        }
        incrResult = smsDbRedisClient.incr(frequencyDayKey);
        if (incrResult == 1L) {
            smsDbRedisClient.expire(frequencyMinuteKey, EXPIRE_DAY);
        }
    }

}
