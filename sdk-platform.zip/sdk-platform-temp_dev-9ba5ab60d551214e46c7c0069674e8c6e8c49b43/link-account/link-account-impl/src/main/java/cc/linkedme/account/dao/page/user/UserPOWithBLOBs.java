package cc.linkedme.account.dao.page.user;

import lombok.Data;

@Data
public class UserPOWithBLOBs extends UserPO {
    private String dspNote;

    private String sspNote;

}