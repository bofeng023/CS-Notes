package cc.linkedme.account.dao.account.audit;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AuditInfoPOMapper {
    long countByExample(AuditInfoPOExample example);

    int deleteByExample(AuditInfoPOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuditInfoPO record);

    int insertSelective(AuditInfoPO record);

    List<AuditInfoPO> selectByExample(AuditInfoPOExample example);

    AuditInfoPO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuditInfoPO record, @Param("example") AuditInfoPOExample example);

    int updateByExample(@Param("record") AuditInfoPO record, @Param("example") AuditInfoPOExample example);

    int updateByPrimaryKeySelective(AuditInfoPO record);

    int updateByPrimaryKey(AuditInfoPO record);
}