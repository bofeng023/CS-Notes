package cc.linkedme.account.dao.account.invoice;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InvoicePOMapper {
    long countByExample(InvoicePOExample example);

    int deleteByExample(InvoicePOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InvoicePO record);

    int insertSelective(InvoicePO record);

    List<InvoicePO> selectByExample(InvoicePOExample example);

    InvoicePO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InvoicePO record, @Param("example") InvoicePOExample example);

    int updateByExample(@Param("record") InvoicePO record, @Param("example") InvoicePOExample example);

    int updateByPrimaryKeySelective(InvoicePO record);

    int updateByPrimaryKey(InvoicePO record);

    List<InvoicePO> selectByExampleWithLimit(@Param("example") InvoicePOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);

//    InvoicePO getInvoiceAndAuditInfo(@Param("id") Integer id, @Param("bizType") Integer bizType);

    Long countInvoiceAmount(InvoicePOExample example);
}