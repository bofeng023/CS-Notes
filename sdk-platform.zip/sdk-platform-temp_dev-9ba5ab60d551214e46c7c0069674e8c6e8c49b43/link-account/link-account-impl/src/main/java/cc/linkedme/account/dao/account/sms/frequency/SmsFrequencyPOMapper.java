package cc.linkedme.account.dao.account.sms.frequency;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SmsFrequencyPOMapper {
    long countByExample(SmsFrequencyPOExample example);

    int deleteByExample(SmsFrequencyPOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SmsFrequencyPO record);

    int insertSelective(SmsFrequencyPO record);

    List<SmsFrequencyPO> selectByExample(SmsFrequencyPOExample example);

    SmsFrequencyPO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SmsFrequencyPO record, @Param("example") SmsFrequencyPOExample example);

    int updateByExample(@Param("record") SmsFrequencyPO record, @Param("example") SmsFrequencyPOExample example);

    int updateByPrimaryKeySelective(SmsFrequencyPO record);

    int updateByPrimaryKey(SmsFrequencyPO record);
}