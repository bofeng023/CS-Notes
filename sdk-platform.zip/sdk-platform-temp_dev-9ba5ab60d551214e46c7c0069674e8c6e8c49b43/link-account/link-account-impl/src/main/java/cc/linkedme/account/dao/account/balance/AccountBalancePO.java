package cc.linkedme.account.dao.account.balance;

import lombok.Data;

import java.util.Date;

@Data
public class AccountBalancePO {
    private Integer id;

    private Integer uid;

    private Integer amount;

    private Integer balance;

    private Date gmtCreate;

    private Date gmtModified;
}