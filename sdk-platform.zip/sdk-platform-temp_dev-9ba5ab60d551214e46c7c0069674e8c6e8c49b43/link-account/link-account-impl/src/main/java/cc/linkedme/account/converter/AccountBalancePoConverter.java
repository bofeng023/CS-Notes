package cc.linkedme.account.converter;

import cc.linkedme.account.dao.account.balance.AccountBalancePO;
import cc.linkedme.account.model.AccountBalanceInfo;
import org.springframework.beans.BeanUtils;

/**
 * @author zhanghaowei
 * @date 2019-6-5 10:17
 * @description
 **/
public class AccountBalancePoConverter {

    public static AccountBalancePO bo2Po(AccountBalanceInfo accountBalanceBO) {
        AccountBalancePO accountBalancePO = new AccountBalancePO();
        BeanUtils.copyProperties(accountBalanceBO,accountBalancePO);
        return accountBalancePO;
    }

    public static AccountBalanceInfo po2Bo(AccountBalancePO accountBalancePO) {
        AccountBalanceInfo accountBalanceBO = new AccountBalanceInfo();
        BeanUtils.copyProperties(accountBalancePO,accountBalanceBO);
        return accountBalanceBO;
    }
}
