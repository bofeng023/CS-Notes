package cc.linkedme.account.service.impl;

import cc.linkedme.account.common.http.HttpClientUtil;
import cc.linkedme.account.constants.MessageConstants;
import cc.linkedme.account.converter.UserPoConverter;
import cc.linkedme.account.dao.page.user.UserPOExample;
import cc.linkedme.account.dao.page.user.UserPOMapper;
import cc.linkedme.account.dao.page.user.UserPOWithBLOBs;
import cc.linkedme.account.enums.MessageType;
import cc.linkedme.account.enums.RechargeType;
import cc.linkedme.account.errorcode.AuthConfigErrorCode;
import cc.linkedme.account.errorcode.UserErrorCode;
import cc.linkedme.account.exception.AuditInfoException;
import cc.linkedme.account.exception.AuthConfigException;
import cc.linkedme.account.exception.UserInfoException;
import cc.linkedme.account.model.AppInfo;
import cc.linkedme.account.model.MessageInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.TopUpInfo;
import cc.linkedme.account.model.UserInfo;
import cc.linkedme.account.service.MessageService;
import cc.linkedme.account.service.OperativeActivityService;
import cc.linkedme.account.service.UserService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.util.Preconditions;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 用户信息实现
 * @author zhanghaowei
 */
@Service("userService")
public class UserServiceImpl implements UserService {

    private static final String ERR_CODE = "err_code";
    private static final String ERR_MSG = "err_msg";

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Resource
    private UserPOMapper userPOMapper;

    @Resource
    private MessageService messageService;

    @Resource
    private OperativeActivityService operativeActivityService;

    @Value("#{config.link_page_url}")
    private String linkPageUrl;
    /**
     * 通过多个用户ID 获取多个用户信息接口地址
     */
    @Value("#{config.user_info_ids_list_url}")
    private String userInfoIdsUrl;
    /**
     * 账户认证审核 url
     */
    @Value("#{config.account_authentication_update_audit_url}")
    private String accountAuditUrl;
    /**
     * linkAccount 开通审核url
     */
    @Value("#{config.account_opening_update_audit_url}")
    private String openingUpdateAuditUrl;
    /**
     * 账户认证列表url
     */
    @Value("#{config.account_authentication_list_url}")
    private String accountListUrl;
    /**
     * 账户认证查看url
     */
    @Value("#{config.account_authentication_get_url}")
    private String accountGetUrl;
    /**
     * 账户开通列表url
     */
    @Value("#{config.account_opening_list_url}")
    private String openingListUrl;
    @Value("#{config.user_info_url_email}")
    private String userInfoUrlEmail;


    @Value("#{config.get_user_token}")
    private String userTokenUrl;

    @Value("#{config.get_app_info}")
    private String appInfoUrl;

    @Value("#{config.info_by_key}")
    private String infoByKeyUrl;

    @Resource
    private HttpClientUtil httpClientUtil;

    private static DateTime dateTime = new DateTime();

    @Override
    public Map<Integer, UserInfo> batchUserInfoBOByIds(List<Integer> idsList) {

        Preconditions.checkNotNull(idsList, new AuditInfoException(UserErrorCode.ID_NULL_ERROR));

        Map<String, String> paramsMap = new HashMap<>();
        String ids = idsList.stream().map(id -> String.valueOf(id))
                .collect(Collectors.joining(","));
        paramsMap.put("batch_user_id",ids);

        String responseResult = getHttpResponseResult(linkPageUrl + userInfoIdsUrl, paramsMap, null);

        List<UserInfo> userInfoList = new ArrayList<>();
        JSONObject responseJsonObject = JSONObject.fromObject(responseResult);
        if (responseJsonObject.containsKey("ret")) {
            JSONArray jsonArray = (JSONArray) responseJsonObject.get("ret");
            for (int i = 0; i < jsonArray.size(); i++) {
                ObjectMapper objectMapper = new ObjectMapper();
                try {
                    UserInfo userInfo = objectMapper.readValue(jsonArray.get(i).toString()
                            , UserInfo.class);
                    userInfoList.add(userInfo);
                } catch (IOException e) {
                    throw new AuditInfoException(UserErrorCode.USER_RESPONSE_FORMAT_ERROR);
                }
            }
        } else if (responseJsonObject.containsKey(ERR_CODE)) {
            throw new UserInfoException(new ErrorCode(Integer.parseInt(responseJsonObject.get(ERR_CODE).toString()), responseJsonObject.get(ERR_MSG).toString()));
        }

        Map<Integer, UserInfo> userInfoBOMap = userInfoList.stream().collect(Collectors.toMap(UserInfo::getUid, a -> a,(k1, k2)->k1));

        return userInfoBOMap;
    }

    @Override
    public Integer updateAccountAudit(UserInfo userInfo) throws UserInfoException {

        String requestUrl = "";
        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put("audit_state", String.valueOf(userInfo.getAuditState().getType()));
        paramsMap.put("audit_remark", userInfo.getAuditRemark());
        if (BizType.ACCOUNT_AUTHENTICATION.equals(userInfo.getBizType())) {

            if (userInfo.getAuditState().getType() == AuditState.AUDIT_FAIL.getType()) {
                MessageInfo messageInfo = new MessageInfo();
                messageInfo.setMessageType(MessageType.SYSTEM_MSG);
                messageInfo.setSenderId(MessageConstants.ADMINISTRATOR_ID);
                messageInfo.setSendTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                messageInfo.setTitle("您的账号认证未审核通过，请重新提交审核！");
                messageInfo.setReceiverId(userInfo.getUid());
                messageInfo.setContent("您的账号未审核通过，原因：<strong>" + userInfo.getAuditRemark() + "</strong><br/> 请尽快重新提交审核，以免影响您使用LinkedME产品，任何问题或疑问请联系QQ群：639389757，感谢您的理解和支持。");
                messageService.sendMsg(messageInfo);
            } else if (userInfo.getAuditState().getType() == AuditState.AUDIT_PASS.getType()) {
                MessageInfo messageInfo = new MessageInfo();
                messageInfo.setMessageType(MessageType.SYSTEM_MSG);
                messageInfo.setSenderId(MessageConstants.ADMINISTRATOR_ID);
                messageInfo.setReceiverId(userInfo.getUid());
                messageInfo.setSendTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                messageInfo.setTitle("【通知】您的账号已通过认证，邀您体验新品LinkAccount！");
                messageInfo.setContent(" 恭喜您已通过账号认证，LinkedME赠送您的5000次认证流量已充值到您的账号中，邀您免费试用<a style='color: #428bca' href=https://www.linkedme.cc/linkaccount.html>LinkAccount</a>产品，请您速速集成<a style='color: #428bca' href=https://pagedoc.lkme.cc/linkaccount/linkaccount-integrated-document>SDK</a>，体验一键登录&账号认证为您带来的便捷吧！<br/>如您在产品使用过程中，遇到一些问题，欢迎添加LinkedME用户服务QQ群进行反馈，群号：639389757。");
                messageService.sendMsg(messageInfo);
                /**
                 * 如果该账号为子账号，给主账号和子账号发送消息
                 */
                UserInfo userInfoByUid = getUserInfoByUid(userInfo.getUid());
                if (userInfoByUid.getPid() != -1) {
                    messageInfo.setReceiverId(userInfo.getPid());
                    messageService.sendMsg(messageInfo);
                }
                TopUpInfo topUpInfo = new TopUpInfo();
                topUpInfo.setUid(userInfo.getUid());
                topUpInfo.setRechargeType(RechargeType.GIFT_RECHARGE);
                operativeActivityService.giftMoney(topUpInfo);

            }
            paramsMap.put("user_id", String.valueOf(userInfo.getUid()));
            requestUrl = accountAuditUrl;

        } else if (BizType.ACCOUNT_OPENING.equals(userInfo.getBizType())) {
            paramsMap.put("app_id", String.valueOf(userInfo.getAppId()));
            paramsMap.put("product_identity", String.valueOf(userInfo.getProductIdentity()));
            requestUrl = openingUpdateAuditUrl;
        }

        String responseCode = getHttpResponseResult(linkPageUrl + requestUrl, paramsMap, null);
        logger.info("updateAccountAudit, userInfo:{}, responseCode:{}" ,userInfo,responseCode);
        return 1;
    }

    @Override
    public UserInfo getUserInfo(Integer uid) throws UserInfoException {

        Map<String, String> params = new HashMap<>();
        params.put("user_id", String.valueOf(uid));

        String userInfoResponse = getHttpResponseResult(linkPageUrl + accountGetUrl, params, null);

        UserInfo userInfo;
        JSONObject userInfoJsonObject = JSONObject.fromObject(userInfoResponse);
        if (!userInfoJsonObject.containsKey(ERR_CODE)) {
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                userInfo = objectMapper.readValue(userInfoJsonObject.toString(), UserInfo.class);
            } catch (IOException e) {
                throw new UserInfoException(BaseErrorCode.FAIL);
            }
        } else {
            throw new UserInfoException(BaseErrorCode.FAIL);
        }

        return userInfo;
    }

    @Override
    public UserInfo getUserInfoByEmail(String email) throws UserInfoException {
        
        Map<String, String> params = new HashMap<>();
        params.put("email", email);
        
        UserInfo userInfo = new UserInfo();
        String userInfoResponse = getHttpResponseResult(linkPageUrl + userInfoUrlEmail, params, null);
        JSONObject jsonObject = JSONObject.fromObject(userInfoResponse);
        if (!jsonObject.containsKey(ERR_CODE)) {
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                userInfo = objectMapper.readValue(jsonObject.toString(), UserInfo.class);
            } catch (IOException e) {
                throw new UserInfoException(UserErrorCode.USER_RESPONSE_FORMAT_ERROR);
            }
        }
        return userInfo;
    }

    @Override
    public List<UserInfo> listAccountAuthentication(SearchParam searchParam) throws UserInfoException {

        Map<String, String> paramsMap = new HashMap<>();
        if (StringUtils.isNotEmpty(searchParam.getEmail())) {
            paramsMap.put("email", searchParam.getEmail());
        }
        if (StringUtils.isNotEmpty(searchParam.getCompany())) {
            paramsMap.put("company", searchParam.getCompany());
        }
        if (searchParam.getAuditState() != null) {
            paramsMap.put("audit_state", searchParam.getAuditState() + "");
        }
        if (searchParam.getStartDate() != null) {
            dateTime = new DateTime(searchParam.getStartDate());
            paramsMap.put("start_date", dateTime.toString("yyyy-MM-dd HH:mm:ss"));
        }
        if (searchParam.getEndDate() != null) {
            dateTime = new DateTime(searchParam.getEndDate());
            paramsMap.put("end_date", dateTime.toString("yyyy-MM-dd HH:mm:ss"));
        }


        paramsMap.put("skip_number", (searchParam.getPage() - 1) * searchParam.getSize() + "");
        paramsMap.put("return_number", searchParam.getSize() + "");
        logger.info("listAccountAuthentication, paramsMap:{}", paramsMap);

        String userInfoResponse = getHttpResponseResult(linkPageUrl + accountListUrl, paramsMap, null);

        List<UserInfo> userInfoList = new ArrayList<>();
        JSONObject userInfoJsonObject = JSONObject.fromObject(userInfoResponse);
        packageUserInfo(userInfoList,userInfoJsonObject);
        return userInfoList;
    }

    @Override
    public Long countAccountAuthentication(SearchParam searchParam) throws UserInfoException {
        Map<String, String> paramsMap = new HashMap<>();
        if (StringUtils.isNotEmpty(searchParam.getEmail())) {
            paramsMap.put("email", searchParam.getEmail());
        }
        if (StringUtils.isNotEmpty(searchParam.getCompany())) {
            paramsMap.put("company", searchParam.getCompany());
        }
        if (searchParam.getAuditState() != null) {
            paramsMap.put("audit_state", searchParam.getAuditState() + "");
        }
        if (searchParam.getStartDate() != null) {
            dateTime = new DateTime(searchParam.getStartDate());
            paramsMap.put("start_date", dateTime.toString("yyyy-MM-dd HH:mm:ss"));
        }
        if (searchParam.getEndDate() != null) {
            dateTime = new DateTime(searchParam.getEndDate());
            paramsMap.put("end_date", dateTime.toString("yyyy-MM-dd HH:mm:ss"));
        }
        paramsMap.put("skip_number", "0");
        paramsMap.put("return_number", "10");
        String userInfoResponse = getHttpResponseResult(linkPageUrl + accountListUrl, paramsMap, null);
        JSONObject userInfoJsonObject = JSONObject.fromObject(userInfoResponse);
        return countUserInfo(userInfoJsonObject);
    }

    @Override
    public List<UserInfo> listAccountOpening(SearchParam searchParam) throws UserInfoException {

        Map<String, String> paramsMap = new HashMap<>();
        if (StringUtils.isNotEmpty(searchParam.getEmail())) {
            paramsMap.put("email", searchParam.getEmail());
        }
        if (StringUtils.isNotEmpty(searchParam.getAppName())) {
            paramsMap.put("app_name", searchParam.getAppName());
        }
        if (searchParam.getAuditState() != null) {
            paramsMap.put("audit_state", searchParam.getAuditState() + "");
        }
        if (searchParam.getStartDate() != null) {
            dateTime = new DateTime(searchParam.getStartDate());
            paramsMap.put("start_date", dateTime.toString("yyyy-MM-dd HH:mm:ss"));
        }
        if (searchParam.getEndDate() != null) {
            dateTime = new DateTime(searchParam.getEndDate());
            paramsMap.put("end_date", dateTime.toString("yyyy-MM-dd HH:mm:ss"));
        }
        paramsMap.put("skip_number", (searchParam.getPage() - 1) * searchParam.getSize() + "");
        paramsMap.put("return_number", searchParam.getSize() + "");

        String userInfoResponse = getHttpResponseResult(linkPageUrl + openingListUrl, paramsMap, null);

        List<UserInfo> userInfoList = new ArrayList<>();
        JSONObject userInfoJsonObject = JSONObject.fromObject(userInfoResponse);
        packageUserInfo(userInfoList,userInfoJsonObject);
        return userInfoList;
    }

    @Override
    public Long countAccountOpening(SearchParam searchParam) throws UserInfoException {
        Map<String, String> paramsMap = new HashMap<>();
        if (StringUtils.isNotEmpty(searchParam.getEmail())) {
            paramsMap.put("email", searchParam.getEmail());
        }
        if (StringUtils.isNotEmpty(searchParam.getCompany())) {
            paramsMap.put("app_name", searchParam.getAppName());
        }
        if (searchParam.getAuditState() != null) {
            paramsMap.put("audit_state", searchParam.getAuditState() + "");
        }
        if (searchParam.getStartDate() != null) {
            dateTime = new DateTime(searchParam.getStartDate());
            paramsMap.put("start_date", dateTime.toString("yyyy-MM-dd HH:mm:ss"));
        }
        if (searchParam.getEndDate() != null) {
            dateTime = new DateTime(searchParam.getEndDate());
            paramsMap.put("end_date", dateTime.toString("yyyy-MM-dd HH:mm:ss"));
        }
        paramsMap.put("skip_number", "0");
        paramsMap.put("return_number", "10");
        String userInfoResponse = getHttpResponseResult(linkPageUrl + openingListUrl, paramsMap, null);
        JSONObject userInfoJsonObject = JSONObject.fromObject(userInfoResponse);
        return countUserInfo(userInfoJsonObject);
    }

    /**
     * 发起http请求，获取结果
     * @param url 请求地址
     * @return String
     */
    private String getHttpResponseResult(String url,Map<String,String> paramsMap
            ,Map<String,String> headerMap) throws UserInfoException {
        logger.info("getHttpResponseResult, url:{}, paramsMap:{}, headerMap:{}", url, paramsMap, headerMap);
        StringBuffer out = new StringBuffer();
        InputStream in = null;
        try {
            in = httpClientUtil.httpGet(url,paramsMap,headerMap);
            byte[] b = new byte[4096];
            try {
                for (int n; (n = in.read(b)) != -1;) {
                    out.append(new String(b, 0, n));
                }
            } catch (IOException e) {
                throw new UserInfoException(BaseErrorCode.SYSTEM_EXCEPTION);
            }
        } catch (Exception e){
            throw new UserInfoException(BaseErrorCode.SYSTEM_EXCEPTION);
        }finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    throw new UserInfoException(BaseErrorCode.SYSTEM_EXCEPTION);
                }
            }
        }
        return out.toString();
    }

    @Override
    public String getUserToken(String userId) {
        logger.info("getUserToken, userId:{}", userId);

        Preconditions.checkNotNull(userId, new AuditInfoException(BaseErrorCode.ID_NOT_VALID));

        Map<String, String> paramsMap = new HashMap<>();
        paramsMap.put("user_id", userId);

        String responseResult = getHttpResponseResult(linkPageUrl + userTokenUrl, paramsMap, null);
        logger.info("getUserToken, responseResult:{}", responseResult);

        String token = null;
        JSONObject responseJsonObject = JSONObject.fromObject(responseResult);

        //处理结果获取token
        if (responseJsonObject.containsKey("token")) {
            Object tokenObj = responseJsonObject.get("token");
            if (tokenObj != null ) {
                token = tokenObj.toString();
            }
        } else if (responseJsonObject.containsKey(ERR_CODE)) {
            throw new UserInfoException(new ErrorCode(Integer.parseInt(responseJsonObject.get(ERR_CODE).toString()), responseJsonObject.get(ERR_MSG).toString()));
        }

        logger.info("getUserToken, token:{}", token);

        return token;
    }

    /**
     * 返回结果进行userInfo对象封装
     * @param userInfoList
     * @param userInfoJsonObject
     */
    private void packageUserInfo(List<UserInfo> userInfoList,JSONObject userInfoJsonObject) {
        if (userInfoJsonObject.containsKey("ret")) {
            JSONArray jsonArray = (JSONArray) userInfoJsonObject.get("ret");
            for (int i = 0; i < jsonArray.size(); i++) {
                ObjectMapper objectMapper = new ObjectMapper();
                try {
                    UserInfo userInfo = objectMapper.readValue(jsonArray.get(i).toString()
                            , UserInfo.class);
                    userInfoList.add(userInfo);
                } catch (IOException e) {
                    throw new UserInfoException(UserErrorCode.USER_RESPONSE_FORMAT_ERROR);
                }
            }
        } else if (userInfoJsonObject.containsKey(ERR_CODE)) {
            throw new UserInfoException(new ErrorCode(Integer.parseInt(userInfoJsonObject.get(ERR_CODE).toString()), userInfoJsonObject.get(ERR_MSG).toString()));
        }

    }

    /**
     * 统计用户列表个数
     * @param userInfoJsonObject
     * @return
     */
    private long countUserInfo(JSONObject userInfoJsonObject) {
        if (userInfoJsonObject.containsKey("total_count")) {
            return Long.parseLong(userInfoJsonObject.get("total_count").toString());
        } else if (userInfoJsonObject.containsKey(ERR_CODE)) {
            throw new UserInfoException(new ErrorCode(Integer.parseInt(userInfoJsonObject.get(ERR_CODE).toString()), userInfoJsonObject.get(ERR_MSG).toString()));
        }
        return 0;
    }


    @Override
    public AppInfo getAppInfo(Integer appId) {
        logger.info("getAppInfo, appId:{}", appId);

        httpClientUtil.setProxy(null);

        Preconditions.checkNotNull(appId, new AuditInfoException(BaseErrorCode.ID_NOT_VALID));

        HashMap paramsMap = new HashMap();

        paramsMap.put("app_id", appId+"");

        String result = getHttpResponseResult(linkPageUrl + appInfoUrl, paramsMap, null);

        logger.info("getAppInfo, result:{}", result);

        AppInfo appInfo;
        JSONObject responseJsonObject = JSONObject.fromObject(result);
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            appInfo = objectMapper.readValue(responseJsonObject.toString()
                    , AppInfo.class);
        } catch (IOException e) {
            throw new UserInfoException(UserErrorCode.APP_RESPONSE_FORMAT_ERROR);
        }

        logger.debug("getAppInfo, appId:{}, appInfo:{}", appId, appInfo);
        return appInfo;
    }


    /**
     * 通过appKey 获取appinfo 信息
     *
     * @param appKey
     * @return
     */
    @Override
    public AppInfo getAppInfoByAppKey(String appKey) {

        //todo

        logger.info("getAppInfoByAppKey, appKey:{}", appKey);

        httpClientUtil.setProxy(null);

        Preconditions.checkNotNull(appKey, new AuditInfoException(BaseErrorCode.ID_NOT_VALID));

        Map<String, String> paramsMap = new HashMap<>();

        paramsMap.put("app_key", appKey);

        String result = getHttpResponseResult(linkPageUrl + infoByKeyUrl, paramsMap, null);
        logger.info("getAppInfoByAppKey, result:{}", result);
        if (result == null) {
            throw new AuthConfigException(AuthConfigErrorCode.APP_KEY_NO_VALID);
        }

        AppInfo appInfo;
        JSONObject responseJsonObject = JSONObject.fromObject(result);

        if (responseJsonObject.containsKey(ERR_CODE)) {
            throw new UserInfoException(new ErrorCode(Integer.parseInt(responseJsonObject.get(ERR_CODE).toString()), responseJsonObject.get(ERR_MSG).toString()));
        }
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            appInfo = objectMapper.readValue(responseJsonObject.toString()
                    , AppInfo.class);
        } catch (IOException e) {
            throw new UserInfoException(UserErrorCode.APP_RESPONSE_FORMAT_ERROR);
        }

        logger.debug("getAppInfoByAppKey, appKey:{}, appInfo:{}", appKey, appInfo);
        return appInfo;
    }


    /**============================ new =============================**/

    @Override
    public List<UserInfo> getUserInfoList(SearchParam searchParam) {

        logger.info("getUserInfoList start, searchParam:{}", searchParam);

        UserPOExample userPOExample = new UserPOExample();
        UserPOExample.Criteria criteria = userPOExample.createCriteria();
        List<UserPOWithBLOBs> userPOList = null;
        if (StringUtils.isNotEmpty(searchParam.getEmail())) {
            criteria.andEmailEqualTo(searchParam.getEmail());
        }
        if (StringUtils.isNotEmpty(searchParam.getCompany())) {
            criteria.andCompanyEqualTo(searchParam.getCompany());
        }
        if (searchParam.getAuditState() != null) {
            criteria.andAuditStateEqualTo(searchParam.getAuditState().byteValue());
        }
        if (searchParam.getStartDate() != null) {
            criteria.andAuthSubmitTimeGreaterThanOrEqualTo(searchParam.getStartDate());
        }
        if (searchParam.getEndDate() != null) {
            criteria.andAuthSubmitTimeLessThanOrEqualTo(searchParam.getEndDate());
        }

        if (searchParam.getPage() != null && searchParam.getSize() != null) {
            userPOList = userPOMapper.selectByExampleWithLimit(userPOExample, searchParam.getOffset(), searchParam.getSize());
        } else {
            userPOList = userPOMapper.selectByExampleWithBLOBs(userPOExample);
        }

        List<UserInfo> userInfoList = userPOList.stream().map(userPO -> UserPoConverter.po2Bo(userPO)).collect(Collectors.toList());

        logger.debug("getUserInfoList end, searchParam:{}, userInfoList:{}", searchParam, userInfoList);
        return userInfoList;
    }

    @Override
    public UserInfo getUserInfoByUid(Integer uid) {

        logger.info("getUserInfoByUid start, uid:{}", uid);
        Preconditions.checkNotNull(uid, new AuditInfoException(BaseErrorCode.ID_NOT_VALID));

        UserPOWithBLOBs userPOWithBLOBs = userPOMapper.selectByPrimaryKey(uid);

        logger.info("getUserInfoByUid end, uid:{}, userPOWithBLOBs:{}", uid, userPOWithBLOBs);
        return UserPoConverter.po2Bo(userPOWithBLOBs);
    }

}
