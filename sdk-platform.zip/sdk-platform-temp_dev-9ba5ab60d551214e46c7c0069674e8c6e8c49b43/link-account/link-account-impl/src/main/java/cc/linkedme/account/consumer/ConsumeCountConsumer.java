package cc.linkedme.account.consumer;

import cc.linkedme.account.model.ConsumeCountInfo;
import cc.linkedme.account.model.ConsumeCountMessage;
import cc.linkedme.account.service.ConsumeCountSerivce;
import cc.linkedme.enums.BizType;
import cc.linkedme.kafka.MqEntity;
import cc.linkedme.kafka.consumer.AbstractKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

/**
 * @author zhanghaowei
 * @date 2019-7-19 16:00
 * @description acount 消费统计
 **/
public class ConsumeCountConsumer extends AbstractKafkaConsumer {

    Logger logger = LoggerFactory.getLogger(ConsumeCountConsumer.class);

    @Resource
    private ConsumeCountSerivce consumeCountSerivce;

    @Override
    protected void process(Object mqEntry) {
        logger.info("process, mqEntry:{}", mqEntry);

        MqEntity mqEntity = (MqEntity) mqEntry;
        ConsumeCountMessage consumeCountMessage = (ConsumeCountMessage)mqEntity.getBody();

        if (consumeCountMessage != null) {

            ConsumeCountInfo consumeCountInfo  = new ConsumeCountInfo();
            consumeCountInfo.setHourSlot(consumeCountMessage.getHourSlot());
            BizType bizType = consumeCountMessage.getBizType();
            Integer count = consumeCountMessage.getCount();
            Integer unitPrice = consumeCountMessage.getUnitPrice() * count;
            switch (bizType) {
                case TEXT_SMS:
                    consumeCountInfo.setSmsCount(count);
                    break;
                case VOICE_SMS:
                    consumeCountInfo.setVoiceCount(count);
                    break;
                case QUICK_LOGIN:
                    consumeCountInfo.setQuickLoginCount(count);
                    break;
                case NUMBER_VERIFY:
                    consumeCountInfo.setVerifyCount(count);
                    break;
            }
            consumeCountInfo.setTotalAmount(unitPrice);
            consumeCountInfo.setHourSlot(consumeCountMessage.getHourSlot());
            consumeCountInfo.setDate(consumeCountMessage.getDate());
            consumeCountInfo.setUid(consumeCountMessage.getUid());
            boolean status = consumeCountSerivce.updateCountDate(consumeCountInfo, bizType);
            logger.info("process, mqEntity:{}, bizType:{}, status:{}", mqEntity, bizType, status);
        }
    }
}
