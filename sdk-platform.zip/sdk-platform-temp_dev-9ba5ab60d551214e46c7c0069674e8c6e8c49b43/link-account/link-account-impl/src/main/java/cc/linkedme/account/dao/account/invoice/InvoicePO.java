package cc.linkedme.account.dao.account.invoice;

import lombok.Data;
import java.util.Date;

@Data
public class InvoicePO {
    private Integer id;

    private Integer uid;

    private Byte invoiceType;

    private String invoiceTitle;

    private String taxpayerIdentification;

    private String contactInfo;

    private String bankAccountInfo;

    private String invoiceItem;

    private Long invoiceAmount;

    private String recipientName;

    private String recipientAddress;

    private String recipientPhone;

    private Byte auditState;

    private String expressCompany;

    private String trackingNumber;

    private Date sendOutTime;

    private String trackingRemark;

    private Date gmtCreate;

    private Date gmtModified;

    private String auditRemark;

    private String auditor;
}