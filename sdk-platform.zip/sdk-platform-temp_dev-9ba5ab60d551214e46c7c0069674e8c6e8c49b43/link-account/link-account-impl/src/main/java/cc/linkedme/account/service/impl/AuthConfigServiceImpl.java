package cc.linkedme.account.service.impl;

import cc.linkedme.json.JsonConverter;
import cc.linkedme.account.converter.AuthConfigPoConverter;
import cc.linkedme.account.dao.account.config.AuthConfigPO;
import cc.linkedme.account.dao.account.config.AuthConfigPOExample;
import cc.linkedme.account.dao.account.config.AuthConfigPOMapper;
import cc.linkedme.account.errorcode.AuthConfigErrorCode;
import cc.linkedme.account.exception.AuthConfigException;
import cc.linkedme.account.model.AppInfo;
import cc.linkedme.account.model.AuthConfigInfo;
import cc.linkedme.account.service.AuthConfigService;
import cc.linkedme.account.service.UserService;
import cc.linkedme.account.common.crypto.Rsa;
import cc.linkedme.cache.CacheUtil;
import cc.linkedme.cache.redis.RedisClientUtil;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import javax.annotation.Resource;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Date;
import java.util.List;

/**
 * @author zhanghaowei
 * @date 2019-6-15 17:15
 * @description
 **/

@Service("authConfigService")
public class AuthConfigServiceImpl implements AuthConfigService {

    Logger logger = LoggerFactory.getLogger(AuthConfigServiceImpl.class);

    private final static String CUCC_CLIENT_ID = "99166000000000000402";

    private final static String CUCC_CLIENT_SECRET = "975475a897d2d33c4bb8ffbea20dbfbb";

    private final static String CUCC_GRANT_SECRET = "b5a6e4ab3da18953875b89696237354b";

    private static final String CUCC_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC0PZZAbTqhPhmp9oILXQHyyWxxFIU6g" +
            "+hu3YpMBozC75ZZcecZL+sw6p/BonHkP9qDPX2Z7rEIgCIpevbi+CA3enIFgh" +
            "N7WdTHf+ALSiYIk87WXUGfa2y55nQUzInDwJG4cADZ4moYXG3gfBtAqibbI3OMz5MqZa7gbdhtv1kw6wIDAQAB";
    private static final String CUCC_PRIVATE_KEY = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALQ9lkBtOqE+Gan2" +
            "ggtdAfLJbHEUhTqD6G7dikwGjMLvlllx5xkv6zDqn8GiceQ/2oM9fZnusQiAIil6" +
            "9uL4IDd6cgWCE3tZ1Md/4AtKJgiTztZdQZ9rbLnmdBTMicPAkbhwANniahhcbeB8" +
            "G0CqJtsjc4zPkyplruBt2G2/WTDrAgMBAAECgYEArEdZwIcnTUwAV9bJgncKD7i7" +
            "sHJ+zembV6zmLbjs/r7nJOOckxScZ4s73GebGSJ3iI5T6bie+pMPFDr2lQe6MfHI" +
            "bhend4IhQA+q4Gh38zp0BPmepiPjXqQwezvuFBBJ1cCr4SYD2hqx0OVnyC3sA7LR" +
            "eKyuAnKCzh0qcR6aSQECQQDjWlFzrW2d6LzNkuLzo5I9+8ZqWGc/yh6x2R67ZznU" +
            "PE53hoM3smAig9qrlQtjoHfRgP53wMAug+RN+wDcSFtBAkEAyvOTyYXgUONLoXGm" +
            "0PZlOgNrLIscjNwxsDUfY96C5pR4x1+Yh18kyJLScp3v8QWb5Kfgoe1492bgkFQ9" +
            "x3udKwJAA9RxqtExF4fkJlJjIFeRDxo+rWvv0VNGURinO+DxSHH7oGfTrgyDMhGm" +
            "jV1lY7hATHcv0jSdCCuQnP+tdAiEAQJBAJwVDBm2TjenNukooOSgOmWNb4VIT2K9" +
            "jbE4ibWi0QVINkMO8B1cPMvMrvDbKkcwyx3lRksCeT+77QTS5Nhf5xUCQDJLuaZP" +
            "STnoq/9SN9ux+o7Dnrc8SzMYTwCJj+/qCWOMjiRGs5TknWRB0tDjG5ioEtutvZ3o" +
            "FeRhepsyYaII2h0=";
    /**
     * ip白名单 写到运营商报备IP
     */
    private static final String ACCOUNT_IP_WHITELIST = "101.201.237.75,47.93.219.95";

    /**
     * 1day
     */
    private static final int AUTH_CONFIG_CACHE_EXPIRE = 24 * 60 * 60;

    private static final String AUTH_CONFIG_KEY_PREFIX = "auth_config";


    @Resource
    private AuthConfigPOMapper authConfigPOMapper;

    @Resource
    private UserService userService;

    @Resource
    private RedisClientUtil authConfigRedisClient;

    @Override
    public void updateAuthConfig(AuthConfigInfo authConfigInfo) throws AuthConfigException {
        logger.info("updateAuthConfig AuthConfigInfo:{}", authConfigInfo);

        AuthConfigPO authConfigPO = AuthConfigPoConverter.bo2Po(authConfigInfo);
        Date date = new Date();
        authConfigPO.setGmtModified(date);
        authConfigPOMapper.updateByPrimaryKeySelective(authConfigPO);

        //删除缓存
        authConfigRedisClient.del(CacheUtil.genKey(AUTH_CONFIG_KEY_PREFIX, authConfigInfo.getAppId()));

        logger.debug("updateAuthConfig AuthConfigInfo:{}", authConfigInfo);
    }

    @Override
    public AuthConfigInfo saveAuthConfig(AuthConfigInfo authConfigInfo) throws AuthConfigException {
        logger.info("saveAuthConfig, AuthConfigInfo:{}", authConfigInfo);

        AuthConfigPO authConfigPO = AuthConfigPoConverter.bo2Po(authConfigInfo);

        try {
            KeyPair keyPair = Rsa.getKeyPair();
            PrivateKey privateKey = keyPair.getPrivate();
            PublicKey publicKey = keyPair.getPublic();
            String privateKeyEncoded = new String(Base64.encodeBase64(privateKey.getEncoded()));
            String publicKeyEncoded = new String(Base64.encodeBase64(publicKey.getEncoded()));
            authConfigPO.setCmccPrivateKey(privateKeyEncoded);
            authConfigPO.setCmccPublicKey(publicKeyEncoded);
            authConfigPO.setCtccPrivateKey(privateKeyEncoded);
            authConfigPO.setCtccPublicKey(publicKeyEncoded);
        } catch (Exception e) {
            logger.warn("saveAuthConfig create private key, public key ERROR, AuthConfigInfo:{}", authConfigInfo, e);
            throw new AuthConfigException(AuthConfigErrorCode.SECRET_KEY_CREATE_FAIL);
        }
        Date date = new Date();
        authConfigPO.setGmtCreate(date);
        authConfigPO.setGmtModified(date);
        authConfigPOMapper.insertSelective(authConfigPO);
        authConfigInfo = AuthConfigPoConverter.po2Bo(authConfigPO);

        //缓存重入
        authConfigRedisClient.setex(CacheUtil.genKey(AUTH_CONFIG_KEY_PREFIX, authConfigInfo.getAppId()), JsonConverter.format(authConfigInfo), AUTH_CONFIG_CACHE_EXPIRE);

        logger.debug("saveAuthConfig, AuthConfigInfo:{}", authConfigInfo);
        return authConfigInfo;
    }

    @Override
    public AuthConfigInfo getAuthConfig(Integer appId) throws AuthConfigException {

        logger.info("getAuthConfig appId:{}", appId);

        String key = CacheUtil.genKey(AUTH_CONFIG_KEY_PREFIX, appId);

        AuthConfigInfo authConfigInfo = CacheUtil.getValue(key, cacheFactoryKey -> {
            String value = authConfigRedisClient.get(cacheFactoryKey);
            return value != null ? JsonConverter.parse(value, AuthConfigInfo.class) : null;
        }, persistFactoryKey -> getAuthConfigInfo(appId), flushCacheObj -> authConfigRedisClient.setex(key, JsonConverter.format(flushCacheObj), AUTH_CONFIG_CACHE_EXPIRE));

        logger.info("getAuthConfig, appId:{}, AuthConfigInfo:{}", appId, authConfigInfo);
        return authConfigInfo;
    }

    @Override
    public AuthConfigInfo getAuthConifgInfo(Integer appId, String appKey) throws AuthConfigException {
        AuthConfigInfo authConfigInfo;

        AuthConfigPOExample authConfigPOExample = new AuthConfigPOExample();
        AuthConfigPOExample.Criteria criteria = authConfigPOExample.createCriteria();
        if (appId != null) {
            criteria.andAppIdEqualTo(appId);
        }
        if (StringUtils.isNotEmpty(appKey)) {
            criteria.andAppKeyEqualTo(appKey);
        }
        List<AuthConfigPO> authConfigPOList = authConfigPOMapper.selectByExample(authConfigPOExample);
        if (CollectionUtils.isEmpty(authConfigPOList)) {
            return null;
        } else {
            AuthConfigPO authConfigPO = authConfigPOList.get(0);
            authConfigInfo = AuthConfigPoConverter.po2Bo(authConfigPO);
            return authConfigInfo;
        }
    }

    @Override
    public AuthConfigInfo getCuccAuthConfig(Integer appId) throws AuthConfigException {

        logger.info("getCuccAuthConfig");

        AuthConfigInfo authConfigInfo = new AuthConfigInfo();
        AuthConfigInfo.Cucc cucc = new AuthConfigInfo.Cucc();
        cucc.setClientId(CUCC_CLIENT_ID);
        cucc.setClientSecret(CUCC_CLIENT_SECRET);
        cucc.setGrantSecret(CUCC_GRANT_SECRET);
        cucc.setPrivateKey(CUCC_PRIVATE_KEY);
        cucc.setPublicKey(CUCC_PUBLIC_KEY);

        if (appId != null) {
            AppInfo appInfo = userService.getAppInfo(appId);
            cucc.setAndroidPackName(appInfo.getAndroid().getPackageName());
            cucc.setAndroidPackSign(appInfo.getAndroid().getSignMd5());
            cucc.setIosBundleId(appInfo.getIos().getBundleId());
        }
        authConfigInfo.setCucc(cucc);

        return authConfigInfo;
    }

    /**
     * 获取配置信息
     * @param appId
     * @return
     */
    private AuthConfigInfo getAuthConfigInfo(Integer appId) {
        //联通
        AuthConfigInfo.Cucc cucc = getCuccAuthConfig(appId).getCucc();
        AuthConfigInfo authConfig;

        AuthConfigPOExample authConfigPOExample = new AuthConfigPOExample();
        AuthConfigPOExample.Criteria criteria = authConfigPOExample.createCriteria();
        if (appId != null) {
            criteria.andAppIdEqualTo(appId);
        }

        List<AuthConfigPO> authConfigPOList = authConfigPOMapper.selectByExample(authConfigPOExample);

        if (CollectionUtils.isEmpty(authConfigPOList)) {

            throw new AuthConfigException(AuthConfigErrorCode.APP_KEY_NO_VALID);
        }

        AuthConfigPO authConfigPO = authConfigPOList.get(0);
        authConfig = AuthConfigPoConverter.po2Bo(authConfigPO);
        authConfig.setCucc(new AuthConfigInfo.Cucc(cucc.getClientId(), cucc.getClientSecret(), cucc.getGrantSecret(), cucc.getPrivateKey(), cucc.getPublicKey()));
        authConfig.setAccountIpWhitelist(ACCOUNT_IP_WHITELIST);

        return authConfig;
    }
}
