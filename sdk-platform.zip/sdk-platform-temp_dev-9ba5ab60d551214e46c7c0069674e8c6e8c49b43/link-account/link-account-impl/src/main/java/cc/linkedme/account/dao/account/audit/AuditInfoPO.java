package cc.linkedme.account.dao.account.audit;

import lombok.Data;

import java.util.Date;

@Data
public class AuditInfoPO {
    private Integer id;

    private Integer uid;

    private Integer bizId;

    private Byte bizType;

    private Byte auditState;

    private String auditRemark;

    private String auditor;

    private Date gmtCreate;

    private Date gmtModified;

}