package cc.linkedme.account.converter;

import cc.linkedme.account.enums.InvoiceType;
import cc.linkedme.account.dao.account.invoice.InvoicePO;
import cc.linkedme.account.model.InvoiceInfo;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 16:18
 * @description
 **/
public class InvoicePoConverter {

    public static InvoicePO bo2Po(InvoiceInfo invoiceInfo) {

        InvoicePO invoicePO = new InvoicePO();
        BeanUtils.copyProperties(invoiceInfo, invoicePO);
        invoicePO.setAuditState(invoiceInfo.getAuditState() == null ? null : invoiceInfo.getAuditState().getType().byteValue());
        invoicePO.setInvoiceType(invoiceInfo.getInvoiceType() == null ? null : invoiceInfo.getInvoiceType().getCode().byteValue());

        return invoicePO;
    }

    public static InvoiceInfo po2Bo(InvoicePO invoicePO) {

        InvoiceInfo invoiceInfo = new InvoiceInfo();
        BeanUtils.copyProperties(invoicePO, invoiceInfo);
        invoiceInfo.setInvoiceType(invoicePO.getInvoiceType() == null ? null : InvoiceType.get(invoicePO.getInvoiceType().intValue()));

        return invoiceInfo;
    }
}
