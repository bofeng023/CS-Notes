package cc.linkedme.account.service.impl;

import cc.linkedme.account.converter.TopUpPoConverter;
import cc.linkedme.account.dao.account.top.up.TopUpPO;
import cc.linkedme.account.dao.account.top.up.TopUpPOExample;
import cc.linkedme.account.dao.account.top.up.TopUpPOMapper;
import cc.linkedme.account.enums.RechargeType;
import cc.linkedme.account.errorcode.TopUpErrorCode;
import cc.linkedme.account.exception.TopUpException;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.TopUpInfo;
import cc.linkedme.account.service.TopUpService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author zhanghaowei
 * 账户充值
 */
@Service("topUpService")
public class TopUpServiceImpl implements TopUpService {

    private static final Logger logger = LoggerFactory.getLogger(TopUpServiceImpl.class);

    @Resource
    private TopUpPOMapper topUpPOMapper;

    @Override
    public TopUpInfo saveTopUp(TopUpInfo topUpInfo) throws TopUpException {

        logger.info("saveTopUp begin, topUpInfo:{}", topUpInfo);
        Preconditions.checkNotNull(topUpInfo.getUid(), new TopUpException(TopUpErrorCode.UID_NULL_ERROR));
        Preconditions.checkNotNull(topUpInfo.getAmount(), new TopUpException(TopUpErrorCode.AMOUNT_NULL_ERROR));
        if (topUpInfo.getRechargeType().getType() == RechargeType.NORMAL_RECHARGE.getType()) {
            Preconditions.checkNotNull(topUpInfo.getReceipt(), new TopUpException(TopUpErrorCode.RECEIPT_NULL_ERROR));
        }
        topUpInfo.setAuditState(AuditState.TO_BE_AUDITED);
        TopUpPO topUpPO = TopUpPoConverter.bo2Po(topUpInfo);
        Date currentTime = new Date();
        topUpPO.setGmtCreate(currentTime);
        topUpPO.setGmtModified(currentTime);
        topUpPO.setConsumeState((byte)0);

        topUpPOMapper.insertSelective(topUpPO);

        logger.info("saveTopUp end, topUpInfo:{}, topUpPO:{}", topUpInfo, topUpPO);
        return TopUpPoConverter.po2Bo(topUpPO);
    }

    @Override
    public Integer updateTopUp(TopUpInfo topUpInfo) throws TopUpException {

        logger.info("updateTopUp, topUpInfo:{}", topUpInfo);
        Preconditions.checkNotNull(topUpInfo.getId(), new TopUpException(TopUpErrorCode.ID_NULL_ERROR));

        TopUpPO topUpPO = TopUpPoConverter.bo2Po(topUpInfo);
        topUpPO.setGmtModified(new Date());
        int updateResult = topUpPOMapper.updateByPrimaryKeySelective(topUpPO);

        logger.info("updateTopUp, topUpInfo:{}, topUpPO:{}", topUpInfo, topUpPO);

        return updateResult;
    }

    @Override
    public TopUpInfo getTopUp(Integer id) throws TopUpException {

        logger.info("getTopUp, id:{}", id);
        Preconditions.checkNotNull(id, new TopUpException(TopUpErrorCode.ID_NULL_ERROR));

        TopUpPO topUpPO = topUpPOMapper.selectByPrimaryKey(id);
        if(topUpPO == null) {
            return null;
        }

        TopUpInfo topUpInfo = TopUpPoConverter.po2Bo(topUpPO);
        logger.info("getTopUp, id:{}, topUpInfo:{}", id, topUpInfo);

        return topUpInfo;
    }

    @Override
    public List<TopUpInfo> listTopUp(SearchParam searchParam) throws TopUpException {

        logger.info("listTopUp, searchParam:{}", searchParam);
        Preconditions.checkNotNull(searchParam, new TopUpException(TopUpErrorCode.PARAM_NULL_ERROR));

        TopUpPOExample topUpPOExample = new TopUpPOExample();
        TopUpPOExample.Criteria criteria = topUpPOExample.createCriteria();
        if (searchParam.getStartDate() != null && searchParam.getEndDate() != null) {
            criteria.andGmtCreateBetween(searchParam.getStartDate(), searchParam.getEndDate());
        }
        if (searchParam.getUid() != null) {
            criteria.andUidEqualTo(searchParam.getUid());
        }
        if (searchParam.getAuditState() != null) {
            criteria.andAuditStateEqualTo(searchParam.getAuditState().byteValue());
        }

        if (searchParam.getConsumeState() != null) {
            criteria.andConsumeStateEqualTo(searchParam.getConsumeState().byteValue());
        }

        topUpPOExample.setOrderByClause("gmt_create desc");

        List<TopUpPO> topUpPOList = topUpPOMapper.selectByExampleWithLimit(topUpPOExample, searchParam.getOffset(), searchParam.getSize());
        if (CollectionUtils.isEmpty(topUpPOList)) {
            return Collections.EMPTY_LIST;
        }

        List<TopUpInfo> topUpInfoList = topUpPOList.stream().map(topUpPO -> TopUpPoConverter.po2Bo(topUpPO)).collect(Collectors.toList());
        logger.debug("listTopUp, searchParam:{}, topUpInfoList:{}", searchParam, topUpInfoList);

        return topUpInfoList;
    }

    @Override
    public Long countTopUp(Integer uid, SearchParam searchParam) throws TopUpException {

        logger.info("countTopUp, uid:{}", uid);

        TopUpPOExample topUpPOExample = new TopUpPOExample();
        TopUpPOExample.Criteria criteria = topUpPOExample.createCriteria();
        if (uid != null) {
            criteria.andUidEqualTo(uid);
        }
        if (searchParam != null) {
            if (searchParam.getStartDate() != null && searchParam.getEndDate() != null) {
                criteria.andGmtCreateBetween(searchParam.getStartDate(), searchParam.getEndDate());
            }
            if (searchParam.getUid() != null) {
                criteria.andUidEqualTo(searchParam.getUid());
            }

            if (searchParam.getAuditState() != null) {
                criteria.andAuditStateEqualTo(searchParam.getAuditState().byteValue());
            }

            if (searchParam.getConsumeState() != null) {
                criteria.andConsumeStateEqualTo(searchParam.getConsumeState().byteValue());
            }
        }

        Long topUpCount = topUpPOMapper.countByExample(topUpPOExample);
        logger.info("countTopUp, uid:{}, topUpCount:{}", uid, topUpCount);

        return topUpCount;
    }

    @Override
    public Long countHistoryTopUpAmount(Integer uid) {

        logger.info("countHistoryTopUp, uid:{}", uid);
        Preconditions.checkNotNull(uid, new TopUpException(BaseErrorCode.UID_NULL_ERROR));

        TopUpPOExample topUpPOExample = new TopUpPOExample();
        TopUpPOExample.Criteria criteria = topUpPOExample.createCriteria();
        criteria.andAuditStateEqualTo(AuditState.AUDIT_PASS.getType().byteValue());
        criteria.andUidEqualTo(uid);
        Long amount = topUpPOMapper.countHistoryTopUp(topUpPOExample);

        logger.info("countHistoryTopUpAmount, uid:{}, amount:{}", uid, amount);
        return amount !=  null ? amount : 0;
    }

}

