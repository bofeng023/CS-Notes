package cc.linkedme.account.service.impl;

import cc.linkedme.account.converter.InvoicePoConverter;
import cc.linkedme.account.dao.account.invoice.InvoicePO;
import cc.linkedme.account.dao.account.invoice.InvoicePOExample;
import cc.linkedme.account.dao.account.invoice.InvoicePOMapper;
import cc.linkedme.account.errorcode.InvoiceErrorCode;
import cc.linkedme.account.exception.InvoiceException;
import cc.linkedme.account.model.InvoiceInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.service.InvoiceService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 发票
 * @author zhanghaowei
 */
@Service("invoiceService")
public class InvoiceServiceImpl implements InvoiceService {

    private static final Logger logger = LoggerFactory.getLogger(InvoiceServiceImpl.class);

    @Resource
    private InvoicePOMapper invoicePOMapper;

    @Override
    public InvoiceInfo saveInvoiceInfo(InvoiceInfo invoiceInfo) throws InvoiceException {

        logger.info("saveInvoiceInfo, begin invoiceInfo:{}", invoiceInfo);

        InvoicePO invoicePO = InvoicePoConverter.bo2Po(invoiceInfo);
        Date date = new Date();
        invoicePO.setAuditState(AuditState.TO_BE_AUDITED.getType().byteValue());
        invoicePO.setGmtCreate(date);
        invoicePO.setGmtModified(date);

        invoicePOMapper.insertSelective(invoicePO);

        logger.info("saveInvoiceInfo, end invoiceInfo:{}", invoiceInfo);
        return InvoicePoConverter.po2Bo(invoicePO);
    }

    @Override
    public Integer updateInvoiceInfo(InvoiceInfo invoiceInfo) throws InvoiceException {

        logger.info("updateInvoiceInfo, invoiceInfo:{}", invoiceInfo);
        Preconditions.checkNotNull(invoiceInfo.getId(), new InvoiceException(InvoiceErrorCode.ID_NULL_ERROR));

        InvoicePO invoicePO = InvoicePoConverter.bo2Po(invoiceInfo);
        invoicePO.setGmtModified(new Date());
        invoicePO.setAuditState(AuditState.TO_BE_AUDITED.getType().byteValue());
        logger.info("updateInvoiceInfo, invoiceInfo:{}, InvoicePO:{}", invoiceInfo, invoicePO);

        return invoicePOMapper.updateByPrimaryKeySelective(invoicePO);
    }

    @Override
    public InvoiceInfo getInvoiceInfo(Integer id) {

        logger.info("getInvoiceInfoBO, id:{}", id);
        Preconditions.checkNotNull(id, new InvoiceException(InvoiceErrorCode.ID_NULL_ERROR));

        InvoicePO invoicePO = this.invoicePOMapper.selectByPrimaryKey(id);
        if (invoicePO == null) {
            return null;
        }

        InvoiceInfo invoiceInfo = InvoicePoConverter.po2Bo(invoicePO);
        logger.info("getInvoiceInfoBO, id:{}, invoiceInfo:{}", id, invoiceInfo);

        return invoiceInfo;
    }

    @Override
    public List<InvoiceInfo> listInvoice(SearchParam searchParam) {

        logger.info("listInvoice, searchParam:{}", searchParam);
        Preconditions.checkNotNull(searchParam, new InvoiceException(InvoiceErrorCode.PARAM_NULL_ERROR));

        InvoicePOExample invoicePOExample = new InvoicePOExample();
        InvoicePOExample.Criteria criteria = invoicePOExample.createCriteria();
        if (searchParam.getStartDate() != null && searchParam.getEndDate() != null) {
            criteria.andGmtCreateBetween(searchParam.getStartDate(), searchParam.getEndDate());
        }
        if (searchParam.getUid() != null) {
            criteria.andUidEqualTo(searchParam.getUid());
        }
        if (searchParam.getAuditState() != null) {
            criteria.andAuditStateEqualTo(searchParam.getAuditState().byteValue());
        }

        invoicePOExample.setOrderByClause("gmt_create desc");

        List<InvoicePO> invoicePOList = invoicePOMapper.selectByExampleWithLimit(invoicePOExample, searchParam.getOffset(), searchParam.getSize());
        if (CollectionUtils.isEmpty(invoicePOList)) {
            return Collections.EMPTY_LIST;
        }

        List<InvoiceInfo> invoiceInfoList = invoicePOList.stream().map(invoicePO -> InvoicePoConverter.po2Bo(invoicePO)).collect(Collectors.toList());
        logger.debug("listInvoice, searchParam:{}, invoiceBOList:{}", searchParam, invoiceInfoList);

        return invoiceInfoList;
    }

//    @Override
//    public InvoiceInfo getInvoiceAndAuditInfo(Integer id) throws InvoiceException {
//
//        bizlog.info("getInvoiceAndAuditInfo, id:{}", id);
//        Preconditions.checkNotNull(id, new InvoiceException(InvoiceErrorCode.ID_NULL_ERROR));
//
//        InvoicePO invoicePO = this.invoicePOMapper.getInvoiceAndAuditInfo(id, BizType.INVOINCE.getType());
//        if (invoicePO == null) {
//            return null;
//        }
//
//        InvoiceInfo invoiceInfo = InvoicePoConverter.po2Bo(invoicePO);
//        bizlog.info("getInvoiceAndAuditInfo, id:{}, invoiceInfo:{}", id, invoiceInfo);
//
//        return invoiceInfo;
//    }

    @Override
    public Long countInvoice(Integer uid, SearchParam searchParam) throws InvoiceException {

        logger.info("countInvoice, uid:{}", uid);

        InvoicePOExample invoicePOExample = new InvoicePOExample();
        InvoicePOExample.Criteria criteria = invoicePOExample.createCriteria();
        if (uid != null) {
            criteria.andUidEqualTo(uid);
        }
        if (searchParam != null) {
            if (searchParam.getStartDate() != null && searchParam.getEndDate() != null) {
                criteria.andGmtCreateBetween(searchParam.getStartDate(), searchParam.getEndDate());
            }
            if (searchParam.getUid() != null) {
                criteria.andUidEqualTo(searchParam.getUid());
            }
            if (searchParam.getAuditState() != null) {
                criteria.andAuditStateEqualTo(searchParam.getAuditState().byteValue());
            }
        }

        Long invoiceCount = invoicePOMapper.countByExample(invoicePOExample);
        logger.info("countInvoice, uid:{}, invoiceCount:{}", uid, invoiceCount);

        return invoiceCount;
    }

    @Override
    public Integer cancelInvoice(Integer id) {

        logger.info("cancelInvoice, id:{}", id);

        Date date = new Date();
        InvoicePO invoiceInfPO = new InvoicePO();
        invoiceInfPO.setId(id);
        invoiceInfPO.setAuditState(AuditState.CANCEL.getType().byteValue());
        invoiceInfPO.setGmtModified(date);

        return invoicePOMapper.updateByPrimaryKeySelective(invoiceInfPO);
    }

    @Override
    public Long countInvoiceAmount(Integer uid) {
        logger.info("countInvoiceAmount, uid:{}", uid);

        InvoicePOExample invoicePOExample = new InvoicePOExample();

        InvoicePOExample.Criteria criteria = invoicePOExample.createCriteria();
        criteria.andUidEqualTo(uid);
        criteria.andAuditStateNotEqualTo(AuditState.AUDIT_FAIL.getType().byteValue());

        Long amount = invoicePOMapper.countInvoiceAmount(invoicePOExample);

        logger.info("countInvoiceAmount, uid:{}, amount:{}", uid, amount);
        return amount != null ? amount : 0;
    }
}

