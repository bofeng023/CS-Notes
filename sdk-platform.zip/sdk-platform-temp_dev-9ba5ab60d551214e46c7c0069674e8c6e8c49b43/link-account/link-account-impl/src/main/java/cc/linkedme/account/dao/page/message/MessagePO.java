package cc.linkedme.account.dao.page.message;

import lombok.Data;

import java.util.Date;

@Data
public class MessagePO {
    private Long id;

    private Integer senderId;

    private Integer receiverId;

    private Date sendTime;

    private String content;

    private String title;

    private Integer category;

}