package cc.linkedme.account.dao.page.message;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface MessagePOMapper {
    int countByExample(MessagePOExample example);

    int deleteByExample(MessagePOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(MessagePO record);

    int insertSelective(MessagePO record);

    List<MessagePO> selectByExample(MessagePOExample example);

    MessagePO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") MessagePO record, @Param("example") MessagePOExample example);

    int updateByExample(@Param("record") MessagePO record, @Param("example") MessagePOExample example);

    int updateByPrimaryKeySelective(MessagePO record);

    int updateByPrimaryKey(MessagePO record);
}