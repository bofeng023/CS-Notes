package cc.linkedme.account.dao.account.sms.sign;

import lombok.Data;

import java.util.Date;

@Data
public class SmsSignPO {
    private Integer id;

    private Integer uid;

    private Integer appId;

    private String signName;

    private String powerAttorney;

    private Byte isGlobal;

    private String applyRemark;

    private Byte certificationState;

    private Byte isDeleted;

    private Date gmtCreate;

    private Date gmtUpdate;

}