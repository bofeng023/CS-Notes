package cc.linkedme.account.dao.account.sms.sign;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SmsSignPOMapper {
    long countByExample(SmsSignPOExample example);

    int deleteByExample(SmsSignPOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SmsSignPO record);

    int insertSelective(SmsSignPO record);

    List<SmsSignPO> selectByExample(SmsSignPOExample example);

    SmsSignPO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SmsSignPO record, @Param("example") SmsSignPOExample example);

    int updateByExample(@Param("record") SmsSignPO record, @Param("example") SmsSignPOExample example);

    int updateByPrimaryKeySelective(SmsSignPO record);

    int updateByPrimaryKey(SmsSignPO record);

    List<SmsSignPO> selectByExampleWithLimit(@Param("example") SmsSignPOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);
}