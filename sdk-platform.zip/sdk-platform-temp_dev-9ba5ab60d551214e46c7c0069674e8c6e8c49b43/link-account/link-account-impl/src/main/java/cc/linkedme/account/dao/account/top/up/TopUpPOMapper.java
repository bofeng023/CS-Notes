package cc.linkedme.account.dao.account.top.up;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TopUpPOMapper {
    long countByExample(TopUpPOExample example);

    int deleteByExample(TopUpPOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(TopUpPO record);

    int insertSelective(TopUpPO record);

    List<TopUpPO> selectByExample(TopUpPOExample example);

    TopUpPO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") TopUpPO record, @Param("example") TopUpPOExample example);

    int updateByExample(@Param("record") TopUpPO record, @Param("example") TopUpPOExample example);

    int updateByPrimaryKeySelective(TopUpPO record);

    int updateByPrimaryKey(TopUpPO record);

//    TopUpPO getTopUpAndAuditInfo(@Param("id") Integer id,@Param("bizType") Integer bizType);

    List<TopUpPO> selectByExampleWithLimit(@Param("example") TopUpPOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);

    Long countHistoryTopUp(TopUpPOExample example);

}