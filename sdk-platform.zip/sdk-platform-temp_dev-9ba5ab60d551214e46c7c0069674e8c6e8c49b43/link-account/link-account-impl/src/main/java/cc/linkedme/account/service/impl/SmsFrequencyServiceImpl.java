package cc.linkedme.account.service.impl;

import cc.linkedme.account.converter.SmsFrequencyPoConverter;
import cc.linkedme.account.dao.account.sms.frequency.SmsFrequencyPO;
import cc.linkedme.account.dao.account.sms.frequency.SmsFrequencyPOExample;
import cc.linkedme.account.dao.account.sms.frequency.SmsFrequencyPOMapper;
import cc.linkedme.account.errorcode.SmsFrequencyErrorCode;
import cc.linkedme.account.exception.SmsFrequencyException;
import cc.linkedme.account.model.sms.SmsFrequencyInfo;
import cc.linkedme.account.service.SmsFrequencyService;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service("smsFrequencyService")
public class SmsFrequencyServiceImpl implements SmsFrequencyService {

    private static final Logger logger = LoggerFactory.getLogger(SmsFrequencyServiceImpl.class);
    @Resource
    private SmsFrequencyPOMapper smsFrequencyPOMapper;

    private static final byte DEFAULT_FREQUENCY_PER_DAY = (byte) 40;
    private static final byte DEFAULT_FREQUENCY_PER_HOUR = (byte) 40;
    private static final byte DEFAULT_FREQUENCY_PER_MINUTE = (byte) 40;
    private static final byte MAX_FREQUENCY = (byte) 40;


    @Override
    public SmsFrequencyInfo saveDefaultSmsFrequency(Integer uid) throws SmsFrequencyException {

        logger.info("saveDefaultSmsFrequency, uid:{}", uid);
        Preconditions.checkNotNull(uid, new SmsFrequencyException(SmsFrequencyErrorCode.UID_NULL_ERROR));

        SmsFrequencyPO smsFrequencyPO = new SmsFrequencyPO();
        smsFrequencyPO.setUid(uid);
        smsFrequencyPO.setCountPerDay(DEFAULT_FREQUENCY_PER_DAY);
        smsFrequencyPO.setCountPerHour(DEFAULT_FREQUENCY_PER_HOUR);
        smsFrequencyPO.setCountPerMinute(DEFAULT_FREQUENCY_PER_MINUTE);
        Date currentTime = new Date();
        smsFrequencyPO.setGmtCreate(currentTime);
        smsFrequencyPO.setGmtUpdate(currentTime);

        smsFrequencyPOMapper.insertSelective(smsFrequencyPO);

        logger.info("saveDefaultSmsFrequency, uid:{}, smsFrequencyPO:{}", uid, smsFrequencyPO);
        return SmsFrequencyPoConverter.po2Bo(smsFrequencyPO);

    }

    @Override
    public void updateSmsFrequency(SmsFrequencyInfo smsFrequencyInfo) throws SmsFrequencyException {

        logger.info("updateSmsFrequency start, smsFrequencyInfo:{}", smsFrequencyInfo);
        Preconditions.checkNotNull(smsFrequencyInfo, new SmsFrequencyException(SmsFrequencyErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(smsFrequencyInfo.getId(), new SmsFrequencyException(SmsFrequencyErrorCode.ID_NULL_ERROR));

        SmsFrequencyInfo smsFrequencyInfoCurrent = getSmsFrequency(smsFrequencyInfo.getId(), null);
        if (smsFrequencyInfo.getCountPerMinute() != null) {
            smsFrequencyInfoCurrent.setCountPerMinute(smsFrequencyInfo.getCountPerMinute());
        }
        if (smsFrequencyInfo.getCountPerHour() != null) {
            smsFrequencyInfoCurrent.setCountPerHour(smsFrequencyInfo.getCountPerHour());
        }
        if (smsFrequencyInfo.getCountPerDay() != null) {
            smsFrequencyInfoCurrent.setCountPerDay(smsFrequencyInfo.getCountPerDay());
        }

        checkCountPerUnit(smsFrequencyInfoCurrent);

        SmsFrequencyPO smsFrequencyPO = SmsFrequencyPoConverter.bo2Po(smsFrequencyInfo);
        smsFrequencyPO.setGmtUpdate(new Date());

        smsFrequencyPOMapper.updateByPrimaryKeySelective(smsFrequencyPO);
        logger.info("updateSmsFrequency end, smsFrequencyInfo:{}", smsFrequencyInfo);

    }

    private void checkCountPerUnit(SmsFrequencyInfo smsFrequencyInfo) throws SmsFrequencyException {

        logger.info("checkNewCountPerUnit, smsFrequencyInfo:{}", smsFrequencyInfo);

        if (smsFrequencyInfo.getCountPerMinute() <= 0 || smsFrequencyInfo.getCountPerMinute() > MAX_FREQUENCY
                || smsFrequencyInfo.getCountPerHour() <= 0 || smsFrequencyInfo.getCountPerHour() > MAX_FREQUENCY
                || smsFrequencyInfo.getCountPerDay() <= 0 || smsFrequencyInfo.getCountPerDay() > MAX_FREQUENCY) {
            throw new SmsFrequencyException(SmsFrequencyErrorCode.COUNT_PER_UNIT_ERROR);
        }

        if (smsFrequencyInfo.getCountPerHour() < smsFrequencyInfo.getCountPerMinute()) {
            throw new SmsFrequencyException(SmsFrequencyErrorCode.FREQUENCY_HOUR_LESS_MINUTE_ERROR);
        }
        if (smsFrequencyInfo.getCountPerDay() < smsFrequencyInfo.getCountPerHour()) {
            throw new SmsFrequencyException(SmsFrequencyErrorCode.FREQUENCY_DAY_LESS_HOUR_ERROR);
        }
    }

    @Override
    public SmsFrequencyInfo getSmsFrequency(Integer id, Integer uid) throws SmsFrequencyException {

        logger.info("getSmsFrequency, id:{}, uid:{}", id, uid);
        if (null == id && null == uid) {
            throw new SmsFrequencyException(SmsFrequencyErrorCode.PARAM_NULL_ERROR);
        }

        SmsFrequencyPOExample smsFrequencyPOExample = new SmsFrequencyPOExample();
        SmsFrequencyPOExample.Criteria criteria = smsFrequencyPOExample.createCriteria();
        if (null != uid) {
            criteria.andUidEqualTo(uid);
        } else {
            criteria.andIdEqualTo(id);
        }

        List<SmsFrequencyPO> smsFrequencyPOList = smsFrequencyPOMapper.selectByExample(smsFrequencyPOExample);
        if (CollectionUtils.isEmpty(smsFrequencyPOList)) {
            return null;
        }
        logger.info("getSmsFrequency, id:{}, uid:{}, smsFrequencyPOList:{}", id, uid, smsFrequencyPOList);

        return SmsFrequencyPoConverter.po2Bo(smsFrequencyPOList.get(0));

    }

}
