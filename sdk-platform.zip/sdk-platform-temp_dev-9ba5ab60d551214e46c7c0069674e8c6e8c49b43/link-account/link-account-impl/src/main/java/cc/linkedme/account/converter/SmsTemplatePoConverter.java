package cc.linkedme.account.converter;

import cc.linkedme.account.dao.account.sms.template.SmsTemplatePO;
import cc.linkedme.account.model.sms.SmsTemplateInfo;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 16:04
 * @description
 **/
public class SmsTemplatePoConverter {

    public static SmsTemplatePO bo2Po(SmsTemplateInfo smsTemplateInfo) {

        SmsTemplatePO smsTemplatePO = new SmsTemplatePO();
        BeanUtils.copyProperties(smsTemplateInfo, smsTemplatePO);
        smsTemplatePO.setCertificationState(smsTemplateInfo.getCertificationState() == null ? null : smsTemplateInfo.getCertificationState().getType().byteValue());
        smsTemplatePO.setIsGlobal(smsTemplateInfo.getIsGlobal() == null ? null : smsTemplateInfo.getIsGlobal().getIndex());

        return smsTemplatePO;
    }

    public static SmsTemplateInfo po2Bo(SmsTemplatePO smsTemplatePO) {

        SmsTemplateInfo smsTemplateInfo = new SmsTemplateInfo();
        BeanUtils.copyProperties(smsTemplatePO, smsTemplateInfo);
        smsTemplateInfo.setCertificationState(smsTemplatePO.getCertificationState() == null ? null : AuditState.get(smsTemplatePO.getCertificationState().intValue()));
        smsTemplateInfo.setIsGlobal(smsTemplatePO.getIsGlobal() == null ? null : YesNoEnum.get(smsTemplatePO.getIsGlobal()));

        return smsTemplateInfo;
    }
}
