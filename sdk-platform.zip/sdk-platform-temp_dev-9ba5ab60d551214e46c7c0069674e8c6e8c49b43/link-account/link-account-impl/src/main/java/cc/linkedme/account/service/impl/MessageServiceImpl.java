package cc.linkedme.account.service.impl;

import cc.linkedme.account.constants.MessageConstants;
import cc.linkedme.account.converter.MessagePoConverter;
import cc.linkedme.account.converter.UserMessagePoConverter;
import cc.linkedme.account.dao.page.message.MessagePO;
import cc.linkedme.account.dao.page.message.MessagePOExample;
import cc.linkedme.account.dao.page.message.MessagePOMapper;
import cc.linkedme.account.dao.page.message.userMessage.UserMessagePO;
import cc.linkedme.account.dao.page.message.userMessage.UserMessagePOExample;
import cc.linkedme.account.dao.page.message.userMessage.UserMessagePOMapper;
import cc.linkedme.account.enums.MessageType;
import cc.linkedme.account.errorcode.MessageErrorCode;
import cc.linkedme.account.exception.MessageException;
import cc.linkedme.account.model.MessageInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.UserInfo;
import cc.linkedme.account.model.UserMessageIndex;
import cc.linkedme.account.service.MessageService;
import cc.linkedme.account.service.UserService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import cc.linkedme.util.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: liuyunmeng
 * @Date: Create in 15:01 2019-08-13
 * @:Description
 */
@Service
public class MessageServiceImpl implements MessageService {

    private static final Logger logger = LoggerFactory.getLogger(MessageServiceImpl.class);

    @Resource
    private UserService userService;

    @Resource
    private MessagePOMapper messagePOMapper;

    @Resource
    private UserMessagePOMapper userMessagePOMapper;


    @Override
    public void sendMsg(MessageInfo messageInfo) {

        logger.info("sendMsg, messageInfo:{}", messageInfo);

        Preconditions.checkNotNull(messageInfo, new MessageException(MessageErrorCode.PARAM_NULL_ERROR));
        MessagePO messagePO = MessagePoConverter.bo2Po(messageInfo);
        messagePO.setSendTime(new Date());
        messagePOMapper.insertSelective(messagePO);
        Long msgId = messagePO.getId();

        if (messageInfo.getMessageType().equals(MessageType.SYSTEM_MSG)) {
            // 系统消息
            List<UserMessageIndex> userMessageIndexList = new ArrayList<>();
            List<UserInfo> userInfos = new ArrayList<>();
            if (messageInfo.getReceiverId() > 0){
                // 指定用户的系统消息
                UserInfo userInfo = new UserInfo();
                userInfo.setUid(messageInfo.getReceiverId());
                userInfos.add(userInfo);
            } else {
                // 系统全局消息
                SearchParam searchParam = new SearchParam();
                searchParam.setAuditState(AuditState.AUDIT_PASS.getType());
                userInfos = userService.getUserInfoList(searchParam);
            }

            for (UserInfo userInfo : userInfos) {
                Integer userId = userInfo.getUid();
                UserMessageIndex userMessageIndex = new UserMessageIndex();
                userMessageIndex.setMsgId(msgId);
                userMessageIndex.setUserId(userId);
                if (userId == MessageConstants.ADMINISTRATOR_ID) {
                    userMessageIndex.setReadStatus(YesNoEnum.YES);
                }else{
                    userMessageIndex.setReadStatus(YesNoEnum.NO);
                }
                userMessageIndexList.add(userMessageIndex);
            }
            saveSystemMsg(userMessageIndexList);
        } else if (messageInfo.getMessageType().equals(MessageType.FEEDBACK_MSG)) {
            // 问题反馈消息
            UserMessageIndex userMsgInfo = new UserMessageIndex();
            userMsgInfo.setMsgId(msgId);
            userMsgInfo.setUserId(messageInfo.getReceiverId());
            userMsgInfo.setReadStatus(YesNoEnum.NO);
            userMsgInfo.setRefProblemId(messageInfo.getRefProblemId());
            saveUserMsg(userMsgInfo);
        }

    }

    @Override
    public MessageInfo getMsg(Long messageId, Integer uid) {

        logger.info("getMessage start, messageId:{}, uid:{}", messageId, uid);

        UserMessageIndex userMessageIndex = getUserMsgInfo(messageId, uid);
        if (userMessageIndex == null) {
            throw new MessageException(MessageErrorCode.INVALID_MESSAGE_ID);
        }

        MessagePO messagePO = messagePOMapper.selectByPrimaryKey(messageId);
        MessageInfo messageInfo = MessagePoConverter.po2Bo(messagePO);

        logger.info("getMessage end, messageId:{}, userMessageIndex:{} messageInfo:{}", messageId, userMessageIndex, messageInfo);
        return messageInfo;
    }

    @Override
    public List<MessageInfo> getMsgList(SearchParam searchParam, Integer messageType, Integer readStatus) {

        logger.info("getMessageList start, searchParam:{}", searchParam);

        List<Long> messageIdList = getUserMsgIndexList(searchParam, readStatus);
        MessagePOExample messagePOExample = new MessagePOExample();
        MessagePOExample.Criteria criteria = messagePOExample.createCriteria();
        criteria.andIdIn(messageIdList);
        criteria.andCategoryEqualTo(messageType);
        List<MessagePO> messagePOS = messagePOMapper.selectByExample(messagePOExample);
        List<MessageInfo> messageInfoList = messagePOS.stream().map(messagePO -> MessagePoConverter.po2Bo(messagePO)).collect(Collectors.toList());

        logger.debug("getMsgList end, searchParam:{}, messageInfoList:{}", searchParam, messageIdList);
        return messageInfoList;
    }

    @Override
    public void deleteMsg(Long messageId, Integer uid) {

        logger.info("deleteMessage start, messageId:{}, uid:{}", messageId, uid);

        UserMessageIndex userMessageIndex = getUserMsgInfo(messageId, uid);
        if (userMessageIndex == null) {
            throw new MessageException(MessageErrorCode.INVALID_MESSAGE_ID);
        }

        messagePOMapper.deleteByPrimaryKey(messageId);

        logger.info("deleteMessage end, messageId:{}, uid:{}, userMessageIndex:{}", messageId, uid, userMessageIndex);
    }

    @Override
    public void changeReadStatus(Long messageId, Integer uid) {

        logger.info("changeReadStatus start, messageId:{}, uid:{}", messageId, uid);

        UserMessagePOExample userMessagePOExample = new UserMessagePOExample();
        UserMessagePOExample.Criteria criteria = userMessagePOExample.createCriteria();
        criteria.andReadStatusEqualTo(YesNoEnum.NO.getIndex());
        criteria.andUserIdEqualTo(uid);
        criteria.andMsgIdEqualTo(messageId);
        UserMessagePO userMessagePO = new UserMessagePO();
        userMessagePO.setReadStatus(YesNoEnum.YES.getIndex());
        userMessagePO.setReadTime(new Date());
        userMessagePOMapper.updateByExampleSelective(userMessagePO, userMessagePOExample);

    }

    private void saveSystemMsg(List<UserMessageIndex> userMessageIndexList) {

        logger.debug("saveSystemMessage start, userMessageIndexList:{}", userMessageIndexList);

        if (CollectionUtils.isEmpty(userMessageIndexList)) {
            throw new MessageException(MessageErrorCode.PARAM_NULL_ERROR);
        }

        for (UserMessageIndex userMessageIndex : userMessageIndexList) {
            UserMessagePO userMessagePO = UserMessagePoConverter.bo2Po(userMessageIndex);
            userMessagePOMapper.insertSelective(userMessagePO);
        }

        logger.debug("saveSystemMessage end, userMessageIndexList:{}", userMessageIndexList);
    }

    private void saveUserMsg(UserMessageIndex userMessageIndex) {

        logger.info("saveUserMessage start, userMessageIndex:{}", userMessageIndex);

        Preconditions.checkNotNull(userMessageIndex, new MessageException(MessageErrorCode.PARAM_NULL_ERROR));

        UserMessagePO userMessagePO = UserMessagePoConverter.bo2Po(userMessageIndex);
        userMessagePOMapper.insertSelective(userMessagePO);

        logger.debug("saveUserMessage end, userMessageIndex:{}", userMessageIndex);
    }

    private List<Long> getUserMsgIndexList(SearchParam searchParam, Integer readStatus) {

        logger.info("getUserMessageInfoList start, searchParam:{}", searchParam);

        UserMessagePOExample userMessagePOExample = new UserMessagePOExample();
        UserMessagePOExample.Criteria criteria = userMessagePOExample.createCriteria();
        criteria.andUserIdEqualTo(searchParam.getUid());
        if (readStatus != 2) {
            criteria.andReadStatusEqualTo(readStatus.byteValue());
        }

        List<UserMessagePO> userMessagePOS = userMessagePOMapper.selectByExampleWithLimit(userMessagePOExample, searchParam.getOffset(), searchParam.getSize());
        if (CollectionUtils.isEmpty(userMessagePOS)) {
            return Collections.EMPTY_LIST;
        }
        List<UserMessageIndex> userMessageIndexList = userMessagePOS.stream().map(userMessagePO -> UserMessagePoConverter.po2Bo(userMessagePO)).collect(Collectors.toList());

        List<Long> messageIdList = userMessageIndexList.stream().map(userMessageIndex -> userMessageIndex.getMsgId()).collect(Collectors.toList());
        logger.debug("getUserMessageInfoList end, searchParam:{}, userMessageIndexList:{},messageIdList:{}", searchParam, userMessageIndexList, messageIdList);
        return messageIdList;
    }

    private UserMessageIndex getUserMsgInfo(Long messageId, Integer uid) {

        logger.info("getUserMessageInfo start, messageId:{}, uid:{}", messageId, uid);

        UserMessagePOExample userMessagePOExample = new UserMessagePOExample();
        UserMessagePOExample.Criteria criteria = userMessagePOExample.createCriteria();
        criteria.andUserIdEqualTo(uid);
        criteria.andMsgIdEqualTo(messageId);
        List<UserMessagePO> userMessagePOS = userMessagePOMapper.selectByExample(userMessagePOExample);
        UserMessageIndex userMessageIndex = UserMessagePoConverter.po2Bo(userMessagePOS.get(0));

        logger.info("getUserMessageInfo end, messageId:{}, uid:{}, userMessageIndex", messageId, uid, userMessageIndex);
        return userMessageIndex;
    }


}
