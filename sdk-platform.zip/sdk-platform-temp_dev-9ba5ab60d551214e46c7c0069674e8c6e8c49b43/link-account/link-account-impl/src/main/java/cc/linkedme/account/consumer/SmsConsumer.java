package cc.linkedme.account.consumer;

import cc.linkedme.account.model.sms.SmsInfo;
import cc.linkedme.account.service.provider.sms.SmsProviderService;
import cc.linkedme.kafka.MqEntity;
import cc.linkedme.kafka.consumer.AbstractKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

/**
 * @author zhanghaowei
 * @date 2019-7-18 16:11
 * @description 调用华为发送短信consumer
 **/
public class SmsConsumer extends AbstractKafkaConsumer {

    Logger logger = LoggerFactory.getLogger(SmsConsumer.class);

    @Resource
    private SmsProviderService smsProviderService;

    @Override
    protected void process(Object mqEntry) {
        logger.info("process, mqEntry:{}", mqEntry);

        MqEntity mqEntity = (MqEntity) mqEntry;

        SmsInfo smsInfo = (SmsInfo)mqEntity.getBody();

        smsProviderService.sendText(smsInfo);

        logger.info("process, mqEntity:{}, smsInfo:{}", mqEntity, smsInfo);


    }
}
