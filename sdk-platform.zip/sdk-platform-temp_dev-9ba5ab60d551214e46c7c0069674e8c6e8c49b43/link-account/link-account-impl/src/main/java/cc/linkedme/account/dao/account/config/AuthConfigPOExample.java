package cc.linkedme.account.dao.account.config;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AuthConfigPOExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public AuthConfigPOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andAppIdIsNull() {
            addCriterion("app_id is null");
            return (Criteria) this;
        }

        public Criteria andAppIdIsNotNull() {
            addCriterion("app_id is not null");
            return (Criteria) this;
        }

        public Criteria andAppIdEqualTo(Integer value) {
            addCriterion("app_id =", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdNotEqualTo(Integer value) {
            addCriterion("app_id <>", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdGreaterThan(Integer value) {
            addCriterion("app_id >", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("app_id >=", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdLessThan(Integer value) {
            addCriterion("app_id <", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdLessThanOrEqualTo(Integer value) {
            addCriterion("app_id <=", value, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdIn(List<Integer> values) {
            addCriterion("app_id in", values, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdNotIn(List<Integer> values) {
            addCriterion("app_id not in", values, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdBetween(Integer value1, Integer value2) {
            addCriterion("app_id between", value1, value2, "appId");
            return (Criteria) this;
        }

        public Criteria andAppIdNotBetween(Integer value1, Integer value2) {
            addCriterion("app_id not between", value1, value2, "appId");
            return (Criteria) this;
        }

        public Criteria andAppKeyIsNull() {
            addCriterion("app_key is null");
            return (Criteria) this;
        }

        public Criteria andAppKeyIsNotNull() {
            addCriterion("app_key is not null");
            return (Criteria) this;
        }

        public Criteria andAppKeyEqualTo(String value) {
            addCriterion("app_key =", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotEqualTo(String value) {
            addCriterion("app_key <>", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyGreaterThan(String value) {
            addCriterion("app_key >", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyGreaterThanOrEqualTo(String value) {
            addCriterion("app_key >=", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLessThan(String value) {
            addCriterion("app_key <", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLessThanOrEqualTo(String value) {
            addCriterion("app_key <=", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyLike(String value) {
            addCriterion("app_key like", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotLike(String value) {
            addCriterion("app_key not like", value, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyIn(List<String> values) {
            addCriterion("app_key in", values, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotIn(List<String> values) {
            addCriterion("app_key not in", values, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyBetween(String value1, String value2) {
            addCriterion("app_key between", value1, value2, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppKeyNotBetween(String value1, String value2) {
            addCriterion("app_key not between", value1, value2, "appKey");
            return (Criteria) this;
        }

        public Criteria andAppSecretIsNull() {
            addCriterion("app_secret is null");
            return (Criteria) this;
        }

        public Criteria andAppSecretIsNotNull() {
            addCriterion("app_secret is not null");
            return (Criteria) this;
        }

        public Criteria andAppSecretEqualTo(String value) {
            addCriterion("app_secret =", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotEqualTo(String value) {
            addCriterion("app_secret <>", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretGreaterThan(String value) {
            addCriterion("app_secret >", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretGreaterThanOrEqualTo(String value) {
            addCriterion("app_secret >=", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLessThan(String value) {
            addCriterion("app_secret <", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLessThanOrEqualTo(String value) {
            addCriterion("app_secret <=", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretLike(String value) {
            addCriterion("app_secret like", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotLike(String value) {
            addCriterion("app_secret not like", value, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretIn(List<String> values) {
            addCriterion("app_secret in", values, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotIn(List<String> values) {
            addCriterion("app_secret not in", values, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretBetween(String value1, String value2) {
            addCriterion("app_secret between", value1, value2, "appSecret");
            return (Criteria) this;
        }

        public Criteria andAppSecretNotBetween(String value1, String value2) {
            addCriterion("app_secret not between", value1, value2, "appSecret");
            return (Criteria) this;
        }

        public Criteria andPublicKeyIsNull() {
            addCriterion("public_key is null");
            return (Criteria) this;
        }

        public Criteria andPublicKeyIsNotNull() {
            addCriterion("public_key is not null");
            return (Criteria) this;
        }

        public Criteria andPublicKeyEqualTo(String value) {
            addCriterion("public_key =", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyNotEqualTo(String value) {
            addCriterion("public_key <>", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyGreaterThan(String value) {
            addCriterion("public_key >", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyGreaterThanOrEqualTo(String value) {
            addCriterion("public_key >=", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyLessThan(String value) {
            addCriterion("public_key <", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyLessThanOrEqualTo(String value) {
            addCriterion("public_key <=", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyLike(String value) {
            addCriterion("public_key like", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyNotLike(String value) {
            addCriterion("public_key not like", value, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyIn(List<String> values) {
            addCriterion("public_key in", values, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyNotIn(List<String> values) {
            addCriterion("public_key not in", values, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyBetween(String value1, String value2) {
            addCriterion("public_key between", value1, value2, "publicKey");
            return (Criteria) this;
        }

        public Criteria andPublicKeyNotBetween(String value1, String value2) {
            addCriterion("public_key not between", value1, value2, "publicKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdIsNull() {
            addCriterion("cmcc_android_app_id is null");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdIsNotNull() {
            addCriterion("cmcc_android_app_id is not null");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdEqualTo(String value) {
            addCriterion("cmcc_android_app_id =", value, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdNotEqualTo(String value) {
            addCriterion("cmcc_android_app_id <>", value, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdGreaterThan(String value) {
            addCriterion("cmcc_android_app_id >", value, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdGreaterThanOrEqualTo(String value) {
            addCriterion("cmcc_android_app_id >=", value, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdLessThan(String value) {
            addCriterion("cmcc_android_app_id <", value, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdLessThanOrEqualTo(String value) {
            addCriterion("cmcc_android_app_id <=", value, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdLike(String value) {
            addCriterion("cmcc_android_app_id like", value, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdNotLike(String value) {
            addCriterion("cmcc_android_app_id not like", value, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdIn(List<String> values) {
            addCriterion("cmcc_android_app_id in", values, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdNotIn(List<String> values) {
            addCriterion("cmcc_android_app_id not in", values, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdBetween(String value1, String value2) {
            addCriterion("cmcc_android_app_id between", value1, value2, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppIdNotBetween(String value1, String value2) {
            addCriterion("cmcc_android_app_id not between", value1, value2, "cmccAndroidAppId");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyIsNull() {
            addCriterion("cmcc_android_app_key is null");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyIsNotNull() {
            addCriterion("cmcc_android_app_key is not null");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyEqualTo(String value) {
            addCriterion("cmcc_android_app_key =", value, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyNotEqualTo(String value) {
            addCriterion("cmcc_android_app_key <>", value, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyGreaterThan(String value) {
            addCriterion("cmcc_android_app_key >", value, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyGreaterThanOrEqualTo(String value) {
            addCriterion("cmcc_android_app_key >=", value, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyLessThan(String value) {
            addCriterion("cmcc_android_app_key <", value, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyLessThanOrEqualTo(String value) {
            addCriterion("cmcc_android_app_key <=", value, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyLike(String value) {
            addCriterion("cmcc_android_app_key like", value, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyNotLike(String value) {
            addCriterion("cmcc_android_app_key not like", value, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyIn(List<String> values) {
            addCriterion("cmcc_android_app_key in", values, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyNotIn(List<String> values) {
            addCriterion("cmcc_android_app_key not in", values, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyBetween(String value1, String value2) {
            addCriterion("cmcc_android_app_key between", value1, value2, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppKeyNotBetween(String value1, String value2) {
            addCriterion("cmcc_android_app_key not between", value1, value2, "cmccAndroidAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretIsNull() {
            addCriterion("cmcc_android_app_secret is null");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretIsNotNull() {
            addCriterion("cmcc_android_app_secret is not null");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretEqualTo(String value) {
            addCriterion("cmcc_android_app_secret =", value, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretNotEqualTo(String value) {
            addCriterion("cmcc_android_app_secret <>", value, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretGreaterThan(String value) {
            addCriterion("cmcc_android_app_secret >", value, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretGreaterThanOrEqualTo(String value) {
            addCriterion("cmcc_android_app_secret >=", value, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretLessThan(String value) {
            addCriterion("cmcc_android_app_secret <", value, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretLessThanOrEqualTo(String value) {
            addCriterion("cmcc_android_app_secret <=", value, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretLike(String value) {
            addCriterion("cmcc_android_app_secret like", value, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretNotLike(String value) {
            addCriterion("cmcc_android_app_secret not like", value, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretIn(List<String> values) {
            addCriterion("cmcc_android_app_secret in", values, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretNotIn(List<String> values) {
            addCriterion("cmcc_android_app_secret not in", values, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretBetween(String value1, String value2) {
            addCriterion("cmcc_android_app_secret between", value1, value2, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccAndroidAppSecretNotBetween(String value1, String value2) {
            addCriterion("cmcc_android_app_secret not between", value1, value2, "cmccAndroidAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdIsNull() {
            addCriterion("cmcc_ios_app_id is null");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdIsNotNull() {
            addCriterion("cmcc_ios_app_id is not null");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdEqualTo(String value) {
            addCriterion("cmcc_ios_app_id =", value, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdNotEqualTo(String value) {
            addCriterion("cmcc_ios_app_id <>", value, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdGreaterThan(String value) {
            addCriterion("cmcc_ios_app_id >", value, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdGreaterThanOrEqualTo(String value) {
            addCriterion("cmcc_ios_app_id >=", value, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdLessThan(String value) {
            addCriterion("cmcc_ios_app_id <", value, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdLessThanOrEqualTo(String value) {
            addCriterion("cmcc_ios_app_id <=", value, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdLike(String value) {
            addCriterion("cmcc_ios_app_id like", value, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdNotLike(String value) {
            addCriterion("cmcc_ios_app_id not like", value, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdIn(List<String> values) {
            addCriterion("cmcc_ios_app_id in", values, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdNotIn(List<String> values) {
            addCriterion("cmcc_ios_app_id not in", values, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdBetween(String value1, String value2) {
            addCriterion("cmcc_ios_app_id between", value1, value2, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppIdNotBetween(String value1, String value2) {
            addCriterion("cmcc_ios_app_id not between", value1, value2, "cmccIosAppId");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyIsNull() {
            addCriterion("cmcc_ios_app_key is null");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyIsNotNull() {
            addCriterion("cmcc_ios_app_key is not null");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyEqualTo(String value) {
            addCriterion("cmcc_ios_app_key =", value, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyNotEqualTo(String value) {
            addCriterion("cmcc_ios_app_key <>", value, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyGreaterThan(String value) {
            addCriterion("cmcc_ios_app_key >", value, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyGreaterThanOrEqualTo(String value) {
            addCriterion("cmcc_ios_app_key >=", value, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyLessThan(String value) {
            addCriterion("cmcc_ios_app_key <", value, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyLessThanOrEqualTo(String value) {
            addCriterion("cmcc_ios_app_key <=", value, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyLike(String value) {
            addCriterion("cmcc_ios_app_key like", value, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyNotLike(String value) {
            addCriterion("cmcc_ios_app_key not like", value, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyIn(List<String> values) {
            addCriterion("cmcc_ios_app_key in", values, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyNotIn(List<String> values) {
            addCriterion("cmcc_ios_app_key not in", values, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyBetween(String value1, String value2) {
            addCriterion("cmcc_ios_app_key between", value1, value2, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppKeyNotBetween(String value1, String value2) {
            addCriterion("cmcc_ios_app_key not between", value1, value2, "cmccIosAppKey");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretIsNull() {
            addCriterion("cmcc_ios_app_secret is null");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretIsNotNull() {
            addCriterion("cmcc_ios_app_secret is not null");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretEqualTo(String value) {
            addCriterion("cmcc_ios_app_secret =", value, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretNotEqualTo(String value) {
            addCriterion("cmcc_ios_app_secret <>", value, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretGreaterThan(String value) {
            addCriterion("cmcc_ios_app_secret >", value, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretGreaterThanOrEqualTo(String value) {
            addCriterion("cmcc_ios_app_secret >=", value, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretLessThan(String value) {
            addCriterion("cmcc_ios_app_secret <", value, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretLessThanOrEqualTo(String value) {
            addCriterion("cmcc_ios_app_secret <=", value, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretLike(String value) {
            addCriterion("cmcc_ios_app_secret like", value, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretNotLike(String value) {
            addCriterion("cmcc_ios_app_secret not like", value, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretIn(List<String> values) {
            addCriterion("cmcc_ios_app_secret in", values, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretNotIn(List<String> values) {
            addCriterion("cmcc_ios_app_secret not in", values, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretBetween(String value1, String value2) {
            addCriterion("cmcc_ios_app_secret between", value1, value2, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccIosAppSecretNotBetween(String value1, String value2) {
            addCriterion("cmcc_ios_app_secret not between", value1, value2, "cmccIosAppSecret");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyIsNull() {
            addCriterion("cmcc_private_key is null");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyIsNotNull() {
            addCriterion("cmcc_private_key is not null");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyEqualTo(String value) {
            addCriterion("cmcc_private_key =", value, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyNotEqualTo(String value) {
            addCriterion("cmcc_private_key <>", value, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyGreaterThan(String value) {
            addCriterion("cmcc_private_key >", value, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyGreaterThanOrEqualTo(String value) {
            addCriterion("cmcc_private_key >=", value, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyLessThan(String value) {
            addCriterion("cmcc_private_key <", value, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyLessThanOrEqualTo(String value) {
            addCriterion("cmcc_private_key <=", value, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyLike(String value) {
            addCriterion("cmcc_private_key like", value, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyNotLike(String value) {
            addCriterion("cmcc_private_key not like", value, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyIn(List<String> values) {
            addCriterion("cmcc_private_key in", values, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyNotIn(List<String> values) {
            addCriterion("cmcc_private_key not in", values, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyBetween(String value1, String value2) {
            addCriterion("cmcc_private_key between", value1, value2, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPrivateKeyNotBetween(String value1, String value2) {
            addCriterion("cmcc_private_key not between", value1, value2, "cmccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyIsNull() {
            addCriterion("cmcc_public_key is null");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyIsNotNull() {
            addCriterion("cmcc_public_key is not null");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyEqualTo(String value) {
            addCriterion("cmcc_public_key =", value, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyNotEqualTo(String value) {
            addCriterion("cmcc_public_key <>", value, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyGreaterThan(String value) {
            addCriterion("cmcc_public_key >", value, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyGreaterThanOrEqualTo(String value) {
            addCriterion("cmcc_public_key >=", value, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyLessThan(String value) {
            addCriterion("cmcc_public_key <", value, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyLessThanOrEqualTo(String value) {
            addCriterion("cmcc_public_key <=", value, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyLike(String value) {
            addCriterion("cmcc_public_key like", value, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyNotLike(String value) {
            addCriterion("cmcc_public_key not like", value, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyIn(List<String> values) {
            addCriterion("cmcc_public_key in", values, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyNotIn(List<String> values) {
            addCriterion("cmcc_public_key not in", values, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyBetween(String value1, String value2) {
            addCriterion("cmcc_public_key between", value1, value2, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCmccPublicKeyNotBetween(String value1, String value2) {
            addCriterion("cmcc_public_key not between", value1, value2, "cmccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdIsNull() {
            addCriterion("ctcc_app_id is null");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdIsNotNull() {
            addCriterion("ctcc_app_id is not null");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdEqualTo(String value) {
            addCriterion("ctcc_app_id =", value, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdNotEqualTo(String value) {
            addCriterion("ctcc_app_id <>", value, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdGreaterThan(String value) {
            addCriterion("ctcc_app_id >", value, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdGreaterThanOrEqualTo(String value) {
            addCriterion("ctcc_app_id >=", value, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdLessThan(String value) {
            addCriterion("ctcc_app_id <", value, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdLessThanOrEqualTo(String value) {
            addCriterion("ctcc_app_id <=", value, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdLike(String value) {
            addCriterion("ctcc_app_id like", value, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdNotLike(String value) {
            addCriterion("ctcc_app_id not like", value, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdIn(List<String> values) {
            addCriterion("ctcc_app_id in", values, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdNotIn(List<String> values) {
            addCriterion("ctcc_app_id not in", values, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdBetween(String value1, String value2) {
            addCriterion("ctcc_app_id between", value1, value2, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppIdNotBetween(String value1, String value2) {
            addCriterion("ctcc_app_id not between", value1, value2, "ctccAppId");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretIsNull() {
            addCriterion("ctcc_app_secret is null");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretIsNotNull() {
            addCriterion("ctcc_app_secret is not null");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretEqualTo(String value) {
            addCriterion("ctcc_app_secret =", value, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretNotEqualTo(String value) {
            addCriterion("ctcc_app_secret <>", value, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretGreaterThan(String value) {
            addCriterion("ctcc_app_secret >", value, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretGreaterThanOrEqualTo(String value) {
            addCriterion("ctcc_app_secret >=", value, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretLessThan(String value) {
            addCriterion("ctcc_app_secret <", value, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretLessThanOrEqualTo(String value) {
            addCriterion("ctcc_app_secret <=", value, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretLike(String value) {
            addCriterion("ctcc_app_secret like", value, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretNotLike(String value) {
            addCriterion("ctcc_app_secret not like", value, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretIn(List<String> values) {
            addCriterion("ctcc_app_secret in", values, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretNotIn(List<String> values) {
            addCriterion("ctcc_app_secret not in", values, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretBetween(String value1, String value2) {
            addCriterion("ctcc_app_secret between", value1, value2, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccAppSecretNotBetween(String value1, String value2) {
            addCriterion("ctcc_app_secret not between", value1, value2, "ctccAppSecret");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyIsNull() {
            addCriterion("ctcc_private_key is null");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyIsNotNull() {
            addCriterion("ctcc_private_key is not null");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyEqualTo(String value) {
            addCriterion("ctcc_private_key =", value, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyNotEqualTo(String value) {
            addCriterion("ctcc_private_key <>", value, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyGreaterThan(String value) {
            addCriterion("ctcc_private_key >", value, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyGreaterThanOrEqualTo(String value) {
            addCriterion("ctcc_private_key >=", value, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyLessThan(String value) {
            addCriterion("ctcc_private_key <", value, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyLessThanOrEqualTo(String value) {
            addCriterion("ctcc_private_key <=", value, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyLike(String value) {
            addCriterion("ctcc_private_key like", value, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyNotLike(String value) {
            addCriterion("ctcc_private_key not like", value, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyIn(List<String> values) {
            addCriterion("ctcc_private_key in", values, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyNotIn(List<String> values) {
            addCriterion("ctcc_private_key not in", values, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyBetween(String value1, String value2) {
            addCriterion("ctcc_private_key between", value1, value2, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPrivateKeyNotBetween(String value1, String value2) {
            addCriterion("ctcc_private_key not between", value1, value2, "ctccPrivateKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyIsNull() {
            addCriterion("ctcc_public_key is null");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyIsNotNull() {
            addCriterion("ctcc_public_key is not null");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyEqualTo(String value) {
            addCriterion("ctcc_public_key =", value, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyNotEqualTo(String value) {
            addCriterion("ctcc_public_key <>", value, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyGreaterThan(String value) {
            addCriterion("ctcc_public_key >", value, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyGreaterThanOrEqualTo(String value) {
            addCriterion("ctcc_public_key >=", value, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyLessThan(String value) {
            addCriterion("ctcc_public_key <", value, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyLessThanOrEqualTo(String value) {
            addCriterion("ctcc_public_key <=", value, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyLike(String value) {
            addCriterion("ctcc_public_key like", value, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyNotLike(String value) {
            addCriterion("ctcc_public_key not like", value, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyIn(List<String> values) {
            addCriterion("ctcc_public_key in", values, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyNotIn(List<String> values) {
            addCriterion("ctcc_public_key not in", values, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyBetween(String value1, String value2) {
            addCriterion("ctcc_public_key between", value1, value2, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andCtccPublicKeyNotBetween(String value1, String value2) {
            addCriterion("ctcc_public_key not between", value1, value2, "ctccPublicKey");
            return (Criteria) this;
        }

        public Criteria andGmtCreateIsNull() {
            addCriterion("gmt_create is null");
            return (Criteria) this;
        }

        public Criteria andGmtCreateIsNotNull() {
            addCriterion("gmt_create is not null");
            return (Criteria) this;
        }

        public Criteria andGmtCreateEqualTo(Date value) {
            addCriterion("gmt_create =", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateNotEqualTo(Date value) {
            addCriterion("gmt_create <>", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateGreaterThan(Date value) {
            addCriterion("gmt_create >", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateGreaterThanOrEqualTo(Date value) {
            addCriterion("gmt_create >=", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateLessThan(Date value) {
            addCriterion("gmt_create <", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateLessThanOrEqualTo(Date value) {
            addCriterion("gmt_create <=", value, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateIn(List<Date> values) {
            addCriterion("gmt_create in", values, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateNotIn(List<Date> values) {
            addCriterion("gmt_create not in", values, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateBetween(Date value1, Date value2) {
            addCriterion("gmt_create between", value1, value2, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtCreateNotBetween(Date value1, Date value2) {
            addCriterion("gmt_create not between", value1, value2, "gmtCreate");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedIsNull() {
            addCriterion("gmt_modified is null");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedIsNotNull() {
            addCriterion("gmt_modified is not null");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedEqualTo(Date value) {
            addCriterion("gmt_modified =", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedNotEqualTo(Date value) {
            addCriterion("gmt_modified <>", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedGreaterThan(Date value) {
            addCriterion("gmt_modified >", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedGreaterThanOrEqualTo(Date value) {
            addCriterion("gmt_modified >=", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedLessThan(Date value) {
            addCriterion("gmt_modified <", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedLessThanOrEqualTo(Date value) {
            addCriterion("gmt_modified <=", value, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedIn(List<Date> values) {
            addCriterion("gmt_modified in", values, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedNotIn(List<Date> values) {
            addCriterion("gmt_modified not in", values, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedBetween(Date value1, Date value2) {
            addCriterion("gmt_modified between", value1, value2, "gmtModified");
            return (Criteria) this;
        }

        public Criteria andGmtModifiedNotBetween(Date value1, Date value2) {
            addCriterion("gmt_modified not between", value1, value2, "gmtModified");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}