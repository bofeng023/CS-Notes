package cc.linkedme.account.converter;

import cc.linkedme.account.dao.page.message.userMessage.UserMessagePO;
import cc.linkedme.account.model.UserMessageIndex;
import cc.linkedme.enums.YesNoEnum;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 12:03 2019-08-14
 * @:Description
 */
public class UserMessagePoConverter {

    public static UserMessagePO bo2Po(UserMessageIndex userMessageIndex) {

        UserMessagePO userMessagePo = new UserMessagePO();
        BeanUtils.copyProperties(userMessageIndex, userMessagePo);
        userMessagePo.setReadStatus(userMessageIndex.getReadStatus() == null ? 0 : userMessageIndex.getReadStatus().getIndex().byteValue());
        return userMessagePo;
    }

    public static UserMessageIndex po2Bo(UserMessagePO userMessagePo) {

        UserMessageIndex userMessageIndex = new UserMessageIndex();
        BeanUtils.copyProperties(userMessagePo, userMessageIndex);
        userMessageIndex.setReadStatus(YesNoEnum.get(userMessagePo.getReadStatus().byteValue()));
        return userMessageIndex;
    }

}
