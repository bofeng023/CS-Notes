package cc.linkedme.account.converter;

import cc.linkedme.account.dao.page.user.UserPOWithBLOBs;
import cc.linkedme.account.model.UserInfo;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:55 2019-08-16
 * @:Description
 */
public class UserPoConverter {

    public static UserInfo po2Bo(UserPOWithBLOBs userPO) {

        UserInfo userInfo = new UserInfo();
        BeanUtils.copyProperties(userPO, userInfo);
        userInfo.setUid(userPO.getId());
        userInfo.setActiveStatus(userPO.getActiveStatus() == null ? null : YesNoEnum.get(userPO.getActiveStatus()));
        userInfo.setAuditState(userPO.getAuditState() == null ? null : AuditState.get(userPO.getAuditState().intValue()));

        return userInfo;

    }
}
