package cc.linkedme.account.converter;

import cc.linkedme.account.dao.account.audit.AuditInfoPO;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 16:28
 * @description
 **/
public class AuditPoConverter {

    public static AuditInfoPO bo2Po(AuditInfo auditInfo) {

        AuditInfoPO auditInfoPO = new AuditInfoPO();
        BeanUtils.copyProperties(auditInfo, auditInfoPO);
        auditInfoPO.setBizType(auditInfo.getBizType() == null ? null : auditInfo.getBizType().getType().byteValue());
        auditInfoPO.setAuditState(auditInfo.getAuditState() == null ? null : auditInfo.getAuditState().getType().byteValue());

        return auditInfoPO;
    }

    public static AuditInfo po2Bo(AuditInfoPO auditInfoPO) {

        AuditInfo auditInfo = new AuditInfo();
        BeanUtils.copyProperties(auditInfoPO, auditInfo);
        auditInfo.setBizType(auditInfoPO.getBizType() == null ? null : BizType.get(auditInfoPO.getBizType().intValue()));
        auditInfo.setAuditState(auditInfoPO.getAuditState() == null ? null : AuditState.get(auditInfoPO.getAuditState().intValue()));

        return auditInfo;
    }
}
