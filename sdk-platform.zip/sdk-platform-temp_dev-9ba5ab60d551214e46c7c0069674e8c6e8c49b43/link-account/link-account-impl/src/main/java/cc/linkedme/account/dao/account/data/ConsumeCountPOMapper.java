package cc.linkedme.account.dao.account.data;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ConsumeCountPOMapper {
    long countByExample(ConsumeCountPOExample example);

    int deleteByExample(ConsumeCountPOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ConsumeCountPO record);

    int insertSelective(ConsumeCountPO record);

    List<ConsumeCountPO> selectByExample(ConsumeCountPOExample example);

    ConsumeCountPO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ConsumeCountPO record, @Param("example") ConsumeCountPOExample example);

    int updateByExample(@Param("record") ConsumeCountPO record, @Param("example") ConsumeCountPOExample example);

    int updateByPrimaryKeySelective(ConsumeCountPO record);

    int updateByPrimaryKey(ConsumeCountPO record);

    List<ConsumeCountPO> selectByExampleWithLimitByDay(@Param("example") ConsumeCountPOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);

    List<ConsumeCountPO> selectByExampleWithLimitByHour(@Param("example") ConsumeCountPOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);

    Long countConsumeCountByDay(@Param("example") ConsumeCountPOExample example);

    Long countConsumeCountByHour(@Param("example") ConsumeCountPOExample example);

    ConsumeCountPO totalConsumeCount(@Param("example") ConsumeCountPOExample example);

    ConsumeCountPO countDayTotalAmountAndRequestCount(@Param("example") ConsumeCountPOExample example);

}