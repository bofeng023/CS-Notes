package cc.linkedme.account.dao.page.message.userMessage;

import lombok.Data;

import java.util.Date;

@Data
public class UserMessagePO {
    private Long id;

    private Long msgId;

    private Long refProblemId;

    private Integer userId;

    private Byte readStatus;

    private Date readTime;
}