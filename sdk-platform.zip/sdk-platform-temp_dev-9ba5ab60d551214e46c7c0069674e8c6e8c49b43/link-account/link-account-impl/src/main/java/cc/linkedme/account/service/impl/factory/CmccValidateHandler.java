package cc.linkedme.account.service.impl.factory;

import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.enums.provider.login.CmccResponseCode;
import cc.linkedme.account.enums.Platform;
import cc.linkedme.account.errorcode.PhoneNumVerificationErrorCode;
import cc.linkedme.account.exception.PhoneNumVerificationException;
import cc.linkedme.account.model.AuthConfigInfo;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.model.provider.login.CmccGetMobileRequest;
import cc.linkedme.account.model.provider.login.CmccGetMobileResponse;
import cc.linkedme.account.model.provider.login.CmccVerifyMobileRequest;
import cc.linkedme.account.model.provider.login.CmccVerifyMobileResponse;
import cc.linkedme.account.service.AccountBalanceService;
import cc.linkedme.account.service.impl.PhoneNumVerificationServiceImpl;
import cc.linkedme.account.common.crypto.HmacSHA256;
import cc.linkedme.json.JsonConverter;
import cc.linkedme.account.common.crypto.Sha256;
import cc.linkedme.account.common.http.HttpClientUtil;
import cc.linkedme.account.common.crypto.Rsa;
import cc.linkedme.account.common.crypto.SignAlgorithm;
import cc.linkedme.enums.BizType;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.util.UUID;

/**
 * @author yangpeng
 * @date 2019-06-13 14:21
 * @description
 **/

@Component("cmccValidateHandler")
public class CmccValidateHandler extends PhoneNumVerificationServiceImpl {

    private static final Logger logger = LoggerFactory.getLogger(CmccValidateHandler.class);

    private static final String CMCC_GET_PHONE_NUM_URL = "http://www.cmpassport.com/unisdk/rsapi/loginTokenValidate";
    private static final String CMCC_VERIFY_PHONE_NUM_URL = "http://www.cmpassport.com/openapi/rs/tokenValidate";
    @Resource
    protected AccountBalanceService accountBalanceService;

    @Override
    protected Object buildGetMobileRequestParams(Platform platform, String token, String authCode, AuthConfigInfo authConfigInfo) {

        logger.info("buildGetMobileRequestParams, platform:{}, token:{}", platform, token);
        AuthConfigInfo.Cmcc cmcc = authConfigInfo.getCmcc();

        CmccGetMobileRequest cmccGetMobileRequest = new CmccGetMobileRequest();
        cmccGetMobileRequest.setVersion("2.0");
        cmccGetMobileRequest.setMsgid(UUID.randomUUID().toString());
        cmccGetMobileRequest.setSystemtime(String.valueOf(LocalDate.now().getYear()) + System.currentTimeMillis());
        cmccGetMobileRequest.setStrictcheck("1");
        cmccGetMobileRequest.setAppid(Platform.IOS.equals(platform) ? cmcc.getIosAppId() : cmcc.getAndroidAppId());
        cmccGetMobileRequest.setToken(token);

        logger.debug("buildGetMobileRequestParams, platform:{}, token:{}, cmccGetMobileRequest:{}", platform, token, cmccGetMobileRequest);
        return cmccGetMobileRequest;
    }

    @Override
    protected Object fillGetMobileRequestSign(Object requestParams, AuthConfigInfo authConfigInfo) {

        logger.info("fillGetMobileRequestSign, requestParams:{}", requestParams);
        AuthConfigInfo.Cmcc cmcc = authConfigInfo.getCmcc();

        CmccGetMobileRequest cmccGetMobileRequest = (CmccGetMobileRequest) requestParams;
        String sign;
        try {
            sign = Rsa.signHex(cmccGetMobileRequest.getAppid() + cmccGetMobileRequest.getToken(), cmcc.getPrivateKey(), SignAlgorithm.SHA256withRSA);
        } catch (Exception e) {
            logger.warn("fillGetMobileRequestSign, sign error, requestParams:{}", requestParams, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.RSA_SIGN_ERROR);
        }

        cmccGetMobileRequest.setEncryptionalgorithm("RSA");
        cmccGetMobileRequest.setSign(sign);
        logger.debug("fillGetMobileRequestSign, requestParams:{}", requestParams);

        return cmccGetMobileRequest;
    }

    @Override
    protected String requestGetMobileServer(Object requestParams) {

        logger.info("requestGetMobileServer, requestParams:{}", requestParams);

        CmccGetMobileRequest cmccGetMobileRequest = (CmccGetMobileRequest) requestParams;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        httpClientUtil.httpPost(CMCC_GET_PHONE_NUM_URL, JsonConverter.format(cmccGetMobileRequest), byteArrayOutputStream);
        String result = byteArrayOutputStream.toString();
        return result;
    }

    @Override
    protected Long parseMobile(String response, AuthConfigInfo authConfigInfo, BalanceUnitPrice balanceUnitPrice, Integer uid, Channel channel) {

        logger.info("parseMobile, response:{}, balanceUnitPrice:{}", response, balanceUnitPrice);

        CmccGetMobileResponse cmccGetMobileResponse = JsonConverter.parse(response, CmccGetMobileResponse.class);
        if (!CmccResponseCode.SUCCESS.equals(CmccResponseCode.get(cmccGetMobileResponse.getResultCode()))) {
            accountBalanceService.refund(uid, BizType.QUICK_LOGIN, balanceUnitPrice, channel, 1);
            checkResponseCode(cmccGetMobileResponse.getResultCode());
        }

        String mobile;
        try {
            mobile = Rsa.decryptHex(cmccGetMobileResponse.getMsisdn(), authConfigInfo.getCmcc().getPrivateKey());
        } catch (Exception e) {
            logger.warn("parseMobile error, response:{}, cmccGetMobileResponse:{}", response, cmccGetMobileResponse);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.RSA_DECRYPT_ERROR);
        }

        logger.info("parseMobile, response:{}, balanceUnitPrice:{}, mobile:{}", response, balanceUnitPrice, mobile);
        return Long.valueOf(mobile);
    }

    @Override
    protected Object buildVerifyMobileRequestParams(Platform platform, String token, String mobile, AuthConfigInfo authConfigInfo) {

        logger.info("buildVerifyMobileRequestParams, platform:{}, token:{}, mobile:{}", platform, token, mobile);

        AuthConfigInfo.Cmcc cmcc = authConfigInfo.getCmcc();

        CmccVerifyMobileRequest cmccVerifyMobileRequest = new CmccVerifyMobileRequest();
        CmccVerifyMobileRequest.Header header = new CmccVerifyMobileRequest.Header();
        CmccVerifyMobileRequest.Body body = new CmccVerifyMobileRequest.Body();

        header.setVersion("1.0");
        header.setMsgId(UUID.randomUUID().toString());
        header.setTimestamp(String.valueOf(LocalDate.now().getYear()) + System.currentTimeMillis());
        header.setAppId(Platform.IOS.equals(platform) ? cmcc.getIosAppId() : cmcc.getAndroidAppId());

        body.setOpenType("1");
        body.setRequesterType("0");
        String appKey = Platform.IOS.equals(platform) ? cmcc.getIosAppKey() : cmcc.getAndroidAppKey();
        body.setPhoneNum(Sha256.SHA256(mobile + appKey + header.getTimestamp()).toUpperCase());
        body.setToken(token);

        cmccVerifyMobileRequest.setHeader(header);
        cmccVerifyMobileRequest.setBody(body);
        logger.debug("buildVerifyMobileRequestParams, platform:{}, token:{}, mobile:{}, cmccVerifyMobileRequest:{}", platform, token, mobile, cmccVerifyMobileRequest);

        return cmccVerifyMobileRequest;
    }

    @Override
    protected Object fillVerifyMobileRequestSign(Object requestParams, AuthConfigInfo authConfigInfo) {

        logger.info("fillVerifyMobileRequestSign, requestParams:{}", requestParams);

        AuthConfigInfo.Cmcc cmcc = authConfigInfo.getCmcc();

        CmccVerifyMobileRequest cmccVerifyMobileRequest = (CmccVerifyMobileRequest) requestParams;
        String appKey = cmccVerifyMobileRequest.getHeader().getAppId().equals(cmcc.getIosAppId()) ? cmcc.getIosAppKey() : cmcc.getAndroidAppKey();
        String sign = HmacSHA256.sha256_HMAC(cmccVerifyMobileRequest.getHeader().getAppId()
                + cmccVerifyMobileRequest.getHeader().getMsgId() + cmccVerifyMobileRequest.getBody().getPhoneNum()
                + cmccVerifyMobileRequest.getHeader().getTimestamp() + cmccVerifyMobileRequest.getBody().getToken()
                + cmccVerifyMobileRequest.getHeader().getVersion(), appKey).toUpperCase();

        cmccVerifyMobileRequest.getBody().setSign(sign);
        logger.debug("fillVerifyMobileRequestSign, cmccVerifyMobileRequest:{}", cmccVerifyMobileRequest);

        return cmccVerifyMobileRequest;
    }

    @Override
    protected String requestVerifyMobileServer(Object requestParams, AuthConfigInfo authConfigInfo) {

        logger.info("requestVerifyMobileServer, requestParams:{}", requestParams);
        CmccVerifyMobileRequest cmccVerifyMobileRequest = (CmccVerifyMobileRequest) requestParams;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        httpClientUtil.httpPost(CMCC_VERIFY_PHONE_NUM_URL, JsonConverter.format(cmccVerifyMobileRequest), byteArrayOutputStream);

        return byteArrayOutputStream.toString();
    }

    @Override
    protected Boolean parseVerifyResult(String response, AuthConfigInfo authConfigInfo, BalanceUnitPrice balanceUnitPrice, Integer uid, Channel channel) {

        logger.info("parseVerifyResult, response:{}", response);

        CmccVerifyMobileResponse cmccVerifyMobileResponse = JsonConverter.parse(response, CmccVerifyMobileResponse.class);
        Boolean verifyResult = false;
        String responseCode =cmccVerifyMobileResponse.getHeader().getResultCode();
        if (CmccResponseCode.OWN_NUMBER.equals(CmccResponseCode.get(responseCode))) {
            verifyResult = true;
        } else if (!CmccResponseCode.NO_OWN_NUMBER.equals(CmccResponseCode.get(responseCode))) {
            accountBalanceService.refund(uid, BizType.NUMBER_VERIFY, balanceUnitPrice, channel, 1);
            checkResponseCode(responseCode);
        }

        return verifyResult;
    }

    @Override
    protected void checkResponseCode(String responseCode) {

        logger.info("checkResponseCode, responseCode:{}", responseCode);

        switch (CmccResponseCode.get(responseCode)) {
            case SUCCESS:
                break;
            case SIGN_ERROR:
            case SING_VERIFY_ERROR:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.SIGN_ERROR);
            case TOKEN_ERROR:
            case TOKEN_NULL:
            case TOKEN_INTERNAL_VERIFY_FAILED:
            case TOKEN_VERIFY_FAILED:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.TOKEN_ERROR);
            case TOKEN_INVALID:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.TOKEN_EXPIRED);
            case APP_ID_NOT_EXIST:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.APP_ID_ERROR);
            case PARAM_VERIFY_ERROR:
            case PARAM_ERROR:
            case PARAM_INVALID:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.PARAM_ERROR);
            case PERMISSION_DENIED:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.PERMISSION_DENIED);
            case APP_NO_AUTHORIZATION:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.APP_NO_AUTHORIZATION);
            case MOBILE_ENCRYPT_ERROR:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.ENCRYPT_ERROR);
            case WHITELIST_VERIFY_ERROR:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.IP_WHITELIST_ERROR);
            case GET_NUMBER_FAILED:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.GET_MOBILE_FAILED);
            case NO_QUOTAS:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.NO_QUOTAS);
            default:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.OTHER_ERROR);
        }
    }

    public static void main(String[] args) {
        String token = "STsid0000001560508857384aNr3BYrAbRR5gv0wJCXHjfcE7gCUju2I";
        Long mobile = 15255708552L;
        HttpClientUtil httpClientUtil = new HttpClientUtil();
        CmccValidateHandler cmccValidateHandler = new CmccValidateHandler();
        cmccValidateHandler.setHttpClientUtil(httpClientUtil);

        Integer appId = 0;

        cmccValidateHandler.verifyLoginPhoneNum(Channel.MOBILE, Platform.ANDROID, token, mobile, appId);
    }


}
