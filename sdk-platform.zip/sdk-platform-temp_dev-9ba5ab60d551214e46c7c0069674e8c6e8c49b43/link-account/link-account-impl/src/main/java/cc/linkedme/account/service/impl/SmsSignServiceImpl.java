package cc.linkedme.account.service.impl;

import cc.linkedme.account.converter.SmsSignPoConverter;
import cc.linkedme.account.dao.account.sms.sign.SmsSignPO;
import cc.linkedme.account.dao.account.sms.sign.SmsSignPOExample;
import cc.linkedme.account.dao.account.sms.sign.SmsSignPOMapper;
import cc.linkedme.account.errorcode.SmsSignErrorCode;
import cc.linkedme.account.exception.SmsSignException;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.sms.SmsSignInfo;
import cc.linkedme.account.service.SmsSignService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service("smsSignService")
public class SmsSignServiceImpl implements SmsSignService {

    private static final Logger logger = LoggerFactory.getLogger(SmsSignServiceImpl.class);

    @Resource
    private SmsSignPOMapper smsSignPOMapper;

    @Override
    public SmsSignInfo saveSmsSign(SmsSignInfo smsSignInfo) throws SmsSignException {

        logger.info("saveSmsSign, begin smsSignInfo:{}", smsSignInfo);
        Preconditions.checkNotNull(smsSignInfo, new SmsSignException(SmsSignErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(smsSignInfo.getUid(), new SmsSignException(SmsSignErrorCode.UID_NULL_ERROR));
        Preconditions.checkNotNull(smsSignInfo.getSignName(), new SmsSignException(SmsSignErrorCode.NAME_NULL_ERROR));
        Preconditions.checkNotNull(smsSignInfo.getIsGlobal(), new SmsSignException(SmsSignErrorCode.GLOBAL_NULL_ERROR));
        //无论是否开通国际/港澳台 都要上传授权委托书
        Preconditions.checkNotNull(smsSignInfo.getPowerAttorney(), new SmsSignException(SmsSignErrorCode.POWER_ATTORNEY_NULL_ERROR));

        SmsSignPO smsSignPO = SmsSignPoConverter.bo2Po(smsSignInfo);
        smsSignPO.setIsDeleted(YesNoEnum.NO.getIndex());
        smsSignPO.setCertificationState(AuditState.AUDITING.getType().byteValue());
        Date currentTime = new Date();
        smsSignPO.setGmtCreate(currentTime);
        smsSignPO.setGmtUpdate(currentTime);

        smsSignPOMapper.insertSelective(smsSignPO);
        logger.info("saveSmsSign, end smsSignInfo:{}, smsSignPO:{}", smsSignInfo, smsSignPO);

        return SmsSignPoConverter.po2Bo(smsSignPO);

    }

    @Override
    public Integer updateSmsSign(SmsSignInfo smsSignInfo) throws SmsSignException {

        logger.info("updateSmsSign, smsSignInfo:{}", smsSignInfo);
        Preconditions.checkNotNull(smsSignInfo, new SmsSignException(SmsSignErrorCode.PARAM_NULL_ERROR));
        Preconditions.checkNotNull(smsSignInfo.getId(), new SmsSignException(SmsSignErrorCode.ID_NULL_ERROR));

        SmsSignPO smsSignPO = SmsSignPoConverter.bo2Po(smsSignInfo);
        smsSignPO.setCertificationState(smsSignInfo.getCertificationState() == null ? AuditState.TO_BE_AUDITED.getType().byteValue() : smsSignInfo.getCertificationState().getType().byteValue());
        smsSignPO.setGmtUpdate(new Date());

        return smsSignPOMapper.updateByPrimaryKeySelective(smsSignPO);

    }

    @Override
    public void removeSmsSign(Integer smsSignId) throws SmsSignException {

        logger.info("removeSmsSign, smsSignId:{}", smsSignId);
        Preconditions.checkNotNull(smsSignId, new SmsSignException(SmsSignErrorCode.ID_NULL_ERROR));

        SmsSignPO smsSignPO = new SmsSignPO();
        smsSignPO.setId(smsSignId);
        smsSignPO.setIsDeleted(YesNoEnum.YES.getIndex());
        smsSignPO.setGmtUpdate(new Date());

        smsSignPOMapper.updateByPrimaryKeySelective(smsSignPO);

    }

    @Override
    public SmsSignInfo getSmsSign(Integer smsSignId) throws SmsSignException {

        logger.info("getSmsSign, smsSignId:{}", smsSignId);
        Preconditions.checkNotNull(smsSignId, new SmsSignException(SmsSignErrorCode.ID_NULL_ERROR));

        SmsSignPOExample smsSignPOExample = new SmsSignPOExample();
        SmsSignPOExample.Criteria criteria = smsSignPOExample.createCriteria();
        criteria.andIdEqualTo(smsSignId);
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());

        List<SmsSignPO> smsSignPOList = smsSignPOMapper.selectByExample(smsSignPOExample);
        if (CollectionUtils.isEmpty(smsSignPOList)) {
            return null;
        }

        SmsSignInfo smsSignInfo = SmsSignPoConverter.po2Bo(smsSignPOList.get(0));
        logger.info("getSmsSign, smsSignId:{}, smsSignInfo:{}", smsSignId, smsSignInfo);

        return smsSignInfo;
    }

    @Override
    public SmsSignInfo getSmsSign(String signName, Integer appId, AuditState auditState) throws SmsSignException {

        logger.info("getSmsSign, signName:{}, appId:{}, certificationState:{}", signName, appId, auditState);

        Preconditions.checkNotNull(signName, new SmsSignException(SmsSignErrorCode.NAME_NULL_ERROR));
        Preconditions.checkNotNull(appId, new SmsSignException(SmsSignErrorCode.APPID_NULL_ERROR));
        Preconditions.checkNotNull(auditState, new SmsSignException(SmsSignErrorCode.AUDITSTATUS_NULL_ERROR));

        SmsSignPOExample smsSignPOExample = new SmsSignPOExample();
        SmsSignPOExample.Criteria criteria = smsSignPOExample.createCriteria();
        criteria.andSignNameEqualTo(signName);
        criteria.andAppIdEqualTo(appId);
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());
        criteria.andCertificationStateEqualTo(auditState.getType().byteValue());

        List<SmsSignPO> smsSignPOList = smsSignPOMapper.selectByExample(smsSignPOExample);
        if (CollectionUtils.isEmpty(smsSignPOList)) {
            return null;
        }

        SmsSignInfo smsSignInfo = SmsSignPoConverter.po2Bo(smsSignPOList.get(0));
        logger.info("getSmsSign, signName:{}, appId:{}, certificationState:{}, smsSignInfo:{}", signName, appId, auditState, smsSignInfo);

        return smsSignInfo;
    }

    @Override
    public Map<Integer, SmsSignInfo> getBatchSmsSign(List<Integer> smsSignIdList) throws SmsSignException {

        logger.info("getBatchSmsSign, smsSignIdList:{}", smsSignIdList);
        Preconditions.checkNotEmpty(smsSignIdList, new SmsSignException(SmsSignErrorCode.ID_NULL_ERROR));

        SmsSignPOExample smsSignPOExample = new SmsSignPOExample();
        SmsSignPOExample.Criteria criteria = smsSignPOExample.createCriteria();
        criteria.andIdIn(smsSignIdList);
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());

        List<SmsSignPO> smsSignPOList = smsSignPOMapper.selectByExample(smsSignPOExample);
        if (CollectionUtils.isEmpty(smsSignPOList)) {
            return Collections.EMPTY_MAP;
        }

        Map<Integer, SmsSignInfo> smsSignInfoMap = new HashMap<>(smsSignIdList.size());
        smsSignPOList.forEach(smsSignPO -> smsSignInfoMap.put(smsSignPO.getId(), SmsSignPoConverter.po2Bo(smsSignPO)));

        logger.debug("getBatchSmsSign, smsSignIdList:{}, smsSignInfoMap:{}", smsSignIdList, smsSignInfoMap);
        return smsSignInfoMap;
    }


    @Override
    public List<SmsSignInfo> listSmsSign(Integer uid, SearchParam searchParam) throws SmsSignException {

        logger.info("listSmsSign, uid:{}, page:{}", uid, searchParam);
        Preconditions.checkNotNull(searchParam, new SmsSignException(SmsSignErrorCode.PARAM_NULL_ERROR));

        SmsSignPOExample smsSignPOExample = new SmsSignPOExample();
        SmsSignPOExample.Criteria criteria = smsSignPOExample.createCriteria();
        if (null != uid) {
            criteria.andUidEqualTo(uid);
        }
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());

        if (searchParam.getStartDate() != null && searchParam.getEndDate() != null) {
            criteria.andGmtCreateBetween(searchParam.getStartDate(), searchParam.getEndDate());
        }

        if (searchParam.getUid() != null) {
            criteria.andUidEqualTo(searchParam.getUid());
        }
        if (searchParam.getAuditState() != null) {
            criteria.andCertificationStateEqualTo(searchParam.getAuditState().byteValue());
        }

        smsSignPOExample.setOrderByClause("gmt_create desc");

        List<SmsSignPO> smsSignPOList = smsSignPOMapper.selectByExampleWithLimit(smsSignPOExample, searchParam.getOffset(), searchParam.getSize());
        if (CollectionUtils.isEmpty(smsSignPOList)) {
            return Collections.EMPTY_LIST;
        }

        List<SmsSignInfo> smsSignInfoList = smsSignPOList.stream().map(smsSignPO -> SmsSignPoConverter.po2Bo(smsSignPO)).collect(Collectors.toList());
        logger.debug("listSmsSign, uid:{}, page:{}, smsSignInfoList:{}", uid, searchParam, smsSignInfoList);

        return smsSignInfoList;
    }

//    @Override
//    public SmsSignInfo getSmsSignAndAuditInfo(Integer smsSignId) throws SmsSignException {
//
//        bizlog.info("getSmsSignAndAuditInfo, smsSignId:{}", smsSignId);
//        Preconditions.checkNotNull(smsSignId, new SmsSignException(SmsSignErrorCode.ID_NULL_ERROR));
//
//        SmsSignPO smsSignPO = smsSignPOMapper.getSmsSignAndAuditInfo(smsSignId, BizType.SIGN.getType());
//        if (smsSignPO == null) {
//            return null;
//        }
//
//        bizlog.info("getSmsSignAndAuditInfo, smsSignId:{}, smsSignPO:{}", smsSignId, smsSignPO);
//        return SmsSignPoConverter.po2Bo(smsSignPO);
//    }

    @Override
    public Long countSmsSign(Integer uid, SearchParam searchParam) throws SmsSignException {

        logger.info("countSmsSign, uid:{}");

        SmsSignPOExample smsSignPOExample = new SmsSignPOExample();
        SmsSignPOExample.Criteria criteria = smsSignPOExample.createCriteria();
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());
        if (null != uid) {
            criteria.andUidEqualTo(uid);
        }

        if (searchParam != null) {
            if (searchParam.getStartDate() != null && searchParam.getEndDate() != null) {
                criteria.andGmtCreateBetween(searchParam.getStartDate(), searchParam.getEndDate());
            }

            if (searchParam.getUid() != null) {
                criteria.andUidEqualTo(searchParam.getUid());
            }
            if (searchParam.getAuditState() != null) {
                criteria.andCertificationStateEqualTo(searchParam.getAuditState().byteValue());
            }
        }

        Long smsSignCount = smsSignPOMapper.countByExample(smsSignPOExample);

        logger.info("countSmsSign, uid:{}, smsSignCount:{}", uid, smsSignCount);
        return smsSignCount;
    }

    @Override
    public Long countAuditPassGlobal(Integer uid) throws SmsSignException {

        SmsSignPOExample smsSignPOExample = new SmsSignPOExample();
        SmsSignPOExample.Criteria criteria = smsSignPOExample.createCriteria();
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());
        if (null != uid) {
            criteria.andUidEqualTo(uid);
        }

        criteria.andIsGlobalEqualTo((byte) 1);
        criteria.andCertificationStateEqualTo(AuditState.AUDIT_PASS.getType().byteValue());

        Long smsSignCount = smsSignPOMapper.countByExample(smsSignPOExample);

        logger.info("countAuditPassGlobal, uid:{}, smsSignCount:{}", uid, smsSignCount);
        return smsSignCount;

    }

    @Override
    public SmsSignInfo getSmsSign(Integer appId, String smsSignName) throws SmsSignException {
        logger.info("getSmsSign, appId:{}, smsSignName:{}", appId, smsSignName);
        Preconditions.checkNotNull(smsSignName, new SmsSignException(SmsSignErrorCode.NAME_NULL_ERROR));

        SmsSignPOExample smsSignPOExample = new SmsSignPOExample();
        SmsSignPOExample.Criteria criteria = smsSignPOExample.createCriteria();
        criteria.andAppIdEqualTo(appId);
        criteria.andSignNameEqualTo(smsSignName);
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());

        List<SmsSignPO> smsSignPOList = smsSignPOMapper.selectByExample(smsSignPOExample);
        if (CollectionUtils.isEmpty(smsSignPOList)) {
            return null;
        }

        SmsSignInfo smsSignInfo = SmsSignPoConverter.po2Bo(smsSignPOList.get(0));
        logger.info("getSmsSign, appId:{}, smsSignName:{}, smsSignInfo:{}", appId, smsSignName, smsSignInfo);

        return smsSignInfo;
    }
}
