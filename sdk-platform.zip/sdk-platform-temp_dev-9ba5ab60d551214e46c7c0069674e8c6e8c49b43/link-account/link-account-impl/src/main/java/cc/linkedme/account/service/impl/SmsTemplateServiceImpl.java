package cc.linkedme.account.service.impl;

import cc.linkedme.account.common.punctuation.Punctuation;
import cc.linkedme.account.converter.SmsTemplatePoConverter;
import cc.linkedme.account.dao.account.sms.template.SmsTemplatePO;
import cc.linkedme.account.dao.account.sms.template.SmsTemplatePOExample;
import cc.linkedme.account.dao.account.sms.template.SmsTemplatePOMapper;
import cc.linkedme.account.enums.SmsTemplateType;
import cc.linkedme.account.enums.provider.sms.huawei.HuaweiVoiceSmsTemplateMapping;
import cc.linkedme.account.errorcode.SmsTemplateErrorCode;
import cc.linkedme.account.exception.SmsTemplateException;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.sms.SmsTemplateInfo;
import cc.linkedme.account.service.SmsTemplateService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service("smsTemplateService")
public class SmsTemplateServiceImpl implements SmsTemplateService {

    private static final Logger logger = LoggerFactory.getLogger(SmsTemplateServiceImpl.class);

    @Resource
    private SmsTemplatePOMapper smsTemplatePOMapper;

    public static final String SMS_TEMPLATE_REGULAR = "\\$\\{.*?\\}";

    public static final String IS_NUMBER_REGULAR ="^[0-9]*$";

    public static final Integer DATE_OR_TIME_TEMPLATE_LENGTH = 1;

    public static final Integer TXT_OR_NUM_TEMPLATE_LENGTH = 3;

    public static final Integer SMS_INPUT_MAXIMUM = 20;

    public static final Integer VOICE_INPUT_MAXIMUM = 6;

    @Override
    public SmsTemplateInfo saveSmsTemplate(SmsTemplateInfo smsTemplateInfo) throws SmsTemplateException {

        logger.info("saveSmsTemplate, smsTemplateInfo:{}", smsTemplateInfo);
        Preconditions.checkNotNull(smsTemplateInfo, new SmsTemplateException(SmsTemplateErrorCode.PARAM_INVALID_ERROR));

        SmsTemplatePO smsTemplatePO = SmsTemplatePoConverter.bo2Po(smsTemplateInfo);
        smsTemplatePO.setIsDeleted(YesNoEnum.NO.getIndex());
        smsTemplatePO.setCertificationState(AuditState.TO_BE_AUDITED.getType().byteValue());
        Date currentTime = new Date();
        smsTemplatePO.setGmtCreate(currentTime);
        smsTemplatePO.setGmtUpdate(currentTime);

        smsTemplatePOMapper.insertSelective(smsTemplatePO);

        SmsTemplatePO updateSmsTemplatePO = new SmsTemplatePO();
        updateSmsTemplatePO.setId(smsTemplatePO.getId());
        updateSmsTemplatePO.setTemplateCode(smsTemplatePO.getId() + "");
        smsTemplatePOMapper.updateByPrimaryKeySelective(updateSmsTemplatePO);

        logger.info("saveSmsTemplate, result smsTemplateInfo:{} smsTemplatePO:{}", smsTemplateInfo, smsTemplatePO);
        return SmsTemplatePoConverter.po2Bo(smsTemplatePO);
    }

    @Override
    public Integer updateSmsTemplate(SmsTemplateInfo smsTemplateInfo) throws SmsTemplateException {

        logger.info("updateSmsTemplate, smsTemplateInfo:{}", smsTemplateInfo);
        Preconditions.checkNotNull(smsTemplateInfo, new SmsTemplateException(SmsTemplateErrorCode.PARAM_INVALID_ERROR));
        Preconditions.checkNotNull(smsTemplateInfo.getId(), new SmsTemplateException(SmsTemplateErrorCode.ID_NULL_ERROR));

        SmsTemplatePO smsTemplatePO = SmsTemplatePoConverter.bo2Po(smsTemplateInfo);
        smsTemplatePO.setCertificationState(smsTemplateInfo.getCertificationState() == null ? AuditState.TO_BE_AUDITED.getType().byteValue() : smsTemplateInfo.getCertificationState().getType().byteValue());
        smsTemplatePO.setGmtUpdate(new Date());

        logger.info("updateSmsTemplate, end smsTemplateInfo:{}, smsTemplatePO:{}", smsTemplateInfo, smsTemplatePO);
        return smsTemplatePOMapper.updateByPrimaryKeySelective(smsTemplatePO);

    }

    @Override
    public void removeSmsTemplate(Integer smsTemplateId) throws SmsTemplateException {

        logger.info("removeSmsTemplate, smsTemplateId:{}", smsTemplateId);
        Preconditions.checkNotNull(smsTemplateId, new SmsTemplateException(SmsTemplateErrorCode.ID_NULL_ERROR));

        SmsTemplatePO smsTemplatePO = new SmsTemplatePO();
        smsTemplatePO.setId(smsTemplateId);
        smsTemplatePO.setIsDeleted(YesNoEnum.YES.getIndex());
        smsTemplatePO.setGmtUpdate(new Date());

        smsTemplatePOMapper.updateByPrimaryKeySelective(smsTemplatePO);
        logger.info("removeSmsTemplate, end smsTemplateId:{}", smsTemplateId);
    }


    @Override
    public SmsTemplateInfo getSmsTemplate(Integer smsTemplateId, AuditState auditState) throws SmsTemplateException {

        logger.info("getSmsTemplate, smsTemplateId:{}, auditState:{}", smsTemplateId, auditState);
        Preconditions.checkNotNull(smsTemplateId, new SmsTemplateException(SmsTemplateErrorCode.ID_NULL_ERROR));

        SmsTemplatePOExample smsTemplatePOExample = new SmsTemplatePOExample();
        SmsTemplatePOExample.Criteria criteria = smsTemplatePOExample.createCriteria();
        criteria.andIdEqualTo(smsTemplateId);
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());
        if (null != auditState) {
            criteria.andCertificationStateEqualTo((auditState.getType().byteValue()));
        }
        List<SmsTemplatePO> smsTemplatePOList = smsTemplatePOMapper.selectByExample(smsTemplatePOExample);
        if (CollectionUtils.isEmpty(smsTemplatePOList)) {
            return null;
        }

        SmsTemplateInfo smsTemplateInfo = SmsTemplatePoConverter.po2Bo(smsTemplatePOList.get(0));
        logger.info("getSmsTemplate, smsTemplateId:{}, smsTemplateInfo:{}", smsTemplateId, smsTemplateInfo);

        return smsTemplateInfo;
    }


    @Override
    public Map<Integer, SmsTemplateInfo> getBatchSmsTemplate(List<Integer> smsTemplateIdList) throws SmsTemplateException {

        logger.info("getBatchSmsTemplate, smsTemplageList:{}", smsTemplateIdList);
        Preconditions.checkNotNull(smsTemplateIdList, new SmsTemplateException(SmsTemplateErrorCode.ID_NULL_ERROR));

        SmsTemplatePOExample smsTemplatePOExample = new SmsTemplatePOExample();
        SmsTemplatePOExample.Criteria criteria = smsTemplatePOExample.createCriteria();
        criteria.andIdIn(smsTemplateIdList);
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());

        List<SmsTemplatePO> smsTemplatePOList = smsTemplatePOMapper.selectByExample(smsTemplatePOExample);
        if (CollectionUtils.isEmpty(smsTemplatePOList)) {
            return Collections.EMPTY_MAP;
        }

        Map<Integer, SmsTemplateInfo> smsTemplateInfoMap = new HashMap<>(smsTemplateIdList.size());
        smsTemplatePOList.forEach(smsTemplatePO -> smsTemplateInfoMap.put(smsTemplatePO.getId(), SmsTemplatePoConverter.po2Bo(smsTemplatePO)));

        logger.debug("getBatchSmsTemplate, smsTemplateIdList:{}, smsTemplateInfoMap:{}", smsTemplateIdList, smsTemplateInfoMap);
        return smsTemplateInfoMap;
    }

    @Override
    public List<SmsTemplateInfo> listSmsTemplate(Integer uid, SearchParam searchParam) throws SmsTemplateException {

        logger.info("listSmsTemplate, uid:{}, searchParam:{}", uid, searchParam);

        SmsTemplatePOExample smsTemplatePOExample = new SmsTemplatePOExample();
        SmsTemplatePOExample.Criteria criteria = smsTemplatePOExample.createCriteria();
        if (null != uid) {
            criteria.andUidEqualTo(uid);
        }

        if (searchParam.getStartDate() != null && searchParam.getEndDate() != null) {
            criteria.andGmtCreateBetween(searchParam.getStartDate(), searchParam.getEndDate());
        }

        if (searchParam.getUid() != null) {
            criteria.andUidEqualTo(searchParam.getUid());
        }
        if (searchParam.getAuditState() != null) {
            criteria.andCertificationStateEqualTo(searchParam.getAuditState().byteValue());
        }

        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());
        smsTemplatePOExample.setOrderByClause("gmt_create desc");

        List<SmsTemplatePO> smsTemplatePOList = smsTemplatePOMapper.selectByExampleWithLimit(smsTemplatePOExample, searchParam.getOffset(), searchParam.getSize());
        if (CollectionUtils.isEmpty(smsTemplatePOList)) {
            return Collections.EMPTY_LIST;
        }

        List<SmsTemplateInfo> smsTemplateInfoList = smsTemplatePOList.stream().map(smsTemplatePO -> SmsTemplatePoConverter.po2Bo(smsTemplatePO)).collect(Collectors.toList());
        logger.debug("listSmsTemplate, uid:{}, page:{}, smsTemplateInfoList:{}", uid, searchParam, smsTemplateInfoList);

        return smsTemplateInfoList;
    }

    @Override
    public Long countSmsTextTemplate(Integer uid, SearchParam smsSearchParam) throws SmsTemplateException {

        logger.info("countSmsTextTemplate, uid:{}", uid);

        SmsTemplatePOExample smsTemplatePOExample = new SmsTemplatePOExample();
        SmsTemplatePOExample.Criteria criteria = smsTemplatePOExample.createCriteria();
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());
        if (null != uid) {
            criteria.andUidEqualTo(uid);
        }

        if (smsSearchParam != null) {
            if (smsSearchParam.getStartDate() != null) {
                criteria.andGmtCreateBetween(smsSearchParam.getStartDate(), smsSearchParam.getEndDate());
            }
            if (smsSearchParam.getUid() != null) {
                criteria.andUidEqualTo(smsSearchParam.getUid());
            }
            if (smsSearchParam.getAuditState() != null) {
                criteria.andCertificationStateEqualTo(smsSearchParam.getAuditState().byteValue());
            }
        }

        Long smsTemplateCount = smsTemplatePOMapper.countByExample(smsTemplatePOExample);

        logger.info("countSmsTextTemplate, uid:{}, smsTemplateCount:{}", uid, smsTemplateCount);
        return smsTemplateCount;
    }

    @Override
    public SmsTemplateInfo getSmsTemplateByCode(Integer appId, String smsTemplateCode) throws SmsTemplateException {
        logger.info("getSmsTemplateByCode, appId:{}, smsTemplateCode:{}", appId, smsTemplateCode);
        Preconditions.checkNotNull(smsTemplateCode, new SmsTemplateException(SmsTemplateErrorCode.CODE_NULL_ERROR));

        SmsTemplatePOExample smsTemplatePOExample = new SmsTemplatePOExample();
        SmsTemplatePOExample.Criteria criteria = smsTemplatePOExample.createCriteria();
        criteria.andAppIdEqualTo(appId);
        criteria.andTemplateCodeEqualTo(smsTemplateCode);
        criteria.andIsDeletedEqualTo(YesNoEnum.NO.getIndex());

        List<SmsTemplatePO> smsTemplatePOList = smsTemplatePOMapper.selectByExample(smsTemplatePOExample);
        if (CollectionUtils.isEmpty(smsTemplatePOList)) {
            return null;
        }
        SmsTemplateInfo smsTemplateInfo = SmsTemplatePoConverter.po2Bo(smsTemplatePOList.get(0));
        logger.info("getSmsTemplateByCode, appId:{}, smsTemplateCode:{}, smsTemplateInfo:{}", appId, smsTemplateCode, smsTemplateInfo);

        return smsTemplateInfo;
    }

    @Override
    public String getVoiceTemplateId(String voiceTemplateId, String... templateParas) {

        logger.info("checkVoiceTemplate, voiceTemplateId:{}, templateParas:{}", voiceTemplateId, templateParas);

        Preconditions.checkNotNull(voiceTemplateId, new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_ID_ERROR));
        Preconditions.checkNotNull(templateParas, new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_PARAS_ILLEGAL));
        HuaweiVoiceSmsTemplateMapping huaweiVoiceSmsTemplateMapping = HuaweiVoiceSmsTemplateMapping.get(voiceTemplateId);
        Preconditions.checkNotNull(huaweiVoiceSmsTemplateMapping, new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_NOT_EXIST));

        if (!templateParas[0].matches(IS_NUMBER_REGULAR) || templateParas[0].length() > VOICE_INPUT_MAXIMUM) {
            throw new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_PARAS_ILLEGAL);
        }
        String templateId = huaweiVoiceSmsTemplateMapping.getTemplateId();
        logger.info("checkVoiceTemplate, voiceTemplateId{}, templateParas{}, templateId{}", voiceTemplateId, templateParas, templateId);

        return templateId;
    }

    @Override
    public void checkSmsTemplate(String smsTemplateContent) {

        logger.info("checkSmsTemplate, smsTemplateContent:{}", smsTemplateContent);
        Preconditions.checkNotNull(smsTemplateContent, new SmsTemplateException(SmsTemplateErrorCode.CONTENT_NULL_ERROR));

        /** 使用正则表达式校验模版 */
        Matcher smsTemplateMatcher = Pattern.compile(SMS_TEMPLATE_REGULAR).matcher(smsTemplateContent);

        boolean isCorrect = false;
        while (smsTemplateMatcher.find()) {
            String templateVariable = smsTemplateMatcher.group();
            templateVariable = StringUtils.remove(templateVariable, "${");
            templateVariable = StringUtils.remove(templateVariable, "}");
            String[] variableDetails = StringUtils.split(templateVariable, Punctuation.UNDERLINE);

            if (variableDetails.length == DATE_OR_TIME_TEMPLATE_LENGTH) {
                if (!StringUtils.equals(templateVariable, SmsTemplateType.DATE_TYPE.getType()) && !StringUtils.equals(templateVariable, SmsTemplateType.TIME_TYPE.getType())) {
                    throw new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_PARAS_ILLEGAL);
                }
            } else if (variableDetails.length == TXT_OR_NUM_TEMPLATE_LENGTH) {
                if (!StringUtils.equals(variableDetails[1], SmsTemplateType.NUM_TYPE.getType()) && !StringUtils.equals(variableDetails[1], SmsTemplateType.TXT_TYPE.getType())) {
                    throw new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_PARAS_ILLEGAL);
                }
                if (!variableDetails[2].matches(IS_NUMBER_REGULAR) || Integer.valueOf(variableDetails[2]) > SMS_INPUT_MAXIMUM) {
                    throw new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_PARAS_ILLEGAL);
                }
            } else {
                throw new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_PARAS_ILLEGAL);
            }

            isCorrect = true;
        }

        if (!isCorrect){
            throw new SmsTemplateException(SmsTemplateErrorCode.TEMPLATE_PARAS_ILLEGAL);
        }

    }
}
