package cc.linkedme.account.service.impl;

import cc.linkedme.account.constants.AuditConstants;
import cc.linkedme.account.errorcode.AuditInfoErrorCode;
import cc.linkedme.account.exception.AuditInfoException;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.TopUpInfo;
import cc.linkedme.account.service.AuditInfoSerivce;
import cc.linkedme.account.service.OperativeActivityService;
import cc.linkedme.account.service.TopUpService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Author: liuyunmeng
 * @Date: Create in 20:34 2019-08-22
 * @:Description
 */
@Service
public class OperativeActivityServiceImpl implements OperativeActivityService {


    Logger logger = LoggerFactory.getLogger(OperativeActivityServiceImpl.class);

    @Resource
    private TopUpService topUpService;

    @Resource
    private AuditInfoSerivce auditInfoSerivce;

    private static final Integer DEFAULT_AMOUNT_DEFAULT = 0;

    private static final Integer DEFAULT_GIFT_DEFAULT = 200000;

    private static final Integer DEFAULT_QUICK_LOGIN_PER_DEFAULT = 40;

    private static final Integer DEFAULT_VERIFY_PER_DEFAULT = 40;

    private static final Integer DEFAULT_SMS_PER_DEFAULT = 40;

    private static final Integer DEFAULT_VOICE_PER_DEFAULT = 100;

    private static final Integer DEFAULT_GLOBAL_PER_DEFAULT = 1000;


    @Override
    public void giftMoney(TopUpInfo topUpInfo) {

        logger.info("giftMoney start, topUpInfo:{}", topUpInfo);
        Preconditions.checkNotNull(topUpInfo, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));

        if (topUpInfo.getAmount() == null) {
            topUpInfo.setAmount(DEFAULT_AMOUNT_DEFAULT);
            topUpInfo.setGiftAmount(DEFAULT_GIFT_DEFAULT);
        }

        if (topUpInfo.getQuickLoginOnceAmount() == null) {
            topUpInfo.setQuickLoginOnceAmount(DEFAULT_QUICK_LOGIN_PER_DEFAULT);
            topUpInfo.setVerifyOnceAmount(DEFAULT_VERIFY_PER_DEFAULT);
            topUpInfo.setSmsOnceAmount(DEFAULT_SMS_PER_DEFAULT);
            topUpInfo.setVoiceOnceAmount(DEFAULT_VOICE_PER_DEFAULT);
            topUpInfo.setGlobalOnceAmount(DEFAULT_GLOBAL_PER_DEFAULT);
        }
        topUpInfo = topUpService.saveTopUp(topUpInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setUid(topUpInfo.getUid());
        auditInfo.setBizId(topUpInfo.getId());
        auditInfo.setBizType(BizType.TOP_UP);
        auditInfo = auditInfoSerivce.saveAudit(auditInfo);

        auditInfo.setAuditPassword(AuditConstants.AUDIT_PASSWORD);
        auditInfo.setAuditState(AuditState.AUDIT_PASS);
        int updateBizResult = auditInfoSerivce.updateBizEntity(auditInfo);
        if (updateBizResult == 0) {
            throw new AuditInfoException(AuditInfoErrorCode.UPDATE_BIZ_ENTITY_STATE_ERROR);
        }
        auditInfoSerivce.updateAudit(auditInfo);
    }
}
