package cc.linkedme.account.dao.page.message.userMessage;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMessagePOMapper {
    int countByExample(UserMessagePOExample example);

    int deleteByExample(UserMessagePOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserMessagePO record);

    int insertSelective(UserMessagePO record);

    List<UserMessagePO> selectByExample(UserMessagePOExample example);

    UserMessagePO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserMessagePO record, @Param("example") UserMessagePOExample example);

    int updateByExample(@Param("record") UserMessagePO record, @Param("example") UserMessagePOExample example);

    int updateByPrimaryKeySelective(UserMessagePO record);

    int updateByPrimaryKey(UserMessagePO record);

    List<UserMessagePO> selectByExampleWithLimit(@Param("example") UserMessagePOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);
}