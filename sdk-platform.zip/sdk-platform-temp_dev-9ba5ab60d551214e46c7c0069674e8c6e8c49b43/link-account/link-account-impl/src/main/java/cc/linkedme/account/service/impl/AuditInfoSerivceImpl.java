package cc.linkedme.account.service.impl;

import cc.linkedme.account.common.crypto.MD5;
import cc.linkedme.account.converter.AuditPoConverter;
import cc.linkedme.account.dao.account.audit.AuditInfoPO;
import cc.linkedme.account.dao.account.audit.AuditInfoPOExample;
import cc.linkedme.account.dao.account.audit.AuditInfoPOMapper;
import cc.linkedme.account.errorcode.AccountBalanceErrorCode;
import cc.linkedme.account.errorcode.AuditInfoErrorCode;
import cc.linkedme.account.exception.AccountBalanceException;
import cc.linkedme.account.exception.AuditInfoException;
import cc.linkedme.account.model.AccountBalanceInfo;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.model.InvoiceInfo;
import cc.linkedme.account.model.TopUpInfo;
import cc.linkedme.account.model.UserInfo;
import cc.linkedme.account.model.sms.SmsSignInfo;
import cc.linkedme.account.model.sms.SmsTemplateInfo;
import cc.linkedme.account.service.AccountBalanceService;
import cc.linkedme.account.service.AuditInfoSerivce;
import cc.linkedme.account.service.InvoiceService;
import cc.linkedme.account.service.SmsSignService;
import cc.linkedme.account.service.SmsTemplateService;
import cc.linkedme.account.service.TopUpService;
import cc.linkedme.account.service.UserService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 审核处理
 * @author zhanghaowei
 */
@Service("auditInfoService")
public class AuditInfoSerivceImpl implements AuditInfoSerivce {

    private static final Logger logger = LoggerFactory.getLogger(AuditInfoSerivceImpl.class);

    @Resource
    private TopUpService topUpService;
    @Resource
    private InvoiceService invoiceInfoService;
    @Resource
    private SmsSignService smsSignService;
    @Resource
    private SmsTemplateService smsTemplateService;
    @Resource
    private UserService userService;
    @Resource
    private AccountBalanceService accountBalanceService;
    @Resource
    private AuditInfoPOMapper auditInfoPOMapper;

    @Value("#{config.auditPassword}")
    private String auditPassword;

    @Override
    public AuditInfo saveAudit(AuditInfo auditInfo) throws AuditInfoException {

        logger.info("saveAudit, auditInfo:{}", auditInfo);
        Preconditions.checkNotNull(auditInfo.getUid(), new AuditInfoException(AuditInfoErrorCode.UID_NULL_ERROR));
        Preconditions.checkNotNull(auditInfo.getBizType(), new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NULL_ERROR));
        Preconditions.checkNotNull(auditInfo.getBizId(), new AuditInfoException(AuditInfoErrorCode.BIZ_ID_NULL_ERROR));

        AuditInfoPO auditInfoPO = AuditPoConverter.bo2Po(auditInfo);
        auditInfoPO.setAuditState(AuditState.TO_BE_AUDITED.getType().byteValue());
        Date date = new Date();
        auditInfoPO.setGmtCreate(date);
        auditInfoPO.setGmtModified(date);
        auditInfoPOMapper.insertSelective(auditInfoPO);

        logger.info("saveAudit, auditInfo:{}, auditInfoPO:{}", auditInfo, auditInfoPO);
        return AuditPoConverter.po2Bo(auditInfoPO);
    }

    @Override
    public Integer updateAudit(AuditInfo auditInfo) throws AuditInfoException {

        logger.info("updateAudit, auditInfo:{}", auditInfo);
        Preconditions.checkNotNull(auditInfo.getId(), new AuditInfoException(AuditInfoErrorCode.ID_NULL_ERROR));

        AuditInfoPO auditInfoPO = AuditPoConverter.bo2Po(auditInfo);
        auditInfoPO.setGmtModified(new Date());

        return auditInfoPOMapper.updateByPrimaryKeySelective(auditInfoPO);
    }

    @Override
    public Integer updateAuditByBizId(AuditInfo auditInfo) throws AuditInfoException {

        logger.info("updateAuditByBizId, auditInfo:{}", auditInfo);
        Preconditions.checkNotNull(auditInfo.getBizId(), new AuditInfoException(AuditInfoErrorCode.BIZ_ID_NULL_ERROR));
        Preconditions.checkNotNull(auditInfo.getBizType(), new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NULL_ERROR));

        AuditInfoPOExample auditInfoPOExample = new AuditInfoPOExample();
        AuditInfoPOExample.Criteria criteria = auditInfoPOExample.createCriteria();
        criteria.andBizIdEqualTo(auditInfo.getBizId());
        criteria.andBizTypeEqualTo(auditInfo.getBizType().getType().byteValue());

        AuditInfoPO auditInfoPO = AuditPoConverter.bo2Po(auditInfo);
        auditInfoPO.setGmtModified(new Date());

        int updateResult = auditInfoPOMapper.updateByExampleSelective(auditInfoPO, auditInfoPOExample);

        return updateResult;
    }

    @Override
    public AuditInfo getAuditByBizId(Integer bizId, BizType bizType) throws AuditInfoException {

        logger.info("getAuditByBizId, bizId:{}, bizType:{}", bizId, bizType);
        Preconditions.checkNotNull(bizId, new AuditInfoException(AuditInfoErrorCode.BIZ_ID_NULL_ERROR));
        Preconditions.checkNotNull(bizType, new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NULL_ERROR));

        AuditInfoPOExample auditInfoPOExample = new AuditInfoPOExample();
        AuditInfoPOExample.Criteria criteria = auditInfoPOExample.createCriteria();
        criteria.andBizTypeEqualTo(bizType.getType().byteValue());
        criteria.andBizIdEqualTo(bizId);

        List<AuditInfoPO> auditInfoPOList = auditInfoPOMapper.selectByExample(auditInfoPOExample);
        if (CollectionUtils.isEmpty(auditInfoPOList)) {
            return null;
        }
        logger.info("getAuditByBizId, bizId:{}, bizType:{}, auditInfoPOList:{}", bizId, bizType, auditInfoPOList);

        return AuditPoConverter.po2Bo(auditInfoPOList.get(0));
    }

    @Override
    public Map<Integer, AuditInfo> batchGetAuditByBizId(List<Integer> bizIdList, BizType bizType) throws AuditInfoException {

        logger.info("batchGetAuditByBizId, bizIdList:{}, bizType:{}", bizIdList, bizType);
        Preconditions.checkNotNull(bizIdList, new AuditInfoException(AuditInfoErrorCode.BIZ_ID_NULL_ERROR));
        Preconditions.checkNotNull(bizType, new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NULL_ERROR));

        AuditInfoPOExample auditInfoPOExample = new AuditInfoPOExample();
        AuditInfoPOExample.Criteria criteria = auditInfoPOExample.createCriteria();
        criteria.andBizIdIn(bizIdList);
        criteria.andBizTypeEqualTo(bizType.getType().byteValue());

        List<AuditInfoPO> auditInfoPOList = auditInfoPOMapper.selectByExample(auditInfoPOExample);
        if (CollectionUtils.isEmpty(auditInfoPOList)) {
            return Collections.EMPTY_MAP;
        }

        Map<Integer, AuditInfo> auditInfoBOMap = new HashMap<>(auditInfoPOList.size());
        auditInfoPOList.forEach(auditInfoPO -> auditInfoBOMap.put(auditInfoPO.getBizId(), AuditPoConverter.po2Bo(auditInfoPO)));
        logger.debug("batchGetAuditByBizId, bizIdList:{}, bizType:{}, auditInfoBOMap:{}", bizIdList, bizType, auditInfoBOMap);

        return auditInfoBOMap;
    }

    @Override
    public int updateBizEntity(AuditInfo auditInfo) {

        int updateBizResult;
        switch (auditInfo.getBizType()) {

            case TOP_UP:
                //审核账户充值
                TopUpInfo oldTopUpInfo = topUpService.getTopUp(auditInfo.getBizId());
                TopUpInfo topUpInfo = new TopUpInfo();
                topUpInfo.setId(auditInfo.getBizId());
                Preconditions.checkNotNull(auditInfo.getAuditPassword(), new AuditInfoException(AuditInfoErrorCode.TOP_UP_FINANCE_AUDIT_PASSWORD_ERROR));
                Preconditions.checkEquals(MD5.GetMD5Code(auditInfo.getAuditPassword()), auditPassword, new AuditInfoException(AuditInfoErrorCode.TOP_UP_FINANCE_AUDIT_PASSWORD_ERROR));

                topUpInfo.setAuditState(auditInfo.getAuditState());

                updateBizResult = topUpService.updateTopUp(topUpInfo);
                //充值审核通过，更新账户余额
                if (auditInfo.getAuditState().getType() == AuditState.AUDIT_PASS.getType()) {
                    if (oldTopUpInfo.getAuditState() != AuditState.AUDIT_PASS) {

                        Integer constractId = oldTopUpInfo.getId();
                        Integer constractAmount = oldTopUpInfo.getAmount();
                        Integer giftAmount = oldTopUpInfo.getGiftAmount() != null ? oldTopUpInfo.getGiftAmount() : 0;
                        constractAmount += giftAmount.intValue();
                        boolean contractBiggerThenCreditConsumed = accountBalanceService.checkContractAndCreditAmount(oldTopUpInfo.getUid(), constractAmount);
                        if (!contractBiggerThenCreditConsumed) {
                            throw new AccountBalanceException(AccountBalanceErrorCode.CONTRACT_AMOUNT_LESS_THEN_CREDIT_CONSUMED);
                        }

                        updateAccountBalance(oldTopUpInfo);
                        //重入redis(合同金额)
                        BalanceUnitPrice balanceUnitPrice = new BalanceUnitPrice();
                        balanceUnitPrice.setContractId(constractId);
                        balanceUnitPrice.setLoginUnitPrice(oldTopUpInfo.getQuickLoginOnceAmount());
                        balanceUnitPrice.setTextSmsUnitPrice(oldTopUpInfo.getSmsOnceAmount());
                        balanceUnitPrice.setVoiceSmsUnitPrice(oldTopUpInfo.getVoiceOnceAmount());
                        balanceUnitPrice.setMobileVerifyUnitPrice(oldTopUpInfo.getVerifyOnceAmount());
                        balanceUnitPrice.setGlobalSmsUnitPrice(oldTopUpInfo.getGlobalOnceAmount());
                        accountBalanceService.saveUserContractBalance(oldTopUpInfo.getUid(), constractId, constractAmount, giftAmount , balanceUnitPrice);
                    }
                }
                break;

            case INVOINCE:
                //审核发票信息
                InvoiceInfo invoiceInfo = new InvoiceInfo();
                invoiceInfo.setId(auditInfo.getBizId());
                if (AuditState.SEND_OUT.equals(auditInfo.getAuditState())) {
                    Preconditions.checkNotNull(auditInfo.getExpressCompany(), new AuditInfoException(AuditInfoErrorCode.EXPRESS_COMPANY_NULL_ERROR));
                    Preconditions.checkNotNull(auditInfo.getTrackingNumber(), new AuditInfoException(AuditInfoErrorCode.TRACKING_NUMBER_NULL_ERROR));
                    invoiceInfo.setExpressCompany(auditInfo.getExpressCompany());
                    invoiceInfo.setTrackingNumber(auditInfo.getTrackingNumber());
                }
                invoiceInfo.setAuditState(auditInfo.getAuditState());

                updateBizResult = invoiceInfoService.updateInvoiceInfo(invoiceInfo);
                break;

            case SIGN:
                //短信签名
                SmsSignInfo smsSignInfo = new SmsSignInfo();
                smsSignInfo.setId(auditInfo.getBizId());
                smsSignInfo.setCertificationState(auditInfo.getAuditState());

                updateBizResult = smsSignService.updateSmsSign(smsSignInfo);
                break;

            case SMS_TEMPLATE:
                //短信模版
                SmsTemplateInfo smsTemplateInfo = new SmsTemplateInfo();
                smsTemplateInfo.setId(auditInfo.getBizId());
                smsTemplateInfo.setCertificationState(auditInfo.getAuditState());

                updateBizResult = smsTemplateService.updateSmsTemplate(smsTemplateInfo);
                break;

            case ACCOUNT_AUTHENTICATION:
                //账户认证
                UserInfo userInfo = new UserInfo();
                userInfo.setAuditState(auditInfo.getAuditState());
                userInfo.setUid(auditInfo.getBizId());
                userInfo.setBizType(auditInfo.getBizType());
                userInfo.setAuditRemark(auditInfo.getAuditRemark());
                updateBizResult = userService.updateAccountAudit(userInfo);
                break;

            case ACCOUNT_OPENING:
                //账户开通情况
                UserInfo userInfoOpening = new UserInfo();
                userInfoOpening.setAuditState(auditInfo.getAuditState());
                userInfoOpening.setBizType(auditInfo.getBizType());
                userInfoOpening.setAppId(auditInfo.getBizId());
                userInfoOpening.setProductIdentity(auditInfo.getProductIdentity());

                updateBizResult = userService.updateAccountAudit(userInfoOpening);
                break;

            default:
                throw new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NOT_EXIST);
        }

        return updateBizResult;
    }

    /**
     * 更新账户余额
     * @param topUpInfo
     */
    private void updateAccountBalance(TopUpInfo topUpInfo) {
        logger.info("updateAccountBalance begin, topUpInfo:{}", topUpInfo);

        Integer amount = topUpInfo.getAmount();
        Integer giftAmount = topUpInfo.getGiftAmount();
        if (giftAmount == null) {
            giftAmount = 0;
        }
        AccountBalanceInfo oldAccountBalanceInfo = accountBalanceService.getAccountBalanceBOByUid(topUpInfo.getUid());
        if (oldAccountBalanceInfo == null) {
            AccountBalanceInfo accountBalanceInfo = new AccountBalanceInfo();
            Integer totalAmount = amount + giftAmount;
            accountBalanceInfo.setBalance(totalAmount);
            accountBalanceInfo.setAmount(totalAmount);
            accountBalanceInfo.setUid(topUpInfo.getUid());
            accountBalanceService.saveAccountBalanceBO(accountBalanceInfo);
        } else {
            accountBalanceService.updateAccountBalance(topUpInfo.getUid(), amount, giftAmount);
        }
        logger.info("updateAccountBalance end, topUpInfo:{}", topUpInfo);
    }

}
