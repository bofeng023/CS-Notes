package cc.linkedme.account.consumer;

import cc.linkedme.account.model.sms.VoiceSmsCallbackInfo;
import cc.linkedme.account.service.SmsService;
import cc.linkedme.kafka.MqEntity;
import cc.linkedme.kafka.consumer.AbstractKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

/**
 * @Author: liuyunmeng
 * @Date: Create in 20:10 2019-07-24
 * @:Description
 */
public class VoiceSmsCallbackConsumer extends AbstractKafkaConsumer {

    Logger logger = LoggerFactory.getLogger(SmsConsumer.class);

    @Resource
    private SmsService smsService;


    @Override
    protected void process(Object mqEntry) {
        logger.info("process, mqEntry:{}", mqEntry);

        MqEntity mqEntity = (MqEntity) mqEntry;
        VoiceSmsCallbackInfo voiceCallbackInfo = (VoiceSmsCallbackInfo) mqEntity.getBody();

        logger.debug("process, mqEntry:{}, voiceCallbackInfo:{}", mqEntry, voiceCallbackInfo);
        boolean statusCode = false;

        statusCode = smsService.sendVoiceCallback(voiceCallbackInfo);

        logger.info("process, mqEntity:{}, statusCode:{}", mqEntity, statusCode);
    }
}
