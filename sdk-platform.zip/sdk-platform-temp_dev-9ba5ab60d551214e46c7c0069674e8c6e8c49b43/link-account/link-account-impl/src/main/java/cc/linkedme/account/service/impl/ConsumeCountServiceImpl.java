package cc.linkedme.account.service.impl;

import cc.linkedme.json.JsonConverter;
import cc.linkedme.account.common.util.DigitalUtil;
import cc.linkedme.account.common.util.ExcelUtils;
import cc.linkedme.account.constants.BalanceConstants;
import cc.linkedme.account.converter.ConsumeCountPoConverter;
import cc.linkedme.account.dao.account.data.ConsumeCountPO;
import cc.linkedme.account.dao.account.data.ConsumeCountPOExample;
import cc.linkedme.account.dao.account.data.ConsumeCountPOMapper;
import cc.linkedme.account.errorcode.ConsumeCountErrorCode;
import cc.linkedme.account.exception.ConsumeCountException;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.model.ConsumeCountInfo;
import cc.linkedme.account.model.ConsumeCountMessage;
import cc.linkedme.account.model.DataInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.service.ConsumeCountSerivce;
import cc.linkedme.cache.CacheUtil;
import cc.linkedme.cache.redis.RedisClientUtil;
import cc.linkedme.enums.BizType;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.kafka.MqEntity;
import cc.linkedme.kafka.Topics;
import cc.linkedme.kafka.producer.MqProducer;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 统计数据实现类
 *
 * @author zhanghaowei
 */
@Service
public class ConsumeCountServiceImpl implements ConsumeCountSerivce {

    Logger logger = LoggerFactory.getLogger(ConsumeCountServiceImpl.class);

    @Resource
    private ConsumeCountPOMapper consumeCountPOMapper;

    @Resource
    private MqProducer mqProducer;

    @Resource
    private RedisClientUtil costDbRedisClient;

    @Override
    public List<ConsumeCountInfo> listConsumeCountBO(SearchParam searchParam) throws ConsumeCountException {

        logger.info("listConsumerCountBO, searchParam:{}", searchParam);

        Preconditions.checkNotNull(searchParam, new ConsumeCountException(BaseErrorCode.PARAM_NOT_VALID));

        ConsumeCountPOExample consumeCountPOExample = new ConsumeCountPOExample();
        ConsumeCountPOExample.Criteria criteria = consumeCountPOExample.createCriteria();
        Date startDate = searchParam.getStartDate();
        Date endDate = searchParam.getEndDate();

        criteria.andDateBetween(startDate, endDate);
        criteria.andUidEqualTo(searchParam.getUid());

        List<ConsumeCountPO> consumeCountPOList;
        //同一天
        if (DateUtils.isSameDay(startDate, endDate)) {
            consumeCountPOExample.setOrderByClause("hour_slot");
            consumeCountPOList = consumeCountPOMapper.selectByExampleWithLimitByHour(consumeCountPOExample, searchParam.getOffset(), searchParam.getSize());
        } else {
            consumeCountPOExample.setOrderByClause("date");
            consumeCountPOList = consumeCountPOMapper.selectByExampleWithLimitByDay(consumeCountPOExample, searchParam.getOffset(), searchParam.getSize());
        }
        List<ConsumeCountInfo> consumeCountBOList = new ArrayList<>();
        consumeCountPOList.stream().forEach(consumeCountPO -> consumeCountBOList.add(ConsumeCountPoConverter.po2Bo(consumeCountPO)));

        logger.debug("listConsumerCountBO, searchParam:{}, consumeCountBOList:{}", searchParam, consumeCountBOList);

        return consumeCountBOList;
    }

    @Override
    public Long countConsumeCount(SearchParam searchParam) throws ConsumeCountException {

        logger.info("countConsumeCount, searchParam:{}", searchParam);

        Preconditions.checkNotNull(searchParam, new ConsumeCountException(BaseErrorCode.PARAM_NOT_VALID));

        ConsumeCountPOExample consumeCountPOExample = new ConsumeCountPOExample();
        ConsumeCountPOExample.Criteria criteria = consumeCountPOExample.createCriteria();
        Date startDate = searchParam.getStartDate();
        Date endDate = searchParam.getEndDate();
        criteria.andDateBetween(startDate, endDate);
        criteria.andUidEqualTo(searchParam.getUid());

        Long count;
        //同一天
        if (DateUtils.isSameDay(startDate, endDate)) {
            count = consumeCountPOMapper.countConsumeCountByHour(consumeCountPOExample);
        } else {
            count = consumeCountPOMapper.countConsumeCountByDay(consumeCountPOExample);
        }

        logger.debug("countConsumeCount, searchParam:{}, count:{}", searchParam, count);

        return count != null ? count : 0;
    }

    @Override
    public ConsumeCountInfo totalCountConsume(SearchParam searchParam) throws ConsumeCountException {
        logger.info("countTotalConsume, searchParam:{}", searchParam);

        Preconditions.checkNotNull(searchParam, new ConsumeCountException(BaseErrorCode.PARAM_NOT_VALID));

        ConsumeCountPOExample consumeCountPOExample = new ConsumeCountPOExample();
        ConsumeCountPOExample.Criteria criteria = consumeCountPOExample.createCriteria();
        Date startDate = searchParam.getStartDate();
        Date endDate = searchParam.getEndDate();
        criteria.andDateBetween(startDate, endDate);
        criteria.andUidEqualTo(searchParam.getUid());

        ConsumeCountPO consumeCountPO = consumeCountPOMapper.totalConsumeCount(consumeCountPOExample);
        if (consumeCountPO == null) {
            return new ConsumeCountInfo();
        }

        ConsumeCountInfo consumeCountBO = ConsumeCountPoConverter.po2Bo(consumeCountPO);

        logger.debug("countTotalConsume, consumeCountBO:{}, searchParam:{}", consumeCountBO, searchParam);
        return consumeCountBO;
    }

    @Override
    public ConsumeCountInfo countDayTotalAmountAndRequestCount(Integer uid) {

        ConsumeCountPOExample consumeCountPOExample = new ConsumeCountPOExample();

        ConsumeCountPOExample.Criteria criteria = consumeCountPOExample.createCriteria();
        Date date = new Date();
        try {
            SimpleDateFormat datesdf = new SimpleDateFormat("yyyy-MM-dd");
            criteria.andDateEqualTo(datesdf.parse(datesdf.format(date)));
            criteria.andUidEqualTo(uid);
        } catch (Exception e) {
            logger.error("countDayTotalAmountAndRequestCount, date format error", e);
        }
        ConsumeCountPO consumeCountPO = consumeCountPOMapper.countDayTotalAmountAndRequestCount(consumeCountPOExample);
        if (consumeCountPO == null) {
            return null;
        }

        return ConsumeCountPoConverter.po2Bo(consumeCountPO);
    }

    @Override
    public DataInfo getDataInfo(SearchParam searchParam) throws ConsumeCountException {
        logger.info("getDataInfo, searchParam:{}", searchParam);

        Integer uid = searchParam.getUid();
        Preconditions.checkNotNull(uid, new ConsumeCountException(BaseErrorCode.UID_NULL_ERROR));

        List<ConsumeCountInfo> consumeCountBOList = listConsumeCountBO(searchParam);

        DataInfo dataBO = new DataInfo();
        if (CollectionUtils.isEmpty(consumeCountBOList)) {
            return dataBO;
        }

        //趋势图
        Map<String, ConsumeCountInfo> trendMap = new TreeMap<>();
        Date startDate = searchParam.getStartDate();
        Date endDate = searchParam.getEndDate();
        if (DateUtils.isSameDay(startDate, endDate)) {
            consumeCountBOList.stream().forEach(consumeCountBO -> trendMap.put(new Date(consumeCountBO.getHourSlot()).getHours() + "", consumeCountBO));
        } else {
            consumeCountBOList.stream().forEach(consumeCountBO -> trendMap.put(new SimpleDateFormat("MM-dd").format(consumeCountBO.getDate()), consumeCountBO));
        }

        //指标列表
        dataBO.setConsumerCountBOList(consumeCountBOList);
        //趋势图
        dataBO.setTrendMap(trendMap);

        logger.debug("getDataBO, dataBO:{}", dataBO);
        return dataBO;
    }

    @Override
    public ResponseEntity<byte[]> exportExcel(SearchParam searchParam) throws ConsumeCountException {
        logger.info("exportExcel begin, searchParam:{}", searchParam);

        long count = countConsumeCount(searchParam);
        searchParam.setSize(Integer.valueOf(String.valueOf(count)));
        List<ConsumeCountInfo> consumeCountBOList = listConsumeCountBO(searchParam);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH");
        List<String> excelHeader = Arrays.asList("日期", "消耗（元）", "请求总量", "一键登录量", "账号认证量", "文本短信量", "语音短信量");
        List<List<HashMap<String, Object>>> excelBody = new ArrayList<>(7);
        consumeCountBOList.forEach(consumeCountBO -> {
            ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
            //日期
            HashMap<String, Object> dateMap = new HashMap<>(1);
            if (DateUtils.isSameDay(searchParam.getStartDate(), searchParam.getEndDate())) {
                long hourSlot = consumeCountBO.getHourSlot();
                Date date = new Date(hourSlot);
                dateMap.put("type", "String");
                dateMap.put("value", simpleDateFormat.format(date));
            } else {
                Date date = consumeCountBO.getDate();
                dateMap.put("type", "String");
                dateMap.put("value", simpleDateFormat.format(date));
            }
            listMap.add(dateMap);

            Integer quickLoginCount = consumeCountBO.getQuickLoginCount() != null ? consumeCountBO.getQuickLoginCount() : 0;
            Integer verifyCount = consumeCountBO.getVerifyCount() != null ? consumeCountBO.getVerifyCount() : 0;
            Integer voiceCount = consumeCountBO.getVoiceCount() != null ? consumeCountBO.getVoiceCount() : 0;
            Integer smsCount = consumeCountBO.getSmsCount() != null ? consumeCountBO.getSmsCount() : 0;
            //消费
            HashMap<String, Object> totalAmountMap = new HashMap<>(1);
            Integer totalAmount = consumeCountBO.getTotalAmount();
            totalAmountMap.put("type", "Double");

            totalAmountMap.put("value", DigitalUtil.moneyConverToDouble(totalAmount));
            listMap.add(totalAmountMap);

            //请求总量
            HashMap<String, Object> requestCountMap = new HashMap<>(1);
            requestCountMap.put("type", "Long");
            Integer requestCode = quickLoginCount + verifyCount + voiceCount + smsCount;
            requestCountMap.put("value", requestCode);
            listMap.add(requestCountMap);

            //一键登录量
            HashMap<String, Object> loginCountMap = new HashMap<>(1);
            loginCountMap.put("type", "Long");
            loginCountMap.put("value", quickLoginCount);
            listMap.add(loginCountMap);
            //账号认证量
            HashMap<String, Object> verifyCountMap = new HashMap<>(1);
            verifyCountMap.put("type", "Long");
            verifyCountMap.put("value", verifyCount);
            listMap.add(verifyCountMap);
            //文本短信量
            HashMap<String, Object> smsCountMap = new HashMap<>(1);
            smsCountMap.put("type", "Long");
            smsCountMap.put("value", smsCount);
            listMap.add(smsCountMap);
            //语音短信量
            HashMap<String, Object> voiceCountMap = new HashMap<>(1);
            voiceCountMap.put("type", "Long");
            voiceCountMap.put("value", voiceCount);
            listMap.add(voiceCountMap);
            excelBody.add(listMap);
        });

        String sheetName = "数据";
        ByteArrayOutputStream out;
        ResponseEntity<byte[]> responseEntity;
        try {
            out = ExcelUtils.writeExcelResponse(sheetName, excelHeader, excelBody);
            HttpHeaders headers = new HttpHeaders();
            String fileName = new String((sheetName + ".xls").getBytes("UTF-8"), "iso-8859-1");
            headers.setContentDispositionFormData("attachment", fileName);
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            responseEntity = new ResponseEntity<>(out.toByteArray(), headers, HttpStatus.CREATED);
            out.close();
        } catch (Exception e) {
            throw new ConsumeCountException(ConsumeCountErrorCode.DATA_EXPORT_EXCEL_FAIL);
        }
        return responseEntity;
    }

    @Override
    public Boolean sendConsumeCountMessage(Integer uid, BizType bizType, BalanceUnitPrice balanceUnitPrice, Date date, Integer count) {
        logger.info("sendConsumeCountMessage, uid:{}, bizType:{}, balanceUnitPrice:{}, date:{}, count:{}", uid, bizType, balanceUnitPrice, date, count);

        ConsumeCountMessage consumeCountMessage = new ConsumeCountMessage();
        consumeCountMessage.setUid(uid);
        consumeCountMessage.setBizType(bizType);
        Integer bizUnitPrice = 0;
        switch (bizType) {
            case TEXT_SMS:
                bizUnitPrice = balanceUnitPrice.getTextSmsUnitPrice();
                break;
            case VOICE_SMS:
                bizUnitPrice = balanceUnitPrice.getVoiceSmsUnitPrice();
                break;
            case GLOBAL_SMS:
                bizUnitPrice = balanceUnitPrice.getGlobalSmsUnitPrice();
                break;
            case QUICK_LOGIN:
                bizUnitPrice = balanceUnitPrice.getLoginUnitPrice();
                break;
            case NUMBER_VERIFY:
                bizUnitPrice = balanceUnitPrice.getMobileVerifyUnitPrice();
                break;
            default:
                throw new ConsumeCountException(ConsumeCountErrorCode.BIZ_TYPE_INVALID);
        }
        consumeCountMessage.setUnitPrice(bizUnitPrice);
        consumeCountMessage.setCount(count);
        try {
            Date tempDate = org.apache.commons.lang3.time.DateUtils.parseDate(new SimpleDateFormat("yyyy-MM-dd HH").format(date), "yyyy-MM-dd HH");
            consumeCountMessage.setHourSlot(tempDate.getTime());
            SimpleDateFormat datesdf = new SimpleDateFormat("yyyy-MM-dd");
            consumeCountMessage.setDate(datesdf.parse(datesdf.format(date)));
        } catch (Exception e) {
            logger.error("sendConsumeCountMesage, date format error", e);
        }
        String message = JsonConverter.format(consumeCountMessage);
        logger.info("sendConsumeCountMesage, uid:{}, bizType:{}, balanceUnitPrice:{}, date:{}, count:{}, message:{}", uid, bizType, balanceUnitPrice, date, count, message);

        //放入kafka
        MqEntity mqEntry = new MqEntity(Topics.USER_BEHAVIOR_STATISTICS, consumeCountMessage);
        mqProducer.send(mqEntry);

        return true;
    }

    @Override
    public Boolean updateCountDate(ConsumeCountInfo consumeCountInfo, BizType bizType) {
        logger.info("updateCountDate, consumeCountInfo:{}, bizType:{}", consumeCountInfo, bizType);
        Integer uid = consumeCountInfo.getUid();
        Long hourSlot = consumeCountInfo.getHourSlot();
        ConsumeCountInfo oldConsumeCountInfo = getConsumeCountInfo(uid, hourSlot);
        Integer count;
        if (oldConsumeCountInfo == null) {
            count = saveConsumeCountInfo(consumeCountInfo);
        } else {
            switch (bizType) {
                case TEXT_SMS:
                    Integer smsCount = oldConsumeCountInfo.getSmsCount() != null ? oldConsumeCountInfo.getSmsCount() : 0;
                    consumeCountInfo.setSmsCount(smsCount + consumeCountInfo.getSmsCount());
                    break;
                case VOICE_SMS:
                    Integer voiceCount = oldConsumeCountInfo.getVoiceCount() != null ? oldConsumeCountInfo.getVoiceCount() : 0;
                    consumeCountInfo.setVoiceCount(voiceCount + consumeCountInfo.getVoiceCount());
                    break;
                case QUICK_LOGIN:
                    Integer quickLoginCount = oldConsumeCountInfo.getQuickLoginCount() != null ? oldConsumeCountInfo.getQuickLoginCount() : 0;
                    consumeCountInfo.setQuickLoginCount(quickLoginCount + consumeCountInfo.getQuickLoginCount());
                    break;
                case NUMBER_VERIFY:
                    Integer verifyCount = oldConsumeCountInfo.getVerifyCount() != null ? oldConsumeCountInfo.getVerifyCount() : 0;
                    consumeCountInfo.setVerifyCount(verifyCount + consumeCountInfo.getVerifyCount());
                    break;
                default:
                    throw new ConsumeCountException(ConsumeCountErrorCode.BIZ_TYPE_INVALID);
            }
            consumeCountInfo.setId(oldConsumeCountInfo.getId());
            consumeCountInfo.setTotalAmount(oldConsumeCountInfo.getTotalAmount() +
                    consumeCountInfo.getTotalAmount());
            count = updateConsumeCountInfo(consumeCountInfo);
        }
        return count > 0 ? true : false;
    }

    @Override
    public ConsumeCountInfo getConsumeCountInfo(Integer uid, Long hourSlot) {

        ConsumeCountPOExample consumeCountPOExample = new ConsumeCountPOExample();
        ConsumeCountPOExample.Criteria criteria = consumeCountPOExample.createCriteria();
        criteria.andUidEqualTo(uid);
        criteria.andHourSlotEqualTo(hourSlot);
        List<ConsumeCountPO> consumeCountPOList = consumeCountPOMapper.selectByExample(consumeCountPOExample);
        if (!CollectionUtils.isNotEmpty(consumeCountPOList)) {
            return null;
        } else {
            return ConsumeCountPoConverter.po2Bo(consumeCountPOList.get(0));
        }
    }

    @Override
    public Integer saveConsumeCountInfo(ConsumeCountInfo consumeCountInfo) {
        Date date = new Date();
        consumeCountInfo.setGmtCreate(date);
        consumeCountInfo.setGmtModified(date);
        return consumeCountPOMapper.insertSelective(ConsumeCountPoConverter.bo2Po(consumeCountInfo));
    }

    @Override
    public Integer updateConsumeCountInfo(ConsumeCountInfo consumeCountInfo) {
        consumeCountInfo.setGmtModified(new Date());
        return consumeCountPOMapper.updateByPrimaryKeySelective(ConsumeCountPoConverter.bo2Po(consumeCountInfo));
    }


    @Override
    public Integer getBalanceByUid(Integer uid) {
        logger.info("getBalanceByUid, uid:{}", uid);

        Map<String, String> balanceMap = costDbRedisClient
                .hgetAll(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid));
        String strSurplusCreditAmount = costDbRedisClient
                .hget(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(BalanceConstants.CREDIT_CACHE_AVATAR_ID));
        String strTotalCreditAmount = costDbRedisClient
                .get(CacheUtil.genKey(BalanceConstants.USER_CREDIT_AMOUNT_PREFIX, uid));
        logger.info("getBalanceByUid, uid:{}, balanceMap:{}, surplusCreditAmount:{}, totalCreditAmount:{}", uid, balanceMap, strSurplusCreditAmount, strTotalCreditAmount);
        Integer amount = 0;
        if (balanceMap != null && balanceMap.size() > 0) {
            Integer totalCreditAmount = StringUtils.isNotEmpty(strTotalCreditAmount) ? Integer.parseInt(strTotalCreditAmount) : 0;
            Integer surplusCreditAmount = StringUtils.isNotEmpty(strSurplusCreditAmount) ? Integer.parseInt(strSurplusCreditAmount) : 0;
            if (surplusCreditAmount >= 0) {
                for (String key : balanceMap.keySet()) {
                    String balance = balanceMap.get(key);
                    amount = amount + (balance != null ? (Integer.parseInt(balance) < 0 ? 0 : Integer.parseInt(balance)) : 0);
                }
                amount = amount - surplusCreditAmount;
                if (amount <= 0) {
                    amount = surplusCreditAmount - totalCreditAmount;
                }
            } else {
                amount = -totalCreditAmount;
            }
        }
        logger.info("getBalanceByUid, uid:{}, amount:{}", uid, amount);
        return amount;
    }
}