package cc.linkedme.account.consumer;

import cc.linkedme.account.model.sms.VoiceSmsInfo;
import cc.linkedme.account.service.provider.sms.SmsProviderService;
import cc.linkedme.kafka.MqEntity;
import cc.linkedme.kafka.consumer.AbstractKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

/**
 * @author zhanghaowei
 * @date 2019-07-25 09:51
 * @description 语音短信消费服务
 **/
public class VoiceSmsConsumer extends AbstractKafkaConsumer {

    Logger logger = LoggerFactory.getLogger(VoiceSmsConsumer.class);

    @Resource
    private SmsProviderService smsProviderService;


    @Override
    protected void process(Object mqEntry) {

        logger.info("process, mqEntry:{}", mqEntry);

        MqEntity mqEntity = (MqEntity) mqEntry;
        VoiceSmsInfo voiceSmsInfo = (VoiceSmsInfo)mqEntity.getBody();

        smsProviderService.sendVoice(voiceSmsInfo);

        logger.info("process, mqEntity:{}, smsInfo:{}", mqEntity, voiceSmsInfo);

    }
}
