package cc.linkedme.account.service.impl.factory;

import cc.linkedme.account.common.crypto.CryptUtil;
import cc.linkedme.account.common.crypto.Rsa;
import cc.linkedme.account.common.crypto.SignAlgorithm;
import cc.linkedme.account.common.http.HttpClientUtil;
import cc.linkedme.json.JsonConverter;
import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.enums.Platform;
import cc.linkedme.account.enums.provider.login.CuccResponseCode;
import cc.linkedme.account.errorcode.PhoneNumVerificationErrorCode;
import cc.linkedme.account.exception.PhoneNumVerificationException;
import cc.linkedme.account.model.AuthConfigInfo;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.model.provider.login.CuccGetMobileRequest;
import cc.linkedme.account.model.provider.login.CuccGetMobileResponse;
import cc.linkedme.account.model.provider.login.CuccVerifyMobileRequest;
import cc.linkedme.account.model.provider.login.CuccVerifyMobileResponse;
import cc.linkedme.account.service.AccountBalanceService;
import cc.linkedme.account.service.impl.PhoneNumVerificationServiceImpl;
import cc.linkedme.enums.BizType;
import cc.linkedme.errorcode.ErrorCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @author zhanghaowei
 * @date 2019-6-15 13:37
 * @description
 **/

@Component("cuccValidateHandler")
public class CuccValidateHandler extends PhoneNumVerificationServiceImpl {

    Logger logger = LoggerFactory.getLogger(CuccValidateHandler.class);

   /* private static final String PRIVATE_KEY = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALQ9lkBtOqE+Gan2" +
            "ggtdAfLJbHEUhTqD6G7dikwGjMLvlllx5xkv6zDqn8GiceQ/2oM9fZnusQiAIil6" +
            "9uL4IDd6cgWCE3tZ1Md/4AtKJgiTztZdQZ9rbLnmdBTMicPAkbhwANniahhcbeB8" +
            "G0CqJtsjc4zPkyplruBt2G2/WTDrAgMBAAECgYEArEdZwIcnTUwAV9bJgncKD7i7" +
            "sHJ+zembV6zmLbjs/r7nJOOckxScZ4s73GebGSJ3iI5T6bie+pMPFDr2lQe6MfHI" +
            "bhend4IhQA+q4Gh38zp0BPmepiPjXqQwezvuFBBJ1cCr4SYD2hqx0OVnyC3sA7LR" +
            "eKyuAnKCzh0qcR6aSQECQQDjWlFzrW2d6LzNkuLzo5I9+8ZqWGc/yh6x2R67ZznU" +
            "PE53hoM3smAig9qrlQtjoHfRgP53wMAug+RN+wDcSFtBAkEAyvOTyYXgUONLoXGm" +
            "0PZlOgNrLIscjNwxsDUfY96C5pR4x1+Yh18kyJLScp3v8QWb5Kfgoe1492bgkFQ9" +
            "x3udKwJAA9RxqtExF4fkJlJjIFeRDxo+rWvv0VNGURinO+DxSHH7oGfTrgyDMhGm" +
            "jV1lY7hATHcv0jSdCCuQnP+tdAiEAQJBAJwVDBm2TjenNukooOSgOmWNb4VIT2K9" +
            "jbE4ibWi0QVINkMO8B1cPMvMrvDbKkcwyx3lRksCeT+77QTS5Nhf5xUCQDJLuaZP" +
            "STnoq/9SN9ux+o7Dnrc8SzMYTwCJj+/qCWOMjiRGs5TknWRB0tDjG5ioEtutvZ3o" +
            "FeRhepsyYaII2h0=";*/

    private static final String CUCC_MOBILE_VERIFY_URL="http://opencloud.wostore.cn/account/verifyMobile";
    private static final String CUCC_GET_MOBILE_URL = "http://opencloud.wostore.cn/account/tokenValidate";
   // private static final String CUCC_ANDROID_PACK_NAME = "com.microquation.linkedme";
   // private static final String CUCC_ANDROID_PACK_SIGN = "";
   // private static final String CUCC_IOS_BUNDLE_ID = "com.microquation.LinkedME";
    //private static final String CUCC_CLIENT_SECRET = "975475a897d2d33c4bb8ffbea20dbfbb";
   // private static final String CUCC_CLIENT_ID = "99166000000000000402";
   // private static final String CUCC_GRANT_SECRET = "b5a6e4ab3da18953875b89696237354b";
   // private static final String CONTENT_TYPE = "application/json;charset=UTF-8";
   @Resource
   protected AccountBalanceService accountBalanceService;

    @Override
    protected Object buildGetMobileRequestParams(Platform platform, String token, String authCode, AuthConfigInfo authConfigInfo) {

        logger.info("buildGetMobileRequestParams, platform:{}, token:{}, authCode:{}, AuthConfigInfo:{}", platform, token, authCode, authConfigInfo);
        AuthConfigInfo.Cucc cucc = authConfigInfo.getCucc();

        CuccGetMobileRequest cuccGetMobileRequest = new CuccGetMobileRequest();
        cuccGetMobileRequest.setHeader(new CuccGetMobileRequest.Header(cucc.getClientId(), "2.0", token));

        CuccGetMobileRequest.Body body = new CuccGetMobileRequest.Body();
        body.setMsgid(UUID.randomUUID().toString());
        body.setTimeStamp(String.valueOf(System.currentTimeMillis()));
        cuccGetMobileRequest.setBody(body);

        logger.debug("buildGetMobileRequestParams, platform:{}, token:{}, authCode:{}, cuccGetMobileRequest:{}", platform, token, authCode, cuccGetMobileRequest);
        return cuccGetMobileRequest;
    }

    @Override
    protected Object fillGetMobileRequestSign(Object requestParams, AuthConfigInfo authConfigInfo) {

        logger.info("fillGetMobileRequestSign, requestParams:{}", requestParams);
        AuthConfigInfo.Cucc cucc = authConfigInfo.getCucc();

        CuccGetMobileRequest cuccGetMobileRequest = (CuccGetMobileRequest) requestParams;

        String sign;
        try {
            String signContent = cuccGetMobileRequest.getHeader().getClientId() + cuccGetMobileRequest.getHeader().getAccessToken();
            sign = Rsa.sign(signContent, cucc.getPrivateKey(), SignAlgorithm.SHA1withRSA);
        } catch (Exception e) {
            logger.warn("fillGetMobileRequestSign rsa error, cuccGetMobileRequest:{}", cuccGetMobileRequest, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.RSA_SIGN_ERROR);
        }
        cuccGetMobileRequest.getBody().setSign(sign);
        cuccGetMobileRequest.getBody().setEncrypt("RSA");

        logger.info("fillGetMobileRequestSign, cuccGetMobileRequest:{}", cuccGetMobileRequest);
        return cuccGetMobileRequest;
    }

    @Override
    protected String requestGetMobileServer(Object requestParams) {

        logger.info("requestGetMobileServer, requestParams:{}", requestParams);
        CuccGetMobileRequest cuccGetMobileRequest = (CuccGetMobileRequest) requestParams;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        CuccGetMobileRequest.Header header = cuccGetMobileRequest.getHeader();
        Map<String,String> headeMap = new HashMap<>();
        headeMap.put("client_id", header.getClientId());
        headeMap.put("version", header.getVersion());
        headeMap.put("access_token", header.getAccessToken());

        httpClientUtil.httpPost(CUCC_GET_MOBILE_URL, JsonConverter.format(cuccGetMobileRequest.getBody()), headeMap, byteArrayOutputStream, StandardCharsets.UTF_8.name());
        String response = byteArrayOutputStream.toString();
        logger.debug("requestGetMobileServer, cuccGetMobileRequest:{}, response:{}", cuccGetMobileRequest, response);

        return response;
    }

    @Override
    protected Long parseMobile(String response, AuthConfigInfo authConfigInfo, BalanceUnitPrice balanceUnitPrice, Integer uid, Channel channel) {

        logger.info("parseMobile, response:{}", response);
        AuthConfigInfo.Cucc cucc = authConfigInfo.getCucc();

        CuccGetMobileResponse cuccGetMobileResponse = JsonConverter.parse(response,CuccGetMobileResponse.class);
        System.out.println(cuccGetMobileResponse);

        if (!CuccResponseCode.SUCCESS.equals(CuccResponseCode.get(cuccGetMobileResponse.getCode()))) {
            accountBalanceService.refund(uid, BizType.QUICK_LOGIN, balanceUnitPrice, channel, 1);
            checkResponseCode(cuccGetMobileResponse.getCode());
        }

        CuccGetMobileResponse.Data data = cuccGetMobileResponse.getData();
        System.out.println("parseMobile, cuccGetMobileResponse:" + cuccGetMobileResponse );
        String mobile;
        if ("0".equals(cuccGetMobileResponse.getCode())) {
           try {
               mobile = Rsa.decrypt(data.getMobilePhone(), cucc.getPrivateKey());
               System.out.println("mobile : " + mobile);
           } catch (Exception e) {
               logger.warn("parseMobile, RSA decrypt error, cuccGetMobileResponse:{}", cuccGetMobileResponse, e);
               throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.RSA_DECRYPT_ERROR);
           }
        } else {
            throw new PhoneNumVerificationException(new ErrorCode(Integer.parseInt(cuccGetMobileResponse.getCode()),cuccGetMobileResponse.getMsg()));
        }

        logger.info("parseMobile, response:{}, mobile:{}", response, mobile);
        return Long.valueOf(mobile);
    }

    @Override
    protected Object buildVerifyMobileRequestParams(Platform platform, String token, String mobile, AuthConfigInfo authConfigInfo) {

        logger.info("buildVerifyMobileRequestParams, platform:{}, token:{}, mobile:{}", platform, token, mobile);
        AuthConfigInfo.Cucc cucc = authConfigInfo.getCucc();

        CuccVerifyMobileRequest cuccVerifyMobileRequest = new CuccVerifyMobileRequest();
        CuccVerifyMobileRequest.Header header = new CuccVerifyMobileRequest.Header();
        CuccVerifyMobileRequest.Body body = new CuccVerifyMobileRequest.Body();

        header.setClientId(cucc.getClientId());
        header.setClientType("3");
        if (platform == Platform.ANDROID) {
            header.setPackname(cucc.getAndroidPackName());
            header.setPacksign(cucc.getAndroidPackSign());
        } else if (platform == Platform.IOS) {
            header.setPackname(cucc.getIosBundleId());
        }
        header.setVersion("2.0");
        header.setFormat("json");

        body.setTimeStamp(System.currentTimeMillis());
        body.setAccessCode(token);
        body.setMobile(mobile);

        cuccVerifyMobileRequest.setHeader(header);
        cuccVerifyMobileRequest.setBody(body);

        logger.info("buildVerifyMobileRequestParams, platform:{}, token:{}, mobile:{}, cuccVerifyMobileRequest:{}",platform, token, mobile, cuccVerifyMobileRequest);
        return cuccVerifyMobileRequest;
    }

    @Override
    protected Object fillVerifyMobileRequestSign(Object requestParams, AuthConfigInfo authConfigInfo) {
        logger.info("fillVerifyMobileRequestSign, requestParams:{}", requestParams);

        CuccVerifyMobileRequest cuccVerifyMobileRequest = (CuccVerifyMobileRequest) requestParams;
        return cuccVerifyMobileRequest;
    }

    @Override
    protected String requestVerifyMobileServer(Object requestParams, AuthConfigInfo authConfigInfo) {

        logger.info("requestVerifyMobileServer, requestParams:{}", requestParams);
        AuthConfigInfo.Cucc cucc = authConfigInfo.getCucc();

        CuccVerifyMobileRequest cuccVerifyMobileRequest = (CuccVerifyMobileRequest) requestParams;
        System.out.println("cuccVerifyMobileRequest:" + JsonConverter.format(cuccVerifyMobileRequest));
        String cryptParams;
        try {
            cryptParams = CryptUtil.encryptBy3DesAndBase64(JsonConverter.format(cuccVerifyMobileRequest.getBody()), cucc.getClientSecret());
        } catch (Exception e) {
            logger.warn("requestVerifyMobileServer 3DesAndBase64 crypto error, requestParams:{}", requestParams, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.DESANDBASE64_ENCRYPT_ERROR);
        }

        System.out.println("cryptParams:" + cryptParams);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("client_id", cuccVerifyMobileRequest.getHeader().getClientId());
        headerMap.put("client_type", cuccVerifyMobileRequest.getHeader().getClientType());
        headerMap.put("packname", cuccVerifyMobileRequest.getHeader().getPackname());
        headerMap.put("version", cuccVerifyMobileRequest.getHeader().getVersion());
        headerMap.put("format", cuccVerifyMobileRequest.getHeader().getFormat());

        System.out.println("headerMap:" + headerMap);

        httpClientUtil.httpPost(CUCC_MOBILE_VERIFY_URL, cryptParams, headerMap, byteArrayOutputStream, StandardCharsets.UTF_8.name());
        String response = byteArrayOutputStream.toString();
        logger.info("requestVerifyMobileServer, cuccVerifyMobileRequest:{}, response:{}", cuccVerifyMobileRequest, response);

        return response;
    }

    @Override
    protected Boolean parseVerifyResult(String response, AuthConfigInfo authConfigInfo, BalanceUnitPrice balanceUnitPrice, Integer uid, Channel channel) {

        logger.info("parseMobile, response:{}", response);
        AuthConfigInfo.Cucc cucc = authConfigInfo.getCucc();

        CuccVerifyMobileResponse cuccVerifyMobileResponse = JsonConverter.parse(response,CuccVerifyMobileResponse.class);
        if (!CuccResponseCode.SUCCESS.equals(CuccResponseCode.get(cuccVerifyMobileResponse.getCode()))) {
            accountBalanceService.refund(uid, BizType.NUMBER_VERIFY, balanceUnitPrice, channel, 1);
            checkResponseCode(cuccVerifyMobileResponse.getCode());
        }
        String dataDecrypt;
        try {
            dataDecrypt = CryptUtil.decryptBy3DesAndBase64(cuccVerifyMobileResponse.getData(), cucc.getClientSecret());
            dataDecrypt = URLDecoder.decode(dataDecrypt);
        } catch (Exception e) {
            logger.warn("parseVerifyResult, decrypt data error, response:{}", response, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.DESANDBASE64_ENCRYPT_ERROR);
        }

        System.out.println("dataDecrypt:" + dataDecrypt);

        CuccVerifyMobileResponse.Data data = JsonConverter.parse(dataDecrypt, CuccVerifyMobileResponse.Data.class);
        Integer isVerify = data.getIsVerify();

        logger.info("parseMobile, response:{}, verifyStatus:{}", response, isVerify);
        return isVerify == 0 ? true : false;
    }

    @Override
    protected void checkResponseCode(String responseCode) {

        logger.info("checkResponseCode, responseCode:{}", responseCode);

        switch (CuccResponseCode.get(responseCode)) {
            case SUCCESS:
                break;
            case SIGN_FAIL:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.SIGN_ERROR);
            case TOKEN_INVALID:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.TOKEN_ERROR);
            case TOKEN_OVERDUE:
            case AUTH_CODE_OVERDUE:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.TOKEN_EXPIRED);
            case APP_NOT_VALID:
            case USER_NOT_EXIST:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.APP_ID_ERROR);
            case PARAMS_EMTRY:
            case PARAMS_INCOMPLETE:
            case PARAMS_INVALID:
            case APP_PACKAGE_NOT_VALID:
            case REQUEST_INVALID:
            case REQUEST_PARSING_ERROR:
            case REQUEST_OVERDUE:
            case URLENCODE_FAIL:
            case NON_UNICOM_NUMBER:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.PARAM_ERROR);
            case INTER_SERVICE_ACCESS_FAIL:
            case INTER_SERVICE_ACCESS_ERROR:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.PERMISSION_DENIED);
            case APP_UNAUTHORIZED:
            case APP_STATE_NOT_VALID:
            case MERCHANT_STATE_NOT_VALID:
            case TOKEN_UNAUTHORIZED_APP:
            case AUTHENTICATION_INVALID:
            case INTERFACE_NOT_OPEN:
            case APP_INTERFACE_UNAUTHORIZED:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.APP_NO_AUTHORIZATION);
            case APP_SECRET_KEY:
            case ENCRYPT_NOT_SUPPORT:
            case RSA_ENCRYPT_ERROR:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.ENCRYPT_ERROR);
            case IP_UNAUTHORIZED:
            case IP_UNAUTHORIZED_INTERFACE:
            case SOURCE_IP_AUTHENTICATION_FAIL:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.IP_WHITELIST_ERROR);
            case NETWORK_GET_NUMBER_FAILED_NOT_FORWARD:
            case NET_GET_NUMBER:
            case WIFI_INVALID_GET_NUMBER:
            case IMSI_GET_FAIL:
            case GATEWAY_NUMBER_ERROR:
            case GATEWAY_GET_NUMBER_FAIL:
            case CUCC_GATEWAY_GET_NUMBER_FAIL:
            case CUCC_GATEWAY_GET_NUMBER_ERROR:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.GET_MOBILE_FAILED);
            case ACCESS_COUNT_NOT_ENOUGH:
            case MERCHANT_REQUEST_COUNT_EXCEED_LIMIT:
            case APP_ACCESS_INTERFACE_OVERTIME_LIMIT:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.NO_QUOTAS);
            default:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.OTHER_ERROR);
        }
    }

    public static void main(String args[]) {
        String token = "846b85fd74894b5f9bfee4611e5009bd";
        Long mobile = 15510680829L;
        CuccValidateHandler cuccValidateHandler = new CuccValidateHandler();
        HttpClientUtil httpClientUtil = new HttpClientUtil();
        cuccValidateHandler.setHttpClientUtil(httpClientUtil);
        boolean verifyResult = cuccValidateHandler.verifyLoginPhoneNum(null, Platform.ANDROID, token, mobile,10230);
        System.out.println(verifyResult);

       //long mobile = cuccValidateHandler.getLoginPhoneNum( null, Platform.IOS, token, null, 10230 );
       //System.out.println(mobile);

    }
}
