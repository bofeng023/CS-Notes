package cc.linkedme.account.converter;

import cc.linkedme.account.dao.account.data.ConsumeCountPO;
import cc.linkedme.account.model.ConsumeCountInfo;
import org.springframework.beans.BeanUtils;

/**
 * @author zhanghaowei
 * @date 2019-6-5 09:58
 * @description
 **/
public class ConsumeCountPoConverter {

    public static ConsumeCountPO bo2Po(ConsumeCountInfo consumeCountBO) {
        ConsumeCountPO consumeCountPO = new ConsumeCountPO();
        BeanUtils.copyProperties(consumeCountBO, consumeCountPO);
        return consumeCountPO;
    }

    public static ConsumeCountInfo po2Bo(ConsumeCountPO consumeCountPO) {
        ConsumeCountInfo consumeCountBO = new ConsumeCountInfo();
        BeanUtils.copyProperties(consumeCountPO,consumeCountBO);
        return consumeCountBO;
    }
}
