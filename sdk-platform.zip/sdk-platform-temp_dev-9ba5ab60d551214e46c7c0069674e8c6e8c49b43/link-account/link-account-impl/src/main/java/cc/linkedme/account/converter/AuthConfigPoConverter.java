package cc.linkedme.account.converter;

import cc.linkedme.account.dao.account.config.AuthConfigPO;
import cc.linkedme.account.model.AuthConfigInfo;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;

/**
 * @author zhanghaowei
 * @date 2019-6-15 17:22
 * @description
 **/
public class AuthConfigPoConverter {


    public static AuthConfigPO bo2Po(AuthConfigInfo authConfigInfo) {

        if (authConfigInfo == null) {
            return null;
        }

        AuthConfigPO authConfigPO = new AuthConfigPO();
        BeanUtils.copyProperties(authConfigInfo, authConfigPO);

        AuthConfigInfo.Cmcc cmcc = authConfigInfo.getCmcc();
        if (cmcc != null) {

            //android
            String androidAppId = cmcc.getAndroidAppId();
            if (StringUtils.isNotEmpty(androidAppId)) {
                authConfigPO.setCmccAndroidAppId(androidAppId);
            }
            String androidAppKey = cmcc.getAndroidAppKey();
            if (StringUtils.isNotEmpty(androidAppKey)) {
                authConfigPO.setCmccAndroidAppKey(androidAppKey);
            }
            String androidAppSecret = cmcc.getAndroidAppSecret();
            if (StringUtils.isNotEmpty(androidAppSecret)) {
                authConfigPO.setCmccAndroidAppSecret(androidAppSecret);
            }

            //ios
            String iosAppId = cmcc.getIosAppId();
            if (StringUtils.isNotEmpty(iosAppId)) {
                authConfigPO.setCmccIosAppId(iosAppId);
            }
            String iosAppKey = cmcc.getIosAppKey();
            if (StringUtils.isNotEmpty(iosAppKey)) {
                authConfigPO.setCmccIosAppKey(iosAppKey);
            }
            String iosAppSecret = cmcc.getIosAppSecret();
            if (StringUtils.isNotEmpty(iosAppSecret)) {
                authConfigPO.setCmccIosAppSecret(iosAppSecret);
            }

            //秘钥
            String cmccPrivateKey = cmcc.getPrivateKey();
            if (StringUtils.isNotEmpty(cmccPrivateKey)) {
                authConfigPO.setCmccPrivateKey(cmccPrivateKey);
            }
            String cmccPublicKey = cmcc.getPublicKey();
            if (StringUtils.isNotEmpty(cmccPublicKey)) {
                authConfigPO.setCmccPublicKey(cmccPublicKey);
            }

        }

        AuthConfigInfo.Ctcc ctcc = authConfigInfo.getCtcc();
        if (ctcc != null) {
            String appId = ctcc.getAppId();
            if (StringUtils.isNotEmpty(appId)) {
                authConfigPO.setCtccAppId(appId);
            }
            String appSecret = ctcc.getAppSecret();
            if (StringUtils.isNotEmpty(appSecret)) {
                authConfigPO.setCtccAppSecret(appSecret);
            }

            String ctccPrivateKey = ctcc.getPrivateKey();
            if (StringUtils.isNotEmpty(ctccPrivateKey)) {
                authConfigPO.setCtccPrivateKey(ctccPrivateKey);
            }
            String ctccPublicKey = ctcc.getPublicKey();
            if (StringUtils.isNotEmpty(ctccPublicKey)) {
                authConfigPO.setCtccPublicKey(ctccPublicKey);
            }

        }
        return authConfigPO;

    }

    public static AuthConfigInfo po2Bo(AuthConfigPO authConfigPO) {

        if (authConfigPO == null) {
            return null;
        }
        AuthConfigInfo authConfigInfo = new AuthConfigInfo();

        BeanUtils.copyProperties(authConfigPO, authConfigInfo);

        authConfigInfo.setCtcc(new AuthConfigInfo.Ctcc());
        authConfigInfo.setCmcc(new AuthConfigInfo.Cmcc());

        //cmcc
        String cmccAndroidAppId = authConfigPO.getCmccAndroidAppId();
        if (StringUtils.isNotEmpty(cmccAndroidAppId)) {
            authConfigInfo.getCmcc().setAndroidAppId(cmccAndroidAppId);
        }
        String cmccAndroidAppKey = authConfigPO.getCmccAndroidAppKey();
        if (StringUtils.isNotEmpty(cmccAndroidAppKey)) {
            authConfigInfo.getCmcc().setAndroidAppKey(cmccAndroidAppKey);
        }
        String cmccAndroidAppSecret = authConfigPO.getCmccAndroidAppSecret();
        if (StringUtils.isNotEmpty(cmccAndroidAppSecret)) {
            authConfigInfo.getCmcc().setAndroidAppSecret(cmccAndroidAppSecret);
        }
        String cmccIosAppId = authConfigPO.getCmccIosAppId();
        if (StringUtils.isNotEmpty(cmccIosAppId)) {
            authConfigInfo.getCmcc().setIosAppId(cmccIosAppId);
        }
        String cmccIosAppKey = authConfigPO.getCmccIosAppKey();
        if (StringUtils.isNotEmpty(cmccIosAppKey)) {
            authConfigInfo.getCmcc().setIosAppKey(cmccIosAppKey);
        }
        String cmccIosAppSecret = authConfigPO.getCmccIosAppSecret();
        if (StringUtils.isNotEmpty(cmccIosAppSecret)) {
            authConfigInfo.getCmcc().setIosAppSecret(cmccIosAppSecret);
        }
        String cmccPublicKey = authConfigPO.getCmccPublicKey();
        if (StringUtils.isNotEmpty(cmccPublicKey)) {
            authConfigInfo.getCmcc().setPublicKey(cmccPublicKey);
        }
        String cmccPrivateKey = authConfigPO.getCmccPrivateKey();
        if (StringUtils.isNotEmpty(cmccPrivateKey)) {
            authConfigInfo.getCmcc().setPrivateKey(cmccPrivateKey);
        }

        //ctcc
        String ctccAppId = authConfigPO.getCtccAppId();
        if (StringUtils.isNotEmpty(ctccAppId)) {
            authConfigInfo.getCtcc().setAppId(ctccAppId);
        }
        String ctccAppSecret = authConfigPO.getCtccAppSecret();
        if (StringUtils.isNotEmpty(ctccAppSecret)) {
            authConfigInfo.getCtcc().setAppSecret(ctccAppSecret);
        }
        String ctccPrivateKey = authConfigPO.getCtccPrivateKey();
        if (StringUtils.isNotEmpty(ctccPrivateKey)) {
            authConfigInfo.getCtcc().setPrivateKey(ctccPrivateKey);
        }
        String ctccPublicKey = authConfigPO.getCtccPublicKey();
        if (StringUtils.isNotEmpty(ctccPublicKey)) {
            authConfigInfo.getCtcc().setPublicKey(ctccPublicKey);
        }

        return authConfigInfo;
    }

}
