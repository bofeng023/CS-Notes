package cc.linkedme.account.dao.account.sms.template;

import lombok.Data;

import java.util.Date;

@Data
public class SmsTemplatePO {
    private Integer id;

    private Integer uid;

    private Integer appId;

    private String templateCode;

    private String aliyunTemplateCode;

    private String templateName;

    private Byte templateType;

    private Byte isGlobal;

    private String content;

    private String applyRemark;

    private Byte certificationState;

    private Byte isDeleted;

    private Date gmtCreate;

    private Date gmtUpdate;

}