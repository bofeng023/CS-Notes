package cc.linkedme.account.service.impl.factory;

import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.service.impl.PhoneNumVerificationServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanghaowei
 * @date 2019-6-18 17:43
 * @description
 **/
@Component("phoneNumValidateFactory")
public class PhoneNumValidateFactory {

    Logger logger = LoggerFactory.getLogger(PhoneNumValidateFactory.class);

    private Map<Channel, PhoneNumVerificationServiceImpl> validateHandlerMap;

    @Autowired
    private PhoneNumVerificationServiceImpl cmccValidateHandler, ctccValidateHandler, cuccValidateHandler;

    @PostConstruct
    public void init() {
        validateHandlerMap = new HashMap<>(3);
        validateHandlerMap.put(Channel.MOBILE, cmccValidateHandler);
        validateHandlerMap.put(Channel.UNICOM, cuccValidateHandler);
        validateHandlerMap.put(Channel.TELECOM, ctccValidateHandler);
    }

    public PhoneNumVerificationServiceImpl getSearchHandler(Channel channel) {
        logger.info("getSearchHandler, channel:{}", channel);

        return validateHandlerMap.get(channel);
    }


}
