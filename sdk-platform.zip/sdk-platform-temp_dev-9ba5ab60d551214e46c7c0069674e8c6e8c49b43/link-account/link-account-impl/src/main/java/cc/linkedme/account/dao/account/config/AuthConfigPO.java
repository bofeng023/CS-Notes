package cc.linkedme.account.dao.account.config;

import lombok.Data;

import java.util.Date;

@Data
public class AuthConfigPO {
    private Integer id;

    private Integer appId;

    private String appKey;

    private String appSecret;

    private String publicKey;

    private String ipWhitelist;

    private String cmccAndroidAppId;

    private String cmccAndroidAppKey;

    private String cmccAndroidAppSecret;

    private String cmccIosAppId;

    private String cmccIosAppKey;

    private String cmccIosAppSecret;

    private String cmccPrivateKey;

    private String cmccPublicKey;

    private String ctccAppId;

    private String ctccAppSecret;

    private String ctccPrivateKey;

    private String ctccPublicKey;

    private Date gmtCreate;

    private Date gmtModified;
}