package cc.linkedme.account.converter;

import cc.linkedme.account.dao.account.sms.frequency.SmsFrequencyPO;
import cc.linkedme.account.model.sms.SmsFrequencyInfo;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 15:31
 * @description
 **/
public class SmsFrequencyPoConverter {

    public static SmsFrequencyPO bo2Po(SmsFrequencyInfo smsFrequencyInfo) {

        SmsFrequencyPO smsFrequencyPO = new SmsFrequencyPO();
        BeanUtils.copyProperties(smsFrequencyInfo, smsFrequencyPO);
        smsFrequencyPO.setCountPerDay(smsFrequencyInfo.getCountPerDay() == null ? null : smsFrequencyInfo.getCountPerDay().byteValue());
        smsFrequencyPO.setCountPerHour(smsFrequencyInfo.getCountPerHour() == null ? null : smsFrequencyInfo.getCountPerHour().byteValue());
        smsFrequencyPO.setCountPerMinute(smsFrequencyInfo.getCountPerMinute() == null ? null : smsFrequencyInfo.getCountPerMinute().byteValue());

        return smsFrequencyPO;
    }

    public static SmsFrequencyInfo po2Bo(SmsFrequencyPO smsFrequencyPO) {

        SmsFrequencyInfo smsFrequencyInfo = new SmsFrequencyInfo();
        BeanUtils.copyProperties(smsFrequencyPO, smsFrequencyInfo);
        smsFrequencyInfo.setCountPerDay(smsFrequencyPO.getCountPerDay() == null ? null : smsFrequencyPO.getCountPerDay().intValue());
        smsFrequencyInfo.setCountPerHour(smsFrequencyPO.getCountPerHour() == null ? null : smsFrequencyPO.getCountPerHour().intValue());
        smsFrequencyInfo.setCountPerMinute(smsFrequencyPO.getCountPerMinute() == null ? null : smsFrequencyPO.getCountPerMinute().intValue());

        return smsFrequencyInfo;
    }
}
