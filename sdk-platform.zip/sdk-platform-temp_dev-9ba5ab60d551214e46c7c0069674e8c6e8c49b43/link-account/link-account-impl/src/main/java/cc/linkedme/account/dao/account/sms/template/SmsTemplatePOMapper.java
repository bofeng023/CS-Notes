package cc.linkedme.account.dao.account.sms.template;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SmsTemplatePOMapper {
    long countByExample(SmsTemplatePOExample example);

    int deleteByExample(SmsTemplatePOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SmsTemplatePO record);

    int insertSelective(SmsTemplatePO record);

    List<SmsTemplatePO> selectByExample(SmsTemplatePOExample example);

    SmsTemplatePO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SmsTemplatePO record, @Param("example") SmsTemplatePOExample example);

    int updateByExample(@Param("record") SmsTemplatePO record, @Param("example") SmsTemplatePOExample example);

    int updateByPrimaryKeySelective(SmsTemplatePO record);

    int updateByPrimaryKey(SmsTemplatePO record);

    List<SmsTemplatePO> selectByExampleWithLimit(@Param("example") SmsTemplatePOExample example, @Param("offset") Integer offset, @Param("limit") Integer limit);
}