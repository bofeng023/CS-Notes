package cc.linkedme.account.dao.account.balance;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AccountBalancePOMapper {
    long countByExample(AccountBalancePOExample example);

    int deleteByExample(AccountBalancePOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(AccountBalancePO record);

    int insertSelective(AccountBalancePO record);

    List<AccountBalancePO> selectByExample(AccountBalancePOExample example);

    AccountBalancePO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AccountBalancePO record, @Param("example") AccountBalancePOExample example);

    int updateByExample(@Param("record") AccountBalancePO record, @Param("example") AccountBalancePOExample example);

    int updateByPrimaryKeySelective(AccountBalancePO record);

    int updateByPrimaryKey(AccountBalancePO record);

    AccountBalancePO getAccountBalancePOByUid(Integer id);

    int updateAccountBalance(@Param("accountBalancePO") AccountBalancePO accountBalancePO, @Param("amount") Integer amount, @Param("giftAmount") Integer giftAmount);
}