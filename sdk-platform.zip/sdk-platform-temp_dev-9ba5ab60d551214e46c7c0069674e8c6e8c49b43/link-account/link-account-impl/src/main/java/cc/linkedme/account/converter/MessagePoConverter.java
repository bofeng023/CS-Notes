package cc.linkedme.account.converter;

import cc.linkedme.account.dao.page.message.MessagePO;
import cc.linkedme.account.enums.MessageType;
import cc.linkedme.account.model.MessageInfo;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:44 2019-08-14
 * @:Description
 */
public class MessagePoConverter {

    public static MessagePO bo2Po(MessageInfo messageInfo) {

        MessagePO messagePo = new MessagePO();
        BeanUtils.copyProperties(messageInfo, messagePo);
        messagePo.setCategory(messageInfo.getMessageType() == null ? null : messageInfo.getMessageType().getType());
        return messagePo;
    }

    public static MessageInfo po2Bo(MessagePO messagePo) {

        MessageInfo messageInfo = new MessageInfo();
        BeanUtils.copyProperties(messagePo, messageInfo);
        messageInfo.setMessageType(MessageType.get(messagePo.getCategory()));
        return messageInfo;
    }
}
