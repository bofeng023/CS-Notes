package cc.linkedme.account.service.impl.provider.sms;

import cc.linkedme.account.common.crypto.CryptUtil;
import cc.linkedme.account.common.http.CloseableHttpClientUtil;
import cc.linkedme.json.JsonConverter;
import cc.linkedme.account.common.punctuation.Punctuation;
import cc.linkedme.account.enums.provider.sms.huawei.HuaweiSmsCallbackStatus;
import cc.linkedme.account.enums.provider.sms.huawei.HuaweiSmsResponseCode;
import cc.linkedme.account.errorcode.SmsErrorCode;
import cc.linkedme.account.exception.SmsException;
import cc.linkedme.account.model.provider.sms.HuaweiSmsRequest;
import cc.linkedme.account.model.provider.sms.HuaweiSmsResponse;
import cc.linkedme.account.model.provider.sms.HuaweiVoiceSmsRequest;
import cc.linkedme.account.model.provider.sms.HuaweiVoiceSmsResponse;
import cc.linkedme.account.model.sms.SmsCallbackInfo;
import cc.linkedme.account.model.sms.SmsExtend;
import cc.linkedme.account.model.sms.SmsInfo;
import cc.linkedme.account.model.sms.SmsTextKey;
import cc.linkedme.account.model.sms.VoiceSmsInfo;
import cc.linkedme.account.service.SmsService;
import cc.linkedme.account.service.provider.sms.SmsProviderService;
import cc.linkedme.cache.CacheUtil;
import cc.linkedme.cache.redis.RedisClientUtil;
import cc.linkedme.enums.BizType;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author lipeng
 * @date 2019-08-01 21:46
 * @description
 **/
@Service
public class HuaweiSmsServiceImpl implements SmsProviderService {

    static Logger logger = LoggerFactory.getLogger(HuaweiSmsServiceImpl.class);

    private static final String SEND_URL = "http://api.rtc.huaweicloud.com:10443/sms/batchSendDiffSms/v1";
    private static final String APP_KEY = "juse33U9fR8O14lMY6bdD8z011h6";
    private static final String APP_SECRET = "1445y88LYm3w3Ww54sZ8cv1gq6xg";
    private static final String CHANNEL_ID = "881907158080";
    private static final String HEADER_AUTHORIZATION = "WSSE realm=\"SDP\",profile=\"UsernameToken\",type=\"Appkey\"";
    private static final String HEADER_CONTENT_TYPE = "application/json";
    private static final String HEADER_XWSSE_FORMAT = "UsernameToken Username=\"%s\",PasswordDigest=\"%s\",Nonce=\"%s\",Created=\"%s\"";
    /**
     * 状态回调地址
     */
    private static final String STATUS_CALLBACK_URL = "http://accountcb.linkedme.cc/sms/text";

    private static final String VOICE_APP_KEY = "1cxAhdZm03C8bD77vFg15y8CEn86";
    private static final String VOICE_APP_SECRET = "4h305e15JwrLXI78CfSy8Z6LFqnY";
    private static final String VOICE_API_VERSION = "v2.0";
    /**
     * 绑定号码
     */
    private static final String VOICE_BIND_NBR = "+8678880008689";

    /**
     * 主显号码
     */
    private static final String VOICE_DISPLAY_NBR = "+8631180985016";

    /**
     * 语音短信状态回调地址
     */
    private static final String VOICE_STATUS_CALLBACK_URL = "http://accountcb.linkedme.cc/sms/voice";

    private static final String VOICE_BASE_URL = "http://api.rtc.huaweicloud.com:10443";

    /**
     * 语音短信权限认证
     */
    private static final String VOICE_APP_AUTH = VOICE_BASE_URL + "/rest/fastlogin/v1.0";

    /**
     * access_token refresh url
     */
    private static final String VOICE_REFRESH_TOKEN = VOICE_BASE_URL + "/omp/oauth/refresh";

    private static final String VOICE_HEADER_APP_AUTH = "Authorization";

    private static final String VOICE_ACCESS_TOKEN_REDIS_KEY = "voice_access_token";

    private static final String VOICE_REFRESH_TOKEN_REDIS_KEY = "voice_refresh_token";

    private static final String VOICE_USER_NAME = "WeiFangCheng";

    private static final String VOICE_USER_PASSWORD = "WeiFangCheng@12";


    /**
     * 语音通知api调用地址
     */
    private static final String VOICE_SMS_URL_CALL_NOTIFY = VOICE_BASE_URL + "/rest/httpsessions/callnotify";

    @Resource
    private CloseableHttpClientUtil closeableHttpClientProxyUtil;

    @Resource
    private RedisClientUtil smsDbRedisClient;

    @Resource
    private SmsService smsService;

    @Override
    public void sendText(SmsInfo smsInfo) throws SmsException {
        logger.info("sendText start, smsInfo:{}", smsInfo);

        HuaweiSmsRequest huaweiSmsRequest = buildRequestParams(smsInfo);

        String response = requestSmsService(huaweiSmsRequest);

        parseSmsResult(response, huaweiSmsRequest);

        logger.info("sendText end, smsInfo:{}, huaweiSmsRequest:{}, response:{}", smsInfo, huaweiSmsRequest, response);
    }

    @Override
    public void sendVoice(VoiceSmsInfo voiceSmsInfo) throws SmsException {

        logger.info("sendVoice, voiceSmsInfo:{}", voiceSmsInfo);

        HuaweiVoiceSmsRequest huaweiVoiceSmsSendRequest = buildVoiceSmsRequestParams(voiceSmsInfo);
        logger.info("sendVoice, voiceSmsInfo:{}, huaweiVoiceSmsSendRequest:{}", voiceSmsInfo, huaweiVoiceSmsSendRequest);

        String response = requestVoiceSmsService(huaweiVoiceSmsSendRequest);
        logger.info("sendVoice, voiceSmsInfo:{}, huaweiVoiceSmsSendRequest:{}, response:{}", voiceSmsInfo, huaweiVoiceSmsSendRequest, response);

        parseVoiceSmsResult(response, huaweiVoiceSmsSendRequest);
    }

    /**
     * 构建请求参数
     *
     * @param smsInfo 短信对象
     * @return smsInfo 华为短信请求对象
     */
    protected HuaweiSmsRequest buildRequestParams(SmsInfo smsInfo) {

        logger.info("buildRequestParams, smsInfo:{}", smsInfo);
        HuaweiSmsRequest huaweiSmsRequest = new HuaweiSmsRequest();

        if (smsInfo == null) {
            throw new SmsException(SmsErrorCode.SEND_SMS_EMPTY);
        }

        if (StringUtils.isEmpty(smsInfo.getRecipient())) {
            throw new SmsException(SmsErrorCode.SEND_SMS_EMPTY);
        }

        HuaweiSmsRequest.Header header = new HuaweiSmsRequest.Header();
        header.setAppKey(APP_KEY);
        header.setAppSecret(APP_SECRET);

        HuaweiSmsRequest.Body body = new HuaweiSmsRequest.Body();
        List<HuaweiSmsRequest.DiffSms> diffSmsList = new ArrayList<>();

        HuaweiSmsRequest.DiffSms diffSms = new HuaweiSmsRequest.DiffSms();
        diffSms.setTo(Arrays.asList(smsInfo.getRecipient().split(Punctuation.COMMA)));
        diffSms.setBody(smsInfo.getContent());
        diffSmsList.add(diffSms);

        body.setStatusCallback(STATUS_CALLBACK_URL);
        body.setFrom(CHANNEL_ID);
        body.setSmsContent(diffSmsList);
        //目的异步回调返回接收号码appKey
        body.setExtend(smsInfo.getExtend());
        huaweiSmsRequest.setBody(body);
        huaweiSmsRequest.setHeader(header);

        logger.info("buildRequestParams, smsInfo:{}, huaweiSmsRequest:{}", smsInfo, huaweiSmsRequest);

        return huaweiSmsRequest;
    }


    /**
     * 请求短信服务
     *
     * @param huaweiSmsRequest 华为请求对象
     * @return String
     */
    protected String requestSmsService(HuaweiSmsRequest huaweiSmsRequest) throws SmsException {

        logger.info("requestSmsService, huaweiSmsSendRequest:{}", huaweiSmsRequest);

        String wsseHeader = buildWsseHeader(huaweiSmsRequest);

        logger.info("requestSmsService, huaweiSmsRequest:{}, wsseHeader:{}", huaweiSmsRequest, wsseHeader);

        String responseResult;
        try {

            String body = JsonConverter.format(huaweiSmsRequest.getBody());

            logger.info("requestSmsService, huaweiSmsRequest:{}, body:{}", huaweiSmsRequest, body);

            Map<String, String> headerMap = new HashMap<>(3);
            headerMap.put(HttpHeaders.CONTENT_TYPE, HEADER_CONTENT_TYPE);
            headerMap.put(HttpHeaders.AUTHORIZATION, HEADER_AUTHORIZATION);
            headerMap.put("X-WSSE", wsseHeader);

            HttpResponse response = closeableHttpClientProxyUtil.httpPost(SEND_URL, headerMap, body);
            responseResult = EntityUtils.toString(response.getEntity());
        } catch (Exception e) {
            logger.error("requestSmsService, huaweiSmsRequest, wsseHeader:{}", huaweiSmsRequest, wsseHeader, e);
            throw new SmsException(SmsErrorCode.SEND_SMS_REQUEST_FAIL);
        }

        logger.info("requestSmsService, huaweiSmsRequest, responseResult:{}", huaweiSmsRequest, responseResult);

        return responseResult;
    }


    /**
     * 解析结果
     *
     * @param response         华为响应结果
     * @param huaweiSmsRequest 请求对象
     * @return SmsSyncInfo
     */
    private void parseSmsResult(String response, HuaweiSmsRequest huaweiSmsRequest) throws SmsException {

        logger.info("parseSmsResult, response:{}, huaweiSmsRequest:{}", response, huaweiSmsRequest);

        HuaweiSmsResponse sendSmsResponse = JsonConverter.parse(response, HuaweiSmsResponse.class);

        logger.debug("parseSmsResult, response:{}, huaweiSmsRequest:{}, sendSmsResponse:{}", response, huaweiSmsRequest, sendSmsResponse);

        final int[] refundCount = new int[1];
        String refundKey = null;
        SmsExtend smsExtend = SmsExtend.parse(huaweiSmsRequest.getBody().getExtend());
        if (!HuaweiSmsResponseCode.SUCCESS.getCode().equals(sendSmsResponse.getCode())) {
            //请求华为接口失败，需要全部退款
            List<HuaweiSmsRequest.DiffSms> diffSmsList = huaweiSmsRequest.getBody().getSmsContent();
            diffSmsList.forEach(diffSms -> diffSms.getTo().forEach(to -> {
                //失败信息存入kafka 返回给用户
                smsStatusReport(to, sendSmsResponse.getCode(), huaweiSmsRequest.getBody().getExtend());

                //统计失败，需要退款短信条数
                String key = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getContractId(), to);
                SmsTextKey smsTextKey = smsDbRedisClient.get(key, SmsTextKey.class);
                refundCount[0] = refundCount[0] + smsTextKey.getContentCount();
            }));
            refundKey = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getContractId(), diffSmsList.get(0).getTo().get(0));
            logger.info("parseSmsResult, response:{}, huaweiSmsRequest:{}, refundCount:{}, refundKey:{}, extend:{}", response, huaweiSmsRequest, refundCount[0], refundKey, smsExtend.toString());
        } else {
            //判断请求华为接口成功，但是某个具体的短信不合法需要退款
            List<HuaweiSmsResponse.SmsID> smsIDList = sendSmsResponse.getResult();
            if (CollectionUtils.isNotEmpty(smsIDList)) {
                smsIDList.forEach(smsID -> {
                    if (!smsID.getStatus().equals(HuaweiSmsCallbackStatus.SUCCESS.getCode())) {
                        //失败信息存入kafka 返回给用户
                        smsStatusReport(smsID.getOriginTo(), smsID.getStatus(), huaweiSmsRequest.getBody().getExtend());
                        //统计失败，需要退款单价个数
                        String key = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getContractId(), smsID.getOriginTo());
                        SmsTextKey smsTextKey = smsDbRedisClient.get(key, SmsTextKey.class);
                        refundCount[0] = refundCount[0] + smsTextKey.getContentCount();
                    }
                });
                refundKey = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getContractId(), smsIDList.get(0).getOriginTo());
                logger.info("parseSmsResult, response:{}, huaweiSmsRequest:{}, refundCount:{}, refundKey:{}, extend:{}", response, huaweiSmsRequest, refundCount[0], refundKey, smsExtend.toString());
            }
        }

        //失败退款
        if (refundCount[0] > 0) {
            smsService.refund(refundKey, refundCount[0], String.valueOf(smsExtend.getUid()), BizType.TEXT_SMS);
            logger.info("parseSmsResult huawei return failed, refund success, response:{}, huaweiSmsRequest:{}, refundCount:{}", response, huaweiSmsRequest, refundCount[0]);
        }
    }

    /**
     * 构造X-WSSE参数值
     *
     * @param huaweiSmsRequest
     * @return String
     */
    private String buildWsseHeader(HuaweiSmsRequest huaweiSmsRequest) {
        logger.info("buildWsseHeader, huaweiSmsRequest:{}", huaweiSmsRequest);
        HuaweiSmsRequest.Header header = huaweiSmsRequest.getHeader();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        String time = sdf.format(new Date());
        String uuid = UUID.randomUUID().toString().replace("-", "");
        byte[] passwordDigest = DigestUtils.sha256(uuid + time + header.getAppSecret());
        String hexDigest = Hex.encodeHexString(passwordDigest);
        String passwordDigestBase64Str =
                Base64.encodeBase64String(hexDigest.getBytes(Charset.forName("utf-8")));

        logger.info("buildWsseHeader, huaweiSmsRequest:{}, passwordDigestBase64Str:{}", huaweiSmsRequest, passwordDigestBase64Str);
        return String.format(HEADER_XWSSE_FORMAT, header.getAppKey(), passwordDigestBase64Str, uuid, time);
    }

    /**
     * 构建语音短信请求参数
     *
     * @param voiceSmsInfo 语音短信对象
     * @return HuaweiVoiceSmsRequest 封装华为语音短信对象
     */
    protected HuaweiVoiceSmsRequest buildVoiceSmsRequestParams(VoiceSmsInfo voiceSmsInfo) throws SmsException {

        logger.info("buildVoiceSmsRequestParams, voiceSmsInfo:{}", voiceSmsInfo);
        if (voiceSmsInfo == null) {
            throw new SmsException(SmsErrorCode.SEND_SMS_EMPTY);
        }
        String templateId = voiceSmsInfo.getTemplateId();
        if (StringUtils.isEmpty(templateId)) {
            throw new SmsException(SmsErrorCode.SEND_SMS_EMPTY);
        }
        List<String> templateParamsList = voiceSmsInfo.getTemplateParams();
        if (CollectionUtils.isEmpty(templateParamsList)) {
            throw new SmsException(SmsErrorCode.SEND_SMS_EMPTY);
        }

        HuaweiVoiceSmsRequest huaweiVoiceSmsSendRequest = new HuaweiVoiceSmsRequest();
        HuaweiVoiceSmsRequest.Body body = new HuaweiVoiceSmsRequest.Body();

        body.setBindNbr(VOICE_BIND_NBR);
        body.setCalleeNbr(voiceSmsInfo.getRecipient());
        body.setDisplayNbr(VOICE_DISPLAY_NBR);
        body.setFeeUrl(CryptUtil.Base64.encode(VOICE_STATUS_CALLBACK_URL.getBytes()));
        body.setUserData(voiceSmsInfo.getExtend());

        List<HuaweiVoiceSmsRequest.PlayContentInfo> playContentInfoList = new ArrayList<>();

        HuaweiVoiceSmsRequest.PlayContentInfo playContentInfo = new HuaweiVoiceSmsRequest.PlayContentInfo();

        playContentInfo.setTemplateId(voiceSmsInfo.getTemplateId());
        List<String> huaweiTemplateParamsList = voiceSmsInfo.getTemplateParams();
        playContentInfo.setTemplateParas(huaweiTemplateParamsList.toArray(new String[huaweiTemplateParamsList.size()]));
        playContentInfoList.add(playContentInfo);

        body.setPlayInfoList(playContentInfoList);
        huaweiVoiceSmsSendRequest.setBody(body);
        //获取access_token
        String accessToken = getVoiceSmsAccessToken();
        // 构造URL，在基础URL后面携带从管理员处获取的app_key和作为入参传入的access_token。
        String smsUrlCallNotify = VOICE_SMS_URL_CALL_NOTIFY + "/" + VOICE_API_VERSION + "?app_key=" + VOICE_APP_KEY + "&" + "access_token=" + accessToken;

        huaweiVoiceSmsSendRequest.setVoiceSmsUrlCallNotify(smsUrlCallNotify);

        logger.info("buildVoiceSmsRequestParams, voiceSmsInfo:{}, huaweiVoiceSmsSendRequest:{}", voiceSmsInfo, huaweiVoiceSmsSendRequest);
        return huaweiVoiceSmsSendRequest;
    }

    /**
     * 请求语音短信服务
     *
     * @param huaweiVoiceSmsSendRequest 语音短信对象
     * @return String
     */
    protected String requestVoiceSmsService(HuaweiVoiceSmsRequest huaweiVoiceSmsSendRequest) throws SmsException {

        logger.info("requestVoiceSmsService, huaweiVoiceSmsSendRequest:{}", huaweiVoiceSmsSendRequest);

        String response;
        try {
            String body = JsonConverter.format(huaweiVoiceSmsSendRequest.getBody());
            logger.info("requestVoiceSmsService, huaweiVoiceSmsSendRequest:{}, body:{}", huaweiVoiceSmsSendRequest, body);

            HttpResponse httpResponse = closeableHttpClientProxyUtil.httpPostContent(huaweiVoiceSmsSendRequest.getVoiceSmsUrlCallNotify(), body);
            response = EntityUtils.toString(httpResponse.getEntity());
        } catch (Exception e) {
            logger.error("requestVoiceSmsService, huaweiVoiceSmsSendRequest:{}", huaweiVoiceSmsSendRequest, e);
            throw new SmsException(SmsErrorCode.VOICE_SMS_INTERFACE_FAIL);
        }

        logger.info("requestVoiceSmsService, huaweiVoiceSmsSendRequest:{}, response:{}", huaweiVoiceSmsSendRequest, response);
        return response;
    }

    /**
     * 语音短信解析结果
     *
     * @param response                  华为语音响应结果
     * @param huaweiVoiceSmsSendRequest 请求对象
     */
    protected void parseVoiceSmsResult(String response, HuaweiVoiceSmsRequest huaweiVoiceSmsSendRequest) throws SmsException {

        logger.info("parseVoiceSmsResult, response:{}, huaweiVoiceSmsSendRequest:{}", response, huaweiVoiceSmsSendRequest);

        HuaweiVoiceSmsResponse huaweiVoiceSmsSendResponse = JsonConverter.parse(response, HuaweiVoiceSmsResponse.class);

        logger.info("parseVoiceSmsResult, response:{}, huaweiVoiceSmsSendRequest:{}, huaweiVoiceSmsSendResponse:{}", response, huaweiVoiceSmsSendRequest, huaweiVoiceSmsSendResponse);

        if (!HuaweiSmsResponseCode.VOICE_SEND_SMS_SUCCESS.getCode().equals(huaweiVoiceSmsSendResponse.getResultCode())) {
            logger.info("parseVoiceSmsResult refund start, response:{}, huaweiVoiceSmsSendRequest:{}", response, huaweiVoiceSmsSendRequest);

            SmsExtend smsExtend = SmsExtend.parse(huaweiVoiceSmsSendRequest.getBody().getUserData());
            String key = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getContractId(), huaweiVoiceSmsSendRequest.getBody().getCalleeNbr());
            smsService.refund(key, 1, String.valueOf(smsExtend.getUid()), BizType.VOICE_SMS);
            logger.info("parseVoiceSmsResult refund end, response:{}, huaweiVoiceSmsSendRequest:{}, extend:{}, key:{}", response, huaweiVoiceSmsSendRequest, smsExtend.toString(), key);
        }
    }

    /**
     * 获取语音短信 access_token
     *
     * @return String
     */
    private String getVoiceSmsAccessToken() {
        logger.info("getVoiceSmsAccessToken get access_token start");

        String accessToken = smsDbRedisClient.get(VOICE_ACCESS_TOKEN_REDIS_KEY);
        String refreshToken = smsDbRedisClient.get(VOICE_REFRESH_TOKEN_REDIS_KEY);
        logger.info("getVoiceAccessToken, accessToken:{}, refreshToken:{}", accessToken, refreshToken);

        //过期时间
        int expires = 0;
        boolean setExpire = false;

        Map<String, String> response = null;
        if (refreshToken == null) {
            //需要号码认证
            response = fastLogin();
        } else {
            if (accessToken == null) {
                //已认证过，只需要重新refresh
                response = voiceSmsRefresh(refreshToken);
            }
        }

        if (response != null) {
            accessToken = response.get("access_token");
            refreshToken = response.get("refresh_token");
            expires = Integer.parseInt(response.get("expires_in"));
            setExpire = true;
        }

        if (setExpire) {
            smsDbRedisClient.setex(VOICE_REFRESH_TOKEN_REDIS_KEY, refreshToken, expires);
            smsDbRedisClient.setex(VOICE_ACCESS_TOKEN_REDIS_KEY, accessToken, expires / 4);
        }

        logger.info("getVoiceAccessToken get access_token end, accessToken:{}, refreshToken:{}", accessToken, refreshToken);
        return accessToken;
    }

    /**
     * 华为语音短信获取 access_token
     *
     * @return HashMap （access_token, refresh_token, expires_in）
     */
    private Map fastLogin() {

        logger.info("fastLogin, username:{}, password:{}", VOICE_USER_NAME, VOICE_USER_PASSWORD);

        String urlLogin = VOICE_APP_AUTH + "?app_key=" + VOICE_APP_KEY + "&username=" + VOICE_USER_NAME;

        Map<String, String> headers = new HashMap<>(1);
        headers.put(VOICE_HEADER_APP_AUTH, VOICE_USER_PASSWORD);
        String response;
        try {
            HttpResponse httpResponse = closeableHttpClientProxyUtil.httpPost(urlLogin, headers);
            response = EntityUtils.toString(httpResponse.getEntity());

            logger.info("fastLogin, username:{}, password:{}, result:{}", VOICE_USER_NAME, VOICE_USER_PASSWORD, response);
            return JsonConverter.parse(response, Map.class);
        } catch (Exception e) {
            logger.error("fastLogin, username:{}, password:{}", VOICE_USER_NAME, VOICE_USER_PASSWORD, e);
            throw new SmsException(SmsErrorCode.VOICE_SMS_LOGIN_ACCESS_TOKEN);
        }
    }

    /**
     * 刷新过期access_token
     *
     * @param refreshToken 刷新token
     * @return HashMap (access_token, refresh_token, expires_in）
     */
    private Map voiceSmsRefresh(String refreshToken) {

        logger.info("voiceSmsRefresh, refreshToken:{}", refreshToken);

        Map<String, Object> body = new HashMap<>(4);
        body.put("app_key", VOICE_APP_KEY);
        body.put("app_secret", VOICE_APP_SECRET);
        body.put("grant_type", "refresh_token");
        body.put("refresh_token", refreshToken);

        String response;
        try {
            List<NameValuePair> requestBody = closeableHttpClientProxyUtil.paramsConverter(body);
            HttpResponse httpResponse = closeableHttpClientProxyUtil.httpPost(VOICE_REFRESH_TOKEN, requestBody);
            response = EntityUtils.toString(httpResponse.getEntity());

            logger.info("voiceSmsRefresh, refreshToken:{}, result:{}", refreshToken, response);
            return JsonConverter.parse(response, Map.class);

        } catch (Exception e) {
            logger.error("voiceSmsRefresh, refreshToken:{}", refreshToken, e);
            throw new SmsException(SmsErrorCode.VOICE_SMS_REFRESH_ACCESS_TOKEN);
        }
    }

    /**
     * 短信报告存入mq
     *
     * @param originTo 接收号码
     * @param status   短信状态
     * @param extend   扩展字段
     */
    public void smsStatusReport(String originTo, String status, String extend) {
        logger.info("smsStatusReport, originTo:{}, status:{}, extend:{}", originTo, status, extend);

        SmsCallbackInfo smsCallbackInfo = new SmsCallbackInfo();
        smsCallbackInfo.setStatus(status);
        SmsExtend smsExtend = SmsExtend.parse(extend);
        String key = CacheUtil.genKey(smsExtend.getAppId(), smsExtend.getContractId(), originTo);
        SmsTextKey smsTextKey = smsDbRedisClient.get(key, SmsTextKey.class);
        smsCallbackInfo.setExtend(smsTextKey.getExtend());
        smsCallbackInfo.setRecipient(originTo);
        smsCallbackInfo.setTotal(String.valueOf(smsTextKey.getContentCount()));

        logger.info("smsStatusReport, originTo:{}, status:{}, extend:{}, smsCallbackInfo:{}", originTo, status, extend, smsCallbackInfo);
        smsService.asyncHandleProviderTextCallback(smsCallbackInfo);
    }


}
