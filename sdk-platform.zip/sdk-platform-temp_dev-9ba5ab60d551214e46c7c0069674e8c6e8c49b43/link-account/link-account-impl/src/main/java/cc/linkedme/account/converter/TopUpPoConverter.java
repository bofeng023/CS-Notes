package cc.linkedme.account.converter;

import cc.linkedme.account.dao.account.top.up.TopUpPO;
import cc.linkedme.account.model.TopUpInfo;
import cc.linkedme.enums.AuditState;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 16:15
 * @description
 **/
public class TopUpPoConverter {

    public static TopUpPO bo2Po(TopUpInfo topUpInfo) {

        TopUpPO topUpPO = new TopUpPO();
        BeanUtils.copyProperties(topUpInfo, topUpPO);
        topUpPO.setAuditState(topUpInfo.getAuditState() == null ? null : topUpInfo.getAuditState().getType().byteValue());

        return topUpPO;
    }

    public static TopUpInfo po2Bo(TopUpPO topUpPO) {

        TopUpInfo topUpInfo = new TopUpInfo();
        BeanUtils.copyProperties(topUpPO, topUpInfo);
        topUpInfo.setAuditState(topUpPO.getAuditState() == null ? null : AuditState.get(topUpPO.getAuditState().intValue()));

        return topUpInfo;
    }
}
