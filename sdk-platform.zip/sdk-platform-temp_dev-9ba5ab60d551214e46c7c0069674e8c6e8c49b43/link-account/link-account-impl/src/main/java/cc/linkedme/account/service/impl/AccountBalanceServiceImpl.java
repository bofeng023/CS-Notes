package cc.linkedme.account.service.impl;

import cc.linkedme.json.JsonConverter;
import cc.linkedme.account.constants.BalanceConstants;
import cc.linkedme.account.converter.AccountBalancePoConverter;
import cc.linkedme.account.dao.account.balance.AccountBalancePO;
import cc.linkedme.account.dao.account.balance.AccountBalancePOMapper;
import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.enums.TradingType;
import cc.linkedme.account.errorcode.AccountBalanceErrorCode;
import cc.linkedme.account.exception.AccountBalanceException;
import cc.linkedme.account.model.AccountBalanceInfo;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.model.TradingFlowInfo;
import cc.linkedme.account.service.AccountBalanceService;
import cc.linkedme.account.service.ConsumeCountSerivce;
import cc.linkedme.cache.CacheUtil;
import cc.linkedme.cache.redis.RedisClientUtil;
import cc.linkedme.cache.redis.ScoreValue;
import cc.linkedme.enums.BizType;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
/**
 * @author zhanghaowei
 * @date 2019-6-4 10:41
 * @description 账户余额
 **/
@Service
public class AccountBalanceServiceImpl implements AccountBalanceService {

    Logger logger = LoggerFactory.getLogger(AccountBalanceServiceImpl.class);

    Logger tradingFlowLogger = LoggerFactory.getLogger("tradingFlow");

    @Resource
    private AccountBalancePOMapper accountBalancePOMapper;
    @Resource
    private RedisClientUtil costDbRedisClient;
    @Resource
    private ConsumeCountSerivce consumeCountSerivce;

    private static final float CREDIT_RATIO = 0.1f;

    @Override
    public AccountBalanceInfo getAccountBalanceBOByUid(Integer uid) {
        logger.info("getAccountBalanceByUid, uid:{}", uid);

        AccountBalancePO accountBalancePO = accountBalancePOMapper.getAccountBalancePOByUid(uid);
        if (accountBalancePO == null) {
            return null;
        }
        logger.debug("getAccountBalanceBOByUid, uid:{}, accountBalancePO:{}", uid,accountBalancePO);
        return AccountBalancePoConverter.po2Bo(accountBalancePO);
    }


    @Override
    public AccountBalanceInfo updateAccountBalanceBO(AccountBalanceInfo accountBalanceBO) {
        logger.info("updateAccountBalanceBO, accountBalanceBO:{}", accountBalanceBO);

        Preconditions.checkNotNull(accountBalanceBO,new AccountBalanceException(BaseErrorCode.PARAM_NOT_VALID));

        Integer uid = accountBalanceBO.getUid();
        Preconditions.checkNotNull(uid,new AccountBalanceException(BaseErrorCode.UID_NULL_ERROR));

        Integer balance = accountBalanceBO.getBalance();
        Preconditions.checkNotNull(balance,new AccountBalanceException(AccountBalanceErrorCode.BALANCE_NULL_ERROR));

        accountBalanceBO.setGmtModified(new Date());

        this.accountBalancePOMapper.updateByPrimaryKeySelective(AccountBalancePoConverter.bo2Po(accountBalanceBO));
        return accountBalanceBO;
    }

    @Override
    public AccountBalanceInfo saveAccountBalanceBO(AccountBalanceInfo accountBalanceBO) {
        logger.info("saveAccountBalanceBO, accountBalanceBO:{}", accountBalanceBO);

        Preconditions.checkNotNull(accountBalanceBO,new AccountBalanceException(BaseErrorCode.PARAM_NOT_VALID));

        Integer uid = accountBalanceBO.getUid();
        Preconditions.checkNotNull(uid,new AccountBalanceException(BaseErrorCode.UID_NULL_ERROR));

        Integer balance = accountBalanceBO.getBalance();
        Preconditions.checkNotNull(balance,new AccountBalanceException(AccountBalanceErrorCode.BALANCE_NULL_ERROR));

        Date date = new Date();
        accountBalanceBO.setGmtCreate(date);
        accountBalanceBO.setGmtModified(date);
        AccountBalancePO accountBalancePO = AccountBalancePoConverter.bo2Po(accountBalanceBO);
        this.accountBalancePOMapper.insertSelective(accountBalancePO);
        accountBalanceBO.setId(accountBalancePO.getId());

        logger.info("saveAccountBalanceBO, accountBalanceBO:{}", accountBalanceBO);
        return accountBalanceBO;
    }

    @Override
    public Integer updateAccountBalance(Integer uid, Integer amount, Integer giftAmount) {

        AccountBalancePO accountBalancePO = new AccountBalancePO();
        accountBalancePO.setGmtModified(new Date());
        accountBalancePO.setUid(uid);

        return accountBalancePOMapper.updateAccountBalance(accountBalancePO, amount, giftAmount);
    }

    @Override
    public Boolean checkContractAndCreditAmount(Integer uid, Integer contractTotalAmount) throws AccountBalanceException {

        logger.info("checkContractAndCreditAmount, uid:{}, contractTotalAmount:{}", uid, contractTotalAmount);
        Boolean contractBiggerThenCreditConsumed = false;

        String currentCreditAmount = costDbRedisClient.get(CacheUtil.genKey(BalanceConstants.USER_CREDIT_AMOUNT_PREFIX, uid));
        String currentCreditAmountBalance = null;
        if (currentCreditAmount == null) {
            contractBiggerThenCreditConsumed = true;
        } else {
            currentCreditAmountBalance = costDbRedisClient.hget(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(BalanceConstants.CREDIT_CACHE_AVATAR_ID));
            Integer consumedCredit = Integer.valueOf(currentCreditAmount) - Integer.valueOf(currentCreditAmountBalance);

            if (contractTotalAmount > consumedCredit) {
                contractBiggerThenCreditConsumed = true;
            }
        }

        logger.info("checkContractAndCreditAmount, uid:{}, contractTotalAmount:{}, currentCreditAmount:{}, currentCreditAmountBalance:{}, consumedCredit:{}", uid, contractTotalAmount, currentCreditAmount, currentCreditAmountBalance);
        return contractBiggerThenCreditConsumed;

    }

    @Override
    public void saveUserContractBalance(Integer uid, Integer contractId, Integer contractAmount, Integer giftAmount, BalanceUnitPrice balanceUnitPrice) throws AccountBalanceException {
        logger.info("saveUserContractBalance start, uid:{}, contractId:{}, contractAmount:{}, giftAmount:{}, balanceUnitPrice:{}", uid, contractId, contractAmount, giftAmount, balanceUnitPrice);
        balanceUnitPrice.setContractId(contractId);
        String contractUnitPrice = JsonConverter.format(balanceUnitPrice);
        balanceUnitPrice.setContractId(BalanceConstants.CREDIT_CACHE_AVATAR_ID);
        String creditUnitPricer = JsonConverter.format(balanceUnitPrice);
        // 写入本次充值合同余额,并记录合同单价
        Long contractBalanceAmount = costDbRedisClient.hincrBy(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(contractId), contractAmount);
        // 先写入新的有效合同单价，让信用额度的消费停止，然后再去做信用额度的平账，平账后再扣减掉多加的《平账》余额
        costDbRedisClient.zadd(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_UNIT_PRICE_PREFIX, uid), contractId, contractUnitPrice);

        // 已使用信用额度平账
        // 获取上次信用额度历史总额
        String userCreditAmount = costDbRedisClient.get(CacheUtil.genKey(BalanceConstants.USER_CREDIT_AMOUNT_PREFIX, uid));
        logger.info("saveUserContractBalance get last credit amount, uid:{}, contractId:{}, contractAmount:{}, giftAmount:{}, balanceUnitPrice:{}, lastCreditAmount:{}", uid, contractId, contractAmount, giftAmount, balanceUnitPrice, userCreditAmount);
        // 平账信用额度后的合同余额，<=合同原有余额
        int balancedContractAmount = contractAmount;
        if (userCreditAmount != null) {
            // 获取上次信用额度余额
            String userCreditBalance = costDbRedisClient.hget(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(BalanceConstants.CREDIT_CACHE_AVATAR_ID));
            logger.info("saveUserContractBalance get credit balance, uid:{}, contractId:{}, contractAmount:{}, giftAmount:{}, balanceUnitPrice:{}, lastCreditAmount:{}, userCreditBalance:{}", uid, contractId, contractAmount, giftAmount, balanceUnitPrice, userCreditBalance);
            // 信用额度消费了多少
            int creditConsumed = Integer.valueOf(userCreditAmount) - Integer.valueOf(userCreditBalance);
            if (creditConsumed > 0) {
                // 平账
                // 信用额度有消费，那么更新本次合同充值余额，再更新新的信用额度
                balancedContractAmount -= creditConsumed;
                // 信用额度有消费，把本次合同充值余额多加的，扣减掉
                contractBalanceAmount = costDbRedisClient.hincrBy(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(contractId), -creditConsumed);
                logger.info("saveUserContractBalance reduce credit cost, uid:{}, contractId:{}, contractAmount:{}, giftAmount:{}, balanceUnitPrice:{}, creditConsumed:{}, balancedContractAmount:{}",
                        uid, contractId, contractAmount, giftAmount, balanceUnitPrice, creditConsumed, balancedContractAmount);

                //平账上次使用的信用额度
                TradingFlowInfo tradingFlowInfo = new TradingFlowInfo(uid, TradingType.CREDIT, contractId, BizType.TOP_UP, creditConsumed, contractBalanceAmount, Channel.OTHER, new Date());
                tradingFlowLogger.info(tradingFlowInfo.toString());

            }
        }
        // 根据本次充值合同金额更新信用额度余额,并记录信用额度单价
        int newCreditAmount = (int) Math.ceil((contractAmount - giftAmount) * CREDIT_RATIO);
        logger.info("saveUserContractBalance current credit amount, uid:{}, contractId:{}, contractAmount:{}, giftAmount:{}, balanceUnitPrice:{}, newCreditAmount:{}",
                uid, contractId, contractAmount, giftAmount, balanceUnitPrice, newCreditAmount);
        costDbRedisClient.hdel(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(BalanceConstants.CREDIT_CACHE_AVATAR_ID));
        costDbRedisClient.hincrBy(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(BalanceConstants.CREDIT_CACHE_AVATAR_ID), newCreditAmount);
        costDbRedisClient.zremrangeByScore(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_UNIT_PRICE_PREFIX, uid), BalanceConstants.CREDIT_CACHE_AVATAR_ID,true, BalanceConstants.CREDIT_CACHE_AVATAR_ID, true);
        costDbRedisClient.zadd(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_UNIT_PRICE_PREFIX, uid), BalanceConstants.CREDIT_CACHE_AVATAR_ID, creditUnitPricer);

        // 记录本次充值的信用额度总额
        costDbRedisClient.set(CacheUtil.genKey(BalanceConstants.USER_CREDIT_AMOUNT_PREFIX, uid), String.valueOf(newCreditAmount));
        logger.info("saveUserContractBalance end, new credit amount、 balance and credit unit price, uid:{}, contractId:{}, contractAmount:{}, giftAmount:{}, balanceUnitPrice:{}, newCreditAmount:{}",
                uid, contractId, contractAmount, giftAmount, balanceUnitPrice, newCreditAmount);

        //记录充值资金流
        TradingFlowInfo tradingFlowInfo = new TradingFlowInfo(uid, TradingType.TOP_UP, contractId, BizType.TOP_UP, contractAmount, contractBalanceAmount, Channel.OTHER, new Date());
        tradingFlowLogger.info(tradingFlowInfo.toString());

    }

    @Override
    public BalanceUnitPrice consume(Integer uid, BizType bizType, Channel channel, Integer count) throws AccountBalanceException {

        logger.info("consume start, uid:{}, bizType:{}, channel:{}, count:{}", uid, bizType, channel, count);
        BalanceUnitPrice balanceUnitPrice = getFirstValidContractUnitPrice(uid);
        if (count == null || count <= 0) {
            throw new AccountBalanceException(AccountBalanceErrorCode.CONSUME_COUNT_INVALID);
        }
        Integer consumeUnitPrice = calculateBizUnitPrice(balanceUnitPrice, bizType) * count;
        logger.info("consume get should consume valid contract and calculate unit price, uid:{}, bizType:{}, channel:{}, balanceUnitPrice:{}, consumeUnitPrice:{}, count:{}", uid, bizType, channel, balanceUnitPrice, consumeUnitPrice, count);

        Long consumedResult = costDbRedisClient.hincrBy(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(balanceUnitPrice.getContractId()), -consumeUnitPrice);
        logger.info("consume consume result, uid:{}, bizType:{}, channel:{}, consumedResult:{}, count:{}", uid, bizType, channel, consumedResult, count);
        Date date = new Date();
        if (consumedResult > 0) {
            // 当前合同还有余额时，结算成功
            logger.info("consume balance success, uid:{}, bizType:{}, channel:{}, balanceUnitPrice:{}, consumedResult:{}, count:{}", uid, bizType, channel, balanceUnitPrice, consumedResult, count);

            //记录扣减资金流
            TradingFlowInfo tradingFlowInfo = new TradingFlowInfo(uid, TradingType.CONSUME, balanceUnitPrice.getContractId(), BizType.get(bizType.getType()), consumeUnitPrice, consumedResult, channel, date);
            tradingFlowLogger.info(tradingFlowInfo.toString());

            consumeCountSerivce.sendConsumeCountMessage(uid, bizType, balanceUnitPrice, date, count);
        } else if (consumedResult > -consumeUnitPrice) {
            // 当前合同还有余额，但不够一次结算的，结算成功，移除有效合同记录
            // 移除有效合同记录，但不能移除合同余额记录，因为请求运营商失败还可能回写旧合同
            costDbRedisClient.zremrangeByScore(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_UNIT_PRICE_PREFIX, uid), balanceUnitPrice.getContractId(), true, balanceUnitPrice.getContractId(), true);
            logger.info("consume balance success, not enough unit price, uid:{}, bizType:{}, channel:{}, balanceUnitPrice:{}, consumedResult:{}, count:{}", uid, bizType, channel, balanceUnitPrice, consumedResult, count);
            //记录扣减资金流
            TradingFlowInfo tradingFlowInfo = new TradingFlowInfo(uid, TradingType.CONSUME, balanceUnitPrice.getContractId(), BizType.get(bizType.getType()), (int)(consumeUnitPrice - Math.abs(consumedResult)), consumedResult, channel, date);
            tradingFlowLogger.info(tradingFlowInfo.toString());

            consumeCountSerivce.sendConsumeCountMessage(uid, bizType, balanceUnitPrice, date, count);
        } else {
            // 并发情况下，当前合同余额为0，移除有效合同记录
            costDbRedisClient.zremrangeByScore(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_UNIT_PRICE_PREFIX, uid), balanceUnitPrice.getContractId(), true, balanceUnitPrice.getContractId(), true);
            // 合同无费可扣的情况下，把扣出来的负数加回去，因为调用失败的请求还会回写原合同
            costDbRedisClient.hincrBy(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(balanceUnitPrice.getContractId()), consumeUnitPrice);
            logger.info("consume balance failed, this contract or credit not enough, uid:{}, bizType:{}, channel:{}, balanceUnitPrice:{}, consumedResult:{}, count:{}", uid, bizType, channel, balanceUnitPrice, consumedResult, count);
            // 如果信用额度也消费完，抛出异常
            if (BalanceConstants.CREDIT_CACHE_AVATAR_ID == (int) balanceUnitPrice.getContractId()) {
                logger.info("consume not quotas, uid:{}, bizType:{}, channel:{}, count:{}", uid, bizType, channel, count);
                throw new AccountBalanceException(BaseErrorCode.NO_QUOTAS);
            }
            // 递归，寻找下一个有效合同
            consume(uid, bizType, channel, 1);
        }

        logger.info("consume end, uid:{}, bizType:{}, channel:{}, count:{}", uid, bizType, channel, count);
        return balanceUnitPrice;
    }

    @Override
    public void refund(Integer uid, BizType bizType, BalanceUnitPrice balanceUnitPrice, Channel channel, Integer count) throws AccountBalanceException {

        logger.info("refund start, uid:{}, bizType:{}, balanceUnitPrice:{}, channel:{}, count:{}", uid, bizType, balanceUnitPrice, channel, count);
        if (count == null || count <= 0) {
            throw new AccountBalanceException(AccountBalanceErrorCode.CONSUME_COUNT_INVALID);
        }
        Integer refundPrice = calculateBizUnitPrice(balanceUnitPrice, bizType) * count;
        Long contractBalanceAmount = costDbRedisClient.hincrBy(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_BALANCE_PREFIX, uid), String.valueOf(balanceUnitPrice.getContractId()), refundPrice);
        costDbRedisClient.zadd(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_UNIT_PRICE_PREFIX, uid), balanceUnitPrice.getContractId(), JsonConverter.format(balanceUnitPrice));
        logger.info("refund end, uid:{}, bizType:{}, balanceUnitPrice:{}, channel:{}, count:{}, contractId:{}, refundPrice:{}", uid, bizType, balanceUnitPrice, channel, count, balanceUnitPrice.getContractId(), refundPrice);
        Date date = new Date();
        //记录失败返还资金流
        TradingFlowInfo tradingFlowInfo = new TradingFlowInfo(uid, TradingType.REFUND, balanceUnitPrice.getContractId(), BizType.get(bizType.getType()), refundPrice, contractBalanceAmount, channel, date);
        tradingFlowLogger.info(tradingFlowInfo.toString());

        consumeCountSerivce.sendConsumeCountMessage(uid, bizType, balanceUnitPrice, date, -count);
    }

    private BalanceUnitPrice getFirstValidContractUnitPrice(Integer uid) {
        logger.info("getFirstValidContractUnitPrice start, uid:{}", uid);

        List<ScoreValue> scoreValueList = costDbRedisClient.zrangeWithScores(CacheUtil.genKey(BalanceConstants.USER_CONTRACT_UNIT_PRICE_PREFIX, uid), 0, 0);
        if (CollectionUtils.isEmpty(scoreValueList)) {
            throw new AccountBalanceException(BaseErrorCode.NO_QUOTAS);
        }
        ScoreValue scoreValue = scoreValueList.iterator().next();
        BalanceUnitPrice balanceUnitPrice = JsonConverter.parse(scoreValue.getElement(), BalanceUnitPrice.class);
        balanceUnitPrice.setContractId((int)scoreValue.getScore().doubleValue());

        logger.info("getFirstValidContractUnitPrice end, uid:{}, balanceUnitPrice:{}", uid, balanceUnitPrice);
        return balanceUnitPrice;
    }

    private Integer calculateBizUnitPrice (BalanceUnitPrice balanceUnitPrice, BizType bizType) {

        logger.info("calculateBizUnitPrice start, balanceUnitPrice:{}, bizType:{}", balanceUnitPrice, bizType);
        Integer bizUnitPrice;
        switch (bizType) {
            case TEXT_SMS:
                bizUnitPrice = balanceUnitPrice.getTextSmsUnitPrice();
                break;
            case VOICE_SMS:

                bizUnitPrice = balanceUnitPrice.getVoiceSmsUnitPrice();
                break;
            case GLOBAL_SMS:
                bizUnitPrice = balanceUnitPrice.getGlobalSmsUnitPrice();
                break;
            case QUICK_LOGIN:
                bizUnitPrice = balanceUnitPrice.getLoginUnitPrice();
                break;
            case NUMBER_VERIFY:
                bizUnitPrice = balanceUnitPrice.getMobileVerifyUnitPrice();
                break;

                default:
                    throw new AccountBalanceException(BaseErrorCode.NO_QUOTAS);
        }

        logger.info("calculateBizUnitPrice end, balanceUnitPrice:{}, bizType:{}, bizUnitPrice:{}", balanceUnitPrice, bizType, bizUnitPrice);
        return bizUnitPrice;
    }

}
