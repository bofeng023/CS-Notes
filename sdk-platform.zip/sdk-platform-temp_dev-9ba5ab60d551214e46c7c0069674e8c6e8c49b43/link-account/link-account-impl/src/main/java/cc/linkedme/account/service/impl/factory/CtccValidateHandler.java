package cc.linkedme.account.service.impl.factory;

import cc.linkedme.account.enums.provider.login.CtccResponseCode;
import cc.linkedme.account.enums.Platform;
import cc.linkedme.account.enums.*;
import cc.linkedme.account.errorcode.PhoneNumVerificationErrorCode;
import cc.linkedme.account.exception.PhoneNumVerificationException;
import cc.linkedme.account.model.AuthConfigInfo;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.model.provider.login.CtccGetMobileRequest;
import cc.linkedme.account.model.provider.login.CtccGetMobileResponse;
import cc.linkedme.account.model.provider.login.CtccVerifyMobileRequest;
import cc.linkedme.account.model.provider.login.CtccVerifyMobileResponse;
import cc.linkedme.account.service.AccountBalanceService;
import cc.linkedme.account.service.impl.PhoneNumVerificationServiceImpl;
import cc.linkedme.json.JsonConverter;
import cc.linkedme.account.common.crypto.XxTea;
import cc.linkedme.account.common.http.HttpClientUtil;
import cc.linkedme.account.common.crypto.Rsa;
import cc.linkedme.account.common.crypto.SignAlgorithm;
import cc.linkedme.enums.BizType;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * @author yangpeng
 * @date 2019-06-13 15:54
 * @description
 **/

@Component("ctccValidateHandler")
public class CtccValidateHandler extends PhoneNumVerificationServiceImpl {

    private static final Logger logger = LoggerFactory.getLogger(CtccValidateHandler.class);

    private static final String CTCC_GET_MOBILE_URL = "http://open.e.189.cn/auth/codeinfo.do";
    private static final String CTCC_VERIFY_MOBILE_URL = "http://open.e.189.cn/auth/verifyinfo.do";
    private static final String CTCC_CONTENT_TYPE = "application/x-www-form-urlencoded;charset=UTF-8";
    @Resource
    protected AccountBalanceService accountBalanceService;

    @Override
    protected Object buildGetMobileRequestParams(Platform platform, String token, String authCode, AuthConfigInfo authConfigInfo) {

        logger.info("buildGetMobileRequestParams, platform:{}, token:{}, authCode:{}", platform, token, authCode);

        AuthConfigInfo.Ctcc ctcc = authConfigInfo.getCtcc();

        CtccGetMobileRequest ctccGetMobileRequest = new CtccGetMobileRequest();
        ctccGetMobileRequest.setAppId(ctcc.getAppId());
        ctccGetMobileRequest.setTimeStamp(System.currentTimeMillis());
        ctccGetMobileRequest.setFormat("json");
        String xxTeaContent = "accessCode=" + token + "&gwAuth=" + authCode;
        try {
            ctccGetMobileRequest.setParams(XxTea.encryptStr(xxTeaContent, StandardCharsets.UTF_8.name(), ctcc.getAppSecret()));
        } catch (Exception e) {
            logger.warn("buildGetMobileRequestParams XXTea error, platform:{}, token:{}, authCode:{}", platform, token, authCode, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.XXTEA_PARAMS_ERROR);
        }
        ctccGetMobileRequest.setAccessCode(token);
        ctccGetMobileRequest.setAuthCode(authCode);

        logger.debug("buildGetMobileRequestParams, platform:{}, token:{}, authCode:{}, ctccGetMobileRequest:{}", platform, token, authCode, ctccGetMobileRequest);
        return ctccGetMobileRequest;
    }

    @Override
    protected Object fillGetMobileRequestSign(Object requestParams, AuthConfigInfo authConfigInfo) {

        logger.info("fillGetMobileRequestSign, requestParams:{}", requestParams);
        AuthConfigInfo.Ctcc ctcc = authConfigInfo.getCtcc();

        CtccGetMobileRequest ctccGetMobileRequest = (CtccGetMobileRequest) requestParams;
        String signContent = ctccGetMobileRequest.getAppId() + ctccGetMobileRequest.getFormat() + ctccGetMobileRequest.getParams() + ctccGetMobileRequest.getTimeStamp();
        String sign;
        try {
            sign = Rsa.signHex(signContent, ctcc.getPrivateKey(), SignAlgorithm.SHA1withRSA);
        } catch (Exception e) {
            logger.warn("fillGetMobileRequestSign, ctccGetMobileRequest:{}", ctccGetMobileRequest, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.RSA_SIGN_ERROR);
        }
        ctccGetMobileRequest.setSign(sign);

        logger.debug("fillGetMobileRequestSign, ctccGetMobileRequest:{}", ctccGetMobileRequest);
        return ctccGetMobileRequest;
    }

    @Override
    protected String requestGetMobileServer(Object requestParams) {

        logger.info("requestGetMobileServer, requestParams:{}", requestParams);
        CtccGetMobileRequest ctccGetMobileRequest = (CtccGetMobileRequest) requestParams;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        httpClientUtil.httpPost(CTCC_GET_MOBILE_URL, ctccGetMobileRequest.toString(), byteArrayOutputStream, CTCC_CONTENT_TYPE, StandardCharsets.UTF_8.name());

        return byteArrayOutputStream.toString();
    }

    @Override
    protected Long parseMobile(String response, AuthConfigInfo authConfigInfo, BalanceUnitPrice balanceUnitPrice, Integer uid, Channel channel) {

        logger.info("parseMobile, response:{}", response);
        AuthConfigInfo.Ctcc ctcc = authConfigInfo.getCtcc();

        CtccGetMobileResponse ctccGetMobileResponse = JsonConverter.parse(response, CtccGetMobileResponse.class);
        if (!CtccResponseCode.SUCCESS.equals(CtccResponseCode.get(ctccGetMobileResponse.getResult()))) {
            accountBalanceService.refund(uid, BizType.QUICK_LOGIN, balanceUnitPrice, channel, 1);
            checkResponseCode(ctccGetMobileResponse.getResult());
        }
        String decryptData;
        CtccGetMobileResponse.Data ctccGetMobileResponseData = null;
        if (StringUtils.isNotEmpty(ctccGetMobileResponse.getData())) {
            try {
                decryptData = Rsa.decryptHex(ctccGetMobileResponse.getData(), ctcc.getPrivateKey());
            } catch (Exception e) {
                logger.warn("parseMobile error, ctccGetMobileResponse:{}", ctccGetMobileResponse, e);
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.RSA_DECRYPT_ERROR);
            }
            ctccGetMobileResponseData = JsonConverter.parse(decryptData, CtccGetMobileResponse.Data.class);
        }

        logger.debug("parseMobile, ctccGetMobileResponse:{}, data:{}", ctccGetMobileResponseData, ctccGetMobileResponseData);

        return Long.valueOf(ctccGetMobileResponseData.getMobile());
    }

    @Override
    protected Object buildVerifyMobileRequestParams(Platform platform, String token, String mobile, AuthConfigInfo authConfigInfo) {

        logger.info("buildVerifyMobileRequestParams, platform:{}, token:{}, mobile:{}", platform, token, mobile);
        AuthConfigInfo.Ctcc ctcc = authConfigInfo.getCtcc();

        CtccVerifyMobileRequest ctccVerifyMobileRequest = new CtccVerifyMobileRequest();
        ctccVerifyMobileRequest.setAppId(ctcc.getAppId());
        ctccVerifyMobileRequest.setTimeStamp(System.currentTimeMillis());
        ctccVerifyMobileRequest.setFormat("json");
        String xxTeaContent = "accessCode=" + token + "&mobile=" + mobile;
        try {
            ctccVerifyMobileRequest.setParams(XxTea.encryptStr(xxTeaContent, StandardCharsets.UTF_8.name(), ctcc.getAppSecret()));
        } catch (Exception e) {
            logger.warn("buildVerifyMobileRequestParams XXTea error, platform:{}, token:{}, mobile:{}, xxTeaContent:{}", platform, token, mobile, xxTeaContent, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.XXTEA_PARAMS_ERROR);
        }

        logger.debug("buildVerifyMobileRequestParams, ctccVerifyMobileRequest:{}", ctccVerifyMobileRequest);
        return ctccVerifyMobileRequest;
    }

    @Override
    protected Object fillVerifyMobileRequestSign(Object requestParams, AuthConfigInfo authConfigInfo) {

        logger.info("fillVerifyMobileRequestSign, requestParams:{}", requestParams);
        AuthConfigInfo.Ctcc ctcc = authConfigInfo.getCtcc();


        CtccVerifyMobileRequest ctccVerifyMobileRequest = (CtccVerifyMobileRequest) requestParams;
        String signContent = ctccVerifyMobileRequest.getAppId() + ctccVerifyMobileRequest.getFormat() + ctccVerifyMobileRequest.getParams() + ctccVerifyMobileRequest.getTimeStamp();
        String sign;
        try {
            sign = Rsa.signHex(signContent, ctcc.getPrivateKey(), SignAlgorithm.SHA1withRSA);
        } catch (Exception e) {
            logger.warn("fillVerifyMobileRequestSign RSA error, ctccVerifyMobileRequest:{}, signContent:{}", ctccVerifyMobileRequest, signContent, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.RSA_SIGN_ERROR);
        }
        ctccVerifyMobileRequest.setSign(sign);

        logger.debug("fillVerifyMobileRequestSign, ctccVerifyMobileRequest:{}", ctccVerifyMobileRequest);
        return ctccVerifyMobileRequest;
    }

    @Override
    protected String requestVerifyMobileServer(Object requestParams, AuthConfigInfo authConfigInfo) {

        logger.info("requestVerifyMobileServer, requestParams:{}", requestParams);
        CtccVerifyMobileRequest ctccVerifyMobileRequest = (CtccVerifyMobileRequest) requestParams;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        httpClientUtil.httpPost(CTCC_VERIFY_MOBILE_URL, ctccVerifyMobileRequest.toString(), byteArrayOutputStream, CTCC_CONTENT_TYPE, StandardCharsets.UTF_8.name());

        return byteArrayOutputStream.toString();
    }

    @Override
    protected Boolean parseVerifyResult(String response, AuthConfigInfo authConfigInfo, BalanceUnitPrice balanceUnitPrice, Integer uid, Channel channel) {

        logger.info("parseVerifyResult, response:{}", response);
        AuthConfigInfo.Ctcc ctcc = authConfigInfo.getCtcc();

        CtccGetMobileResponse ctccGetMobileResponse = JsonConverter.parse(response, CtccGetMobileResponse.class);
        if (!CtccResponseCode.SUCCESS.equals(CtccResponseCode.get(ctccGetMobileResponse.getResult()))) {
            accountBalanceService.refund(uid, BizType.NUMBER_VERIFY, balanceUnitPrice, channel, 1);
            checkResponseCode(ctccGetMobileResponse.getResult());
        }
        String dataDecrypt;
        try {
            dataDecrypt = Rsa.decryptHex(ctccGetMobileResponse.getData(), ctcc.getPrivateKey());
        } catch (Exception e) {
            logger.warn("parseVerifyResult rsa error, ctccGetMobileResponse:{}", ctccGetMobileResponse, e);
            throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.RSA_DECRYPT_ERROR);
        }
        CtccVerifyMobileResponse.Data verifyData = JsonConverter.parse(dataDecrypt, CtccVerifyMobileResponse.Data.class);
        Integer verifyResult = verifyData.getIsVerify();

        return verifyResult == 0;
    }

    @Override
    protected void checkResponseCode(String responseCode) {

        logger.info("checkResponseCode, responseCode:{}", responseCode);

        switch (CtccResponseCode.get(responseCode)) {
            case SUCCESS:
                break;
            case SIGN_INVALID:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.SIGN_ERROR);
            case TIME_EXPIRES:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.TOKEN_ERROR);
            case APP_NOT_EXIST:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.APP_ID_ERROR);
            case PARAMS_EMPTY:
            case PARAM_ERROR:
            case ILLEGAL_TIMESTAMP:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.PARAM_ERROR);
            case PERMISSION_DENIED:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.PERMISSION_DENIED);
            case DECRYPT_FAIL:
            case PARSE_ENCRYPT_PARAMS_FAIL:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.ENCRYPT_ERROR);
            case IP_LIMIT:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.IP_WHITELIST_ERROR);
            case GET_PHONE_NUM_FAIL:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.GET_MOBILE_FAILED);
            case INTERFACE_OVERRUN:
            case OVER_THRESHOLD:
                throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.NO_QUOTAS);
                default:
                    throw new PhoneNumVerificationException(PhoneNumVerificationErrorCode.OTHER_ERROR);
        }
    }

    public static void main(String[] args) {
        String token = "nm232c8f1452a142b396e4431dcf6e9f77";
        String authCode = "33828605652e8c623b8e1ddd70c7f249f7ea07d32ba8b674ed610e8e9e1d03cf";
        String mobile = "13366569790";
        CtccValidateHandler ctccValidateHandler = new CtccValidateHandler();
        HttpClientUtil httpClientUtil = new HttpClientUtil();
        ctccValidateHandler.setHttpClientUtil(httpClientUtil);
//        Long result = ctccValidateHandler.getLoginPhoneNum(null, null, token, authCode);
        Boolean result = ctccValidateHandler.verifyLoginPhoneNum(null, null, token, Long.valueOf(mobile),0);

        System.out.println(result);
    }
}
