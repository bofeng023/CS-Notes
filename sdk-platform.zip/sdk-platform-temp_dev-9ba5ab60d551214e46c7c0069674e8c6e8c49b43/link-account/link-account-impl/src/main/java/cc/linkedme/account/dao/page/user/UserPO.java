package cc.linkedme.account.dao.page.user;

import lombok.Data;

import java.util.Date;

@Data
public class UserPO {
    private Integer id;

    private String email;

    private String pwd;

    private String name;

    private String phoneNumber;

    private String qqNumber;

    private String company;

    private Byte roleId;

    private Date registerTime;

    private Date lastLoginTime;

    private Byte validStatus;

    private String token;

    private String randomCode;

    private Integer pid;

    private String note;

    private Byte activeStatus;

    private Date activeTime;

    private Integer linkActiveAuth;

    private Integer dspAuth;

    private Integer sspAuth;

    private Byte identity;

    private Byte auditState;

    private String authenticationName;

    private String authenticationEmail;

    private String authenticationPhone;

    private String identityCardNumber;

    private String identityCardFront;

    private String identityCardBack;

    private String identityCardHand;

    private String unifiedBusinessCode;

    private String companyLicense;

    private Date authInitialTime;

    private Date authSubmitTime;

}