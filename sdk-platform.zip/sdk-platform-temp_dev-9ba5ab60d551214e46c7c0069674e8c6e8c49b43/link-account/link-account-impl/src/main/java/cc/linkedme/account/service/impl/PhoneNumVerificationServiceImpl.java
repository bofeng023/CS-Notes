package cc.linkedme.account.service.impl;

import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.enums.Platform;
import cc.linkedme.account.exception.PhoneNumVerificationException;
import cc.linkedme.account.model.AppInfo;
import cc.linkedme.account.model.AuthConfigInfo;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.service.AccountBalanceService;
import cc.linkedme.account.service.AuthConfigService;
import cc.linkedme.account.service.PhoneNumVerificationService;
import cc.linkedme.account.service.UserService;
import cc.linkedme.account.common.http.HttpClientUtil;
import cc.linkedme.enums.BizType;

import javax.annotation.Resource;

/**
 * @author yangpeng
 * @date 2019-06-10 18:27
 * @description
 **/
public abstract class PhoneNumVerificationServiceImpl implements PhoneNumVerificationService {

    @Resource
    private AuthConfigService authConfigService;
    @Resource
    protected HttpClientUtil httpClientUtil;
    @Resource
    protected AccountBalanceService accountBalanceService;
    @Resource
    private UserService userService;

    public void setHttpClientUtil(HttpClientUtil httpClientUtil) {
        this.httpClientUtil = httpClientUtil;
    }

    @Override
    public Long getLoginPhoneNum(Channel channel, Platform platform, String token, String authCode, Integer appId) throws PhoneNumVerificationException {

        AuthConfigInfo authConfigInfo = getAuthConfigInfo(channel, appId);

        Object requestParams = buildGetMobileRequestParams(platform, token, authCode, authConfigInfo);

        fillGetMobileRequestSign(requestParams, authConfigInfo);

        AppInfo appInfo = userService.getAppInfo(appId);
        Integer pid = appInfo.getPid();
        Integer uid = pid == -1 ? appInfo.getUid() : pid;
        BalanceUnitPrice balanceUnitPrice = accountBalanceService.consume(uid, BizType.QUICK_LOGIN, channel, 1);

        httpClientUtil.setProxy("192.168.251.73", 443);
        String volidateResponse = requestGetMobileServer(requestParams);

        Long mobile = parseMobile(volidateResponse, authConfigInfo, balanceUnitPrice, uid, channel);

        return mobile;
    }

    private AuthConfigInfo getAuthConfigInfo(Channel channel, Integer appId) {

        AuthConfigInfo authConfigInfo;
        if (Channel.MOBILE.equals(channel) || Channel.TELECOM.equals(channel)) {
            authConfigInfo = authConfigService.getAuthConfig(appId);
        } else {
            authConfigInfo = authConfigService.getCuccAuthConfig(appId);
        }

        return authConfigInfo;
    }

    protected abstract Object buildGetMobileRequestParams(Platform platform, String token, String authCode, AuthConfigInfo authConfigInfo);

    protected abstract Object fillGetMobileRequestSign(Object requestParams, AuthConfigInfo authConfigInfo);

    protected abstract String requestGetMobileServer(Object requestParams);

    protected abstract Long parseMobile(String response, AuthConfigInfo authConfigInfo, BalanceUnitPrice balanceUnitPrice, Integer uid, Channel channel);

    @Override
    public Boolean verifyLoginPhoneNum(Channel channel, Platform platform, String token, Long phoneNum, Integer appId) throws PhoneNumVerificationException {

        AuthConfigInfo authConfigInfo = getAuthConfigInfo(channel, appId);

        Object requestParams = buildVerifyMobileRequestParams(platform, token, String.valueOf(phoneNum), authConfigInfo);

        fillVerifyMobileRequestSign(requestParams, authConfigInfo);

        AppInfo appInfo = userService.getAppInfo(appId);
        Integer pid = appInfo.getPid();
        Integer uid = pid == -1 ? appInfo.getUid() : pid;
        BalanceUnitPrice balanceUnitPrice = accountBalanceService.consume(uid, BizType.NUMBER_VERIFY, channel, 1);

        httpClientUtil.setProxy("192.168.251.73", 443);

        String verifyRespons = requestVerifyMobileServer(requestParams, authConfigInfo);

        Boolean verifyResult = parseVerifyResult(verifyRespons, authConfigInfo, balanceUnitPrice, uid, channel);

        return verifyResult;
    }

    protected abstract Object buildVerifyMobileRequestParams(Platform platform, String token, String mobile, AuthConfigInfo authConfigInfo);

    protected abstract Object fillVerifyMobileRequestSign(Object requestParams, AuthConfigInfo authConfigInfo);

    protected abstract String requestVerifyMobileServer(Object requestParams, AuthConfigInfo authConfigInfo);

    protected abstract Boolean parseVerifyResult(String response, AuthConfigInfo authConfigInfo, BalanceUnitPrice balanceUnitPrice, Integer uid, Channel channel);

    protected abstract void checkResponseCode(String responseCode);

}
