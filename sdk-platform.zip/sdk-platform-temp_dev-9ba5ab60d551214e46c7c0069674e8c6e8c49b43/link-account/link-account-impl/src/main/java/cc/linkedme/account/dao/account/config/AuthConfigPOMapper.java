package cc.linkedme.account.dao.account.config;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AuthConfigPOMapper {
    long countByExample(AuthConfigPOExample example);

    int deleteByExample(AuthConfigPOExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuthConfigPO record);

    int insertSelective(AuthConfigPO record);

    List<AuthConfigPO> selectByExample(AuthConfigPOExample example);

    AuthConfigPO selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuthConfigPO record, @Param("example") AuthConfigPOExample example);

    int updateByExample(@Param("record") AuthConfigPO record, @Param("example") AuthConfigPOExample example);

    int updateByPrimaryKeySelective(AuthConfigPO record);

    int updateByPrimaryKey(AuthConfigPO record);
}