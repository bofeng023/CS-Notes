package cc.linkedme.account.dao.account.sms.frequency;

import lombok.Data;

import java.util.Date;

@Data
public class SmsFrequencyPO {
    private Integer id;

    private Integer uid;

    private Integer appId;

    private Byte countPerMinute;

    private Byte countPerHour;

    private Byte countPerDay;

    private Date gmtCreate;

    private Date gmtUpdate;

}