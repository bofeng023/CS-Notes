package cc.linkedme.account.converter;

import cc.linkedme.account.dao.account.sms.sign.SmsSignPO;
import cc.linkedme.account.model.sms.SmsSignInfo;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 15:45
 * @description
 **/
public class SmsSignPoConverter {

    public static SmsSignPO bo2Po(SmsSignInfo smsSignInfo) {

        SmsSignPO smsSignPO = new SmsSignPO();
        BeanUtils.copyProperties(smsSignInfo, smsSignPO);
        smsSignPO.setIsGlobal(smsSignInfo.getIsGlobal() == null ? null : smsSignInfo.getIsGlobal().getIndex());
        smsSignPO.setCertificationState(smsSignInfo.getCertificationState() == null ? null : smsSignInfo.getCertificationState().getType().byteValue());

        return smsSignPO;
    }

    public static SmsSignInfo po2Bo(SmsSignPO smsSignPO) {

        SmsSignInfo smsSignInfo = new SmsSignInfo();
        BeanUtils.copyProperties(smsSignPO, smsSignInfo);
        smsSignInfo.setIsGlobal(smsSignPO.getIsGlobal() == null ? null : YesNoEnum.get(smsSignPO.getIsGlobal()));
        smsSignInfo.setCertificationState(smsSignPO.getCertificationState() == null ? null : AuditState.get(smsSignPO.getCertificationState().intValue()));

        return smsSignInfo;
    }
}
