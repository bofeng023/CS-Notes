package cc.linkedme.account.consumer;

import cc.linkedme.account.model.sms.SmsCallbackInfo;
import cc.linkedme.account.service.SmsService;
import cc.linkedme.kafka.MqEntity;
import cc.linkedme.kafka.consumer.AbstractKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

/**
 * @author zhanghaowei
 * @date 2019-7-18 10:48
 * @description 异步回调短信状态到用户
 **/
public class SmsCallbackConsumer extends AbstractKafkaConsumer {
    Logger logger = LoggerFactory.getLogger(SmsCallbackConsumer.class);

    @Resource
    private SmsService service;


    @Override
    protected void process(Object mqEntry) {
        logger.info("process, mqEntry:{}", mqEntry);

        MqEntity mqEntity = (MqEntity) mqEntry;
        SmsCallbackInfo smsCallbackInfo = (SmsCallbackInfo)mqEntity.getBody();

        logger.debug("process, mqEntry:{}, smsCallbackInfo:{}", mqEntry, smsCallbackInfo);

        boolean statusCode;
        statusCode = service.sendTextCallback(smsCallbackInfo);

        logger.info("process, mqEntity:{}, statusCode:{}", mqEntity, statusCode);
    }
}
