package cc.linkedme.account.dao.account.top.up;

import lombok.Data;

import java.util.Date;

@Data
public class TopUpPO {
    private Integer id;

    private Integer uid;

    private Integer amount;

    private String receipt;

    private Byte auditState;

    private Date gmtCreate;

    private Date gmtModified;

    private Integer giftAmount;

    private Integer quickLoginOnceAmount;

    private Integer verifyOnceAmount;

    private Integer smsOnceAmount;

    private Integer voiceOnceAmount;

    private Integer globalOnceAmount;

    private Byte consumeState;
}