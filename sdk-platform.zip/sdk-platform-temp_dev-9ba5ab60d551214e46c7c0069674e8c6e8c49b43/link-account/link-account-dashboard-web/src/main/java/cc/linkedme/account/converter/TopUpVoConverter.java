package cc.linkedme.account.converter;

import cc.linkedme.account.enums.RechargeType;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.TopUpInfo;
import cc.linkedme.account.model.request.TopUpRequest;
import cc.linkedme.account.model.response.TopUpResponse;
import cc.linkedme.account.common.util.DigitalUtil;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 17:46
 * @description
 **/
public class TopUpVoConverter {

    public static TopUpResponse bo2Vo(TopUpInfo topUpInfo) {

        return bo2Vo(topUpInfo, null);

    }

    public static TopUpResponse bo2Vo(TopUpInfo topUpInfo, AuditInfo auditInfo) {

        TopUpResponse topUpResponse = new TopUpResponse();
        BeanUtils.copyProperties(topUpInfo, topUpResponse);

        topUpResponse.setAmount(topUpInfo.getAmount() == null ? null : String.valueOf(DigitalUtil.moneyConverToDouble(topUpInfo.getAmount())));
        topUpResponse.setGiftAmount(topUpInfo.getGiftAmount() == null ? null : String.valueOf(DigitalUtil.moneyConverToDouble(topUpInfo.getGiftAmount())));
        topUpResponse.setQuickLoginOnceAmount(topUpInfo.getQuickLoginOnceAmount() == null ? null : String.valueOf(DigitalUtil.moneyConverToDouble(topUpInfo.getQuickLoginOnceAmount())));
        topUpResponse.setVerifyOnceAmount(topUpInfo.getVerifyOnceAmount() == null ? null : String.valueOf(DigitalUtil.moneyConverToDouble(topUpInfo.getVerifyOnceAmount())));
        topUpResponse.setSmsOnceAmount(topUpInfo.getSmsOnceAmount() == null ? null : String.valueOf(DigitalUtil.moneyConverToDouble(topUpInfo.getSmsOnceAmount())));
        topUpResponse.setVoiceOnceAmount(topUpInfo.getVoiceOnceAmount() == null ? null : String.valueOf(DigitalUtil.moneyConverToDouble(topUpInfo.getVoiceOnceAmount())));
        topUpResponse.setGlobalOnceAmount(topUpInfo.getGlobalOnceAmount() == null ? null : String.valueOf(DigitalUtil.moneyConverToDouble(topUpInfo.getGlobalOnceAmount())));

        if (auditInfo != null) {
            topUpResponse.setAuditResponse(AuditVoConverter.bo2Vo(auditInfo));
        }

        return topUpResponse;
    }

    public static TopUpInfo vo2Bo(TopUpRequest topUpRequest) {

        TopUpInfo topUpInfo = new TopUpInfo();
        BeanUtils.copyProperties(topUpRequest, topUpInfo);
        topUpInfo.setAmount(topUpRequest.getAmount() == null ? null : DigitalUtil.moneyConvertToInteger(topUpRequest.getAmount()));
        topUpInfo.setGiftAmount(topUpRequest.getGiftAmount() == null ? null : DigitalUtil.moneyConvertToInteger(topUpRequest.getGiftAmount()));
        topUpInfo.setQuickLoginOnceAmount(topUpRequest.getQuickLoginOnceAmount() == null ? null : DigitalUtil.moneyConvertToInteger(topUpRequest.getQuickLoginOnceAmount()));
        topUpInfo.setSmsOnceAmount(topUpRequest.getSmsOnceAmount() == null ? null : DigitalUtil.moneyConvertToInteger(topUpRequest.getSmsOnceAmount()));
        topUpInfo.setVoiceOnceAmount(topUpRequest.getVoiceOnceAmount() == null ? null : DigitalUtil.moneyConvertToInteger(topUpRequest.getVoiceOnceAmount()));
        topUpInfo.setVerifyOnceAmount(topUpRequest.getVerifyOnceAmount() == null ? null : DigitalUtil.moneyConvertToInteger(topUpRequest.getVerifyOnceAmount()));
        topUpInfo.setGlobalOnceAmount(topUpRequest.getGlobalOnceAmount() == null ? null : DigitalUtil.moneyConvertToInteger(topUpRequest.getGlobalOnceAmount()));
        topUpInfo.setRechargeType(topUpRequest.getRechargeType() == null ? null : RechargeType.get(topUpRequest.getRechargeType()));

        return topUpInfo;

    }

}
