package cc.linkedme.account.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 充值
 * @author zhanghaowei
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class TopUpResponse implements Serializable {

    private Integer id;

    private Integer uid;

    private String amount;

    private String giftAmount;

    private String quickLoginOnceAmount;

    private String verifyOnceAmount;

    private String smsOnceAmount;

    private String voiceOnceAmount;

    private String globalOnceAmount;

    private String receipt;

    private Integer auditState;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date gmtCreate;

    private AuditResponse auditResponse;

}
