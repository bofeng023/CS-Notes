package cc.linkedme.account.model.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: liuyunmeng
 * @Date: Create in 14:08 2019-08-13
 * @:Description
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class UserRequest implements Serializable {

    private Integer uid;

    private String email;

    private Integer auditState;

    private Integer activeStatus;

}
