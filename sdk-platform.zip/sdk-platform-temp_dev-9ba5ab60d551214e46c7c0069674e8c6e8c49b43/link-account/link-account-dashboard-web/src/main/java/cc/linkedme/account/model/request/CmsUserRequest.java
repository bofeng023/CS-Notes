package cc.linkedme.account.model.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;

/**
 * @author zhanghaowei
 * @date 2019-6-6 13:13
 * @description
 **/
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class CmsUserRequest implements Serializable {

    private String email;

    private String password;

    private String goUrl;
}
