package cc.linkedme.account.web;

import cc.linkedme.account.converter.AuthConfigVoConverter;
import cc.linkedme.account.intercepters.RequiredCmsLogin;
import cc.linkedme.account.model.AppInfo;
import cc.linkedme.account.model.AuthConfigInfo;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.request.AuthConfigDashboardRequest;
import cc.linkedme.account.model.request.AuthConfigRequest;
import cc.linkedme.account.model.response.AuthConfigDashboardResponse;
import cc.linkedme.account.model.response.AuthConfigResponse;
import cc.linkedme.account.service.AuthConfigService;
import cc.linkedme.account.service.UserService;
import cc.linkedme.account.validator.Insert;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author zhanghaowei
 * @date 2019-6-15 17:33
 * @description
 **/

@RestController
@RequestMapping("/linkaccount/auth/config/")
public class AuthConfigController extends BaseController{

    @Resource
    private AuthConfigService authConfigService;

    @Resource
    private UserService userService;


    @RequestMapping("get")
    public FrameResp getAuthConfig(@RequestParam("app_id") Integer appId) {
        logger.info("getAuthConfig, appId:{}", appId);

        AuthConfigInfo authConfigInfo = authConfigService.getAuthConfig(appId);
        AuthConfigResponse authConfigResponse = AuthConfigVoConverter.bo2Vo(authConfigInfo);
        logger.info("getAuthConfig, appId:{}, authConfigResponse:{}", appId, authConfigResponse);
        return buildSuccessResp(authConfigResponse);
    }

    @RequestMapping("save")
    @RequiredCmsLogin
    public FrameResp saveAuthConfig(@Validated(value = Insert.class) @RequestBody AuthConfigRequest authConfigRequest) {
        logger.info("saveAuthConfig, authConfigRequest:{}", authConfigRequest);

        Integer appId = authConfigRequest.getAppId();

        AuthConfigInfo oldAuthConfigInfo = authConfigService.getAuthConfig(appId);
        AuthConfigInfo authConfigInfo = AuthConfigVoConverter.vo2Bo(authConfigRequest);

        logger.debug("saveAuthConfig, oldAuthConfigInfo:{}, AuthConfigInfo:{}", oldAuthConfigInfo, authConfigInfo);

        if (oldAuthConfigInfo == null) {

            AppInfo appInfo = userService.getAppInfo(appId);
            String appKey = appInfo.getAppKey();
            authConfigInfo.setAppKey(appKey);
            authConfigInfo.setAppSecret(appInfo.getAppSecret());

            authConfigService.saveAuthConfig(authConfigInfo);
        } else {
            authConfigInfo.setId(oldAuthConfigInfo.getId());
            authConfigService.updateAuthConfig(authConfigInfo);
        }
        return buildSuccessResp();
    }

    @RequestMapping("dashboard/save")
    public FrameResp saveAuthConfigDashboard(@Validated @RequestBody AuthConfigDashboardRequest authConfigDashboardRequest) {
        logger.info("saveAuthConfigDashboard, authConfigDashboardRequest:{}", authConfigDashboardRequest);

        Integer appId = authConfigDashboardRequest.getAppId();

        AuthConfigInfo oldAuthConfigInfo = authConfigService.getAuthConifgInfo(appId, null);
        AuthConfigInfo authConfigInfo = AuthConfigVoConverter.dashboardVo2Bo(authConfigDashboardRequest);
        logger.debug("saveAuthConfigDashboard, oldAuthConfigInfo:{}, AuthConfigInfo:{}", oldAuthConfigInfo, authConfigInfo);

        if (oldAuthConfigInfo == null) {
            authConfigService.saveAuthConfig(authConfigInfo);
        } else {
            authConfigInfo.setId(oldAuthConfigInfo.getId());
            authConfigService.updateAuthConfig(authConfigInfo);
        }
        return buildSuccessResp();
    }


    @RequestMapping("dashboard/get")
    public FrameResp getAuthConfigDashboard(@RequestParam("app_id") Integer appId) {

        logger.info("getAuthConfigDashboard, appId:{}", appId);
        AuthConfigInfo authConfigInfo = authConfigService.getAuthConifgInfo(appId, null);
        AuthConfigDashboardResponse authConfigDashboardResponse = AuthConfigVoConverter.bo2DashboardVo(authConfigInfo);

        logger.info("getAuthConfigDashboard, appId:{}, authConfigDashboardResponse:{}", appId, authConfigDashboardResponse);
        return buildSuccessResp(authConfigDashboardResponse);
    }

}