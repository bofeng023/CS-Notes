package cc.linkedme.account.web;

import cc.linkedme.account.converter.SignVoConverter;
import cc.linkedme.account.errorcode.SmsSignErrorCode;
import cc.linkedme.account.exception.SmsSignException;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.SearchRequest;
import cc.linkedme.account.model.request.SmsSignRequest;
import cc.linkedme.account.model.response.SmsSignResponse;
import cc.linkedme.account.model.sms.SmsSignInfo;
import cc.linkedme.account.service.AuditInfoSerivce;
import cc.linkedme.account.service.SmsSignService;
import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/linkaccount/sms/sign/")
public class SmsSignController extends BaseController {

    private static final Logger logger = LoggerFactory.getLogger(SmsSignController.class);
    @Resource
    private SmsSignService smsSignService;
    @Resource
    private AuditInfoSerivce auditInfoSerivce;

    @RequestMapping("save")
    @ResponseBody
    public FrameResp saveSmsSign(@Validated(value=Insert.class) @RequestBody SmsSignRequest smsSignRequest) throws BusinessException {

        logger.info("saveSmsSign, smsSignRequest:{}", smsSignRequest);

//        if (YesNoEnum.YES.equals(YesNoEnum.get(smsSignRequest.getIsGlobal().byteValue()))) {
//            Preconditions.checkNotNull(smsSignRequest.getPowerAttorney(), new SmsSignException(SmsSignErrorCode.POWER_ATTORNEY_NULL_ERROR));
//        }

        Preconditions.checkNotNull(smsSignRequest.getPowerAttorney(), new SmsSignException(SmsSignErrorCode.POWER_ATTORNEY_NULL_ERROR));


        SmsSignInfo smsSignInfo = SignVoConverter.vo2Bo(smsSignRequest);
        smsSignInfo = smsSignService.saveSmsSign(smsSignInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setUid(smsSignInfo.getUid());
        auditInfo.setBizType(BizType.SIGN);
        auditInfo.setBizId(smsSignInfo.getId());
        auditInfo.setAuditState(AuditState.TO_BE_AUDITED);

        auditInfoSerivce.saveAudit(auditInfo);
        SmsSignResponse smsSignResponse = SignVoConverter.bo2Vo(smsSignInfo, auditInfo);
        logger.info("saveSmsSign, smsSignRequest:{}, smsSignResponse:{}", smsSignRequest, smsSignResponse);

        return buildSuccessResp(smsSignResponse);

    }

    @RequestMapping("update")
    @ResponseBody
    public FrameResp updateSmsSign(@Validated(value=Update.class) @RequestBody SmsSignRequest smsSignRequest) throws BusinessException {

        logger.info("updateSmsSign, smsSignRequest:{}", smsSignRequest);

        SmsSignInfo smsSignInfo = SignVoConverter.vo2Bo(smsSignRequest);
        Preconditions.checkNotNull(smsSignInfo.getPowerAttorney(), new SmsSignException(SmsSignErrorCode.POWER_ATTORNEY_NULL_ERROR));

        smsSignService.updateSmsSign(smsSignInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setAuditState(AuditState.TO_BE_AUDITED);
        auditInfo.setBizId(smsSignInfo.getId());
        auditInfo.setBizType(BizType.SIGN);
        auditInfoSerivce.updateAuditByBizId(auditInfo);

        return buildSuccessResp();
    }

    @RequestMapping("remove")
    @ResponseBody
    public FrameResp removeSmsSign(Integer id) throws BusinessException {

        logger.info("removeSmsSign, id:{}", id);
        Preconditions.checkNotNull(id, new SmsSignException(SmsSignErrorCode.ID_NULL_ERROR));

        smsSignService.removeSmsSign(id);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setAuditState(AuditState.CANCEL);
        auditInfo.setBizId(id);
        auditInfo.setBizType(BizType.SIGN);
        auditInfoSerivce.updateAuditByBizId(auditInfo);

        return buildSuccessResp();
    }

    @RequestMapping("get")
    @ResponseBody
    public FrameResp getSmsSign(Integer id) throws BusinessException {

        logger.info("getSmsSign, id:{}", id);
        Preconditions.checkNotNull(id, new SmsSignException(SmsSignErrorCode.ID_NULL_ERROR));

        SmsSignInfo smsSignInfo = smsSignService.getSmsSign(id);
        if (smsSignInfo == null) {
            return buildSuccessResp();
        }

        AuditInfo auditInfo = auditInfoSerivce.getAuditByBizId(id, BizType.SIGN);
        SmsSignResponse smsSignResponse = SignVoConverter.bo2Vo(smsSignInfo, auditInfo);
        logger.info("getSmsSign, id:{}, smsSignResponse:{}", id, smsSignResponse);

        return buildSuccessResp(smsSignResponse);
    }

    @RequestMapping("list")
    @ResponseBody
    public FrameResp listSmsSign(@RequestBody SearchRequest searchRequest) throws BusinessException {

        logger.info("listSmsSign, searchRequest:{}", searchRequest);
        Integer uid  = searchRequest.getUid();
        Preconditions.checkNotNull(uid, new SmsSignException(SmsSignErrorCode.UID_NULL_ERROR));
        SearchParam searchParam = new SearchParam();
        BeanUtils.copyProperties(searchRequest, searchParam);

        List<SmsSignInfo> smsSignInfoList = smsSignService.listSmsSign(uid, searchParam);

        List<SmsSignResponse> smsSignResponseList = new ArrayList<>();

        if (CollectionUtils.isEmpty(smsSignInfoList)) {
            return buildSuccessResp();
        }

        List<Integer> signIdList = new ArrayList<>();
        smsSignInfoList.forEach(smsSignInfo -> signIdList.add(smsSignInfo.getId()));
        Map<Integer, AuditInfo> auditInfoBOMap = auditInfoSerivce.batchGetAuditByBizId(signIdList,BizType.SIGN);

        smsSignInfoList.forEach(smsSignInfo -> smsSignResponseList.add(SignVoConverter.bo2Vo(smsSignInfo, auditInfoBOMap.get(smsSignInfo.getId()))));

        logger.debug("listSmsSign, uid:{}, searchRequest:{}, smsSignResponseList:{}", uid, searchRequest, smsSignResponseList);
        return buildSuccessResp(smsSignResponseList);
    }

    @RequestMapping("count")
    @ResponseBody
    public FrameResp countSmsSign(Integer uid) throws BusinessException {

        logger.info("countSmsSign, uid:{}", uid);

        Long smsSignCount = smsSignService.countSmsSign(uid,null);

        return buildSuccessResp(smsSignCount);

    }

    @RequestMapping("global")
    @ResponseBody
    public FrameResp countAuditPassGlobal(Integer uid) throws BusinessException {

        logger.info("countAuditPassGlobal, uid:{}", uid);

        Long smsSignCount = smsSignService.countAuditPassGlobal(uid);

        return buildSuccessResp(smsSignCount);

    }
}
