package cc.linkedme.account.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

/**
 * 发票
 * @author zhanghaowei
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class InvoiceResponse implements Serializable {

    private Integer id;

    private Integer uid;

    private Byte invoiceType;

    private String invoiceTitle;

    private String taxpayerIdentification;

    private String contactInfo;

    private String bankAccountInfo;

    private String invoiceItem;

    private String invoiceAmount;

    private String recipientName;

    private String recipientAddress;

    private String recipientPhone;

    private String expressCompany;

    private String trackingNumber;

    private Date sendOutTime;

    private String trackingRemark;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date gmtCreate;

    private AuditResponse auditResponse;

}
