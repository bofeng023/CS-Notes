package cc.linkedme.account.model.request;

import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
/*@ScriptAssert.List(value = {
        @ScriptAssert(lang = "javascript" ,script = "_this.topUpValid(_this.auditState)", message = "充值审核参数有误", groups = Update.class )
})*/
public class AuditInfoRequest implements Serializable {

    @NotNull(message = "ID不能为空", groups = {Update.class})
    private Integer id;

    private Integer uid;

    private Integer appId;

    @NotNull(message = "实体ID不能为空", groups = {Insert.class, Update.class})
    private Integer bizId;

    @NotNull(message = "实体类型不能为空", groups = {Insert.class, Update.class})
    private Integer bizType;

    private String auditor;

    private String auditRemark;

    @NotNull(message = "审核状态不能为空", groups = {Insert.class, Update.class})
    private Integer auditState;

    /**
     * 审核密码
     */
    @Transient
    private String auditPassword;

    private String productIdentity;

    private String expressCompany;

    private String trackingNumber;

    /*public boolean topUpAuditValid(Integer auditState) {
        if (AuditState.SEND_OUT.equals(AuditState.get(auditState))) {
            if (StringUtils.isEmpty(expressCompany) || StringUtils.isEmpty(trackingNumber)) {
                return false;
            }
        }
        return true;
    }*/
}
