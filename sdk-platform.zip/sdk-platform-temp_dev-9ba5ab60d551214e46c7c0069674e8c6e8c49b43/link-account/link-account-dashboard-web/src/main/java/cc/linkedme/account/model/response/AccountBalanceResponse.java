package cc.linkedme.account.model.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;

/**
 * 账户余额
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class AccountBalanceResponse implements Serializable {

    private Integer uid;

    private Double balance;

    private Double todayConsume;
}
