package cc.linkedme.account.model.request;

import cc.linkedme.account.validator.Update;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author yangpeng
 * @date 2019-05-28 18:28
 * @description
 **/
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class SmsFrequencyRequest implements Serializable {

    @NotNull(message="ID不能为空", groups = {Update.class})
    private Integer id;

    private Integer appId;

    private Byte countPerMinute;

    private Byte countPerHour;

    private Byte countPerDay;
}
