package cc.linkedme.account.model.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class SmsTextTemplateRequest implements Serializable {

    private Integer id;

    private Integer uid;

    private Integer appId;

    private String templateName;

    private Integer isGlobal;

    private String content;

    private Integer certificationState;

    private String applyRemark;
}
