package cc.linkedme.account.converter;

import cc.linkedme.account.enums.InvoiceType;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.InvoiceInfo;
import cc.linkedme.account.model.request.InvoiceInfoRequest;
import cc.linkedme.account.model.response.InvoiceResponse;
import cc.linkedme.account.common.util.DigitalUtil;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 20:43
 * @description
 **/
public class InvoiceVoConverter {

    private final static String INVOICE_ITEM = "信息服务费";

    public static InvoiceResponse bo2Vo(InvoiceInfo invoiceInfo) {

        return bo2Vo(invoiceInfo, null);
    }

    public static InvoiceResponse bo2Vo(InvoiceInfo invoiceInfo, AuditInfo auditInfo) {

        InvoiceResponse invoiceResponse = new InvoiceResponse();
        BeanUtils.copyProperties(invoiceInfo, invoiceResponse);
        invoiceResponse.setInvoiceAmount(invoiceInfo.getInvoiceAmount() == null ? null : String.valueOf(DigitalUtil.moneyConverToDouble(invoiceInfo.getInvoiceAmount())));
        invoiceResponse.setInvoiceType(invoiceInfo.getInvoiceType() == null ? null : invoiceInfo.getInvoiceType().getCode().byteValue());

        if (auditInfo != null) {
            invoiceResponse.setAuditResponse(AuditVoConverter.bo2Vo(auditInfo));
        }

        return invoiceResponse;
    }

    public static InvoiceInfo vo2Bo(InvoiceInfoRequest invoiceInfoRequest) {

        InvoiceInfo invoiceInfo = new InvoiceInfo();
        BeanUtils.copyProperties(invoiceInfoRequest, invoiceInfo);
        invoiceInfo.setInvoiceItem(INVOICE_ITEM);
        invoiceInfo.setInvoiceAmount(invoiceInfoRequest.getInvoiceAmount() == null ? null : DigitalUtil.moneyConvertToLong(invoiceInfoRequest.getInvoiceAmount()));
        invoiceInfo.setInvoiceType(invoiceInfoRequest.getInvoiceType() == null ? null : InvoiceType.get(invoiceInfoRequest.getInvoiceType()));

        return invoiceInfo;
    }
}
