package cc.linkedme.account.validator;

public interface Update {
}
