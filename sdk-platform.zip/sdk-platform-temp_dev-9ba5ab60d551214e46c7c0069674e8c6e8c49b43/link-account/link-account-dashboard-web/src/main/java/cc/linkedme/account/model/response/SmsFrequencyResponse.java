package cc.linkedme.account.model.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-05-28 18:25
 * @description
 **/
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class SmsFrequencyResponse {

    private Integer id;

    private Integer uid;

    private Integer appId;

    private Byte countPerMinute;

    private Byte countPerHour;

    private Byte countPerDay;

}
