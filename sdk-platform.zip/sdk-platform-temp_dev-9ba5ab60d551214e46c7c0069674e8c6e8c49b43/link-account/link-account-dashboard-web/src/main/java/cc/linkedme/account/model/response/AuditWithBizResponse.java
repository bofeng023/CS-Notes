package cc.linkedme.account.model.response;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yangpeng
 * @date 2019-05-31 15:03
 * @description
 **/
@Data
public class AuditWithBizResponse implements Serializable {

    private AuditResponse auditResponse;

    private UserResponse userInfoResponse;

    private TopUpResponse topUpResponse;

    private InvoiceResponse invoiceInfoResponse;

    private SmsSignResponse smsSignResponse;

    private SmsTextTemplateResponse smsTextTemplateResponse;

}
