package cc.linkedme.account.converter;

import cc.linkedme.account.model.sms.SmsFrequencyInfo;
import cc.linkedme.account.model.request.SmsFrequencyRequest;
import cc.linkedme.account.model.response.SmsFrequencyResponse;
import org.springframework.beans.BeanUtils;

/**
 * @author zhanghaowei
 * @date 2019-6-25 17:12
 * @description
 **/
public class SmsFrequencyVoConverter {


    public static SmsFrequencyInfo vo2Bo(SmsFrequencyRequest smsFrequencyRequest) {

        SmsFrequencyInfo smsFrequencyInfo = new SmsFrequencyInfo();
        BeanUtils.copyProperties(smsFrequencyRequest, smsFrequencyInfo);

        smsFrequencyInfo.setCountPerDay(smsFrequencyRequest.getCountPerDay() != null ? smsFrequencyRequest.getCountPerDay().intValue() : null);
        smsFrequencyInfo.setCountPerHour(smsFrequencyRequest.getCountPerHour() != null ? smsFrequencyRequest.getCountPerHour().intValue() : null);
        smsFrequencyInfo.setCountPerMinute(smsFrequencyRequest.getCountPerMinute() != null ? smsFrequencyRequest.getCountPerMinute().intValue() : null);

        return smsFrequencyInfo;
    }

    public static SmsFrequencyResponse bo2Vo(SmsFrequencyInfo smsFrequencyInfo) {

        SmsFrequencyResponse smsFrequencyResponse = new SmsFrequencyResponse();
        BeanUtils.copyProperties(smsFrequencyInfo, smsFrequencyResponse);

        smsFrequencyResponse.setCountPerDay(smsFrequencyInfo.getCountPerDay() != null ? smsFrequencyInfo.getCountPerDay().byteValue() : null);
        smsFrequencyResponse.setCountPerHour(smsFrequencyInfo.getCountPerHour() != null ? smsFrequencyInfo.getCountPerHour().byteValue() : null);
        smsFrequencyResponse.setCountPerMinute(smsFrequencyInfo.getCountPerMinute() != null ? smsFrequencyInfo.getCountPerMinute().byteValue() : null);

        return smsFrequencyResponse;
    }
}
