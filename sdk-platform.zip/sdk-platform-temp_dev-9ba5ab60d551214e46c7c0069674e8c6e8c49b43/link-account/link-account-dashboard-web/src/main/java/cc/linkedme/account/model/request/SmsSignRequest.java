package cc.linkedme.account.model.request;

import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class SmsSignRequest implements Serializable {

    @NotNull(message="ID不能为空", groups = {Update.class})
    private Integer id;

    @NotNull(message="uid不能为空", groups = {Update.class,Insert.class})
    private Integer uid;

    private Integer appId;

    @NotNull(message="签名名称不能为空", groups = Insert.class)
    private String signName;

    @NotNull(message="签名使用区域不能为空", groups = Insert.class)
    private Integer isGlobal;

    private String powerAttorney;

    private Integer certificationState;

    private String applyRemark;

}