package cc.linkedme.account.web;

import cc.linkedme.account.converter.MessageVoConverter;
import cc.linkedme.account.enums.MessageType;
import cc.linkedme.account.errorcode.MessageErrorCode;
import cc.linkedme.account.exception.MessageException;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.MessageInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.SearchRequest;
import cc.linkedme.account.model.request.MessageRequest;
import cc.linkedme.account.model.response.MessageResponse;
import cc.linkedme.account.service.MessageService;
import cc.linkedme.account.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: liuyunmeng
 * @Date: Create in 16:25 2019-08-13
 * @:Description 发送站内信
 */
@RestController
@RequestMapping("linkaccount/message")
public class MessageController extends BaseController {

    Logger logger = LoggerFactory.getLogger(MessageController.class);

    @Resource
    private MessageService messageService;

    @Resource
    private UserService userService;

    @RequestMapping("send")
    public FrameResp sendMsg(@RequestBody MessageRequest messageRequest) {

        logger.info("sendMessage start, messageRequest:{}", messageRequest);
        if (messageRequest == null) {
            throw new MessageException(MessageErrorCode.PARAM_NULL_ERROR);
        }
        if (messageRequest.getSenderId() == null || userService.getUserInfo(messageRequest.getSenderId()) == null){
            throw new MessageException(MessageErrorCode.INVALID_SENDER_ID);
        }
        if (messageRequest.getReceiverId() < 0 || ((messageRequest.getReceiverId() != 0) && userService.getUserInfo(messageRequest.getReceiverId()) == null)) {
            throw new MessageException(MessageErrorCode.INVALID_RECEIVER_ID);
        }
        if (messageRequest.getCategory() < MessageType.SYSTEM_MSG.getType() && messageRequest.getCategory() > MessageType.FEEDBACK_MSG.getType()) {
            throw new MessageException(MessageErrorCode.INVALID_TYPE);
        }

        messageService.sendMsg(MessageVoConverter.vo2Bo(messageRequest));

        return buildSuccessResp();
    }

    @RequestMapping("get")
    public FrameResp getMsg(@RequestParam Long messageId, @RequestParam Integer uid) {

        logger.info("getMessage start, messageId:{}, uid:{}", messageId, uid);

        if (uid == null || userService.getUserInfo(uid) == null) {
            throw new MessageException(MessageErrorCode.INVALID_RECEIVER_ID);
        }
        if (messageId == null || messageId < 0 ) {
            throw new MessageException(MessageErrorCode.INVALID_MESSAGE_ID);
        }

        MessageInfo messageInfo = messageService.getMsg(messageId, uid);

        MessageResponse messageResponse = MessageVoConverter.bo2Vo(messageInfo);

        logger.info("getMessage end, messageId:{}, uid:{}, messageInfo:{}, messageResponse:{}", messageId, uid, messageInfo, messageResponse);
        return buildSuccessResp(messageResponse);
    }

    @RequestMapping("list")
    public FrameResp getMessageList(@RequestBody SearchRequest searchRequest, @RequestParam Integer messageType, @RequestParam Integer readStatus) {

        logger.info("getMessageList start, searchRequest:{}", searchRequest);

        if (userService.getUserInfo(searchRequest.getUid()) == null) {
            throw new MessageException(MessageErrorCode.INVALID_SENDER_ID);
        }

        if (MessageType.get(messageType) == null ) {
            throw new MessageException(MessageErrorCode.INVALID_TYPE);
        }

        if (readStatus < 0 || readStatus > 2) {
            throw new MessageException(MessageErrorCode.INVALID_READ_STATUS);
        }

        SearchParam searchParam = new SearchParam();
        BeanUtils.copyProperties(searchRequest, searchParam);

        List<MessageInfo> messageInfos  = messageService.getMsgList(searchParam, messageType, readStatus);
        List<MessageResponse> messageResponseList = messageInfos.stream().map(messageInfo -> MessageVoConverter.bo2Vo(messageInfo)).collect(Collectors.toList());

        logger.debug("getMessageList end, searchRequest:{}, messageResponseList", searchRequest, messageResponseList);
        return buildSuccessResp(messageResponseList);
    }

    @RequestMapping("delete")
    public FrameResp deleteMessage(@RequestParam Long messageId, @RequestParam Integer uid) {

        logger.info("deleteMessage start, messageId:{}, uid:{}", messageId, uid);

        if (uid == null || userService.getUserInfo(uid) == null) {
            throw new MessageException(MessageErrorCode.INVALID_RECEIVER_ID);
        }
        if (messageId == null || messageId < 0 ) {
            throw new MessageException(MessageErrorCode.INVALID_MESSAGE_ID);
        }

        messageService.deleteMsg(messageId, uid);

        return buildSuccessResp();
    }

    @RequestMapping("change")
    public FrameResp changeReadStatus(@RequestParam Long messageId, @RequestParam Integer uid) {

        logger.info("read start, messageId:{}, uid:{}", messageId, uid);

        if (uid == null || userService.getUserInfo(uid) == null) {
            throw new MessageException(MessageErrorCode.INVALID_RECEIVER_ID);
        }
        if (messageId == null || messageId < 0 ) {
            throw new MessageException(MessageErrorCode.INVALID_MESSAGE_ID);
        }

        messageService.changeReadStatus(messageId, uid);

        return buildSuccessResp();
    }
}
