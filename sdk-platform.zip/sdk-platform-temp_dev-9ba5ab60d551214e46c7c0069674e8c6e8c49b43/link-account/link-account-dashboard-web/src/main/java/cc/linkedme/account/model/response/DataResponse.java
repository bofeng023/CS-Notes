package cc.linkedme.account.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.util.List;

/**
 * 数据response
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class DataResponse {

    private Integer[] quickLoginCount;

    private Integer[] verifyCount;

    private Integer[] smsCount;

    private Integer[] voiceCount;

    private Double[] totalAmount;

    private Integer[] requestCount;

    /**
     * 统计指标项列表
     */
    @JsonProperty("consume_count_list")
    private List<ConsumeCountResponse> consumeCountResponseList;


    /**
     * 账户余额
     */
    @JsonProperty("account_balance")
    private AccountBalanceResponse accountBalanceResponse;


    /**
     * 汇总
     */
    @JsonProperty("total_consume_count")
    private ConsumeCountResponse totalConsumerCountResponse;

    private Integer todayRequest;
}
