package cc.linkedme.account.model.request;

import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class TopUpRequest implements Serializable {

    @NotNull(message = "id 不能为空", groups = Update.class)
    private Integer id;

    private Integer uid;

    @NotBlank(message = "充值金额必填", groups = Insert.class)
    private String amount;

    private String giftAmount;

    @NotBlank(message = "一键登录每次金额必填", groups = Insert.class)
    private String quickLoginOnceAmount;

    @NotBlank(message = "号码认证每次金额必填", groups = Insert.class)
    private String verifyOnceAmount;

    @NotBlank(message = "文本短信每次金额必填", groups = Insert.class)
    private String smsOnceAmount;

    @NotBlank(message = "语音短信每次金额必填", groups = Insert.class)
    private String voiceOnceAmount;

    @NotBlank(message = "国际短信每次金额必填", groups = Insert.class)
    private String globalOnceAmount;

    @NotBlank(message = "银行回执单必填", groups = Insert.class)
    private String receipt;

    @NotBlank(message = "充值账号必填", groups = {Insert.class, Update.class})
    @Email(message = "邮箱格式不正确", groups = {Insert.class, Update.class})
    private String email;

    private Integer rechargeType;
}
