package cc.linkedme.account.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 统计数据response
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class ConsumeCountResponse implements Serializable {

    private Integer quickLoginCount;

    private Integer verifyCount;

    private Integer smsCount;

    private Integer voiceCount;

    private Double totalAmount;

    private Long requestCount;

    @JsonFormat(pattern = "yyyy-MM-dd HH", timezone = "GMT+8")
    private Date hourSlot;

    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date date;
}
