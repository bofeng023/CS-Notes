package cc.linkedme.account.validator;

public interface Insert {
}
