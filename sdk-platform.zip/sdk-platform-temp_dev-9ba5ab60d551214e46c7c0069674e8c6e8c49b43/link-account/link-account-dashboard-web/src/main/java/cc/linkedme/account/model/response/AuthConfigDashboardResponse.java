package cc.linkedme.account.model.response;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yangpeng
 * @date 2019-06-17 21:16
 * @description
 **/
@Data
public class AuthConfigDashboardResponse implements Serializable {

    private Integer id;

    private Integer appId;

    private String appKey;

    private String appSecret;

    private String publicKey;

    private String ipWhitelist;

}
