package cc.linkedme.account.converter;

import cc.linkedme.account.enums.MessageType;
import cc.linkedme.account.model.MessageInfo;
import cc.linkedme.account.model.request.MessageRequest;
import cc.linkedme.account.model.response.MessageResponse;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 17:52 2019-08-13
 * @:Description
 */
public class MessageVoConverter {

    public static MessageInfo vo2Bo(MessageRequest messageRequest) {

        if (messageRequest == null) {
            return null;
        }

        MessageInfo messageInfo = new MessageInfo();
        BeanUtils.copyProperties(messageRequest, messageInfo);
        messageInfo.setMessageType(messageRequest.getCategory() != null ? MessageType.get(messageRequest.getCategory()) : null);
        return messageInfo;
    }

    public static MessageResponse bo2Vo(MessageInfo messageInfo) {

        if (messageInfo == null) {
            return null;
        }

        MessageResponse messageResponse = new MessageResponse();
        BeanUtils.copyProperties(messageInfo, messageResponse);
        messageResponse.setMessageType(messageInfo.getMessageType() != null ? messageInfo.getMessageType().getType() : null);
        return messageResponse;
    }

}
