package cc.linkedme.account.intercepters;

import cc.linkedme.account.common.util.CookieUtils;
import cc.linkedme.account.errorcode.CmsLoginErrorCode;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.ResponseBuilder;
import cc.linkedme.cache.redis.RedisClientUtil;
import cc.linkedme.errorcode.ErrorCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.lang.reflect.Method;

/**
 * @author zhanghaowei
 * @date 2019-6-6 13:43
 * @description
 **/
@NoArgsConstructor
public class CmsLoginInterceptor extends HandlerInterceptorAdapter {

    Logger logger = LoggerFactory.getLogger(CmsLoginInterceptor.class);

    /**
     *  有效期15min
     */
    private static final int CACHESECONDS = 21600;

    @Resource
    private RedisClientUtil cacheRedisClient;
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        HandlerMethod handlerMethod = (HandlerMethod) handler;
        Method method = handlerMethod.getMethod();
        Class<?> objClass = method.getDeclaringClass();
        RequiredCmsLogin classRequiredCmsLogin = AnnotationUtils.findAnnotation(objClass,RequiredCmsLogin.class);
        boolean isLogin = false;
        if (classRequiredCmsLogin != null) {
            isLogin = true;
        }
        if (!isLogin) {
            RequiredCmsLogin methodRequiredCmsLogin = AnnotationUtils.findAnnotation(method, RequiredCmsLogin.class);
            if (methodRequiredCmsLogin != null) {
                isLogin = true;
            }
        }
        if (!isLogin) {
            return true;
        }

        String token = CookieUtils.getCookieValue(request,"account_token");

        logger.info("preHandle token:{}",token);

        PrintWriter out = null;

        if (StringUtils.isEmpty(token)) {
            ErrorCode errorCode = CmsLoginErrorCode.TOKEN_NOT_VALID;
            writeResponse(out,errorCode,response);
            return false;
        } else {
            Object value = cacheRedisClient.get(token);
            if (value != null) {
                cacheRedisClient.expire(token,CACHESECONDS);
            } else {
                ErrorCode errorCode = CmsLoginErrorCode.TOKEN_NOT_VALID;
                writeResponse(out,errorCode,response);
                return false;
            }
        }
        return true;
    }

    private void writeResponse(PrintWriter out,ErrorCode errorCode,HttpServletResponse response) {
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=utf-8");
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            out = response.getWriter();
            out.print(objectMapper.writeValueAsString(buildErrorResp(errorCode)));
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    private FrameResp buildErrorResp(ErrorCode errorCode) {
        return new ResponseBuilder().success(false).alert(errorCode.isAlert()).code(errorCode.getCode()).message(errorCode.getMessage()).build();
    }
}
