package cc.linkedme.account.converter;

import cc.linkedme.account.model.AuthConfigInfo;
import cc.linkedme.account.model.request.AuthConfigDashboardRequest;
import cc.linkedme.account.model.request.AuthConfigRequest;
import cc.linkedme.account.model.response.AuthConfigDashboardResponse;
import cc.linkedme.account.model.response.AuthConfigResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;

/**
 * @author zhanghaowei
 * @date 2019-6-18 10:18
 * @description
 **/
public class AuthConfigVoConverter {

    public static AuthConfigResponse bo2Vo(AuthConfigInfo authConfigInfo) {

        if (authConfigInfo == null) {
            return null;
        }
        AuthConfigResponse authConfigResponse = new AuthConfigResponse();
        BeanUtils.copyProperties(authConfigInfo, authConfigResponse);

        //cmcc
        AuthConfigInfo.Cmcc cmcc = authConfigInfo.getCmcc();
        if (cmcc != null) {
            authConfigResponse.setCmcc(new AuthConfigResponse.Cmcc());
            BeanUtils.copyProperties(cmcc, authConfigResponse.getCmcc());
        }

        //ctcc
        AuthConfigInfo.Ctcc ctcc = authConfigInfo.getCtcc();
        if (ctcc != null) {
            authConfigResponse.setCtcc(new AuthConfigResponse.Ctcc());
            BeanUtils.copyProperties(ctcc, authConfigResponse.getCtcc());
        }

        //cucc
        AuthConfigInfo.Cucc cucc = authConfigInfo.getCucc();
        if (cucc != null) {
            authConfigResponse.setCucc(new AuthConfigResponse.Cucc());
            BeanUtils.copyProperties(cucc, authConfigResponse.getCucc());
        }

        return authConfigResponse;
    }

    public static AuthConfigInfo vo2Bo(AuthConfigRequest authConfigRequest) {

        AuthConfigInfo authConfigInfo = new AuthConfigInfo();
        BeanUtils.copyProperties(authConfigRequest, authConfigInfo);

        authConfigInfo.setCmcc(new AuthConfigInfo.Cmcc());
        authConfigInfo.setCtcc(new AuthConfigInfo.Ctcc());

        //cmcc
        String cmccAndroidAppId = authConfigRequest.getCmccAndroidAppId();
        if (StringUtils.isNotEmpty(cmccAndroidAppId)) {
            authConfigInfo.getCmcc().setAndroidAppId(cmccAndroidAppId);
        }
        String cmccAndroidAppKey = authConfigRequest.getCmccAndroidAppKey();
        if (StringUtils.isNotEmpty(cmccAndroidAppKey)) {
            authConfigInfo.getCmcc().setAndroidAppKey(cmccAndroidAppKey);
        }
        String cmccAndroidAppSecret = authConfigRequest.getCmccAndroidAppSecret();
        if (StringUtils.isNotEmpty(cmccAndroidAppSecret)) {
            authConfigInfo.getCmcc().setAndroidAppSecret(cmccAndroidAppSecret);
        }
        String cmccIosAppId = authConfigRequest.getCmccIosAppId();
        if (StringUtils.isNotEmpty(cmccIosAppId)) {
            authConfigInfo.getCmcc().setIosAppId(cmccIosAppId);
        }
        String cmccIosAppKey = authConfigRequest.getCmccIosAppKey();
        if (StringUtils.isNotEmpty(cmccIosAppKey)) {
            authConfigInfo.getCmcc().setIosAppKey(cmccIosAppKey);
        }
        String cmccIosAppSecret = authConfigRequest.getCmccIosAppSecret();
        if (StringUtils.isNotEmpty(cmccIosAppSecret)) {
            authConfigInfo.getCmcc().setIosAppSecret(cmccIosAppSecret);
        }

        //ctcc
        String ctccAppId = authConfigRequest.getCtccAppId();
        if (StringUtils.isNotEmpty(ctccAppId)) {
            authConfigInfo.getCtcc().setAppId(ctccAppId);
        }
        String ctccAppSecret = authConfigRequest.getCtccAppSecret();
        if (StringUtils.isNotEmpty(ctccAppSecret)) {
            authConfigInfo.getCtcc().setAppSecret(ctccAppSecret);
        }

        return authConfigInfo;
    }

    public static AuthConfigInfo dashboardVo2Bo(AuthConfigDashboardRequest authConfigDashboardRequest) {

        AuthConfigInfo authConfigInfo = new AuthConfigInfo();
        BeanUtils.copyProperties(authConfigDashboardRequest,authConfigInfo);

        return authConfigInfo;
    }

    public static AuthConfigDashboardResponse bo2DashboardVo(AuthConfigInfo authConfigInfo) {

        if (authConfigInfo == null) {
            return null;
        }
        AuthConfigDashboardResponse authConfigDashboardResponse = new AuthConfigDashboardResponse();
        BeanUtils.copyProperties(authConfigInfo, authConfigDashboardResponse);

        return authConfigDashboardResponse;
    }
}
