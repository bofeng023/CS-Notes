package cc.linkedme.account.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author zhanghaowei
 * @date 2019-6-6 13:20
 * @description
 **/
@Data
public class CmsUserResponse implements Serializable {

    private String email;

    private String goUrl;

    @JsonProperty(value="account_token")
    private String token;

}
