package cc.linkedme.account.web;

import cc.linkedme.account.converter.TopUpVoConverter;
import cc.linkedme.account.errorcode.TopUpErrorCode;
import cc.linkedme.account.exception.TopUpException;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.SearchRequest;
import cc.linkedme.account.model.TopUpInfo;
import cc.linkedme.account.model.UserInfo;
import cc.linkedme.account.model.request.TopUpRequest;
import cc.linkedme.account.model.response.TopUpResponse;
import cc.linkedme.account.service.AuditInfoSerivce;
import cc.linkedme.account.service.TopUpService;
import cc.linkedme.account.service.UserService;
import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 账户充值
 * @author
 */
@RestController
@RequestMapping("/linkaccount/top_up/")
public class TopUpController extends BaseController{

    private static final Logger logger = LoggerFactory.getLogger(TopUpController.class);

    @Resource
    private TopUpService topUpService;
    @Resource
    private AuditInfoSerivce auditInfoSerivce;
    @Resource
    private UserService userService;

    @RequestMapping("save")
    @ResponseBody
    public FrameResp saveTopUp(@Validated(value = Insert.class) @RequestBody TopUpRequest topUpRequest) throws BusinessException {

        logger.info("saveTopUp, topUpRequest:{}", topUpRequest);

        UserInfo userInfo = userService.getUserInfoByEmail(topUpRequest.getEmail().trim());
        Preconditions.checkNotNull(userInfo.getUid(), new TopUpException(TopUpErrorCode.ACCOUNT_TOP_UP_EMAIL_NOT_EXIST));

        TopUpInfo topUpInfo = TopUpVoConverter.vo2Bo(topUpRequest);
        topUpInfo.setUid(userInfo.getUid());
        topUpInfo = topUpService.saveTopUp(topUpInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setUid(topUpInfo.getUid());
        auditInfo.setBizId(topUpInfo.getId());
        auditInfo.setAuditState(AuditState.TO_BE_AUDITED);
        auditInfo.setBizType(BizType.TOP_UP);
        auditInfoSerivce.saveAudit(auditInfo);

        TopUpResponse topUpResponse = TopUpVoConverter.bo2Vo(topUpInfo);
        logger.info("saveTopUp, topUpRequest:{}, topUpResponse:{}", topUpRequest, topUpResponse);
        return buildSuccessResp(topUpResponse);
    }

    @RequestMapping("get")
    @ResponseBody
    public FrameResp getTopUp(@RequestParam("id") Integer id) throws BusinessException {

        logger.info("getTopUp, id:{}", id);
        Preconditions.checkNotNull(id, new TopUpException(TopUpErrorCode.ID_NULL_ERROR));

        TopUpInfo topUpInfo = topUpService.getTopUp(id);
        if (topUpInfo == null) {
            return buildSuccessResp();
        }

        AuditInfo auditInfo = auditInfoSerivce.getAuditByBizId(id, BizType.TOP_UP);

        TopUpResponse topUpResponse = TopUpVoConverter.bo2Vo(topUpInfo, auditInfo);
        logger.info("getTopUp, id:{}, topUpResponse:{}", id, topUpResponse);

        return buildSuccessResp(topUpResponse);
    }

    @RequestMapping("list")
    @ResponseBody
    public FrameResp listTopUp(@RequestBody SearchRequest searchRequest) throws BusinessException {

        logger.info("listTopUp, searchRequest:{}", searchRequest);
        Preconditions.checkNotNull(searchRequest, new TopUpException(TopUpErrorCode.PARAM_NULL_ERROR));

        SearchParam searchParam = new SearchParam();
        BeanUtils.copyProperties(searchRequest, searchParam);

        List<TopUpInfo> topUpBOList = topUpService.listTopUp(searchParam);
        if (CollectionUtils.isEmpty(topUpBOList)) {
            return buildSuccessResp();
        }

        List<Integer> topUpIdList = new ArrayList<>();
        topUpBOList.forEach(topUpInfo -> topUpIdList.add(topUpInfo.getId()));
        Map<Integer, AuditInfo> auditInfoBOMap = auditInfoSerivce.batchGetAuditByBizId(topUpIdList, BizType.TOP_UP);

        List<TopUpResponse> topUpResponseList = topUpBOList.stream().map(topUpBO -> TopUpVoConverter.bo2Vo(topUpBO, auditInfoBOMap.get(topUpBO.getId()))).collect(Collectors.toList());
        logger.debug("listTopUp, searchRequest:{}, topUpResponseList:{}", searchRequest, topUpResponseList);

        return buildSuccessResp(topUpResponseList);
    }

    @RequestMapping("count")
    @ResponseBody
    public FrameResp countTopUp(Integer uid) {

        logger.info("countTopUp, uid:{}", uid);

        Long topUpCount = topUpService.countTopUp(uid,null);
        logger.info("countTopUp, uid:{}, topUpCount:{}", uid, topUpCount);

        return buildSuccessResp(topUpCount);
    }

    @RequestMapping("update")
    @ResponseBody
    public FrameResp updateTopUp(@Validated(value = Update.class) @RequestBody TopUpRequest topUpRequest) {

        logger.info("updateTopUp, topUpRequest:{}", topUpRequest);

        UserInfo userInfo = userService.getUserInfoByEmail(topUpRequest.getEmail());
        Preconditions.checkNotNull(userInfo.getUid(), new TopUpException(TopUpErrorCode.ACCOUNT_TOP_UP_EMAIL_NOT_EXIST));

        TopUpInfo topUpInfo = TopUpVoConverter.vo2Bo(topUpRequest);
        topUpInfo.setUid(userInfo.getUid());
        topUpService.updateTopUp(topUpInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setBizType(BizType.TOP_UP);
        auditInfo.setBizId(topUpInfo.getId());
        auditInfo.setAuditState(AuditState.TO_BE_AUDITED);
        auditInfoSerivce.updateAuditByBizId(auditInfo);

        logger.info("updateTopUp, topUpRequest:{}, topUpInfo:{}, auditInfo:{}", topUpRequest, topUpInfo, auditInfo);
        return buildSuccessResp();
    }

}
