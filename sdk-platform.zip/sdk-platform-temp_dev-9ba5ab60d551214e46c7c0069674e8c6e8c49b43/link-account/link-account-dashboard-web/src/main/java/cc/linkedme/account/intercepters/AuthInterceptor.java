package cc.linkedme.account.intercepters;

import cc.linkedme.account.exception.AuthException;
import cc.linkedme.account.service.UserService;
import cc.linkedme.errorcode.BaseErrorCode;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;

@NoArgsConstructor
public class AuthInterceptor extends HandlerInterceptorAdapter {

    private static final Logger logger = LoggerFactory.getLogger(AuthInterceptor.class);

    private static final String defaultLoginUrl = "https://www.linkedme.cc/dashboard/index.html#/access/signin";

    @Resource
    private UserService userService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        HandlerMethod handlerMethod = (HandlerMethod) handler;
        Method method = handlerMethod.getMethod();

        RequiredLogin requiredLogin = AnnotationUtils.findAnnotation(method, RequiredLogin.class);
        if (requiredLogin == null) {
            return true;
        }

        String authInfo = request.getHeader("Authorization");
        if (StringUtils.isEmpty(authInfo)) {
            response.sendRedirect(defaultLoginUrl);
            return false;
        }

        String[] authInfoArray = StringUtils.split(authInfo, ":");
        if (authInfoArray.length != 2 || authInfoArray[0] == null || authInfoArray[1] == null) {
            response.sendRedirect(defaultLoginUrl);
            return false;
        }

        String[] authInfoContent = authInfoArray[1].trim().split(" ");
        if (authInfoContent.length != 2 || authInfoContent[0] == null || authInfoContent[1] == null) {
            response.sendRedirect(defaultLoginUrl);
            return false;
        }

        String authMethod = authInfoArray[0];
        String token = authInfoContent[0];
        String uid = authInfoContent[1];

        if (authMethod.trim().equals("Token")) {
            if (checkToken(uid, token)) {
                return true;
            } else {
                throw new AuthException(BaseErrorCode.AUTH_FAIL);
            }
        } else {
            response.sendRedirect(defaultLoginUrl);
            return false;
        }

    }

    private boolean checkToken(String uid, String token) {
        logger.info("checkToken, uid:{}, token:{}",uid,token);
        String oldToken = userService.getUserToken(uid);
        if (token.equals(oldToken)) {
            return true;
        }
        return false;
    }

}
