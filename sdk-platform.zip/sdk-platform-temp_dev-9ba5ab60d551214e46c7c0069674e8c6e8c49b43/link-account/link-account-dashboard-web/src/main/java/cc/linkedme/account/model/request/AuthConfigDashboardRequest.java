package cc.linkedme.account.model.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author zhanghaowei
 * @date 2019-6-18 14:20
 * @description
 **/
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class AuthConfigDashboardRequest {

    @NotNull(message = "appId 不能为空")
    private Integer appId;

    /**
     * dashboard 公钥
     */
    private String publicKey;

    /**
     * dashboard 白名单
     */
    private String ipWhitelist;

    /**
     * app 密钥
     */
    private String appKey;

}
