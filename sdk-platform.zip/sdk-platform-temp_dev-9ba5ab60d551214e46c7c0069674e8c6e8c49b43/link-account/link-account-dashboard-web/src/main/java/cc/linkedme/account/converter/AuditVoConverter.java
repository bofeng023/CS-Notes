package cc.linkedme.account.converter;

import cc.linkedme.account.model.*;
import cc.linkedme.account.model.request.AuditInfoRequest;
import cc.linkedme.account.model.response.*;
import cc.linkedme.account.model.sms.SmsSignInfo;
import cc.linkedme.account.model.sms.SmsTemplateInfo;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 19:58
 * @description
 **/
public class AuditVoConverter {

    public static AuditResponse bo2Vo(AuditInfo auditInfo) {

        AuditResponse auditResponse = new AuditResponse();
        BeanUtils.copyProperties(auditInfo, auditResponse);
        auditResponse.setAuditState(auditInfo.getAuditState() == null ? null : auditInfo.getAuditState().getType());
        auditResponse.setBizType(auditInfo.getBizType() == null ? null : auditInfo.getBizType().getType());

        return auditResponse;
    }

    public static AuditWithBizResponse bo2Vo(AuditInfo auditInfo, TopUpInfo topUpInfo, InvoiceInfo invoiceInfo,
                                             SmsSignInfo smsSignInfo, SmsTemplateInfo smsTemplateInfo, UserInfo userInfo) {

        AuditWithBizResponse auditWithBizResponse = new AuditWithBizResponse();
        auditWithBizResponse.setAuditResponse(bo2Vo(auditInfo));
        auditWithBizResponse.setTopUpResponse(topUpInfo == null ? null : TopUpVoConverter.bo2Vo(topUpInfo));
        auditWithBizResponse.setInvoiceInfoResponse(invoiceInfo == null ? null : InvoiceVoConverter.bo2Vo(invoiceInfo));
        auditWithBizResponse.setSmsSignResponse(smsSignInfo == null ? null : SignVoConverter.bo2Vo(smsSignInfo));
        auditWithBizResponse.setSmsTextTemplateResponse(smsTemplateInfo == null ? null : SmsTemplateVoConverter.bo2Vo(smsTemplateInfo));
        auditWithBizResponse.setUserInfoResponse(userInfo == null ? null : UserVoConverter.bo2Vo(userInfo));

        return auditWithBizResponse;
    }

    public static AuditInfo vo2Bo(AuditInfoRequest auditInfoRequest) {

        AuditInfo auditInfo = new AuditInfo();
        BeanUtils.copyProperties(auditInfoRequest, auditInfo);
        auditInfo.setBizType(auditInfoRequest.getBizType() == null ? null : BizType.get(auditInfoRequest.getBizType()));
        auditInfo.setAuditState(auditInfoRequest.getAuditState() == null ? null : AuditState.get(auditInfoRequest.getAuditState()));

        return auditInfo;
    }

}
