package cc.linkedme.account.model.request;

import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @author zhanghaowei
 * @date 2019-6-17 21:30
 * @description
 **/
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class AuthConfigRequest {

    @NotNull(message = "id 不能为空", groups = {Update.class})
    private Integer id;

    @NotNull(message = "appId 不能为空", groups = {Insert.class, Update.class})
    private Integer appId;

    private String cmccAndroidAppId;

    private String cmccAndroidAppKey;

    private String cmccAndroidAppSecret;

    private String cmccIosAppId;

    private String cmccIosAppKey;

    private String cmccIosAppSecret;

    private String ctccAppId;

    private String ctccAppSecret;
}
