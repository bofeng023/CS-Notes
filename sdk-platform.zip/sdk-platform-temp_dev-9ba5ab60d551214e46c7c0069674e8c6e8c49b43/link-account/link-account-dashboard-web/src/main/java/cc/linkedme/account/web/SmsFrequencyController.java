package cc.linkedme.account.web;

import cc.linkedme.account.converter.SmsFrequencyVoConverter;
import cc.linkedme.account.errorcode.SmsFrequencyErrorCode;
import cc.linkedme.account.exception.SmsFrequencyException;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.request.SmsFrequencyRequest;
import cc.linkedme.account.model.response.SmsFrequencyResponse;
import cc.linkedme.account.model.sms.SmsFrequencyInfo;
import cc.linkedme.account.service.SmsFrequencyService;
import cc.linkedme.account.validator.Update;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author yangpeng
 * @date 2019-05-28 18:16
 * @description
 **/
@RestController
@RequestMapping(value = "/linkaccount/sms/frequency/")
public class SmsFrequencyController extends BaseController {

    private static final Logger logger = LoggerFactory.getLogger(SmsFrequencyController.class);

    @Resource
    private SmsFrequencyService smsFrequencyService;

    @RequestMapping("save")
    @ResponseBody
    public FrameResp saveDefaultSmsFrequency(Integer uid) throws BusinessException {

        logger.info("saveDefaultSmsFrequency, uid:{}", uid);
        Preconditions.checkNotNull(uid, new SmsFrequencyException(SmsFrequencyErrorCode.UID_NULL_ERROR));

        SmsFrequencyInfo smsFrequencyInfo = smsFrequencyService.saveDefaultSmsFrequency(uid);

        SmsFrequencyResponse smsFrequencyResponse = new SmsFrequencyResponse();
        BeanUtils.copyProperties(smsFrequencyInfo, smsFrequencyResponse);
        logger.info("saveDefaultSmsFrequency, uid:{}, smsFrequencyResponse:{}", uid, smsFrequencyResponse);

        return buildSuccessResp(smsFrequencyResponse);

    }

    @RequestMapping("update")
    @ResponseBody
    public FrameResp updateSmsFrequency(@Validated(Update.class) @RequestBody SmsFrequencyRequest smsFrequencyRequest) throws BusinessException {

        logger.info("updateSmsFrequency, smsFrequencyRequest:{}", smsFrequencyRequest);

        SmsFrequencyInfo smsFrequencyInfo  = SmsFrequencyVoConverter.vo2Bo(smsFrequencyRequest);

        smsFrequencyService.updateSmsFrequency(smsFrequencyInfo);

        return buildSuccessResp();
    }

    @RequestMapping("get")
    @ResponseBody
    public FrameResp getSmsFrequency(@RequestParam("uid") Integer uid) throws BusinessException {

        logger.info("getSmsFrequency, uid:{}", uid);
        Preconditions.checkNotNull(uid, new SmsFrequencyException(SmsFrequencyErrorCode.UID_NULL_ERROR));

        SmsFrequencyInfo smsFrequencyInfo = smsFrequencyService.getSmsFrequency(null, uid);
        if (smsFrequencyInfo == null) {
            return buildSuccessResp();
        }

        SmsFrequencyResponse smsFrequencyResponse = SmsFrequencyVoConverter.bo2Vo(smsFrequencyInfo);
        logger.info("getSmsFrequency, uid:{}, smsFrequencyResponse:{}", uid, smsFrequencyResponse);

        return buildSuccessResp(smsFrequencyResponse);
    }
}
