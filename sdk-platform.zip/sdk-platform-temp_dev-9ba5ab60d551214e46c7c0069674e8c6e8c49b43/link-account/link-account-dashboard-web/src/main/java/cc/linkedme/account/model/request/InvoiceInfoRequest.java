package cc.linkedme.account.model.request;

import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class InvoiceInfoRequest implements Serializable {

    @NotNull(message = "id 不能为空", groups = {Update.class})
    private Integer id;

    @NotNull(message = "uid 不能为空", groups = {Insert.class, Update.class})
    private Integer uid;

    @NotNull(message = "发票类型必填", groups = {Insert.class})
    private Integer invoiceType;

    @NotBlank(message = "发票抬头必填", groups = {Insert.class})
    @Length(max = 200, min = 1, message = "发票抬头长度限制1-200字符", groups = {Insert.class, Update.class})
    private String invoiceTitle;

    private String taxpayerIdentification;

    private String contactInfo;

    private String bankAccountInfo;

    private String invoiceItem;

    @NotBlank(message = "发票金额必填", groups = {Insert.class})
    @Pattern(regexp = "^(([0-9]{1}\\d*)|([0]{1}))(\\.(\\d){0,2})?$",message = "发票金额不合法", groups = {Insert.class, Update.class})
    private String invoiceAmount;

    @NotBlank(message = "联系人姓名必填", groups = {Insert.class})
    @Length(max = 50, min = 1, message = "联系人姓名长度限制1-50字符", groups = {Insert.class, Update.class})
    private String recipientName;

    @NotBlank(message = "快递地址必填", groups = {Insert.class})
    private String recipientAddress;

    @NotBlank(message = "联系电话", groups = {Insert.class})
    private String recipientPhone;

    private String expressCompany;

    private String trackingNumber;

    private Date sendOutTime;

    private String trackingRemark;
}
