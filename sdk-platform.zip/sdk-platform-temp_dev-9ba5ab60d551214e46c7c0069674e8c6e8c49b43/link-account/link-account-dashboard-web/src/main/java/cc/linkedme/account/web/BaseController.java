package cc.linkedme.account.web;

import cc.linkedme.account.errorcode.CmsLoginErrorCode;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.ResponseBuilder;
import cc.linkedme.cache.redis.RedisClientUtil;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import javax.annotation.Resource;

public class BaseController {

    Logger logger = LoggerFactory.getLogger(BaseController.class);

    @Resource
    private RedisClientUtil cacheRedisClient;

    private static final int SUCCESS_CODE = 200;

    private static final String SUCCESS_MSG = "操作成功";

    protected FrameResp buildSuccessResp() {
        return buildSuccessResp(null, true);
    }

    protected FrameResp buildSuccessResp(Object body) {
        return buildSuccessResp(body, true);
    }

    protected FrameResp buildSuccessResp(Object body, boolean alert) {
        return new ResponseBuilder().success(true).alert(alert).code(SUCCESS_CODE).message(SUCCESS_MSG).body(body).build();
    }

    @Deprecated
    protected FrameResp buildErrorResp(int code, Object body) {
        return new ResponseBuilder().success(false).code(code).body(body).build();
    }

    protected FrameResp buildErrorResp(BusinessException be) {
        return new ResponseBuilder().success(false).alert(be.getErrorCode().isAlert()).code(be.getErrorCode().getCode())
                .message(be.getErrorCode().getMessage()).build();
    }

    protected FrameResp buildErrorResp(ErrorCode errorCode) {
        return new ResponseBuilder().success(false).alert(errorCode.isAlert()).code(errorCode.getCode()).message(errorCode.getMessage()).build();
    }

    protected FrameResp buildErrorResp(ErrorCode errorCode, Object body) {
        return new ResponseBuilder().success(false).alert(errorCode.isAlert()).code(errorCode.getCode()).message(errorCode.getMessage()).body(body).build();
    }

    /**
     * 验证参数是否合法
     * @param bindingResult
     * @return
     */
    protected void isValidParam(BindingResult bindingResult) {
        //错误信息，key 字段名称，value:提示语
        if (bindingResult.hasErrors()) {
            FieldError fieldError = bindingResult.getFieldErrors().get(0);
            throw new BusinessException(BaseErrorCode.PARAM_NOT_VALID.getCode(), fieldError.getDefaultMessage());
        }
    }

    /**
     * 获取审核人员登录信息
     * @param token
     * @return
     */
    protected String getCmsUserInfo(String token) throws BusinessException{

        logger.info("getCmsUserInfo token:{}",token);
        Object obj = cacheRedisClient.get(token);
        if (obj != null) {
            return obj.toString();
        } else {
            throw new BusinessException(CmsLoginErrorCode.TOKEN_NOT_VALID);
        }
    }
}
