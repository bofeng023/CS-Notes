package cc.linkedme.account.web;

import cc.linkedme.account.common.util.DigitalUtil;
import cc.linkedme.account.converter.ConsumeCountConverter;
import cc.linkedme.account.errorcode.AuditInfoErrorCode;
import cc.linkedme.account.errorcode.ConsumeCountErrorCode;
import cc.linkedme.account.exception.AuditInfoException;
import cc.linkedme.account.exception.ConsumeCountException;
import cc.linkedme.account.model.ConsumeCountInfo;
import cc.linkedme.account.model.DataInfo;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.SearchRequest;
import cc.linkedme.account.model.response.AccountBalanceResponse;
import cc.linkedme.account.model.response.ConsumeCountResponse;
import cc.linkedme.account.model.response.DataResponse;
import cc.linkedme.account.service.ConsumeCountSerivce;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.util.Preconditions;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author zhanghaowei
 * @date 2019-6-4 10:41
 * @description 统计数据
 **/
@RestController
@RequestMapping("/linkaccount/data/")
public class ConsumeCountController extends BaseController {

    Logger logger = LoggerFactory.getLogger(ConsumeCountController.class);

    private final static int hour = 24;

    @Resource
    private ConsumeCountSerivce consumeCountSerivce;


    @RequestMapping("list")
    @ResponseBody
    public FrameResp list(@RequestBody SearchRequest searchRequest) {
        logger.info("list begin, searchRequest:{}", searchRequest);

        Preconditions.checkNotNull(searchRequest.getUid(),new ConsumeCountException(BaseErrorCode.UID_NOT_EXIST));

        SearchParam searchParam = convertSearchBO(searchRequest);
        List<ConsumeCountInfo> consumeCountBOList = consumeCountSerivce.listConsumeCountBO(searchParam);

        List<ConsumeCountResponse> consumerCountResponseList = new ArrayList<>();
        consumeCountBOList.stream().forEach(consumeCountBO -> consumerCountResponseList.add(ConsumeCountConverter.bo2Vo(consumeCountBO)));

        logger.debug("list end, searchRequest:{}, consumerCountResponseList:{}", searchRequest, consumerCountResponseList);

        return buildSuccessResp(consumerCountResponseList);
    }

    @RequestMapping("summary")
    @ResponseBody
    public FrameResp summary(@RequestBody SearchRequest searchRequest) {
        logger.info("summary begin, searchRequest:{}", searchRequest);

        Preconditions.checkNotNull(searchRequest.getUid(),new ConsumeCountException(BaseErrorCode.UID_NOT_EXIST));

        SearchParam searchParam = convertSearchBO(searchRequest);
        DataInfo dataInfo = consumeCountSerivce.getDataInfo(searchParam);

        DataResponse dataResponse = new DataResponse();

        //账户余额
        Integer uid = searchRequest.getUid();
        AccountBalanceResponse accountBalanceResponse = new AccountBalanceResponse();
        accountBalanceResponse.setBalance(DigitalUtil.moneyConverToDouble(consumeCountSerivce.getBalanceByUid(uid)));
        accountBalanceResponse.setUid(uid);
        ConsumeCountInfo consumeCountInfo = consumeCountSerivce.countDayTotalAmountAndRequestCount(uid);
        Integer todayConsume = 0;
        Integer todayRequest = 0;
        if (consumeCountInfo != null) {
            todayRequest = consumeCountInfo.getSmsCount();
            todayConsume = consumeCountInfo.getTotalAmount();
        }
        //今日请求量
        dataResponse.setTodayRequest(todayRequest);
        //今日消耗
        accountBalanceResponse.setTodayConsume(DigitalUtil.moneyConverToDouble(todayConsume.intValue()));
        dataResponse.setAccountBalanceResponse(accountBalanceResponse);

        //数据列表分页
        long start = System.currentTimeMillis();
        logger.info("summary page start, searchRequest:{}, start:{}", searchRequest, start);
        List<ConsumeCountInfo> consumeCountBOList = dataInfo.getConsumerCountBOList();
        List<ConsumeCountResponse> consumeCountResponseList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(consumeCountBOList)) {
            consumeCountBOList.stream().forEach(consumeCountBO -> {
                ConsumeCountResponse consumeCountResponse = ConsumeCountConverter.bo2Vo(consumeCountBO);
                long requestCount = 0;
                requestCount += consumeCountResponse.getQuickLoginCount() != null ?  consumeCountResponse.getQuickLoginCount() : 0;
                requestCount += consumeCountResponse.getSmsCount() != null ? consumeCountResponse.getSmsCount() : 0;
                requestCount += consumeCountResponse.getVerifyCount() != null ? consumeCountResponse.getVerifyCount() : 0;
                requestCount += consumeCountResponse.getVoiceCount() != null ? consumeCountResponse.getVoiceCount() : 0;
                consumeCountResponse.setRequestCount(requestCount);
                consumeCountResponseList.add(consumeCountResponse);
            });
            dataResponse.setConsumeCountResponseList(consumeCountResponseList);
        }
        logger.info("summary page end, searchRequest:{}, end:{}", searchRequest, System.currentTimeMillis() - start);

        //数据趋势图
        logger.info("page start:", System.currentTimeMillis());
        Map<String,ConsumeCountInfo> consumeCountBOMap = dataInfo.getTrendMap();
        if (consumeCountBOMap != null && consumeCountBOMap.size() > 0) {
            Map<String,ConsumeCountResponse> consumeCountResponseMap = new TreeMap<>();
            consumeCountBOMap.forEach((key,consumeCountBO)->consumeCountResponseMap.put(key, ConsumeCountConverter.bo2Vo(consumeCountBO)));
            trendDataHandler(consumeCountResponseMap,searchParam.getStartDate(),searchParam.getEndDate(),dataResponse);
        } else {
            Map<String,ConsumeCountResponse> consumeCountResponseMap = new TreeMap<>();
            trendDataHandler(consumeCountResponseMap,searchParam.getStartDate(),searchParam.getEndDate(),dataResponse);
        }

        logger.info("summary trend end, searchRequest:{}, end:{}", searchRequest, System.currentTimeMillis() - start);


        //汇总指标值
        ConsumeCountInfo totalConsumerCountBO = consumeCountSerivce.totalCountConsume(searchParam);
        if (totalConsumerCountBO != null) {
            ConsumeCountResponse consumeCountResponse = ConsumeCountConverter.bo2Vo(totalConsumerCountBO);
            long requestCount = 0;
            requestCount += consumeCountResponse.getQuickLoginCount() != null ?  consumeCountResponse.getQuickLoginCount() : 0;
            requestCount += consumeCountResponse.getSmsCount() != null ? consumeCountResponse.getSmsCount() : 0;
            requestCount += consumeCountResponse.getVerifyCount() != null ? consumeCountResponse.getVerifyCount() : 0;
            requestCount += consumeCountResponse.getVoiceCount() != null ? consumeCountResponse.getVoiceCount() : 0;
            consumeCountResponse.setRequestCount(requestCount);
            dataResponse.setTotalConsumerCountResponse(consumeCountResponse);
        }

        logger.info("summary sum end, searchRequest:{}, end:{}", searchRequest, System.currentTimeMillis() - start);

        logger.debug("summary, searchRequest:{}, dataResponse:{}", searchRequest, dataResponse);
        return buildSuccessResp(dataResponse);
    }

    @RequestMapping("count")
    @ResponseBody
    public FrameResp count(@RequestBody SearchRequest searchRequest) {
        logger.info("count begin, searchRequest:{}", searchRequest);

        Preconditions.checkNotNull(searchRequest.getUid(),new ConsumeCountException(BaseErrorCode.UID_NOT_EXIST));

        SearchParam searchParam = convertSearchBO(searchRequest);
        Long count = consumeCountSerivce.countConsumeCount(searchParam);
        logger.info("count end, searchRequest:{}, count:{}", searchRequest, count);

        return buildSuccessResp(count);
    }

    @RequestMapping("export")
    public ResponseEntity<byte[]> export(SearchRequest searchRequest) {
        logger.info("export begin, searchRequest:{}", searchRequest);
        Preconditions.checkNotNull(searchRequest.getUid(), new ConsumeCountException(BaseErrorCode.UID_NULL_ERROR));
        Preconditions.checkNotNull(searchRequest.getStartDate(), new ConsumeCountException(ConsumeCountErrorCode.START_DATE_NULL_ERROR));
        Preconditions.checkNotNull(searchRequest.getEndDate(), new ConsumeCountException(ConsumeCountErrorCode.END_DATE_NULL_ERROR));

        SearchParam searchParam = convertSearchBO(searchRequest);
        return consumeCountSerivce.exportExcel(searchParam);
    }

    private SearchParam convertSearchBO(SearchRequest searchRequest) {

        SearchParam searchParam = new SearchParam();
        BeanUtils.copyProperties(searchRequest, searchParam);
        try {
            searchParam.setStartDate(searchRequest.getStartDate() == null ? null : DateUtils.parseDate(searchRequest.getStartDate() + " 00:00:00", "yyyy-MM-dd HH:mm:ss"));
            searchParam.setEndDate(searchRequest.getEndDate() == null ? null : DateUtils.parseDate(searchRequest.getEndDate() + " 23:59:59", "yyyy-MM-dd HH:mm:ss"));
        } catch (ParseException ex) {
            throw new AuditInfoException(AuditInfoErrorCode.DATE_FORMAT_ERROR);
        }
        return searchParam;
    }


    /**
     * 趋势图数据处理
     * @param consumeCountResponseMap 待处理数据
     * @param startDate 开始时间
     * @param endDate 结束时间
     * @param dataResponse 数据结果
     * @return
     */
    private void trendDataHandler(Map<String,ConsumeCountResponse> consumeCountResponseMap,Date startDate, Date endDate,DataResponse dataResponse) {
        logger.info("trendDataHandler, consumeCountResponseMap:{}, startDate:{}, endDate:{}, dataResponse:{}", consumeCountResponseMap, startDate, endDate, dataResponse);
        List<Integer> quickLoginCountList = new ArrayList<>();
        List<Integer> verifyCountList = new ArrayList<>();
        List<Integer> smsCountList = new ArrayList<>();
        List<Integer> voiceCountList = new ArrayList<>();
        List<Double> totalAmountList = new ArrayList<>();
        List<String> keys = new ArrayList<>();
        if (org.apache.commons.lang.time.DateUtils.isSameDay(startDate,endDate)) {
            for (int i = 0; i < hour; i++) {
                keys.add(i+"");
            }
        } else {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd");
            while(startDate.before(endDate)) {
                keys.add(simpleDateFormat.format(startDate));
                startDate =  DateUtils.addDays(startDate,1);
            }
        }
        logger.info("trendDataHandler keys:{}", keys);
        keys.stream().forEach(key -> {
            ConsumeCountResponse consumeCountResponse = consumeCountResponseMap.get(key);
            if (consumeCountResponse != null) {
                quickLoginCountList.add(consumeCountResponse.getQuickLoginCount() == null ? 0 : consumeCountResponse.getQuickLoginCount());
                verifyCountList.add(consumeCountResponse.getVerifyCount() == null ? 0 : consumeCountResponse.getVerifyCount());
                smsCountList.add(consumeCountResponse.getSmsCount() == null ? 0 : consumeCountResponse.getSmsCount());
                voiceCountList.add(consumeCountResponse.getVoiceCount() == null ? 0 : consumeCountResponse.getVoiceCount());
                totalAmountList.add(consumeCountResponse.getTotalAmount() == null ? 0 : consumeCountResponse.getTotalAmount());
            } else {
                quickLoginCountList.add(0);
                verifyCountList.add(0);
                smsCountList.add(0);
                voiceCountList.add(0);
                totalAmountList.add(0d);
            }
        });
        dataResponse.setQuickLoginCount(quickLoginCountList.toArray(new Integer[quickLoginCountList.size()]));
        dataResponse.setVerifyCount(verifyCountList.toArray(new Integer[verifyCountList.size()]));
        dataResponse.setSmsCount(smsCountList.toArray(new Integer[smsCountList.size()]));
        dataResponse.setVoiceCount(voiceCountList.toArray(new Integer[voiceCountList.size()]));
        dataResponse.setTotalAmount(totalAmountList.toArray(new Double[totalAmountList.size()]));
    }
}
