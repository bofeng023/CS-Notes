package cc.linkedme.account.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class SmsSignResponse implements Serializable {

    private Integer id;

    private Integer uid;

    private Integer appId;

    private String signName;

    private String powerAttorney;

    private Integer isGlobal;

    private String applyRemark;

    private Integer certificationState;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date gmtCreate;

    private AuditResponse auditResponse;

}
