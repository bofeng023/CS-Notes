package cc.linkedme.account.web;

import cc.linkedme.account.common.oss.OssClient;
import cc.linkedme.account.common.oss.OssEndpointDomain;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.enums.BizType;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import com.aliyun.oss.model.PutObjectResult;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.Random;

/**
 * 文件上传
 * @author zhanghaowei
 * @date 2019-6-5 11:00
 * @description
 **/
@RestController
@RequestMapping("/linkaccount/oss/")
public class OssResourceController extends BaseController{

    Logger logger = LoggerFactory.getLogger(OssResourceController.class);

    private final static String bucketName = "linkaccount";
    private final static String fileRootDir = "account/";

    /**
     * 充值回执单上传目录
     */
    private final static String topUpSubFileDir = "receipt/";
    /**
     * 短信签名委托书上传目录
     */
    private final static String smsSubFileDir = "sms/";

    /**
     * 账号认证
     */
    private final static String authenticationDir = "authentication/";

    @Resource
    private OssClient ossClient;

    @RequestMapping("upload/resource")
    @ResponseBody
    public FrameResp upload(@RequestParam("file") MultipartFile multipartFile, @RequestParam("biz_type") Integer bizType) {
        logger.info("upload, bizType:{}, multipartFile:{}", bizType, multipartFile);
        String fileDir = fileRootDir;
        switch (BizType.get(bizType)) {
            case TOP_UP:
                fileDir = fileDir + topUpSubFileDir;
                break;
            case SIGN:
                fileDir = fileDir + smsSubFileDir;
                break;
            case ACCOUNT_AUTHENTICATION:
                fileDir = fileDir + authenticationDir;
                break;
            default:
                break;
        }
        String originalFilename = multipartFile.getOriginalFilename();
        if(StringUtils.isEmpty(originalFilename)){
            originalFilename = multipartFile.getName();
        }
        String substring = originalFilename.substring(originalFilename.lastIndexOf(".")).toLowerCase();
        Random random = new Random();
        //自定义文件名
        String fileName = random.nextInt(10000) + System.currentTimeMillis() + substring;
        //文件存储oss 相对目录
        fileDir = fileDir + fileName;
        PutObjectResult putObjectResult = ossClient.uploadMultipartFile(OssEndpointDomain.BEIJING, bucketName, fileDir, multipartFile);

        logger.info("upload, receiptName:{}, putObjectResult:{}", fileDir, putObjectResult);
        return buildSuccessResp(fileDir);
    }


    /**
     * 文件下载
     * @param fileUrl
     * @param response
     * @return
     */
    @RequestMapping(value = "download", method = RequestMethod.GET)
    @ResponseBody
    public void pageDashboardDownload(@RequestParam("url") String fileUrl, HttpServletResponse response) {
        logger.info("pageDashboardDownload, fileUrl:{}, response:{}", fileUrl, response);
        Preconditions.checkNotNull(fileUrl, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));
        ossClient.downloadResource(fileUrl, response);
    }
}
