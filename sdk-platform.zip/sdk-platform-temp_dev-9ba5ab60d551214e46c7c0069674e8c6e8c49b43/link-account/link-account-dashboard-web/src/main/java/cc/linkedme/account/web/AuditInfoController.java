package cc.linkedme.account.web;


import cc.linkedme.account.converter.AuditVoConverter;
import cc.linkedme.account.errorcode.AuditInfoErrorCode;
import cc.linkedme.account.exception.AuditInfoException;
import cc.linkedme.account.intercepters.RequiredCmsLogin;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.InvoiceInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.SearchRequest;
import cc.linkedme.account.model.TopUpInfo;
import cc.linkedme.account.model.UserInfo;
import cc.linkedme.account.model.request.AuditInfoRequest;
import cc.linkedme.account.model.response.AuditResponse;
import cc.linkedme.account.model.response.AuditWithBizResponse;
import cc.linkedme.account.model.sms.SmsSignInfo;
import cc.linkedme.account.model.sms.SmsTemplateInfo;
import cc.linkedme.account.service.AuditInfoSerivce;
import cc.linkedme.account.service.InvoiceService;
import cc.linkedme.account.service.SmsFrequencyService;
import cc.linkedme.account.service.SmsSignService;
import cc.linkedme.account.service.SmsTemplateService;
import cc.linkedme.account.service.TopUpService;
import cc.linkedme.account.service.UserService;
import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import cc.linkedme.enums.BizType;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 审核
 *
 * @author zhanghaowei
 */
@RestController
@RequestMapping("/linkaccount/audit/")
public class AuditInfoController extends BaseController {

    private static final Logger logger = LoggerFactory.getLogger(AuditInfoController.class);

    @Resource
    private AuditInfoSerivce auditInfoSerivce;
    @Resource
    private TopUpService topUpService;
    @Resource
    private InvoiceService invoiceInfoService;
    @Resource
    private SmsSignService smsSignService;
    @Resource
    private SmsTemplateService smsTemplateService;
    @Resource
    private UserService userService;
    @Resource
    private SmsFrequencyService smsFrequencyService;

    /**
     * 保存用户审核信息
     *
     * @param auditInfoRequest   审核信息
     * @return Result
     */
    @RequestMapping("/save")
    @ResponseBody
    public FrameResp saveAudit(@Validated(Insert.class) @RequestBody AuditInfoRequest auditInfoRequest) throws BusinessException {

        logger.info("saveAudit, auditInfoRequest:{}", auditInfoRequest);

        AuditInfo auditInfo = AuditVoConverter.vo2Bo(auditInfoRequest);

        AuditInfo oldAuditInfo = this.auditInfoSerivce.getAuditByBizId(auditInfo.getBizId(), auditInfo.getBizType());

        if (oldAuditInfo != null) {
            auditInfo.setId(oldAuditInfo.getId());
            this.auditInfoSerivce.updateAudit(auditInfo);
        } else {
            this.auditInfoSerivce.saveAudit(auditInfo);
            if (auditInfo.getBizType() == BizType.ACCOUNT_OPENING) {
                smsFrequencyService.saveDefaultSmsFrequency(auditInfoRequest.getUid());
            }
        }

        logger.info("saveAudit, auditInfoRequest:{}, auditInfo:{}", auditInfoRequest, auditInfo);
        return buildSuccessResp(auditInfo);
    }

    @RequestMapping("update")
    @ResponseBody
    @RequiredCmsLogin
    public FrameResp updateAudit(@Validated(Update.class) @RequestBody AuditInfoRequest auditInfoRequest, @CookieValue(value="account_token") String token) throws BusinessException {

        logger.info("updateAudit, auditInfoRequest:{}", auditInfoRequest);

        String email = getCmsUserInfo(token);
        logger.info("updateAudit email:{}",email);

        AuditInfo auditInfo = AuditVoConverter.vo2Bo(auditInfoRequest);

        int updateBizResult = auditInfoSerivce.updateBizEntity(auditInfo);
        if (updateBizResult == 0) {
            throw new AuditInfoException(AuditInfoErrorCode.UPDATE_BIZ_ENTITY_STATE_ERROR);
        }

        auditInfo.setAuditor(email);
        auditInfoSerivce.updateAudit(auditInfo);
        logger.info("updateAudit, auditInfoRequest:{}, auditInfo:{}", auditInfoRequest, auditInfo);
        return buildSuccessResp();
    }

    @RequestMapping("get")
    @ResponseBody
    @RequiredCmsLogin
    public FrameResp getAudit(@RequestBody AuditInfoRequest auditInfoRequest) throws BusinessException {

        logger.info("getAudit, auditInfoRequest:{}", auditInfoRequest);
        Preconditions.checkNotNull(auditInfoRequest.getId(), new AuditInfoException(AuditInfoErrorCode.ID_NULL_ERROR));
        Preconditions.checkNotNull(auditInfoRequest.getBizId(), new AuditInfoException(AuditInfoErrorCode.BIZ_ID_NULL_ERROR));
        Preconditions.checkNotNull(auditInfoRequest.getBizType(), new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NULL_ERROR));

        Integer bizId = auditInfoRequest.getBizId();
        AuditWithBizResponse auditWithBizResponse = null;
        switch (BizType.get(auditInfoRequest.getBizType())) {
            case TOP_UP :
                //账户充值
                TopUpInfo topUpBO = topUpService.getTopUp(bizId);
                if (topUpBO == null) {
                    break;

                }
                AuditInfo topUpAuditInfo = auditInfoSerivce.getAuditByBizId(topUpBO.getId(), BizType.TOP_UP);
                auditWithBizResponse = AuditVoConverter.bo2Vo(topUpAuditInfo, topUpBO, null, null, null, null);
                break;

            case INVOINCE :
                //发票
                InvoiceInfo invoiceInfo = invoiceInfoService.getInvoiceInfo(bizId);
                if (invoiceInfo == null) {
                    break;
                }
                AuditInfo invoiceAuditInfo = auditInfoSerivce.getAuditByBizId(invoiceInfo.getId(), BizType.INVOINCE);
                auditWithBizResponse = AuditVoConverter.bo2Vo(invoiceAuditInfo, null, invoiceInfo, null, null, null);
                break;

            case SIGN :
                //短信
                SmsSignInfo smsSignInfo = smsSignService.getSmsSign(bizId);
                if (smsSignInfo == null) {
                    break;
                }
                AuditInfo signAuditInfo = auditInfoSerivce.getAuditByBizId(smsSignInfo.getId(), BizType.SIGN);
                auditWithBizResponse = AuditVoConverter.bo2Vo(signAuditInfo, null, null, smsSignInfo, null, null);
                break;

            case SMS_TEMPLATE :
                //短信模版
                SmsTemplateInfo smsTemplateInfo = smsTemplateService.getSmsTemplate(bizId, null);
                if (smsTemplateInfo == null) {
                    break;
                }
                AuditInfo templateAuditInfo = auditInfoSerivce.getAuditByBizId(smsTemplateInfo.getId(), BizType.SMS_TEMPLATE);
                auditWithBizResponse = AuditVoConverter.bo2Vo(templateAuditInfo, null, null, null, smsTemplateInfo, null);
                break;

            case ACCOUNT_AUTHENTICATION :
                //账户认证
                UserInfo userInfo = userService.getUserInfo(auditInfoRequest.getBizId());
                if (userInfo == null) {
                    break;
                }
                AuditInfo userAuditInfo = auditInfoSerivce.getAuditByBizId(auditInfoRequest.getBizId(), BizType.ACCOUNT_AUTHENTICATION);

                auditWithBizResponse = AuditVoConverter.bo2Vo(userAuditInfo, null, null, null, null, userInfo);
                break;
                default :
                    throw new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NOT_EXIST);
        }

        logger.info("getAudit, auditInfoRequest:{}, auditWithBizResponse:{}", auditInfoRequest, auditWithBizResponse);
        return buildSuccessResp(auditWithBizResponse);
    }

    @RequestMapping("list")
    @ResponseBody
    @RequiredCmsLogin
    public FrameResp listAudit(@RequestBody SearchRequest searchRequest) {
        logger.info("list, searchRequest:{}", searchRequest);
        Preconditions.checkNotNull(searchRequest.getBizType(), new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NULL_ERROR));

        SearchParam searchParam = convertSearchBO(searchRequest);
        if (StringUtils.isNotEmpty(searchRequest.getEmail())) {
            UserInfo userInfo = userService.getUserInfoByEmail(searchRequest.getEmail().trim());
            Integer uid = userInfo.getUid();
            searchParam.setUid(uid != null ? uid : 0);
        }

        List<Integer> bizIdList = new ArrayList<>();
        List<Integer> uidList = new ArrayList<>();
        List<AuditWithBizResponse> auditWithBizResponseList = new ArrayList<>();

        switch (BizType.get(searchRequest.getBizType())) {
            case TOP_UP :

                List<TopUpInfo> topUpInfoList = topUpService.listTopUp(searchParam);

                if (!CollectionUtils.isEmpty(topUpInfoList)) {
                    topUpInfoList.forEach(topUpInfo -> {
                        bizIdList.add(topUpInfo.getId());
                        uidList.add(topUpInfo.getUid());
                    });
                    Map<Integer, AuditInfo> topUpAuditInfoMap = auditInfoSerivce.batchGetAuditByBizId(bizIdList, BizType.TOP_UP);
                    Map<Integer, UserInfo> topUpUserInfoMap = userService.batchUserInfoBOByIds(uidList);

                    topUpInfoList.forEach(topUpInfo -> auditWithBizResponseList.add(AuditVoConverter.bo2Vo(topUpAuditInfoMap.get(topUpInfo.getId()), topUpInfo, null, null, null, topUpUserInfoMap.get(topUpInfo.getUid()))));
                }
                break;

            case INVOINCE :

                List<InvoiceInfo> invoiceInfoList = invoiceInfoService.listInvoice(searchParam);

                if (!CollectionUtils.isEmpty(invoiceInfoList)) {
                    invoiceInfoList.forEach(invoiceInfo -> {
                        bizIdList.add(invoiceInfo.getId());
                        uidList.add(invoiceInfo.getUid());
                    });
                    Map<Integer, AuditInfo> invoiceAuditInfoMap = auditInfoSerivce.batchGetAuditByBizId(bizIdList, BizType.INVOINCE);
                    Map<Integer, UserInfo> invoiceUserInfoMap = userService.batchUserInfoBOByIds(uidList);

                    invoiceInfoList.forEach(invoiceInfo -> auditWithBizResponseList.add(AuditVoConverter.bo2Vo(invoiceAuditInfoMap.get(invoiceInfo.getId()), null, invoiceInfo, null, null, invoiceUserInfoMap.get(invoiceInfo.getUid()))));
                }
                break;

            case SIGN :

                List<SmsSignInfo> smsSignInfoList = smsSignService.listSmsSign(null, searchParam);

                if (!CollectionUtils.isEmpty(smsSignInfoList)) {
                    smsSignInfoList.forEach(smsSignInfo -> {
                        bizIdList.add(smsSignInfo.getId());
                        uidList.add(smsSignInfo.getUid());
                    });
                    Map<Integer, AuditInfo> signAuditInfoMap = auditInfoSerivce.batchGetAuditByBizId(bizIdList, BizType.SIGN);
                    Map<Integer, UserInfo> signUserInfoMap = userService.batchUserInfoBOByIds(uidList);

                    smsSignInfoList.forEach(smsSignInfo -> auditWithBizResponseList.add(AuditVoConverter.bo2Vo(signAuditInfoMap.get(smsSignInfo.getId()), null, null, smsSignInfo, null, signUserInfoMap.get(smsSignInfo.getUid()))));
                }
                break;

            case SMS_TEMPLATE :

                List<SmsTemplateInfo> smsTemplateInfoList = smsTemplateService.listSmsTemplate(null, searchParam);

                if (!CollectionUtils.isEmpty(smsTemplateInfoList)) {
                    smsTemplateInfoList.forEach(smsTemplateInfo -> {
                        bizIdList.add(smsTemplateInfo.getId());
                        uidList.add(smsTemplateInfo.getUid());
                    });
                    Map<Integer, AuditInfo> templateAuditInfoMap = auditInfoSerivce.batchGetAuditByBizId(bizIdList, BizType.SMS_TEMPLATE);
                    Map<Integer, UserInfo> templateUserInfoMap = userService.batchUserInfoBOByIds(uidList);

                    smsTemplateInfoList.forEach(smsTemplateInfo -> auditWithBizResponseList.add(AuditVoConverter.bo2Vo(templateAuditInfoMap.get(smsTemplateInfo.getId()), null, null, null, smsTemplateInfo, templateUserInfoMap.get(smsTemplateInfo.getUid()))));
                }
                break;

            case ACCOUNT_AUTHENTICATION :

                List<UserInfo> authUserInfoList = userService.listAccountAuthentication(searchParam);
                if (!CollectionUtils.isEmpty(authUserInfoList)) {
                    authUserInfoList.forEach(userInfo -> bizIdList.add(userInfo.getUid()));
                    Map<Integer, AuditInfo> userAuthAuditInfoMap = auditInfoSerivce.batchGetAuditByBizId(bizIdList, BizType.ACCOUNT_AUTHENTICATION);

                    authUserInfoList.forEach(userInfo -> auditWithBizResponseList.add(AuditVoConverter.bo2Vo(userAuthAuditInfoMap.get(userInfo.getUid()), null, null, null, null, userInfo)));
                }
                break;

            case ACCOUNT_OPENING :

                List<UserInfo> openingUserInfoList = userService.listAccountOpening(searchParam);
                if (!CollectionUtils.isEmpty(openingUserInfoList)) {
                    openingUserInfoList.forEach(userInfo -> bizIdList.add(userInfo.getAppId()));
                    Map<Integer, AuditInfo> userOpeningAuditInfoMap = auditInfoSerivce.batchGetAuditByBizId(bizIdList, BizType.ACCOUNT_OPENING);

                    openingUserInfoList.forEach(userInfo -> auditWithBizResponseList.add(AuditVoConverter.bo2Vo(userOpeningAuditInfoMap.get(userInfo.getAppId()), null, null, null, null, userInfo)));
                }
                break;

            default :

                throw new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NOT_EXIST);
        }

        logger.debug("listAudit, searchRequest:{}, auditWithBizResponseList:{}", searchRequest, auditWithBizResponseList);
        return buildSuccessResp(auditWithBizResponseList);
    }

    @RequestMapping(value = "get_audit_info", method = RequestMethod.GET)
    @ResponseBody
    public FrameResp getAuditBaseVO(@RequestParam("biz_id") Integer bizId,@RequestParam("biz_type") Integer bizType) {
        Preconditions.checkNotNull(bizId, new AuditInfoException(AuditInfoErrorCode.BIZ_ID_NULL_ERROR));
        Preconditions.checkNotNull(bizType, new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NULL_ERROR));
        Preconditions.checkNotNull(BizType.get(bizType), new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NOT_EXIST));
        AuditInfo auditInfo = auditInfoSerivce.getAuditByBizId(bizId, BizType.get(bizType));
        AuditResponse auditResponse = new AuditResponse();
        if (auditInfo != null) {
            BeanUtils.copyProperties(auditInfo, auditResponse);
        }
        return buildSuccessResp(auditResponse);
    }


    @RequestMapping("count")
    @ResponseBody
    @RequiredCmsLogin
    public FrameResp count(@RequestBody SearchRequest searchRequest) {

        logger.info("count, searchRequest:{}", searchRequest);
        Preconditions.checkNotNull(searchRequest.getBizType(), new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NULL_ERROR));

        SearchParam searchParam = convertSearchBO(searchRequest);
        if (StringUtils.isNotEmpty(searchRequest.getEmail())) {
            UserInfo userInfo = userService.getUserInfoByEmail(searchRequest.getEmail().trim());
            Integer uid = userInfo.getUid();
            searchParam.setUid(uid != null ? uid : 0);
        }
        long count = 0;
        switch (BizType.get(searchRequest.getBizType())) {
            case TOP_UP:
                count = topUpService.countTopUp(null, searchParam);
                break;

            case INVOINCE:
                count = invoiceInfoService.countInvoice(null, searchParam);
                break;

            case SIGN:
                count = smsSignService.countSmsSign(null, searchParam);
                break;

            case SMS_TEMPLATE:
                count = smsTemplateService.countSmsTextTemplate(null, searchParam);
                break;

            case ACCOUNT_AUTHENTICATION:
                count = userService.countAccountAuthentication(searchParam);
                break;

            case ACCOUNT_OPENING:
                count = userService.countAccountOpening(searchParam);
                break;

            default:
                throw new AuditInfoException(AuditInfoErrorCode.BIZ_TYPE_NOT_EXIST);
        }
        return buildSuccessResp(count);
    }


    private SearchParam convertSearchBO(SearchRequest searchRequest) {

        SearchParam searchParam = new SearchParam();
        BeanUtils.copyProperties(searchRequest, searchParam);
        try {
            searchParam.setStartDate(searchRequest.getStartDate() == null ? null : DateUtils.parseDate(searchRequest.getStartDate() + " 00:00:00", "yyyy-MM-dd HH:mm:ss"));
            searchParam.setEndDate(searchRequest.getEndDate() == null ? null : DateUtils.parseDate(searchRequest.getEndDate() + " 23:59:59", "yyyy-MM-dd HH:mm:ss"));
        } catch (ParseException ex) {
            throw new AuditInfoException(AuditInfoErrorCode.DATE_FORMAT_ERROR);
        }

        return searchParam;
    }


}
