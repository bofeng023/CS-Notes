package cc.linkedme.account.web;

import cc.linkedme.account.converter.TopUpVoConverter;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.request.TopUpRequest;
import cc.linkedme.account.service.OperativeActivityService;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:31 2019-08-13
 * @:Description
 */
@RestController
@RequestMapping("linkaccount/activity/")
public class OperativeActivityController extends BaseController {

    Logger logger = LoggerFactory.getLogger(OperativeActivityController.class);

    @Resource
    private OperativeActivityService operativeActivityService;


    /**
     *  运营活动给用户充钱
     * @param topUpRequest
     * @return
     */
    @RequestMapping("gift")
    public FrameResp giftMoney(@RequestBody TopUpRequest topUpRequest) {

        logger.info("giftMoney start, topUpRequest:{}", topUpRequest);
        Preconditions.checkNotNull(topUpRequest, new BusinessException(BaseErrorCode.PARAM_NULL_ERROR));

        operativeActivityService.giftMoney(TopUpVoConverter.vo2Bo(topUpRequest));

        return buildSuccessResp();
    }
}
