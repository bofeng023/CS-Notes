package cc.linkedme.account.web;

import cc.linkedme.account.converter.SmsTemplateVoConverter;
import cc.linkedme.account.errorcode.SmsTemplateErrorCode;
import cc.linkedme.account.exception.SmsTemplateException;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.SearchRequest;
import cc.linkedme.account.model.request.SmsTextTemplateRequest;
import cc.linkedme.account.model.response.SmsTextTemplateResponse;
import cc.linkedme.account.model.response.SmsVoiceTemplateResponse;
import cc.linkedme.account.model.sms.SmsTemplateInfo;
import cc.linkedme.account.service.AuditInfoSerivce;
import cc.linkedme.account.service.SmsTemplateService;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping("/linkaccount/sms/template/")
public class SmsTemplateController extends BaseController {

    private static final Logger logger = LoggerFactory.getLogger(SmsTemplateController.class);

    @Resource
    private SmsTemplateService smsTemplateService;
    @Resource
    private AuditInfoSerivce auditInfoSerivce;

    private static final List<String> DEFAULT_TEXT_TEMPLATE_CONTENT = Stream.of(
            "您正在申请手机注册，验证码为：${CODE_NUM_6}，5分钟内有效！",
            "尊敬的用户，您的注册会员动态密码为：${CODE_NUM_6}，请勿泄漏于他人！",
            "您的验证码${CODE_NUM_6}，该验证码5分钟内有效，请勿泄漏于他人！",
            "您的注册码：${CODE_NUM_6}，如非本人操作，请忽略本短信！",
            "您的校验码：${CODE_NUM_6}，您正在注册成为会员，感谢您的支持！",
            "验证码为：${CODE_NUM_6}，您正在注册成为平台会员，感谢您的支持！",
            "验证码为：${CODE_NUM_6}，您正在登录，若非本人操作，请勿泄露。").collect(Collectors.toList());

    private static final List<SmsVoiceTemplateResponse> DEFAULT_VOICE_TEMPLATE_CONTENT = Stream.of(
            new SmsVoiceTemplateResponse("注册", "TTS01", "您正在进行注册操作，验证码${CODE_NUM_6}，感谢您的支持！"),
            new SmsVoiceTemplateResponse("登录", "TTS02", "您正在进行登录操作，验证码${CODE_NUM_6}，感谢您的支持！"),
            new SmsVoiceTemplateResponse("身份验证", "TTS03", "您正在进行身份验证，验证码${CODE_NUM_6}，感谢您的支持！"),
            new SmsVoiceTemplateResponse("验证码","TTS04","您的验证码为${CODE_NUM_6}，感谢您的支持！")).collect(Collectors.toList());

    @RequestMapping("text/save")
    @ResponseBody
    public FrameResp saveSmsTextTemplate(@RequestBody SmsTextTemplateRequest smsTemplateRequest) throws BusinessException {

        logger.info("saveSmsTextTemplate, smsTemplateRequest:{}", smsTemplateRequest);
        Preconditions.checkNotNull(smsTemplateRequest.getUid(), new SmsTemplateException(SmsTemplateErrorCode.UID_NULL_ERROR));
        Preconditions.checkNotNull(smsTemplateRequest.getTemplateName(), new SmsTemplateException(SmsTemplateErrorCode.NAME_NULL_ERROR));
        Preconditions.checkNotNull(smsTemplateRequest.getIsGlobal(), new SmsTemplateException(SmsTemplateErrorCode.GLOBAL_DOMAIN_NULL_ERROR));
        Preconditions.checkNotNull(smsTemplateRequest.getContent(), new SmsTemplateException(SmsTemplateErrorCode.CONTENT_NULL_ERROR));
        Preconditions.checkNotNull(smsTemplateRequest.getApplyRemark(), new SmsTemplateException(SmsTemplateErrorCode.APPLY_REMARK_NULL_ERROR));
        smsTemplateService.checkSmsTemplate(smsTemplateRequest.getContent());

        SmsTemplateInfo smsTemplateInfo = SmsTemplateVoConverter.vo2Bo(smsTemplateRequest);
        smsTemplateInfo = smsTemplateService.saveSmsTemplate(smsTemplateInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setUid(smsTemplateRequest.getUid());
        auditInfo.setBizType(BizType.SMS_TEMPLATE);
        auditInfo.setBizId(smsTemplateInfo.getId());

        auditInfoSerivce.saveAudit(auditInfo);

        SmsTextTemplateResponse smsTextTemplateResponse = SmsTemplateVoConverter.bo2Vo(smsTemplateInfo, auditInfo);
        logger.info("saveSmsTextTemplate, smsTemplateRequest:{}, smsTextTemplateResponse:{}", smsTemplateRequest, smsTextTemplateResponse);

        return buildSuccessResp(smsTextTemplateResponse);

    }

    @RequestMapping("text/update")
    @ResponseBody
    public FrameResp updateSmsTextTemplate(@RequestBody SmsTextTemplateRequest smsTemplateRequest) throws BusinessException {

        logger.info("updateSmsTextTemplate, smsTemplateRequest:{}", smsTemplateRequest);
        Preconditions.checkNotNull(smsTemplateRequest.getId(), new SmsTemplateException(SmsTemplateErrorCode.ID_NULL_ERROR));
        smsTemplateService.checkSmsTemplate(smsTemplateRequest.getContent());

        SmsTemplateInfo smsTemplateInfo = SmsTemplateVoConverter.vo2Bo(smsTemplateRequest);
        smsTemplateService.updateSmsTemplate(smsTemplateInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setAuditState(AuditState.TO_BE_AUDITED);
        auditInfo.setBizId(smsTemplateInfo.getId());
        auditInfo.setBizType(BizType.SMS_TEMPLATE);
        auditInfoSerivce.updateAuditByBizId(auditInfo);

        return buildSuccessResp();
    }

    @RequestMapping("text/remove")
    @ResponseBody
    public FrameResp removeSmsTextTemplate(Integer id) throws BusinessException {

        logger.info("removeSmsTextTemplate, id:{}", id);
        Preconditions.checkNotNull(id, new SmsTemplateException(SmsTemplateErrorCode.ID_NULL_ERROR));

        smsTemplateService.removeSmsTemplate(id);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setAuditState(AuditState.CANCEL);
        auditInfo.setBizId(id);
        auditInfo.setBizType(BizType.SMS_TEMPLATE);
        auditInfoSerivce.updateAuditByBizId(auditInfo);

        return buildSuccessResp();
    }

    @RequestMapping("text/get")
    @ResponseBody
    public FrameResp getSmsTextTemplate(Integer id) throws BusinessException {

        logger.info("getSmsTextTemplate, id:{}", id);
        Preconditions.checkNotNull(id, new SmsTemplateException(SmsTemplateErrorCode.ID_NULL_ERROR));

        SmsTemplateInfo smsTemplateInfo = smsTemplateService.getSmsTemplate(id, null);
        if (smsTemplateInfo == null) {
            return buildSuccessResp();
        }

        AuditInfo auditInfo = auditInfoSerivce.getAuditByBizId(id, BizType.SMS_TEMPLATE);

        SmsTextTemplateResponse smsTextTemplateResponse = SmsTemplateVoConverter.bo2Vo(smsTemplateInfo, auditInfo);
        logger.info("getSmsTextTemplate, id:{}, smsTextTemplateResponse:{}", id, smsTextTemplateResponse);

        return buildSuccessResp(smsTextTemplateResponse);
    }

    @RequestMapping("text/list")
    @ResponseBody
    public FrameResp listSmsTextTemplate(@RequestBody SearchRequest searchRequest) throws BusinessException {

        logger.info("listSmsTextTemplate,searchRequest:{}", searchRequest);
        Integer uid  = searchRequest.getUid();
        Preconditions.checkNotNull(uid, new SmsTemplateException(SmsTemplateErrorCode.UID_NULL_ERROR));
        SearchParam searchParam = new SearchParam();
        BeanUtils.copyProperties(searchRequest, searchParam);

        List<SmsTemplateInfo> smsTemplateInfoList = smsTemplateService.listSmsTemplate(uid, searchParam);

        if (CollectionUtils.isEmpty(smsTemplateInfoList)) {
            return buildSuccessResp();
        }

        List<Integer> templateIdList = new ArrayList<>();
        smsTemplateInfoList.forEach(smsTemplateInfo -> templateIdList.add(smsTemplateInfo.getId()));
        Map<Integer, AuditInfo> auditInfoBOMap = auditInfoSerivce.batchGetAuditByBizId(templateIdList, BizType.SMS_TEMPLATE);

        List<SmsTextTemplateResponse> templateResponseList = new ArrayList<>();
        smsTemplateInfoList.forEach(smsTemplateInfo -> templateResponseList.add(SmsTemplateVoConverter.bo2Vo(smsTemplateInfo, auditInfoBOMap.get(smsTemplateInfo.getId()))));

        logger.debug("listSmsTextTemplate, uid:{}, searchRequest:{}, templateResponseList:{}", uid, searchRequest, templateResponseList);
        return buildSuccessResp(templateResponseList);
    }

    @RequestMapping("text_default/list")
    public FrameResp listSmsTextDefaultTemplate() throws BusinessException {

        logger.info("listSmsTextDefaultTemplate");

        return buildSuccessResp(DEFAULT_TEXT_TEMPLATE_CONTENT);

    }

    @RequestMapping("text/count")
    @ResponseBody
    public FrameResp countSmsTextTemplate(Integer uid) throws BusinessException {

        logger.info("countSmsTextTemplate, uid:{}", uid);
        // 不需要校验uid，支持查询uid和全部
        Long smsTextTemplateCount = smsTemplateService.countSmsTextTemplate(uid,null);

        return buildSuccessResp(smsTextTemplateCount);

    }

    @RequestMapping("voice_default/list")
    @ResponseBody
    public FrameResp listSmsVoiceTemplate() throws BusinessException {

        logger.info("listSmsVoiceTemplate begin!");

        return buildSuccessResp(DEFAULT_VOICE_TEMPLATE_CONTENT);
    }
}
