package cc.linkedme.account.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 搜索条件
 * @author zhanghaowei
 */
@Data
public class SearchRequest implements Serializable {

    private Integer uid;

    private String email;

    private String company;

    @JsonProperty("audit_state")
    private Integer auditState;

    @JsonProperty("app_name")
    private String appName;

    @JsonProperty("start_date")
    private String startDate;

    @JsonProperty("end_date")
    private String endDate;

    @JsonProperty("biz_type")
    private Integer bizType;

    private Integer page;

    private Integer size;

}
