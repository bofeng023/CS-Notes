package cc.linkedme.account.converter;

import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.sms.SmsSignInfo;
import cc.linkedme.account.model.request.SmsSignRequest;
import cc.linkedme.account.model.response.SmsSignResponse;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 20:13
 * @description
 **/
public class SignVoConverter {

    public static SmsSignResponse bo2Vo(SmsSignInfo smsSignInfo) {

        return bo2Vo(smsSignInfo, null);
    }

    public static SmsSignResponse bo2Vo(SmsSignInfo smsSignInfo, AuditInfo auditInfo) {

        SmsSignResponse smsSignResponse = new SmsSignResponse();
        BeanUtils.copyProperties(smsSignInfo, smsSignResponse);
        smsSignResponse.setIsGlobal(smsSignInfo.getIsGlobal() == null ? null : smsSignInfo.getIsGlobal().getIndex().intValue());
        smsSignResponse.setCertificationState(smsSignInfo.getCertificationState() == null ? null : smsSignInfo.getCertificationState().getType());

        if (auditInfo != null) {
            smsSignResponse.setAuditResponse(AuditVoConverter.bo2Vo(auditInfo));
        }

        return smsSignResponse;
    }

    public static SmsSignInfo vo2Bo(SmsSignRequest smsSignRequest) {

        SmsSignInfo smsSignInfo = new SmsSignInfo();
        BeanUtils.copyProperties(smsSignRequest, smsSignInfo);
        smsSignInfo.setIsGlobal(smsSignRequest.getIsGlobal() == null ? null : YesNoEnum.get(smsSignRequest.getIsGlobal().byteValue()));
        smsSignInfo.setCertificationState(smsSignRequest.getCertificationState() == null ? null : AuditState.get(smsSignRequest.getCertificationState()));

        return smsSignInfo;
    }
}
