package cc.linkedme.account.web;

import cc.linkedme.account.converter.InvoiceVoConverter;
import cc.linkedme.account.enums.InvoiceType;
import cc.linkedme.account.errorcode.InvoiceErrorCode;
import cc.linkedme.account.exception.InvoiceException;
import cc.linkedme.account.intercepters.RequiredLogin;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.InvoiceInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.SearchRequest;
import cc.linkedme.account.model.request.InvoiceInfoRequest;
import cc.linkedme.account.model.response.InvoiceResponse;
import cc.linkedme.account.service.AuditInfoSerivce;
import cc.linkedme.account.service.InvoiceService;
import cc.linkedme.account.service.TopUpService;
import cc.linkedme.account.validator.Insert;
import cc.linkedme.account.validator.Update;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.exception.BusinessException;
import cc.linkedme.util.Preconditions;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 发票
 * @author zhanghaowei
 */
@RestController
@RequestMapping("/linkaccount/invoice/")
public class InvoiceController extends BaseController{

    private static final Logger logger = LoggerFactory.getLogger(InvoiceController.class);

    @Resource
    private InvoiceService invoiceInfoService;
    @Resource
    private AuditInfoSerivce auditInfoSerivce;
    @Resource
    private TopUpService topUpService;

    @RequestMapping("save")
    @ResponseBody
    public FrameResp saveInvoice(@Validated(Insert.class) @RequestBody InvoiceInfoRequest invoiceInfoRequest) throws BusinessException {

        logger.info("saveInvoiceInfo, invoiceInfoRequest:{}", invoiceInfoRequest);

        if (InvoiceType.INCREMENT_SPECIAL_USE_INVOICE.getCode().intValue() == invoiceInfoRequest.getInvoiceType().intValue()) {
            Preconditions.checkNotNull(invoiceInfoRequest.getTaxpayerIdentification(), new InvoiceException(InvoiceErrorCode.TAXPAYER_IDENTIFICATION_NULL_ERROR));
            Preconditions.checkNotNull(invoiceInfoRequest.getContactInfo(), new InvoiceException(InvoiceErrorCode.CONTACT_INFO_NULL_ERROR));
            Preconditions.checkNotNull(invoiceInfoRequest.getBankAccountInfo(), new InvoiceException(InvoiceErrorCode.BANK_ACCOUNT_NULL_ERROR));
        }

        InvoiceInfo invoiceInfo = InvoiceVoConverter.vo2Bo(invoiceInfoRequest);

        Integer uid = invoiceInfo.getUid();
        Long amount = topUpService.countHistoryTopUpAmount(uid);
        Long invoiceAmount = invoiceInfoService.countInvoiceAmount(uid);
        //发票金额 《= 历史充值金额-已开票金额
        boolean state = invoiceInfo.getInvoiceAmount() <= (amount - invoiceAmount);
        if (!state) {
            throw new InvoiceException(InvoiceErrorCode.EXCESS_INVOICE_VALUE);
        }

        invoiceInfo = invoiceInfoService.saveInvoiceInfo(invoiceInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setUid(invoiceInfo.getUid());
        auditInfo.setAuditState(AuditState.TO_BE_AUDITED);
        auditInfo.setBizId(invoiceInfo.getId());
        auditInfo.setBizType(BizType.INVOINCE);
        auditInfoSerivce.saveAudit(auditInfo);

        logger.info("saveInvoiceInfo, invoiceInfoRequest:{}, invoiceInfo:{}", invoiceInfoRequest, invoiceInfo);
        return buildSuccessResp(invoiceInfo);
    }

    @RequestMapping("update")
    @ResponseBody
    public FrameResp updateInvoice(@Validated(Update.class) @RequestBody InvoiceInfoRequest invoiceInfoRequest) throws BusinessException {

        logger.info("updateInvoice, invoiceInfoRequest:{}", invoiceInfoRequest);

        if (invoiceInfoRequest.getInvoiceType() != null && InvoiceType.INCREMENT_SPECIAL_USE_INVOICE.getCode().intValue() == invoiceInfoRequest.getInvoiceType().intValue()) {
            Preconditions.checkNotNull(invoiceInfoRequest.getTaxpayerIdentification(), new InvoiceException(InvoiceErrorCode.TAXPAYER_IDENTIFICATION_NULL_ERROR));
            Preconditions.checkNotNull(invoiceInfoRequest.getContactInfo(), new InvoiceException(InvoiceErrorCode.CONTACT_INFO_NULL_ERROR));
            Preconditions.checkNotNull(invoiceInfoRequest.getBankAccountInfo(), new InvoiceException(InvoiceErrorCode.BANK_ACCOUNT_NULL_ERROR));
        }

        InvoiceInfo invoiceInfo = InvoiceVoConverter.vo2Bo(invoiceInfoRequest);

        Integer uid = invoiceInfo.getUid();
        Long amount = topUpService.countHistoryTopUpAmount(uid);
        Long invoiceAmount = invoiceInfoService.countInvoiceAmount(uid);
        //发票金额 《= 历史充值金额-已开票金额
        boolean state = invoiceInfo.getInvoiceAmount() <= (amount - invoiceAmount);
        if (!state) {
            Preconditions.checkNotNull(invoiceInfoRequest.getBankAccountInfo(), new InvoiceException(InvoiceErrorCode.EXCESS_INVOICE_VALUE));
        }

        invoiceInfoService.updateInvoiceInfo(invoiceInfo);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setBizId(invoiceInfo.getId());
        auditInfo.setBizType(BizType.INVOINCE);
        auditInfo.setAuditState(AuditState.TO_BE_AUDITED);
        auditInfoSerivce.updateAuditByBizId(auditInfo);


        return buildSuccessResp();
    }

    @RequestMapping("get")
    @ResponseBody
    public FrameResp getInvoice(@RequestParam(name = "id") Integer id) throws BusinessException {

        logger.info("getInvoice, id:{}", id);
        Preconditions.checkNotNull(id, new InvoiceException(InvoiceErrorCode.ID_NULL_ERROR));

        InvoiceInfo invoiceInfo = invoiceInfoService.getInvoiceInfo(id);
        if (invoiceInfo == null) {
            return buildSuccessResp();
        }

        AuditInfo auditInfo = auditInfoSerivce.getAuditByBizId(id, BizType.INVOINCE);

        InvoiceResponse invoiceResponse = InvoiceVoConverter.bo2Vo(invoiceInfo, auditInfo);
        logger.info("getInvoice, id:{}, invoiceResponse:{}", id, invoiceResponse);

        return buildSuccessResp(invoiceResponse);
    }


    @RequestMapping("list")
    @ResponseBody
    @RequiredLogin
    public FrameResp listInvoice(@RequestBody SearchRequest searchRequest) throws BusinessException {

        logger.info("listInvoice, searchRequest:{}", searchRequest);
        //发票查询当前用户ID
        Preconditions.checkNotNull(searchRequest.getUid(), new InvoiceException(BaseErrorCode.UID_NULL_ERROR));

        SearchParam searchParam = new SearchParam();
        BeanUtils.copyProperties(searchRequest, searchParam);
        List<InvoiceInfo> invoiceInfoList = invoiceInfoService.listInvoice(searchParam);
        if (CollectionUtils.isEmpty(invoiceInfoList)) {
            return buildSuccessResp();
        }

        List<Integer> invoiceIdList = new ArrayList<>();
        invoiceInfoList.forEach(invoiceInfo -> invoiceIdList.add(invoiceInfo.getId()));
        Map<Integer, AuditInfo> auditInfoMap = auditInfoSerivce.batchGetAuditByBizId(invoiceIdList, BizType.INVOINCE);

        List<InvoiceResponse> invoiceResponseList = invoiceInfoList.stream().map(invoiceInfo -> InvoiceVoConverter.bo2Vo(invoiceInfo, auditInfoMap.get(invoiceInfo.getId()))).collect(Collectors.toList());
        logger.debug("listInvoice, searchRequest:{}, invoiceResponseList:{}", searchRequest, invoiceResponseList);

        return buildSuccessResp(invoiceResponseList);
    }

    /**
     * 统计总条数
     * @return int
     */
    @RequestMapping("count")
    @ResponseBody
    public FrameResp countInvoice(Integer uid) throws BusinessException {

        logger.info("countInvoice, uid:{}");

        Long invoiceCount = invoiceInfoService.countInvoice(uid,null);

        return buildSuccessResp(invoiceCount);

    }

    /**
     * 发票取消
     * @param id 发票ID
     * @return FrameResp
     */
    @RequestMapping("cancel")
    @ResponseBody
    public FrameResp cancelInvoice(@RequestParam("id") Integer id) {
        logger.info("cancelInvoice, id:{}",id);

        Preconditions.checkNotNull(id, new InvoiceException(BaseErrorCode.ID_NOT_VALID));

        invoiceInfoService.cancelInvoice(id);

        AuditInfo auditInfo = new AuditInfo();
        auditInfo.setBizId(id);
        auditInfo.setBizType(BizType.INVOINCE);
        auditInfo.setAuditState(AuditState.CANCEL);
        auditInfoSerivce.updateAuditByBizId(auditInfo);

        logger.info("cancelInvoice, id:{}, auditInfo:{}", id, auditInfo);
        return buildSuccessResp();

    }
}
