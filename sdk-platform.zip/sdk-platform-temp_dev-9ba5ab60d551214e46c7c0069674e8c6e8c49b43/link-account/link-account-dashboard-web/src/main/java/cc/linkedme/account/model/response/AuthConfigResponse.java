package cc.linkedme.account.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author yangpeng
 * @date 2019-06-17 21:07
 * @description
 **/
@Data
public class AuthConfigResponse implements Serializable {

    private Integer id;

    private Integer appId;

    private String appKey;

    private String appSecret;

    private String publicKey;

    /**
     * dashboard 白名单
     */
    private String ipWhitelist;

    private String accountIpWhitelist;

    private Cmcc cmcc;

    private Ctcc ctcc;

    private Cucc cucc;

    @Data
    public static class Cmcc {

        private String androidAppId;

        private String androidAppKey;

        private String androidAppSecret;

        private String iosAppId;

        private String iosAppKey;

        private String iosAppSecret;

        private String privateKey;

        private String publicKey;

    }

    @Data
    public static class Ctcc {

        private String appId;

        private String appSecret;

        private String privateKey;

        private String publicKey;
    }

    @Data
    public static class Cucc {

        private String clientId;

        private String clientSecret;

        private String grantSecret;

        private String privateKey;

        private String publicKey;
    }

}
