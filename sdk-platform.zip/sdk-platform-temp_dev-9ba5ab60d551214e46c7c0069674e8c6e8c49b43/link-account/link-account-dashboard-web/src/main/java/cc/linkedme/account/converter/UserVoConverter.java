package cc.linkedme.account.converter;

import cc.linkedme.account.model.UserInfo;
import cc.linkedme.account.model.request.UserRequest;
import cc.linkedme.account.model.response.UserResponse;
import cc.linkedme.account.model.response.UserResponse.LinkAccount;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 21:10
 * @description
 **/
public class UserVoConverter {

    public static UserResponse bo2Vo(UserInfo userInfo) {

        if (userInfo == null ) {
            return null;
        }
        UserResponse userResponse = new UserResponse();
        BeanUtils.copyProperties(userInfo, userResponse);
        UserInfo.LinkAccount linkAccount = userInfo.getLinkAccount();
        if (linkAccount != null) {
            LinkAccount linkAccountResponse = userResponse.new LinkAccount();
            BeanUtils.copyProperties(linkAccount,linkAccountResponse);
            userResponse.setLinkAccount(linkAccountResponse);
        }
        return userResponse;
    }

    public static UserInfo vo2Bo(UserRequest userRequest) {

        if (userRequest == null ) {
            return null;
        }
        UserInfo userInfo = new UserInfo();
        BeanUtils.copyProperties(userRequest, userInfo);
        userInfo.setAuditState(userRequest.getAuditState() != null ? AuditState.get(userRequest.getAuditState()) : null);
        userInfo.setActiveStatus(userRequest.getActiveStatus() != null ? YesNoEnum.get(userRequest.getActiveStatus().byteValue()) : null);
        return userInfo;
    }
}
