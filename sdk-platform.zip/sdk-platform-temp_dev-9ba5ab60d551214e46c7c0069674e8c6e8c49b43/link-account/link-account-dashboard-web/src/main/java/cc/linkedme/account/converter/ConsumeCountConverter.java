package cc.linkedme.account.converter;

import cc.linkedme.account.model.ConsumeCountInfo;
import cc.linkedme.account.model.response.ConsumeCountResponse;
import cc.linkedme.account.common.util.DigitalUtil;
import org.springframework.beans.BeanUtils;

import java.util.Date;

/**
 * @author zhanghaowei
 * @date 2019-6-5 09:25
 * @description
 **/
public class ConsumeCountConverter {

    public static ConsumeCountResponse bo2Vo(ConsumeCountInfo consumeCountBO) {

        ConsumeCountResponse consumeCountResponse = new ConsumeCountResponse();
        Long hourSlot = consumeCountBO.getHourSlot();
        Integer totalAmount = consumeCountBO.getTotalAmount();
        BeanUtils.copyProperties(consumeCountBO,consumeCountResponse);
        if (totalAmount != null) {
            consumeCountResponse.setTotalAmount(DigitalUtil.moneyConverToDouble(totalAmount));
        }
        if (hourSlot != null) {
            consumeCountResponse.setHourSlot(new Date(hourSlot));
        }
        return consumeCountResponse;
    }

    public static ConsumeCountInfo vo2Bo(ConsumeCountResponse consumeCountResponse) {

        ConsumeCountInfo consumeCountBO = new ConsumeCountInfo();
        Date hourSlot = consumeCountResponse.getHourSlot();
        Double totalAmount = consumeCountResponse.getTotalAmount();
        BeanUtils.copyProperties(consumeCountResponse,consumeCountBO);
        if (totalAmount != null) {
            consumeCountBO.setTotalAmount(DigitalUtil.moneyConvertToInteger(String.valueOf(totalAmount)));
        }
        if (hourSlot != null) {
            consumeCountBO.setHourSlot(hourSlot.getTime());
        }
        return consumeCountBO;

    }
}

