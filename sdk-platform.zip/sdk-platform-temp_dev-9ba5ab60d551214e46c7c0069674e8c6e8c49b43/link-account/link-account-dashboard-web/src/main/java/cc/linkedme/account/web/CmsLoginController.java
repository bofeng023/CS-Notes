package cc.linkedme.account.web;

import cc.linkedme.account.common.crypto.MD5;
import cc.linkedme.account.common.util.CookieUtils;
import cc.linkedme.account.common.util.LdapHelper;
import cc.linkedme.account.errorcode.CmsLoginErrorCode;
import cc.linkedme.account.exception.CmsLoginException;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.request.CmsUserRequest;
import cc.linkedme.account.model.response.CmsUserResponse;
import cc.linkedme.cache.redis.RedisClientUtil;
import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.util.Preconditions;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.LdapContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.util.UUID;

/**
 * @author zhanghaowei
 * @date 2019-6-6 11:42
 * @description
 **/
@RestController
@RequestMapping("/linkaccount/cms/")
public class CmsLoginController extends BaseController {

    Logger logger = LoggerFactory.getLogger(CmsLoginController.class);

    /**
     * 有效期
     */
    private static final int CACHESECONDS = 6 * 60 * 60;

    /**
     * 密码重试时间
     */
    private static final int PASSWORD_RETRY_TIME = 5 * 60;

    /**
     * 重试次数
     */
    private static final int RETRY_COUNT = 5;

    @Resource
    private RedisClientUtil cacheRedisClient;

    /**
     * 登录
     */
    @RequestMapping(path = "/login", method = RequestMethod.POST)
    @ResponseBody
    public FrameResp ldapLogin(@RequestBody CmsUserRequest cmsUserRequest, HttpServletResponse response) {

        logger.info("ldapLogin cmsUserRequest:{}", cmsUserRequest);

        Preconditions.checkNotNull(cmsUserRequest, new CmsLoginException(BaseErrorCode.PARAM_INVALID_ERROR));

        String email = cmsUserRequest.getEmail();
        Preconditions.checkNotNull(email, new CmsLoginException(CmsLoginErrorCode.EMAIL_NOT_EMPTY));

        String password = cmsUserRequest.getPassword();
        Preconditions.checkNotNull(password, new CmsLoginException(CmsLoginErrorCode.PASSWORD_NOT_EMPTY));


        if (StringUtils.isEmpty(email) || StringUtils.isEmpty(password)) {
            return buildErrorResp(BaseErrorCode.PARAM_INVALID_ERROR);
        }

        String key = MD5.GetMD5Code("cmsUserCount" + email);
        String count = cacheRedisClient.get(key);
        if (count != null && Integer.valueOf(count) > RETRY_COUNT) {
            return buildErrorResp(CmsLoginErrorCode.TOO_MANY_LOGINS_FAIL);
        }

        LdapContext ctx = null;
        String userDN = "";
        try {
            Control[] connCtls = null;
            ctx = LdapHelper.getCtx();
            SearchControls constraints = new SearchControls();
            constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
            NamingEnumeration<SearchResult> en = ctx.search("dc=linkedme,dc=cc", "uid=" + email, constraints);
            if (en == null || !en.hasMoreElements()) {
                return buildErrorResp(CmsLoginErrorCode.USER_NOT_EXIST);
            }
            // maybe more than one element
            while (en != null && en.hasMoreElements()) {
                Object obj = en.nextElement();
                if (obj instanceof SearchResult) {
                    SearchResult si = (SearchResult) obj;
                    userDN += si.getName();
                    userDN += "," + "dc=linkedme,dc=cc";
                    ctx.addToEnvironment(Context.SECURITY_PRINCIPAL, userDN);
                    ctx.addToEnvironment(Context.SECURITY_CREDENTIALS, password);
                    ctx.reconnect(connCtls);
                    logger.info("ldapLogin verification passed ctx:{}", ctx);
                    cacheRedisClient.del(key);
                    return operateUserInformation(cmsUserRequest, response);
                } else {
                    long retryCount = cacheRedisClient.incr(key);
                    if (retryCount == 1) {
                        cacheRedisClient.expire(key, PASSWORD_RETRY_TIME);
                    }
                    logger.info("ldapLogin retryCount:{}", retryCount);

                    return buildErrorResp(CmsLoginErrorCode.USER_PASSWORD_ERROR);
                }
            }
        } catch (Exception e) {
            long retryCount = cacheRedisClient.incr(key);
            if (retryCount == 1) {
                cacheRedisClient.expire(key, PASSWORD_RETRY_TIME);
            }
            logger.info("ldapLogin retryCount:{}", retryCount);

            return buildErrorResp(CmsLoginErrorCode.USER_PASSWORD_ERROR);
        }
        return buildSuccessResp();
    }

    /**
     * 登出系统
     */
    @RequestMapping("loginOut")
    @ResponseBody
    public FrameResp cmsLogOut(@CookieValue(value="account_token") String token,
                               HttpServletRequest request, HttpServletResponse response) {

        cacheRedisClient.del(token);
        CookieUtils.removeCookie(request,response,"account_token");

        return buildSuccessResp();
    }

    private FrameResp operateUserInformation(CmsUserRequest cmsUserRequest, HttpServletResponse response) {
        String token = MD5.GetMD5Code(UUID.randomUUID().toString() + System.nanoTime());

        logger.info("operateUserInformation create token:{}", token);

        //生成缓存需要的对象
        CmsUserResponse cacheUser = new CmsUserResponse();

        //缓存内存储email唯一标识
        cacheUser.setEmail(cmsUserRequest.getEmail());
        cacheUser.setToken(token);
        cacheRedisClient.setex(token, cmsUserRequest.getEmail(), CACHESECONDS);

        CookieUtils.setCookie(response, "account_token", token, CACHESECONDS);
        String goUrl = "/index.html";
        if (StringUtils.isNotEmpty(cmsUserRequest.getGoUrl())) {
            try {
                goUrl = URLDecoder.decode(String.valueOf(cmsUserRequest.getGoUrl()), "UTF-8");
            } catch (Exception e) {
                logger.error("operateUserInformation go to url fail", e);
            }
        }
        cacheUser.setGoUrl(goUrl);
        return buildSuccessResp(cacheUser);
    }

}
