package cc.linkedme.account.model.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: liuyunmeng
 * @Date: Create in 18:03 2019-08-15
 * @:Description
 */
@Data
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class MessageResponse implements Serializable {

    private Long id;

    private Integer senderId;

    private Integer receiverId;

    private String sendTime;

    private String title;

    private String content;

    private Integer messageType;

}
