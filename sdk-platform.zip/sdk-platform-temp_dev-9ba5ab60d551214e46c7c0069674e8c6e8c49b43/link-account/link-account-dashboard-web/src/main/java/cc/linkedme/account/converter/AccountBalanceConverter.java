package cc.linkedme.account.converter;

import cc.linkedme.account.model.AccountBalanceInfo;
import cc.linkedme.account.model.response.AccountBalanceResponse;
import cc.linkedme.account.common.util.DigitalUtil;
import org.springframework.beans.BeanUtils;

/**
 * @author zhanghaowei
 * @date 2019-6-5 09:45
 * @description
 **/
public class AccountBalanceConverter {

    public static AccountBalanceResponse bo2Vo(AccountBalanceInfo accountBalanceBO) {
        AccountBalanceResponse accountBalanceResponse = new AccountBalanceResponse();
        BeanUtils.copyProperties(accountBalanceBO,accountBalanceResponse);
        Integer balance = accountBalanceBO.getBalance();
        accountBalanceResponse.setBalance(DigitalUtil.moneyConverToDouble(balance));
        return accountBalanceResponse;
    }

    public static AccountBalanceInfo vo2Bo(AccountBalanceResponse accountBalanceResponse) {
        AccountBalanceInfo accountBalanceBO = new AccountBalanceInfo();
        BeanUtils.copyProperties(accountBalanceResponse,accountBalanceBO);
        Double balance = accountBalanceResponse.getBalance();
        accountBalanceBO.setBalance(DigitalUtil.moneyConvertToInteger(String.valueOf(balance)));
        return accountBalanceBO;
    }
}
