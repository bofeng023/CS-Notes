package cc.linkedme.account.converter;

import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.account.model.sms.SmsTemplateInfo;
import cc.linkedme.account.model.request.SmsTextTemplateRequest;
import cc.linkedme.account.model.response.SmsTextTemplateResponse;
import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import org.springframework.beans.BeanUtils;

/**
 * @author yangpeng
 * @date 2019-05-31 18:45
 * @description
 **/
public class SmsTemplateVoConverter {

    public static SmsTextTemplateResponse bo2Vo(SmsTemplateInfo smsTemplateInfo) {

        return bo2Vo(smsTemplateInfo, null);
    }

    public static SmsTextTemplateResponse bo2Vo(SmsTemplateInfo smsTemplateInfo, AuditInfo auditInfo) {

        SmsTextTemplateResponse smsTextTemplateResponse = new SmsTextTemplateResponse();
        BeanUtils.copyProperties(smsTemplateInfo, smsTextTemplateResponse);
        smsTextTemplateResponse.setCertificationState(smsTemplateInfo.getCertificationState() == null ? null : smsTemplateInfo.getCertificationState().getType());
        smsTextTemplateResponse.setIsGlobal(smsTemplateInfo.getIsGlobal() == null ? null : smsTemplateInfo.getIsGlobal().getIndex().intValue());

        if (auditInfo != null) {
            smsTextTemplateResponse.setAuditResponse(AuditVoConverter.bo2Vo(auditInfo));
        }

        return smsTextTemplateResponse;
    }

    public static SmsTemplateInfo vo2Bo(SmsTextTemplateRequest smsTextTemplateRequest) {

        SmsTemplateInfo smsTemplateInfo = new SmsTemplateInfo();
        BeanUtils.copyProperties(smsTextTemplateRequest, smsTemplateInfo);
        smsTemplateInfo.setCertificationState(smsTextTemplateRequest.getCertificationState() == null ? null : AuditState.get(smsTextTemplateRequest.getCertificationState()));
        smsTemplateInfo.setIsGlobal(smsTextTemplateRequest.getIsGlobal() == null ? null : YesNoEnum.get(smsTextTemplateRequest.getIsGlobal().byteValue()));

        return smsTemplateInfo;
    }
}
