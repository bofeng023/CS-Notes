package cc.linkedme.account.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

import java.io.Serializable;

/**
 * 用户信息
 * @author zhanghaowei
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class UserResponse implements Serializable {

    private Integer uid;

    private String email;

    private String name;

    private String company;

    private String phoneNumber;

    @JsonProperty("QQ_number")
    private String qqNumber;

    private Integer identity;

    private String unifiedBusinessCode;

    private String identityCardNumber;

    private String authSubmitTime;

    private String companyLicense;

    private String authenticationName;

    private String authenticationEmail;

    private String authenticationPhone;

    private Integer appId;

    private String appName;

    private String linkAccountSubmitTime;

    private String androidPackageName;

    private String iosBundleId;

    private String androidSignMd5;

    private String identityCardFront;

    private String identityCardBack;

    private String identityCardHand;

    private LinkAccount linkAccount;

    @Data
    public class LinkAccount {

        @JsonProperty("has_ios")
        private Boolean hasIos;

        @JsonProperty("has_android")
        private Boolean hasAndroid;

        @JsonProperty("audit_state")
        private Integer auditState;
    }

    private AuditResponse auditResponse;

}
