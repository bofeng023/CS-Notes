package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:45 2019-08-14
 * @:Description
 */
public interface MessageErrorCode extends BaseErrorCode {

    ErrorCode INVALID_SENDER_ID = new ErrorCode(140001, "invalid senderId");

    ErrorCode INVALID_RECEIVER_ID = new ErrorCode(140002, "invalid user id");

    ErrorCode INVALID_TYPE = new ErrorCode(140003, "invalid message type");

    ErrorCode INVALID_READ_STATUS = new ErrorCode(140004, "invalid read_status");

    ErrorCode INVALID_MESSAGE_ID = new ErrorCode(140005, "invalid messageId");
}
