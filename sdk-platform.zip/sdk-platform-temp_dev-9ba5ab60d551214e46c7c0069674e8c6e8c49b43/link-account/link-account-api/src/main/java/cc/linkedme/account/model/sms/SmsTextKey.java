package cc.linkedme.account.model.sms;

import cc.linkedme.account.model.BalanceUnitPrice;
import lombok.Data;

/**
 * @author lipeng
 * @date 2019-07-31 17:13
 * @description
 **/
@Data
public class SmsTextKey {

    private String callback;

    private BalanceUnitPrice balanceUnitPrice;

    private Integer contentCount;

    private Integer unitPrice;

    private String extend;
}
