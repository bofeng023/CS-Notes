package cc.linkedme.account.model.sms;

import cc.linkedme.account.enums.provider.sms.huawei.HuaweiVoiceSmsCallBackStatus;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: liuyunmeng
 * @Date: Create in 19:18 2019-07-24
 * @:Description
 */
@Data
public class VoiceSmsCallbackInfo implements Serializable {

    private static final long serialVersionUID = -2544677816251741804L;

    /**
     * 发起此次呼叫的CallEnabler业务号码
     */
    private String bindNum;

    /**
     * 通话链路的唯一标识
     */
    private String msgId;

    /**
     * 主叫号码，号码为全局号码格式（包含国家码）
     */
    private String callerNum;

    /**
     * 被叫号码，号码为全局号码格式（包含国家码）
     */
    private String recipient;

    /**
     * 呼叫结束时间。
     * 该参数为UTC时间（+8小时为北京时间），时间格式为“yyyy-MM-dd HH:mm:ss”
     */
    private String callEndTime;

    /**
     * 呼入、呼出的失败时间
     */
    private String failTime;

    /**
     * 通话状态
     */
    private HuaweiVoiceSmsCallBackStatus huaweiVoiceSmsCallBackStatus;

    /**
     * Initcall的呼出开始时间
     */
    private String callOutStartTime;

    /**
     * Initcall的呼出应答时间
     */
    private String callOutAnswerTime;

    /**
     * 用户附属信息，此参数的值与“语音通知API”中的"extend"参数值一致
     */
    private String extend;


}
