package cc.linkedme.account.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanghaowei
 * @date 2019-7-9 16:46
 * @description 交易业务类型
 **/
public enum TradingType {

    CREDIT(0, "授信额度平账"),
    TOP_UP(1, "账户充值"),
    CONSUME(2, "扣除"),
    REFUND(3, "退款"),
    OTHER(100,"其它");

    private Integer type;

    private String name;

    TradingType(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private static final Map<Integer, TradingType> lookup = new HashMap();

    static {
        for (TradingType tradingType : EnumSet.allOf(TradingType.class)) {
            lookup.put(tradingType.getType(), tradingType);
        }
    }

    public static TradingType get(Integer type) {

        return lookup.get(type);
    }
}
