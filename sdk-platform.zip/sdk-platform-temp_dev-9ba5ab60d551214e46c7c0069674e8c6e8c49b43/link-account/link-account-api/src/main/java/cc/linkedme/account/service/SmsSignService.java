package cc.linkedme.account.service;

import cc.linkedme.account.exception.SmsSignException;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.sms.SmsSignInfo;
import cc.linkedme.enums.AuditState;

import java.util.List;
import java.util.Map;

public interface SmsSignService {

    SmsSignInfo saveSmsSign(SmsSignInfo smsSignInfo) throws SmsSignException;

    Integer updateSmsSign(SmsSignInfo smsSignInfo) throws SmsSignException;

    void removeSmsSign(Integer smsSignId) throws SmsSignException;

    SmsSignInfo getSmsSign(Integer smsSignId) throws SmsSignException;

    SmsSignInfo getSmsSign(String signName, Integer appId, AuditState certificationState) throws SmsSignException;

    Map<Integer, SmsSignInfo> getBatchSmsSign(List<Integer> smsSignIdList) throws SmsSignException;

    List<SmsSignInfo> listSmsSign(Integer uid, SearchParam searchParam) throws SmsSignException;

//    SmsSignInfo getSmsSignAndAuditInfo(Integer smsSignId) throws SmsSignException;

    Long countSmsSign(Integer uid, SearchParam searchParam) throws SmsSignException;

    Long countAuditPassGlobal(Integer uid) throws SmsSignException;

    SmsSignInfo getSmsSign(Integer appId, String smsSignName) throws SmsSignException;

}
