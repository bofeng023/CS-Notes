package cc.linkedme.account.common.profile.json;


public class JsonUtil {

    /**
     * toJson Object need implements Jsonable
     *
     * @param values
     * @return
     */
    public static String toJson(Jsonable[] values) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        if (values != null) {
            for (int i = 0; i < values.length; i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(values[i].toJson());
            }
        }
        sb.append("]");
        return sb.toString();
    }

    /**
     * xml 1.0: 0-31,127控制字符为非法内容，转为空格
     *
     * @param value
     * @return
     */
    public static String toJsonStr(String value) {
        if (value == null) return null;

        StringBuilder buf = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"':
                    buf.append("\\\"");
                    break;
                case '\\':
                    buf.append("\\\\");
                    break;
                case '\n':
                    buf.append("\\n");
                    break;
                case '\r':
                    buf.append("\\r");
                    break;
                case '\t':
                    buf.append("\\t");
                    break;
                case '\f':
                    buf.append("\\f");
                    break;
                case '\b':
                    buf.append("\\b");
                    break;

                default:
                    if (c < 32 || c == 127) {
                        buf.append(" ");
                    } else {
                        buf.append(c);
                    }
            }
        }
        return buf.toString();
    }

}
