package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;
import lombok.Data;

/**
 * 数据异常类
 * @author zhanghaowei
 */
@Data
public class ConsumeCountException extends BusinessException {
    public ConsumeCountException(ErrorCode errorCode) {
        super(errorCode);
    }
}
