package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

/**
 * @author zhanghaowei
 * @date 2019-6-4 11:05
 * @description
 **/
public interface AccountBalanceErrorCode extends BaseErrorCode {

    ErrorCode BALANCE_NULL_ERROR = new ErrorCode(700001, "充值账户余额不能为空");

    ErrorCode NO_QUATOS = new ErrorCode(7000002, "余额不足");

    ErrorCode CONTRACT_AMOUNT_LESS_THEN_CREDIT_CONSUMED = new ErrorCode(700003, "本次充值额度少于信用额度已消耗量，不足以平账");

    ErrorCode CONSUME_COUNT_INVALID = new ErrorCode(700004, "扣费次数不合法");


}
