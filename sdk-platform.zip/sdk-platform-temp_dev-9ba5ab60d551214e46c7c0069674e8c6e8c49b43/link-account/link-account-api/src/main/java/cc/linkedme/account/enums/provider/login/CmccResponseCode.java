package cc.linkedme.account.enums.provider.login;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum CmccResponseCode {

    SUCCESS("103000", "返回成功"),
    SIGN_ERROR("103101", "签名错误"),
    TOKEN_ERROR("103113", "token内容错误"),
    APP_ID_NOT_EXIST("103119", "appid不存在"),
    SOURCE_ID_ILLEGAL("103133", "sourceid不合法"),
    OTHER_ERROR("103211", "其他错误"),
    INVALID_REQUEST("103412", "无效的请求"),
    PARAM_VERIFY_ERROR("103414", "参数检验异常"),
    TOKEN_NULL("103811", "token为空"),
    TOKEN_INVALID("104201", "token失效或不存在"),
    PERMISSION_DENIED("105018", "用户权限不足"),
    APP_NO_AUTHORIZATION("105019", "应用未授权"),

    OWN_NUMBER("000", "是本机号码"),
    NO_OWN_NUMBER("001", "非本机号码"),
    GET_NUMBER_FAILED("002", "取号失败"),
    TOKEN_INTERNAL_VERIFY_FAILED("003", "调用内部token校验接口失败"),
    MOBILE_ENCRYPT_ERROR("004", "加密手机号码错误"),
    PARAM_INVALID("102", "参数无效"),
    WHITELIST_VERIFY_ERROR("124", "白名单校验失败"),
    SING_VERIFY_ERROR("302", "sign校验失败"),
    PARAM_ERROR("303", "参数解析错误"),
    TOKEN_VERIFY_FAILED("606", "验证token失败"),
    SYSTEM_ERROR("999", "系统异常"),
    NO_QUOTAS("102315", "次数已用完");

    private String code;

    private String msg;

    CmccResponseCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private static final Map<String, CmccResponseCode> lookup = new HashMap<>();
    static {
        for (CmccResponseCode responseCode : EnumSet.allOf(CmccResponseCode.class)) {
            lookup.put(responseCode.getCode(), responseCode);
        }
    }

    public static CmccResponseCode get(String code) {
        return lookup.get(code);
    }
}
