package cc.linkedme.account.common.http;

import lombok.Setter;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * @author yangpeng
 * @date 2019-07-25 15:55
 * @description
 **/
public class HttpClientNew {

    private static final Logger logger = LoggerFactory.getLogger(HttpClientNew.class);
    private CloseableHttpClient httpClient;
    private PoolingHttpClientConnectionManager connectionManager;
    private RequestConfig requestConfig;

    @Setter
    private int SOCKET_TIMEOUT_MS = 2000;
    @Setter
    private int CONNECT_TIMEOUT_MS = 6000;
    @Setter
    private int CONNECT_REQUEST_TIMEOUT_MS = 1000;
    @Setter
    private int MAX_TOTAL = 600;
    @Setter
    private int DEFAULT_MAX_PER_ROUTE = 100;

    public void init() {
        connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(MAX_TOTAL);
        connectionManager.setDefaultMaxPerRoute(DEFAULT_MAX_PER_ROUTE);

        requestConfig = RequestConfig.custom().setConnectTimeout(CONNECT_TIMEOUT_MS)
                .setSocketTimeout(SOCKET_TIMEOUT_MS).setConnectionRequestTimeout(CONNECT_REQUEST_TIMEOUT_MS).build();

        httpClient = HttpClients.custom().setConnectionManager(connectionManager).setDefaultRequestConfig(requestConfig).build();
    }

    public void get(String url, List<NameValuePair> headerPairList, List<NameValuePair> paramPairList) {

        HttpGet httpGet = new HttpGet(url);
        HttpPost httpPost = new HttpPost(url);
    }


}
