package cc.linkedme.account.constants;

/**
 * @Author: liuyunmeng
 * @Date: Create in 14:33 2019-08-16
 * @:Description
 */
public class AuditConstants {

    public static final String AUDIT_PASSWORD = "1234567890";
}
