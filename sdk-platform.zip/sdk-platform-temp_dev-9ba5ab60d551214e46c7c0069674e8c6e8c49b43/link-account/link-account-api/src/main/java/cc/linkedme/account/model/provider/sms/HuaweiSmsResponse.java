package cc.linkedme.account.model.provider.sms;

import lombok.Data;

import java.util.List;

/**
 * @author zhanghaowei
 * @date 2019-07-29 16:05
 * @description
 **/

@Data
public class HuaweiSmsResponse {

    private String code;

    private String description;

    private List<HuaweiSmsResponse.SmsID> result;

    @Data
    public static class SmsID {

        private String smsMsgId;

        private String from;

        private String originTo;

        private String createTime;

        private String status;

    }
}
