package cc.linkedme.account.model.sms;

import lombok.Data;

import java.io.Serializable;

/**
 * @author zhanghaowei
 * @date 2019-7-16 15:50
 * @description
 **/
@Data
public class SmsCallbackInfo implements Serializable {

    private static final long serialVersionUID = 2513633955904759861L;

    /**
     * 短信唯一标识
     */
    private String msgId;

    /**
     * 短信条数
     */
    private String total;

    /**
     * 长短信拆分后的短信序号，当total参数取值 大于1时，该参数才有效
     */
    private String sequence;

    /**
     * 短信状态报告
     */
    private String status;

    /**
     * 短信报告内容
     */
    private String msg;

    /**
     * 短信状态报告来源
     */
    private String source;

    /**
     * 短信资源的更新时间
     */
    private String updateTime;

    /**
     * 扩展字段
     */
    private String extend;

    /**
     * 接收方号码
     */
    private String recipient;

    public void setStatusMsg(String status, String msg) {
        this.status = status;
        this.msg = msg;
    }
}
