package cc.linkedme.account.service;

import cc.linkedme.account.exception.AuthConfigException;
import cc.linkedme.account.model.AuthConfigInfo;

public interface AuthConfigService {

    AuthConfigInfo saveAuthConfig(AuthConfigInfo authConfigInfo) throws AuthConfigException;

    void updateAuthConfig(AuthConfigInfo authConfigInfo) throws AuthConfigException;

    /**
     * 读取cmcc、ctcc、cucc认证配置信息
     * @param appId
     * @return
     * @throws AuthConfigException
     */
    AuthConfigInfo getAuthConfig(Integer appId) throws AuthConfigException;

    /**
     * 
     * @param appId
     * @param appKey
     * @return
     * @throws AuthConfigException
     */
    AuthConfigInfo getAuthConifgInfo(Integer appId, String appKey) throws AuthConfigException;
    
    /**
     * 只读取
     * @return
     * @throws AuthConfigException
     */
    AuthConfigInfo getCuccAuthConfig(Integer appId) throws AuthConfigException;
}
