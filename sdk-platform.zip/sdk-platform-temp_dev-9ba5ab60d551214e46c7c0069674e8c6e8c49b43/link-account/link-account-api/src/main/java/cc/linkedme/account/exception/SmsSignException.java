package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

public class SmsSignException extends BusinessException {

    public SmsSignException(ErrorCode errorCode) {
        super(errorCode);
    }
}
