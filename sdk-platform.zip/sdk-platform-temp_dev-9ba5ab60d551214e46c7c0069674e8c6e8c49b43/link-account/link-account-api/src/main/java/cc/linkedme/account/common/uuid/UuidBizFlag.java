package cc.linkedme.account.common.uuid;

import lombok.Getter;

@Getter
public enum UuidBizFlag {

    LINK_ACCOUNT(1), LINK_PAGE(2), LINK_ACTIVE(3);
    private int bizFlag;

    UuidBizFlag(int bizFlag) {
        this.bizFlag = bizFlag;
    }

    public static void main(String[] args) {
        System.out.println(UuidBizFlag.LINK_ACCOUNT.ordinal());
    }

}
