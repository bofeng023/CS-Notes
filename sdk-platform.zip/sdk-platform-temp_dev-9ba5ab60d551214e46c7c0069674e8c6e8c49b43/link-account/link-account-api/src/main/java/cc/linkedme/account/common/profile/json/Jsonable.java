package cc.linkedme.account.common.profile.json;

public interface Jsonable {

    String toJson();

}
