package cc.linkedme.account.common.uuid;

public interface Uuid {

    long nextId(UuidBizFlag uuidBizFlag);
}
