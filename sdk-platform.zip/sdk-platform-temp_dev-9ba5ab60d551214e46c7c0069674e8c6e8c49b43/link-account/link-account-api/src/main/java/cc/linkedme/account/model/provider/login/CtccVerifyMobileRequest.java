package cc.linkedme.account.model.provider.login;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-14 21:04
 * @description
 **/
@Data
public class CtccVerifyMobileRequest {

    private String appId;

    private Long timeStamp;

    private String format;

    private String sign;

    private String params;

    @Data
    public static class Params {

        private String accessCode;

        private String mobile;

        private String algorithm;
    }

    @Override
    public String toString() {
        return "appId=" + appId + "&timeStamp=" + timeStamp + "&format=" + format + "&sign=" + sign + "&params=" + params;
    }

}
