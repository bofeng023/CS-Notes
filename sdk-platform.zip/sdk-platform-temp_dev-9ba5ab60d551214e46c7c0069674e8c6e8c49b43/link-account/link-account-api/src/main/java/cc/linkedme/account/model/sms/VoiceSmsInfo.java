package cc.linkedme.account.model.sms;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author zhanghaowei
 * @date 2019-07-22 14:57
 * @description 语音短信
 **/

@Data
public class VoiceSmsInfo implements Serializable {

    private static final long serialVersionUID = -3560132713552701979L;

    /**
     * 应用appId
     */
    private Integer appId;

    /**
     * 合同ID
     */
    private Integer contractId;

    /**
     * 用户主账号ID
     */
    private Integer uid;

    /**
     * 被呼叫号码
     */
    private String recipient;

    /**
     * 状态回调地址
     */
    private String statusCallbackUrl;

    /**
     * sessionId
     */
    private String sessionId;

    /**
     * 模版ID
     */
    private String templateId;


    /**
     * 模版动态值
     */
    private List<String> templateParams;

    /**
     * app key
     */
    private String appKey;

    /**
     * 扩展参数，在状态报告中会原样返回
     */
    private String extend;

}
