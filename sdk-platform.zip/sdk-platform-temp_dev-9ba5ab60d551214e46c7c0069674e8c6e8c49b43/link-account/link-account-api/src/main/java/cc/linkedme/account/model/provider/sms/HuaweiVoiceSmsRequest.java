package cc.linkedme.account.model.provider.sms;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.List;

/**
 * @author zhanghaowei
 * @date 2019-7-22 16:00
 * @description 封装语音发送请求
 **/

@Data
public class HuaweiVoiceSmsRequest {

    private Body body;

    @JsonIgnore
    private String voiceSmsUrlCallNotify;

    @Data
    public static class Body {

        /**
         * 绑定号码
         */
        private String bindNbr;

        /**
         * 主显号码
         */
        private String displayNbr;

        /**
         * 被叫号码
         */
        private String calleeNbr;

        /** 播放信息列表，最大支持5个，每个播放信息携带的参数都可以不相同 */
        private List<PlayContentInfo> playInfoList;

        /**
         * 设置SP接收状态上报的URL
         */
        private String feeUrl;

        /** 用户附属信息，此标识由第三方服务器定义，会在后续的通知消息中携带此信息 */
        private String userData;
    }

    @Data
    public static class PlayContentInfo {

        /**
         * 模版ID
         */
        private String templateId;


        /**
         * 模版动态值
         */
        private String[] templateParas;

    }

}
