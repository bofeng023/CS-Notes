package cc.linkedme.account.enums.provider.sms;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanghaowei
 * @date 2019-7-19 11:06
 * @description 平台短信状态code封装
 **/
public enum SmsCallbackStatus {

    DELIVRD("1300001", "用户已成功收到短信"),
    EXPIRED("1300002", "短信已超时"),
    DELETED("1300003", "短信已删除"),
    UNDELIV("1300004", "短信递送失败"),
    ACCEPTD("1300005", "短信已接收"),
    FAIL("1300006", "短信发送失败"),
    REJECTD("1300007", "短信被拒绝"),
    RTE_ERR("1300008", "平台内部路由错误"),
    MILIMIT("1300009", "号码达到分钟下发限制"),
    LIMIT("1300010", "号码达到下发限制"),
    KEYWORD("1300011", "短信关键字拦截"),
    BLACK("1300012", "号码黑名单"),
    PHONE_INVALID("1300013", "手机号码不合法");

    private String code;
    private String msg;

    SmsCallbackStatus(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private static final Map<String, SmsCallbackStatus> lookup = new HashMap<>();

    static {
        for (SmsCallbackStatus smsCallbackStatus : EnumSet.allOf(SmsCallbackStatus.class)) {
            lookup.put(smsCallbackStatus.getCode(), smsCallbackStatus);
        }
    }

    public static SmsCallbackStatus get(String code) {
        return lookup.get(code);
    }
}
