package cc.linkedme.account.service;

import cc.linkedme.account.exception.AuditInfoException;
import cc.linkedme.account.model.AuditInfo;
import cc.linkedme.enums.BizType;

import java.util.List;
import java.util.Map;

/**
 * 实体审核
 * @author zhanghaowei
 */
public interface AuditInfoSerivce {

    /**
     * 保存审核信息
     * @param auditInfo
     * @return
     * @throws AuditInfoException
     */
    AuditInfo saveAudit(AuditInfo auditInfo) throws AuditInfoException;

    Integer updateAudit(AuditInfo auditInfo) throws AuditInfoException;

    /**
     * 更新审核状态
     * @param auditInfo
     * @return
     * @throws AuditInfoException
     */
    Integer updateAuditByBizId(AuditInfo auditInfo) throws AuditInfoException;

    /**
     * 获取审核详细信息
     * @param bizId
     * @return
     */
    AuditInfo getAuditByBizId(Integer bizId, BizType bizType) throws AuditInfoException;

    /**
     * 依据审核ID，通过状态获取审核详细信息
     * @param bizIdList
     * @return
     */
    Map<Integer, AuditInfo> batchGetAuditByBizId(List<Integer> bizIdList, BizType bizType) throws AuditInfoException;

    /**
     * 更新业务信息
     * @param auditInfo
     * @return
     */
    int updateBizEntity(AuditInfo auditInfo);





}
