package cc.linkedme.account.service;

import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.exception.AccountBalanceException;
import cc.linkedme.account.model.AccountBalanceInfo;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.enums.BizType;

/**
 * 账户余额
 */
public interface AccountBalanceService {

    /**
     * 获取商户账户余额
     * @param uid 用户ID
     * @return
     */
    AccountBalanceInfo getAccountBalanceBOByUid(Integer uid);

    /**
     * 更新账户余额
     * @param accountBalanceBO
     * @return
     */
    AccountBalanceInfo updateAccountBalanceBO(AccountBalanceInfo accountBalanceBO);

    /**
     * 保存
     * @param accountBalanceBO
     * @return
     */
    AccountBalanceInfo saveAccountBalanceBO(AccountBalanceInfo accountBalanceBO);

    Integer updateAccountBalance(Integer uid, Integer amount, Integer giftAmount);

    /**
     * 充值保存合同余额、更新信用额度、记录合同单价
     * @param uid
     * @param contractId
     * @param contractAmount
     * @param giftAmount
     * @param balanceUnitPrice
     * @throws AccountBalanceException
     */
    void saveUserContractBalance(Integer uid, Integer contractId, Integer contractAmount, Integer giftAmount, BalanceUnitPrice balanceUnitPrice) throws AccountBalanceException;


    /**
     * 请求运营商前扣费，包含次数
     * @param uid
     * @param bizType
     * @param channel
     * @param count
     * @return
     * @throws AccountBalanceException
     */
    BalanceUnitPrice consume(Integer uid, BizType bizType, Channel channel, Integer count) throws AccountBalanceException;


    /**
     * 运营返回失败退款
     * @param uid
     * @param bizType
     * @param balanceUnitPrice
     * @param count
     * @throws AccountBalanceException
     */
    void refund(Integer uid, BizType bizType, BalanceUnitPrice balanceUnitPrice, Channel channel, Integer count) throws AccountBalanceException;

    /**
     * 本次充值余额是否大于信用额度消耗量，保证足够平账
     * @param uid
     * @param contractTotalAmount
     * @return
     * @throws AccountBalanceException
     */
    Boolean checkContractAndCreditAmount(Integer uid, Integer contractTotalAmount) throws AccountBalanceException;

}
