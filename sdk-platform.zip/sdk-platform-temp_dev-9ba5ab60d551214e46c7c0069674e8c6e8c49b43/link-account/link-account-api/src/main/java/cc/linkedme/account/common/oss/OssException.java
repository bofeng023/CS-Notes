package cc.linkedme.account.common.oss;

public class OssException extends RuntimeException {

    public OssException(String msg, Exception ex) {
        super(msg, ex);
    }
}
