package cc.linkedme.account.service;

import cc.linkedme.account.exception.ConsumeCountException;
import cc.linkedme.account.model.BalanceUnitPrice;
import cc.linkedme.account.model.ConsumeCountInfo;
import cc.linkedme.account.model.DataInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.enums.BizType;
import org.springframework.http.ResponseEntity;
import java.util.Date;
import java.util.List;

/**
 * 统计数据
 * @author zhanghaowei
 */
public interface ConsumeCountSerivce {

    /**
     * 数据列表
     * @param searchParam
     * @return
     * @throws ConsumeCountException
     */
    List<ConsumeCountInfo> listConsumeCountBO(SearchParam searchParam) throws ConsumeCountException;

    /**
     * 统计总条数
     * @param searchParam
     * @return
     * @throws ConsumeCountException
     */
    Long countConsumeCount(SearchParam searchParam) throws  ConsumeCountException;


    /**
     * 汇总指标
     * @param searchParam
     * @return
     * @throws ConsumeCountException
     */
    ConsumeCountInfo totalCountConsume(SearchParam searchParam) throws ConsumeCountException;

    /**
     * 汇总日消耗量 以及日请求量
     * @return
     */
    ConsumeCountInfo countDayTotalAmountAndRequestCount(Integer uid);


    /**
     * 获取统计数据信息
     * @param searchParam 搜索条件
     * @return
     * @throws ConsumeCountException
     */
    DataInfo getDataInfo(SearchParam searchParam) throws ConsumeCountException;


    /**
     * 统计数据导出
     * @param searchParam 搜索条件
     * @throws ConsumeCountException
     * @return ResponseEntity<byte[]>
     */
    ResponseEntity<byte[]> exportExcel(SearchParam searchParam) throws ConsumeCountException;


    /**
     * 发送统计信息
     * @param uid
     * @param bizType
     * @param balanceUnitPrice
     * @param date
     * @param count
     * @return
     */
    Boolean sendConsumeCountMessage(Integer uid, BizType bizType, BalanceUnitPrice balanceUnitPrice, Date date, Integer count);

    Boolean updateCountDate(ConsumeCountInfo consumeCountInfo, BizType bizType);

    ConsumeCountInfo getConsumeCountInfo(Integer uid , Long hourSlot);

    Integer saveConsumeCountInfo (ConsumeCountInfo consumeCountInfo);

    Integer updateConsumeCountInfo(ConsumeCountInfo consumeCountInfo);

    /**
     * 获取用户余额
     * @param uid
     * @return
     */
    Integer getBalanceByUid(Integer uid);


}
