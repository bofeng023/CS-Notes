package cc.linkedme.account.model.provider.login;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-14 16:44
 * @description
 **/
@Data
public class CmccVerifyMobileRequest {

    private Header header;

    private Body body;

    @Data
    public static class Header {

        private String version;

        private String msgId;

        private String timestamp;

        private String appId;
    }

    @Data
    public static class Body {

        private String openType;

        private String requesterType;

        private String phoneNum;

        private String token;

        private String sign;
    }
}
