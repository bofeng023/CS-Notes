package cc.linkedme.account.enums.provider.sms.huawei;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: liuyunmeng
 * @Date: Create in 13:55 2019-07-25
 * @:Description
 */
public enum HuaweiVoiceSmsCallBackStatus {

    SUCCESS(0, "成功接听"),
    RECORDING_FAIL_TO_CREATE_MEETING(501, "录音创建会议失败"),
    RECORDING_CALL_FAIL_TO_JOIN_MEETING(503, "录音主叫加入会议失败"),
    RECORDING_INCREASES_VOICE_ENDPOINT_FAILURE(505, "录音增加录音端点失败"),
    START_RECORDING_FAIL(507, "启动录音失败"),
    PLAY_RECORDING_TONE_FAIL(509, "播放录音提示音失败"),
    PLAY_RECORDING_PROMPT_TIMEOUT(510, "放录音提示音超时"),
    RECORDING_VCU_SWITCHING_RELEASE_CALL(511, "录音VCU倒换释放呼叫"),
    CALLING_TIMEOUT(513, "呼叫超时"),
    RINGING_TIMEOUT(514, "振铃超时"),
    REMOTE_USER_ACTIVE_CANCEL(515, "远端用户主动Cancel"),
    LOCAL_USER_ACTIVE_CANCEL(516, "本端用户主动Cancel"),
    REMOTE_USER_CALL_FAIL(518, "远端用户呼叫失败"),
    LOCAL_USER_CALL_FAIL_OXX(519, "本端用户呼叫失败(OXX)"),
    LOCAL_USER_CALL_FAIL_18X(520, "本端用户呼叫失败(OXX)"),
    AGENT_ACTIVE_HANG_UP(1001,"坐席主动挂机"),
    USER_ACTIVE_HANG_UP(1002,"用户主动挂机"),
    RELEASE_INTERFACE_HANG_UP(1003, "SP调用总机释放接口挂机"),
    SEAT_BLINDLY_AND_HANG_UP(1004,"发起点击外呼后，坐席进行盲转并挂机"),
    IVR_PLAYBACK_FAIL(2801, "IVR放音失败"),
    IVR_RULE_INVALID(2802, "IVR规则无效"),
    IVR_BUTTON_EXCEEDS_MAXIMUM_TIMES(2803, "IVR按键超过最大次数"),
    IVR_OUT_OF_SERVICE_TIME(2805, "IVR不在服务时间-1"),
    MRF_NOT_CONFIGURED(2810, "未配置MRF"),
    ICSCF_NOT_CONFIGURED(2811, "未配置ICSCF"),
    PLAY_TIMEOUT(2812, "放音超时"),
    END_OF_SATISFACTION_SURVEY(2825,"满意度调查结束"),
    ENTERPRISE_INCOMING_LICENSE_RESTRICTED(2831, "企业呼入License受限"),
    PLAY_FAIL(2837, "放音失败"),
    INVITE_TIMEOUT_RELEASE(2838, "INVITE超时释放"),
    NO_AVAILABLE(2847, "总机选线无可用坐席"),
    REFUSED_CALL_IN(2853, "坐席不可用，拒接呼入"),
    COMPANY_HAS_BEEN_DOWN(2868, "企业已停机"),
    DEVELOPER_CALL_FREQUENCY_CONTROL(7001, "开发者呼叫频次管控"),
    APPLICATION_CALL_FREQUENCY_CONTROL(7002, "应用呼叫频次管控"),
    DISPLAY_NUMBER_CALL_FREQUENCY_CONTROL(7003, "显示号码呼叫频次管控"),
    CALLED_BLACKLIST_CALL_CONTROL(7004, "被叫黑名单呼叫管控"),
    CALLER_BLACKLIST_SECURITY_CONTROL(7005, "主叫黑名单安全管控"),
    APP_INFO_NOT_EXIST(7100, "app信息不存在"),
    SERVICE_ERROR(7102, "服务内部出错"),
    CALLER_INFO_NOT_EXIST(7103, "主叫号码信息不存在"),
    BIZ_TYPE_MISMATCH(7105, "业务类型不匹配"),
    SECURITY_CONTROL_TONE_FAIL(7107, "安全管控提示音放音失败");

    private Integer status;
    private String statusDesc;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    HuaweiVoiceSmsCallBackStatus(Integer status, String statusDesc) {
        this.status = status;
        this.statusDesc = statusDesc;
    }

    private static final Map<Integer, HuaweiVoiceSmsCallBackStatus> lookup = new HashMap<>();

    static {
        for (HuaweiVoiceSmsCallBackStatus huaweiVoiceSmsCallBackStatus : EnumSet.allOf(HuaweiVoiceSmsCallBackStatus.class)) {
            lookup.put(huaweiVoiceSmsCallBackStatus.getStatus(), huaweiVoiceSmsCallBackStatus);
        }
    }

    public static HuaweiVoiceSmsCallBackStatus get(Integer code) {
        return lookup.get(code);
    }
}
