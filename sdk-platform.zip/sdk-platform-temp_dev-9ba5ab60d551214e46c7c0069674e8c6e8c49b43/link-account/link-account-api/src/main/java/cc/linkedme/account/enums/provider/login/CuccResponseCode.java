package cc.linkedme.account.enums.provider.login;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum CuccResponseCode {

    SUCCESS("0", "请求成功"),
    APP_UNAUTHORIZED("100", "应用未授权"),
    APP_SECRET_KEY("101", "应用秘钥错误"),
    APP_NOT_VALID("102", "应用无效"),
    IP_UNAUTHORIZED("103", "应用未授权该 IP 访问"),
    ACCESS_COUNT_NOT_ENOUGH("104", "应用访问次数不足"),
    APP_PACKAGE_NOT_VALID("105", "应用包名不正确"),
    APP_STATE_NOT_VALID("106","应用状态非法"),
    MERCHANT_STATE_NOT_VALID("107", "商户状态非法"),
    MERCHANT_REQUEST_COUNT_EXCEED_LIMIT("108", "商户请求次数超限额"),
    TOKEN_INVALID("200", "tokenId 无效"),
    TOKEN_OVERDUE("201", "token 已失效"),
    TOKEN_UNAUTHORIZED_APP("202", "token 未授权该应用访问"),
    AUTHENTICATION_INVALID("203", "登录鉴权级别不满足接口鉴权要求"),
    INTERFACE_NOT_OPEN("300", "接口未开放"),
    APP_INTERFACE_UNAUTHORIZED("301", "应用未授权码访问该接口"),
    IP_UNAUTHORIZED_INTERFACE("302", "IP 未授权码访问该接口"),
    APP_ACCESS_INTERFACE_OVERTIME_LIMIT("303", "应用访问接口次数超日限额"),
    PARAMS_EMTRY("400", "请求参数为空"),
    PARAMS_INCOMPLETE("401", "请求参数不完整"),
    PARAMS_INVALID("402", "请求参数非法"),
    REQUEST_INVALID("600", "请求非法"),
    REQUEST_PARSING_ERROR("1000", "请求解析错误"),
    REQUEST_OVERDUE("1001", "请求已失效"),
    SIGN_FAIL("1002", "验签失败"),
    AUTH_CODE_OVERDUE("1003", "授权码已过期"),
    ENCRYPT_NOT_SUPPORT("1004", "加密方式不支持"),
    RSA_ENCRYPT_ERROR("1005", "RSA 加密错误"),
    INTER_SERVICE_ACCESS_FAIL("1010", "服务间访问失败"),
    INTER_SERVICE_ACCESS_ERROR("1011", "服务间访问错误"),
    USER_NOT_EXIST("2004", "用户不存在"),
    UNIKEY_INVALID("3001", "unikey 无效"),
    JUMPING_OFF_LINE_NUMBER("3002", "跳转异网取号"),
    NETWORK_GET_NUMBER_FAILED_NOT_FORWARD("3003", "本网执行取号失败,不需要重定向"),
    NET_GET_NUMBER("3004", "NET 取号失败"),
    WIFI_INVALID_GET_NUMBER("3005", "上网方式为 WIFI，无法取号"),
    URLENCODE_FAIL("3006", "urlencode 编码失败"),
    REQUEST_AUTHENTICATION_INTERFACE_EXCEPTION("3007", "请求认证接口异常"),
    IMSI_GET_FAIL("3008", "imsi 取号失败"),
    NON_UNICOM_NUMBER("3009", "非联通号码"),
    GATEWAY_NUMBER_ERROR("3010", "网关取号错误"),
    SOURCE_IP_AUTHENTICATION_FAIL("3011", "源 IP 鉴权失败"),
    GATEWAY_GET_NUMBER_FAIL("3012", "网关取号失败"),
    CUCC_GATEWAY_GET_NUMBER_FAIL("3013", "电信网关取号失败"),
    CUCC_GATEWAY_GET_NUMBER_ERROR("3014", "电信网关取号错误"),
    ACCESS_CODE_FAIL("3015", "获取 accessCode 请求参数失败"),
    CMCC_GATEWAY_GET_NUMBER_FAIL("3016", "移动网关取号失败"),
    CMCC_GATEWAY_GET_NUMBER_ERROR("3017", "移劢网关取号错误");

    private String code ;

    private String msg;

    CuccResponseCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private static final Map<String,CuccResponseCode> lookup = new HashMap<>();

    static {
        for (CuccResponseCode cuccResponseCode : EnumSet.allOf(CuccResponseCode.class)) {
            lookup.put(cuccResponseCode.getCode(), cuccResponseCode);
        }
    }

    public static CuccResponseCode get(String code) {
        return lookup.get(code);
    }
}
