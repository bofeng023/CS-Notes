package cc.linkedme.account.common.uuid;

import lombok.Setter;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;

/**
 * @author yangpeng
 * @date 2019-07-19 17:20
 * @description
 **/
public class UuidCreator implements Uuid {
    private static final Logger logger = LoggerFactory.getLogger(UuidCreator.class);
    public static final int RETRY_TIMES = 5;
    private static Random random = new Random();

    @Setter
    private List<String> ipPort;
    private UuidClient uuidClient;
    private UuidClient uuidClientHA;

    public void init() {

        logger.info("uuid creator init begin, ipPort:{}", ipPort);
        if (CollectionUtils.isEmpty(ipPort)) {
            throw new UuidException("uuid creator ip port is empty!");
        }
        if (ipPort.size() != 2) {
            throw new UuidException("uuid must have two servers, otherwise ids are all even or odd");
        }

        uuidClient = new UuidClient();
        uuidClientHA = new UuidClient();
        uuidClient.setServer(ipPort.get(0));
        uuidClientHA.setServer(ipPort.get(1));
        uuidClient.init();
        uuidClientHA.init();
    }

    @Override
    public long nextId(UuidBizFlag uuidBizFlag) {
        Long uuid;
        if (isMaster()) {
            uuid = getNextId(uuidClient, uuidBizFlag);
        } else {
            uuid = getNextId(uuidClientHA, uuidBizFlag);
        }
        return uuid;
    }

    private boolean isMaster() {
        return random.nextInt(2) == 0;
    }

    private long getNextId(UuidClient uuidClient, UuidBizFlag uuidBizFlag) {
        if (uuidBizFlag == null) {
            throw new UuidException("get uuid failed, must have uuidBizFlag!");
        }
        for (int retry = 0; retry < RETRY_TIMES; retry ++) {
            long uuid;
            try {
                long start = System.currentTimeMillis();
                String nextUniqueId = (String) uuidClient.get(String.valueOf(uuidBizFlag.ordinal()));
                logger.info("get next uuid, uuid:{}, uuidBizFlag:{}, uuidServer:{}, cost:{}", nextUniqueId, uuidBizFlag, uuidClient.getServer(), System.currentTimeMillis() - start);
                uuid = Long.valueOf(nextUniqueId);
                return uuid;
            }
            catch (Exception e) {
                logger.warn("get next id failed, retryTimes:{}, uuidBizFlag:{}, uuidServer:{}", retry, uuidBizFlag, uuidClient.getServer(), e);
            }
        }
        throw new UuidException("uuid creator, get uuid faild, retry " + RETRY_TIMES + " times!");
    }

}