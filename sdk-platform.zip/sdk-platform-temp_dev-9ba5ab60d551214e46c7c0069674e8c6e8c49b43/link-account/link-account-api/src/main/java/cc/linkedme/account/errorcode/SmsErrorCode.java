package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface SmsErrorCode extends BaseErrorCode {

    ErrorCode APP_KEY_INVALID = new ErrorCode(1100008, "app_key无效");

    ErrorCode SEND_SMS_EMPTY = new ErrorCode(1100016, "消息发送为空");

    ErrorCode SEND_TO_EMPTY = new ErrorCode(1100017, "短信接收方号码为空");

    ErrorCode SEND_SIGN_NAME_EMPTY = new ErrorCode(1100018, "签名名称为空");

    ErrorCode SEND_TO_FORMAT_ERROR = new ErrorCode(1100020, "短信接收方号码格式错误");

    ErrorCode SEND_SIGN_NAME_INVALID = new ErrorCode(1100021, "短信签名无效");

    ErrorCode SEND_TMEPLATE_ID_INVALID = new ErrorCode(1100022, "模版ID无效");

    ErrorCode SEND_TMEPLATE_PARAMS_COUNT_ERROR = new ErrorCode(1100023, "模版参数个数不匹配");

    ErrorCode SEND_PARAM_LENGTH_THRESHOLD = new ErrorCode(1100024, "参数值长度超过预设值");

    ErrorCode SEND_DATE_ERROR = new ErrorCode(1100025, "日期格式错误");

    ErrorCode SEND_NUM_ERROR = new ErrorCode(1100026, "模版数字格式错误");

    ErrorCode SEND_TEMPLATE_ID_EMPTY = new ErrorCode(1100030, "模版ID为空");

    ErrorCode VOICE_SMS_LOGIN_ACCESS_TOKEN = new ErrorCode(1100031, "语音短信登录认证获取access_token失败");

    ErrorCode VOICE_SMS_REFRESH_ACCESS_TOKEN = new ErrorCode(1100032, "语音短信刷新获取access_token失败");

    ErrorCode VOICE_SMS_INTERFACE_FAIL = new ErrorCode(1100033, "语音短信通知api接口失败");

    ErrorCode SMS_CALLBACK_REQUEST_FAIL = new ErrorCode(1100034, "短信用户回调接口连接失败");

    ErrorCode SEND_SMS_REQUEST_FAIL = new ErrorCode(1100035, "调用短信接口连接失败");

    ErrorCode VOICE_PLAY_INFO_EMPTY = new ErrorCode(1100036, "语音播放信息为空");

    ErrorCode VOICE_SMS_CALLBACK_REQUEST_FAIL = new ErrorCode(1100037, "语音短信用户回调接口连接失败");

    ErrorCode SMS_REFUND_AMOUNT_FAIL = new ErrorCode(1100038, "短信返还金额失败");

    ErrorCode VOICE_SMS_SET_INFO_FAIL = new ErrorCode(1100039, "语音信息设置失败");

    ErrorCode CALLBACK_CONTENT_ERROR =new ErrorCode(1100040, "回调内容为空");

    ErrorCode IP_WHITELIST_ERROR = new ErrorCode(1100041, "ip白名单校验失败");

    ErrorCode PUBLIC_KEY_EMPTY = new ErrorCode(1100042, "公钥为空");



}
