package cc.linkedme.account.model.provider.login;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;

/**
 * @author zhanghaowei
 * @date 2019-6-15 14:46
 * @description
 **/
@Data
public class CuccGetMobileResponse {

    private String code;

    private String msg;

    private Data data;

    @lombok.Data
    @JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
    public static class Data {
        private String mobilePhone;
    }
}
