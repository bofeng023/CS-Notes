package cc.linkedme.account.service;

import cc.linkedme.account.exception.TopUpException;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.TopUpInfo;

import java.util.List;

/**
 * 账户充值
 * @author zhanghaowei
 */
public interface TopUpService {

    /**
     * 保存充值信息
     * @param TopUpBO
     * @return
     * @throws TopUpException
     */
    TopUpInfo saveTopUp(TopUpInfo TopUpBO) throws TopUpException;

    /**
     * 查看充值信息
     * @param id 充值ID
     * @return
     * @throws TopUpException
     */
    TopUpInfo getTopUp(Integer id) throws TopUpException;

    /**
     * 更新充值信息
     * @param TopUpBO
     * @return
     * @throws TopUpException
     */
    Integer updateTopUp(TopUpInfo TopUpBO) throws TopUpException;

    /**
     * 查询 充值信息分页
     * @param searchParam
     * @return
     * @throws TopUpException
     */
    List<TopUpInfo> listTopUp(SearchParam searchParam) throws TopUpException;

    /**
     * 充值条数
     * @param uid
     * @return
     */
    Long countTopUp(Integer uid, SearchParam searchParam) throws TopUpException;

    /**
     * 统计历史充值金额
     * @param uid
     * @return
     */
    Long countHistoryTopUpAmount(Integer uid);


//    /**
//     * 查看充值信息,包含审核信息
//     * @param id 充值ID
//     * @return
//     * @throws TopUpException
//     */
//    TopUpInfo getTopUpAndAuditInfo(Integer id) throws TopUpException;



}
