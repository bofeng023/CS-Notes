package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface SmsSignErrorCode extends BaseErrorCode {

    ErrorCode NAME_NULL_ERROR = new ErrorCode(200000, "签名名称不能为空");

    ErrorCode GLOBAL_NULL_ERROR = new ErrorCode(200001, "签名使用区域不能为空");

    ErrorCode POWER_ATTORNEY_NULL_ERROR = new ErrorCode(200002, "授权委托书不能为空");

    ErrorCode SIGN_NOT_EXIST =new ErrorCode(200003,"签名不存在");

    ErrorCode APPID_NULL_ERROR =new ErrorCode(200004,"appId不能为空");

    ErrorCode AUDITSTATUS_NULL_ERROR =new ErrorCode(200005,"审核状态不能为空");

}