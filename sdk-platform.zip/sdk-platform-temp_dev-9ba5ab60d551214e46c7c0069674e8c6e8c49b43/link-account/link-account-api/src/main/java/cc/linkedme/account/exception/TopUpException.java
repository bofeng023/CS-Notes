package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

public class TopUpException extends BusinessException {
    public TopUpException(ErrorCode errorCode) {
        super(errorCode);
    }
}
