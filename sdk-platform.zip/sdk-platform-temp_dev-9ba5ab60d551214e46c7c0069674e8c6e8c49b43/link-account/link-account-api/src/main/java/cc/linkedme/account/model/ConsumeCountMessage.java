package cc.linkedme.account.model;

import cc.linkedme.enums.BizType;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zhanghaowei
 * @date 2019-6-28 20:02
 * @description
 **/
@Data
public class ConsumeCountMessage implements Serializable {

    private Integer uid;

    private Long hourSlot;

    private BizType bizType;

    private Integer unitPrice;

    private Date date;

    private Integer count;

}
