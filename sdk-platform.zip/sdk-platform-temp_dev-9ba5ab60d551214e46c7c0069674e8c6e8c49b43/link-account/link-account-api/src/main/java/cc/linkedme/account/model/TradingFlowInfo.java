package cc.linkedme.account.model;

import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.enums.TradingType;
import cc.linkedme.enums.BizType;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.joda.time.DateTime;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zhanghaowei
 * @date 2019-7-9 14:47
 * @description 交易流水
 **/

@Data
@AllArgsConstructor
public class TradingFlowInfo implements Serializable {

    private static final long serialVersionUID = -186722587503345992L;

    private Integer uid;

    /**
     * 业务类型（0-授信额度平账、1-账户充值、2-扣除、3-退款）
     */
    private TradingType tradingType;


    private Integer contractId;

    /**
     * 类型
     * (6-一键登录、7-号码认证、8-文本短信、9-语音短信、10-国际短信，4-充值)
     */
    private BizType bizType;

    /**
     * 变更金额
     */
    private Integer amount;


    /**
     * 合同剩余金额
     */
    private Long balanceAmount;

    /**
     * 来源
     */
    private Channel channel;


    private Date createTime;

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(uid)
                .append("\t").append(tradingType != null ? tradingType.getType() : TradingType.OTHER.getType())
                .append("\t").append(contractId)
                .append("\t").append(bizType != null ? bizType.getType() : BizType.OTHER.getType())
                .append("\t").append(amount)
                .append("\t").append(balanceAmount)
                .append("\t").append(channel != null ? channel.getType() : Channel.OTHER.getType())
                .append("\t").append(new DateTime(createTime).toString("yyyy-MM-dd HH:mm:ss"));
        return builder.toString();
    }
}
