package cc.linkedme.account.service;

import cc.linkedme.account.exception.SmsFrequencyException;
import cc.linkedme.account.model.sms.SmsFrequencyInfo;

public interface SmsFrequencyService {

    SmsFrequencyInfo saveDefaultSmsFrequency(Integer uid) throws SmsFrequencyException;

    void updateSmsFrequency(SmsFrequencyInfo smsFrequencyInfo) throws SmsFrequencyException;

    SmsFrequencyInfo getSmsFrequency(Integer id, Integer uid) throws SmsFrequencyException;
}
