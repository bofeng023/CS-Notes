package cc.linkedme.account.enums.provider.sms;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: liuyunmeng
 * @Date: Create in 14:16 2019-07-25
 * @:Description
 */
public enum VoiceSmsCallbackStatus {

    SUCCESS(0, "成功接听"),
    NO_ANSWER(1, "未接听"),
    OTHER(2, "其他原因");

    private Integer status;
    private String statusDesc;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    VoiceSmsCallbackStatus(Integer status, String statusDesc) {
        this.status = status;
        this.statusDesc = statusDesc;
    }

    public static final Map<Integer, VoiceSmsCallbackStatus> lookup = new HashMap<>();

    static {
        for (VoiceSmsCallbackStatus voiceSmsCallbackStatus : EnumSet.allOf(VoiceSmsCallbackStatus.class)) {
            lookup.put(voiceSmsCallbackStatus.getStatus(), voiceSmsCallbackStatus);
        }
    }

    public static VoiceSmsCallbackStatus get(Integer status) {
        return lookup.get(status);
    }
}
