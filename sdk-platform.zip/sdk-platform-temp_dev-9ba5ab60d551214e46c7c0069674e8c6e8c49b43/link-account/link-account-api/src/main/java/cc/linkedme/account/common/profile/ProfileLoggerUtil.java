package cc.linkedme.account.common.profile;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ProfileLoggerUtil {
    private static Logger profileLog = LogManager.getLogger("profile");

    public static void monitor(String string) {
        profileLog.info(string);
    }
}
