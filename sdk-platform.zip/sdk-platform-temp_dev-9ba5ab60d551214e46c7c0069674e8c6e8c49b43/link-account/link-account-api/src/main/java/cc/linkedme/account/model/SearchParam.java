package cc.linkedme.account.model;

import lombok.Data;

import java.util.Date;

@Data
public class SearchParam {

    private Integer uid;

    private String email;

    private String company;

    private Integer auditState;

    private Integer bizType;

    private String appName;

    private Date startDate;

    private Date endDate;

    private Integer page;

    private Integer size;

    private Integer consumeState;

    public int getOffset() {return (getPage() - 1) * getSize();}

}
