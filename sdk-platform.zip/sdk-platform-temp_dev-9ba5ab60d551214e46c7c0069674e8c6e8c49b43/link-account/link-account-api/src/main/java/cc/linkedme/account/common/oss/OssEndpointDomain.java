package cc.linkedme.account.common.oss;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum OssEndpointDomain {

    BEIJING((byte) 0, "北京"), SHANGHAI((byte) 1, "上海"), SHENZHEN((byte) 2, "深圳"), HANGZHOU((byte) 3, "杭州");

    private static final Map<Byte, OssEndpointDomain> lookup = new HashMap<Byte, OssEndpointDomain>();

    static {
        for (OssEndpointDomain s : EnumSet.allOf(OssEndpointDomain.class)) {
            lookup.put(s.getIndex(), s);
        }
    }

    private Byte index;
    private String desc;

    OssEndpointDomain(Byte index, String desc) {
        this.index = index;
        this.desc = desc;
    }

    public static OssEndpointDomain get(Byte index) {
        return lookup.get(index);
    }

    public Byte getIndex() {
        return this.index;
    }

    public String getDesc() {
        return desc;
    }
}
