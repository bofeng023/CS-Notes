package cc.linkedme.account.model.sms;

import cc.linkedme.account.common.punctuation.Punctuation;
import lombok.Data;
import org.apache.commons.lang.StringUtils;

/**
 * @author lipeng
 * @date 2019-07-31 23:01
 * @description 需要透传给文本短信提供方的数据
 **/

@Data
public class SmsExtend {

    private Integer uid;

    private Integer appId;

    /**
     * 用户一次请求的session
     */
    private String sessionId;

    private Integer contractId;

    @Override
    public String toString() {
        return uid + Punctuation.COMMA
                + appId + Punctuation.COMMA
                + sessionId + Punctuation.COMMA
                + contractId;
    }

    public static SmsExtend parse(String extend) {
        SmsExtend smsExtend = new SmsExtend();
        String[] extendArr = StringUtils.split(extend, Punctuation.COMMA);
        if (extendArr.length > 3) {
            smsExtend.setUid(Integer.valueOf(extendArr[0]));
            smsExtend.setAppId(Integer.valueOf(extendArr[1]));
            smsExtend.setSessionId(extendArr[2]);
            smsExtend.setContractId(Integer.valueOf(extendArr[3]));
        }
        return smsExtend;
    }
}
