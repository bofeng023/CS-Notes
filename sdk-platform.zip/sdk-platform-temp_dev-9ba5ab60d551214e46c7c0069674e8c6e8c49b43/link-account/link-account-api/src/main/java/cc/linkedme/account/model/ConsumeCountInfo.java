package cc.linkedme.account.model;

import lombok.Data;

import java.util.Date;

@Data
public class ConsumeCountInfo {
    private Integer id;

    private Integer uid;

    private Integer quickLoginCount;

    private Integer verifyCount;

    private Integer smsCount;

    private Integer voiceCount;

    private Integer totalAmount;

    private Long hourSlot;

    private Date date;

    private Date gmtCreate;

    private Date gmtModified;
}
