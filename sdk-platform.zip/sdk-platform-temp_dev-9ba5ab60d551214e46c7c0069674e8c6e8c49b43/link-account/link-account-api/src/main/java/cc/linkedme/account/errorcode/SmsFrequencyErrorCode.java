package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface SmsFrequencyErrorCode extends BaseErrorCode {

    ErrorCode COUNT_PER_UNIT_ERROR = new ErrorCode(100000, "请输入大于0的整数/数值不可大于40");

    ErrorCode FREQUENCY_HOUR_LESS_MINUTE_ERROR = new ErrorCode(100001, "数值应大于1分钟内的发送条数");

    ErrorCode FREQUENCY_DAY_LESS_HOUR_ERROR = new ErrorCode(100002, "数值应大于1小时内的发送条数");
}
