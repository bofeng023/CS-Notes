package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @author zhanghaowei
 * @date 2019-6-17 10:37
 * @description
 **/
public class AuthConfigException extends BusinessException {

    public AuthConfigException(ErrorCode errorCode) {
        super(errorCode);
    }
}
