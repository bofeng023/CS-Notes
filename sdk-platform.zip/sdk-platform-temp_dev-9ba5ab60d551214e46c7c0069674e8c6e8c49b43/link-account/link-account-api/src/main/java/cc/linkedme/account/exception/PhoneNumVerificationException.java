package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @author yangpeng
 * @date 2019-06-10 18:42
 * @description
 **/
public class PhoneNumVerificationException extends BusinessException {
    public PhoneNumVerificationException(ErrorCode errorCode) {
        super(errorCode);
    }
}
