package cc.linkedme.account.constants;

/**
 * @Author: liuyunmeng
 * @Date: Create in 20:58 2019-08-22
 * @:Description
 */
public class MessageConstants {

    /**
     * 管理员ID
     */
    public static final Integer ADMINISTRATOR_ID = 10192;
}
