package cc.linkedme.account.model.provider.login;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-13 16:02
 * @description
 **/
@Data
public class CtccGetMobileResponse {

    private String result;

    private String msg;

    private String data;

    @lombok.Data
    public static class Data {

        private String mobile;

        private String state;
    }
}
