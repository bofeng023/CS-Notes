package cc.linkedme.account.model.callback;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:42 2019-07-25
 * @:Description
 */
@Data
public class VoiceSmsCallbackRequest implements Serializable {

    private static final long serialVersionUID = 8263702804916290459L;
    /**
     * 通话链路的唯一标识
     */
    private String msgId;

    /**
     * 通话状态
     */
    private Integer status;

    /**
     * 主叫号码，号码为全局号码格式（包含国家码）
     */
    private String callerNum;

    /**
     * 被叫号码，号码为全局号码格式（包含国家码）
     */
    private String to;

    /**
     * Initcall的呼出开始时间
     */
    private String callOutStartTime;

    /**
     * 呼叫结束时间。
     * 该参数为UTC时间（+8小时为北京时间），时间格式为“yyyy-MM-dd HH:mm:ss”
     */
    private String callEndTime;


    /**
     * 用户附属信息，此参数的值与“语音通知API”中的"extend"参数值一致
     */
    private String extend;

}
