package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @author zhanghaowei
 * @date 2019-6-6 11:44
 * @description
 **/
public class CmsLoginException extends BusinessException {
    public CmsLoginException(ErrorCode errorCode) {
        super(errorCode);
    }
}
