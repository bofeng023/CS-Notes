package cc.linkedme.account.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum Platform {

    IOS(0, "ios"),
    ANDROID(1, "android"),
    WEB(2, "web");

    private Integer type;

    private String name;

    Platform(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private final static Map<Integer, Platform> lookup = new HashMap<>();

    static {
        for (Platform platform : EnumSet.allOf(Platform.class)) {
            lookup.put(platform.getType(), platform);
        }
    }

    public static Platform get(Integer type) {
        return lookup.get(type);
    }

}
