package cc.linkedme.account.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum Channel {

    MOBILE(0, "中国移动"),
    TELECOM(1, "中国电信"),
    UNICOM(2, "中国联通"),
    SMS_HUAWEI(3, "华为短信"),
    OTHER(100, "其它");
    private Integer type;

    private String name;

    Channel(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private final static Map<Integer, Channel> lookup = new HashMap<>();

    static {
        for (Channel channel : EnumSet.allOf(Channel.class)) {
            lookup.put(channel.getType(), channel);
        }
    }

    public static Channel get(Integer type) {
        return lookup.get(type);
    }

}
