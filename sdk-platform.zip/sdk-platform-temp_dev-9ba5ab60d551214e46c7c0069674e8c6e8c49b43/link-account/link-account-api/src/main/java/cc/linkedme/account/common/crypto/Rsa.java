package cc.linkedme.account.common.crypto;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class Rsa {

    /**
     * RSA最大加密明文大小
     */
    private static final int MAX_ENCRYPT_BLOCK = 117;

    /**
     * RSA最大解密密文大小
     */
    private static final int MAX_DECRYPT_BLOCK = 128;

    /**
     * 获取密钥对
     *
     * @return 密钥对
     */
    public static KeyPair getKeyPair() throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(1024);
        return generator.generateKeyPair();
    }

    /**
     * 获取私钥
     *
     * @param privateKey 私钥字符串
     * @return
     */
    private static PrivateKey getPrivateKey(String privateKey) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        byte[] decodedKey = Base64.decodeBase64(privateKey.getBytes());
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(decodedKey);
        return keyFactory.generatePrivate(keySpec);
    }

    /**
     * 获取公钥
     *
     * @param publicKey 公钥字符串
     * @return
     */
    private static PublicKey getPublicKey(String publicKey) throws Exception {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        byte[] decodedKey = Base64.decodeBase64(publicKey.getBytes());
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(decodedKey);
        return keyFactory.generatePublic(keySpec);
    }

    /**
     * RSA加密
     *
     * @param data 待加密数据
     * @param publicKey 公钥
     * @return
     */
    public static String encrypt(String data, String publicKey) throws Exception {
        byte[] encryptedData = encrypt(data.getBytes(), publicKey);
        // 获取加密内容使用base64进行编码,并以UTF-8为标准转化成字符串
        // 加密后的字符串
        return Base64.encodeBase64String(encryptedData);
    }

    public static String encryptHex(String data, String publicKey) throws Exception {
        byte[] encryptedData = encrypt(data.getBytes(), publicKey);
        // 加密内容为16进制
        return byte2hex(encryptedData);
    }

    public static byte[] encrypt(byte[] data, String publicKey) throws Exception {
        PublicKey pubKey = getPublicKey(publicKey);
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, pubKey);
        int inputLen = data.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offset = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段加密
        while (inputLen - offset > 0) {
            if (inputLen - offset > MAX_ENCRYPT_BLOCK) {
                cache = cipher.doFinal(data, offset, MAX_ENCRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(data, offset, inputLen - offset);
            }
            out.write(cache, 0, cache.length);
            i++;
            offset = i * MAX_ENCRYPT_BLOCK;
        }
        byte[] encryptedData = out.toByteArray();
        out.close();
        // 加密后的字节
        return encryptedData;
    }



    /**
     * RSA解密
     *
     * @param data 待解密数据
     * @param privateKey 私钥
     * @return
     */
    public static String decrypt(String data, String privateKey) throws Exception {
        byte[] decryptedData = decrypt(Base64.decodeBase64(data), privateKey);
        // 解密后的内容
        return new String(decryptedData, StandardCharsets.UTF_8);
    }

    public static String decryptHex(String data, String privateKey) throws Exception {
        byte[] decryptedData = decrypt(hexStr2byte(data), privateKey);
        return new String(decryptedData, StandardCharsets.UTF_8);
    }

    public static byte[] decrypt(byte[] data, String privateKey) throws Exception {
        PrivateKey priKey = getPrivateKey(privateKey);
        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, priKey);
        int inputLen = data.length;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int offset = 0;
        byte[] cache;
        int i = 0;
        // 对数据分段解密
        while (inputLen - offset > 0) {
            if (inputLen - offset > MAX_DECRYPT_BLOCK) {
                cache = cipher.doFinal(data, offset, MAX_DECRYPT_BLOCK);
            } else {
                cache = cipher.doFinal(data, offset, inputLen - offset);
            }
            out.write(cache, 0, cache.length);
            i++;
            offset = i * MAX_DECRYPT_BLOCK;
        }
        byte[] decryptedData = out.toByteArray();
        out.close();
        // 解密后的字节内容
        return decryptedData;
    }

    /**
     * 签名
     *
     * @param data 待签名数据
     * @param privateKey 私钥
     * @return 签名
     */
    public static String sign(String data, String privateKey, SignAlgorithm signAlgorithm) throws Exception {
        byte[] signData = sign(data.getBytes(), privateKey, signAlgorithm);
        return Base64.encodeBase64String(signData);
    }

    public static String signHex(String data, String privateKey, SignAlgorithm signAlgorithm) throws Exception {
        byte[] signData = sign(data.getBytes(), privateKey, signAlgorithm);
        return byte2hex(signData);
    }

    public static byte[] sign(byte[] data, String privateKey, SignAlgorithm signAlgorithm) throws Exception {
        PrivateKey priKey = getPrivateKey(privateKey);
        Signature signature = Signature.getInstance(signAlgorithm.getAlgorithm());
        signature.initSign(priKey);
        signature.update(data);
        return signature.sign();
    }

    /**
     * 验签
     *
     * @param srcData 原始字符串
     * @param publicKey 公钥
     * @param sign 签名
     * @return 是否验签通过
     */
    public static boolean verify(String srcData, String publicKey, String sign, SignAlgorithm signAlgorithm) throws Exception {
        return verify(srcData.getBytes(), publicKey, Base64.decodeBase64(sign), signAlgorithm);
    }

    public static boolean verifyHex(String srcData, String publicKey, String sign, SignAlgorithm signAlgorithm) throws Exception {
        return verify(srcData.getBytes(), publicKey, hexStr2byte(sign), signAlgorithm);
    }

    public static boolean verify(byte[] srcData, String publicKey, byte[] sign, SignAlgorithm signAlgorithm) throws Exception {
        PublicKey pubKey = getPublicKey(publicKey);
        Signature signature = Signature.getInstance(signAlgorithm.getAlgorithm());
        signature.initVerify(pubKey);
        signature.update(srcData);
        return signature.verify(sign);
    }

    /**
     * Description：将二进制转换成16进制字符串
     *
     * @param b
     * @return
     * @return String
     * @author name：
     */
    private static String byte2hex(byte[] b) {
        String hs = "";
        String stmp = "";
        for (int n = 0; n < b.length; n++) {
            stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
            if (stmp.length() == 1) {
                hs = hs + "0" + stmp;
            } else {
                hs = hs + stmp;
            }
        }
        return hs.toUpperCase();
    }

    /**
     * Description：将十六进制的字符串转换成字节数据
     *
     * @param strhex
     * @return
     * @return byte[]
     * @author name：
     */
    private static byte[] hexStr2byte(String strhex) {
        if (strhex == null) {
            return null;
        }
        int l = strhex.length();
        if (l % 2 == 1) {
            return null;
        }
        byte[] b = new byte[l / 2];
        for (int i = 0; i != l / 2; i++) {
            b[i] = (byte) Integer.parseInt(strhex.substring(i * 2, i * 2 + 2), 16);
        }
        return b;
    }

    public static void main(String[] args) {
        try {
            // 生成密钥对
//            KeyPair keyPair = getKeyPair();
//           String privateKey = new String(Base64.encodeBase64(keyPair.getPrivate().getEncoded()));
//           String publicKey = new String(Base64.encodeBase64(keyPair.getPublic().getEncoded()));
            /*String privateKey = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALQ9lkBtOqE+Gan2" +
                    "ggtdAfLJbHEUhTqD6G7dikwGjMLvlllx5xkv6zDqn8GiceQ/2oM9fZnusQiAIil6" +
                    "9uL4IDd6cgWCE3tZ1Md/4AtKJgiTztZdQZ9rbLnmdBTMicPAkbhwANniahhcbeB8" +
                    "G0CqJtsjc4zPkyplruBt2G2/WTDrAgMBAAECgYEArEdZwIcnTUwAV9bJgncKD7i7" +
                    "sHJ+zembV6zmLbjs/r7nJOOckxScZ4s73GebGSJ3iI5T6bie+pMPFDr2lQe6MfHI" +
                    "bhend4IhQA+q4Gh38zp0BPmepiPjXqQwezvuFBBJ1cCr4SYD2hqx0OVnyC3sA7LR" +
                    "eKyuAnKCzh0qcR6aSQECQQDjWlFzrW2d6LzNkuLzo5I9+8ZqWGc/yh6x2R67ZznU" +
                    "PE53hoM3smAig9qrlQtjoHfRgP53wMAug+RN+wDcSFtBAkEAyvOTyYXgUONLoXGm" +
                    "0PZlOgNrLIscjNwxsDUfY96C5pR4x1+Yh18kyJLScp3v8QWb5Kfgoe1492bgkFQ9" +
                    "x3udKwJAA9RxqtExF4fkJlJjIFeRDxo+rWvv0VNGURinO+DxSHH7oGfTrgyDMhGm" +
                    "jV1lY7hATHcv0jSdCCuQnP+tdAiEAQJBAJwVDBm2TjenNukooOSgOmWNb4VIT2K9" +
                    "jbE4ibWi0QVINkMO8B1cPMvMrvDbKkcwyx3lRksCeT+77QTS5Nhf5xUCQDJLuaZP" +
                    "STnoq/9SN9ux+o7Dnrc8SzMYTwCJj+/qCWOMjiRGs5TknWRB0tDjG5ioEtutvZ3o" +
                    "FeRhepsyYaII2h0=";*/
//            String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC0PZZAbTqhPhmp9oILXQHyyWxxFIU6g" +
//                    "+hu3YpMBozC75ZZcecZL+sw6p/BonHkP9qDPX2Z7rEIgCIpevbi+CA3enIFgh" +
//            KeyPair keyPair = getKeyPair();
////            String privateKey = new String(Base64.encodeBase64(keyPair.getPrivate().getEncoded()));
////            String publicKey = new String(Base64.encodeBase64(keyPair.getPublic().getEncoded()));
            /*String privateKey = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBALjLEijrAtUU37kk" +
                    "9sTbyRno/KHgdmnU2fXiBLCm3M3biKkrrLW6TzPBlN/pz6ICS+ACLwx7J/2SS36P" +
                    "we8p60ICAaIYVhQMMNm02s4aN8L/eTOgUz5z6LbRPXNFNWoGTmjBhzELlIYIuUvA" +
                    "QRnppHqckXYE/JibWoWnzdSFSP8xAgMBAAECgYB+7BN0AT53xheHncjUGzU705e5" +
                    "Q2dxdx2hUXTxNBqSVce+kd3VD7sYjExJotjWqIceu8E+7FPiSRoLOof0UbFgAMQA" +
                    "RkXTb2Or+sL2EJ+7HvkWRxIfqu6cEMK0W2viN9lWZ5vkBLW+jvHalbsztogaKfNi" +
                    "nTTnVSMN9xFjHPM79QJBAOSgd8JFgnQFJySRFLri6Sbfs3+IsXml1PKAhfKOwI54" +
                    "EFRMg4pY3VHEHKvTBhWm/RVMUFqzPK00CHwJYO1kh+cCQQDO6xSzShu2sYt0pfdv" +
                    "GP/1QDKsLu6cNyNeM60SxUAC0yF0PWpaInOezTpdm+ca58/ymjVDDe4UtSoQAvng" +
                    "7/0nAkEA4RxDbuzkGvqr5OxZHf6olRc0dUGRhfbLqw7zVLZMULtVULuZ1VHUcVsI" +
                    "5AI+/njSvvLKN9Q9zUjrhb3ySyxuRwJAHKyjL71jXcv44W9mfLTgM6Jz4zyVwHw7" +
                    "oIBUybcgCcQsbKleJaOElksmfXZvbmEVhi8slmBF0ATTEWj4K93WHQJBAJA2YAB5" +
                    "BaqIHvO8qonIcNcwtnaaIgZPWUfgNmNBkzz3+jPhnp1b9nbehTf/U45o+pbzjJeT" +
                    "TPov73pmpye2LqY=";
            String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4yxIo6wLVFN+5JPbE28kZ6Pyh" +
                    "4HZp1Nn14gSwptzN24ipK6y1uk8zwZTf6c+iAkvgAi8Meyf9kkt+j8HvKetCAgGi" +
                    "GFYUDDDZtNrOGjfC/3kzoFM+c+i20T1zRTVqBk5owYcxC5SGCLlLwEEZ6aR6nJF2" +
                    "BPyYm1qFp83UhUj/MQIDAQAB";
            String data = "yangpeng";*/

            /* String data = "A5FDB55607255C61760ED6EA4FD0A41F0CB1122048BC1CF0F2D1566D1C866E2E6" +
                    "749E8FBC65E86CEDE851851EE8BF6A8E822B9ECE80522729CD132D478B347" +
                    "AFF19388787EBC7F9C51F844E1A21E179E6124F8D8F2908445F1AAAE7CC1D" +
                    "9181A5EAF84DD0819413DDC60D73D1D9C32E5F50EBF536BDAA71D618137912B541848";
            String result = decryptHex(data, privateKey);
            System.out.println(result);*/
//

//           KeyPair keyPair = getKeyPair();
//           String privateKey = new String(Base64.encodeBase64(keyPair.getPrivate().getEncoded()));
//           String publicKey = new String(Base64.encodeBase64(keyPair.getPublic().getEncoded()));


           String privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBANV0fGFrZDmVQgWDVHbi5A67qtS/DoxewW6q4AosFL8GaVqBkQk2QjAT+J0DLk84GQbuZSIT/nyxW0Dt/FtP4t/mnCqObg2lIZgntmG8wyfSCLbyr6jAEwC3TzDa3WZUmAJ4jfCRCpvBYp+axFlIycz+65b9x7MDGHbPRvnQCV0PAgMBAAECgYEAjQCx2TizsEYkoreqaA5hUEowAvFijt9ZL924uX99BOMbXSoRwOASwOewZyfew33vKmD4dZZ3ma8e9LlA5qDS4JdblVxTU+Outd75Wf+K1+SdifP4shi/ZeFnuQP5Xh0fbk06tT3C32rNr0iUevF3DAnUSL+PuhZS74ER6ljZ5iECQQD5fEOzw5qTS21veL0A9cN9NosLPUQeBKEycbIPtmVaywxwMMBA2urOzDxKDDFAQkQ1oQQ/cTfivyjA6qjL5+8rAkEA2wdeeDdyGxHVxUdDv+m7YPhnXBDVo95dbsmEfu1fODZvRpcHuKmR4YDT0iDNMWoNql/en9J8Ug/l1uintn+3rQJAJxGtrH4KO9zJA3bd6kOSXI5pEdaDT0wcTkD9yHYgwyofBYas5LsjoETdgB8Oq2h1NAzGFIVPYiPbZvKYgm4MxwJAa9Mx3460Hr1l9ouBv82J0FAZWgpzkgtbBbow/udOc/bgSuj5BSB9T31DSfOZ8FScS56MkzNkvmVTKbw5LC+ttQJARBLi3w34IZk4JqfNZ2ScWclg4oAcFeUbd6R8t3YiQeS2vteNqthFViR4rh0crf8lK9WZuJJqo2nQSuyFKEJVZA==";
           String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDVdHxha2Q5lUIFg1R24uQOu6rU\n" +
                   "vw6MXsFuquAKLBS/BmlagZEJNkIwE/idAy5POBkG7mUiE/58sVtA7fxbT+Lf5pwq\n" +
                   "jm4NpSGYJ7ZhvMMn0gi28q+owBMAt08w2t1mVJgCeI3wkQqbwWKfmsRZSMnM/uuW\n" +
                   "/cezAxh2z0b50AldDwIDAQAB";
            System.out.println(privateKey);
           System.out.println(publicKey);
           String data = "app_key=7e289a2484f4368dbafbd1e5c7d06903&extend=linkedme&recipient=+8615970704470&status_callback_url=http://requestbin.fullcontact.com/scvavdsc&template_id=TTS01&template_params=2222";
           String sign = Rsa.signHex(data, privateKey, SignAlgorithm.SHA256withRSA);
           System.out.println(sign);
           boolean flag = Rsa.verifyHex(data, publicKey, sign, SignAlgorithm.SHA256withRSA);
           System.out.println(flag);


        } catch (Exception e) {
            e.printStackTrace();
            System.out.print("加解密异常");
        }
    }
}