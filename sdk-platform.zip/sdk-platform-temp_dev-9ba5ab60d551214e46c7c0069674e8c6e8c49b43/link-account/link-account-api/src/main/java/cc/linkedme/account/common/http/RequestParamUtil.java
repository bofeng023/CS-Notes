package cc.linkedme.account.common.http;

import javax.servlet.http.HttpServletRequest;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author yangpeng
 * @date 2019-06-24 18:49
 * @description
 **/
public class RequestParamUtil {

    public static Map<String, String> extractRequestParams(HttpServletRequest request) {

        Map<String, String> params = new TreeMap<>();
        Map<String, String[]> requestParams = request.getParameterMap();
        for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();)
        {
            String name = iter.next();
            String[] values = requestParams.get(name);
            String valueStr = "";
            for (int i = 0; i < values.length; i++)
            {
                valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
            }

            params.put(name, valueStr);
        }
        return params;
    }
}
