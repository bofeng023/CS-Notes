package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

public class SmsTemplateException extends BusinessException {
    public SmsTemplateException(ErrorCode errorCode) {
        super(errorCode);
    }
}
