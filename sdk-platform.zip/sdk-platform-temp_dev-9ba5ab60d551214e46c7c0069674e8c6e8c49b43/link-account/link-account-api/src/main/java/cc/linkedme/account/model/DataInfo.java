package cc.linkedme.account.model;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class DataInfo {

    private Map<String,ConsumeCountInfo> trendMap;

    /**
     * 统计指标项列表
     */
    private List<ConsumeCountInfo> consumerCountBOList;

    /**
     * 汇总
     */
    private ConsumeCountInfo totalConsumerCountBO;

}
