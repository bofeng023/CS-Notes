package cc.linkedme.account.model.provider.login;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-13 15:22
 * @description
 **/
@Data
public class CmccGetMobileRequest {

    /**
     * 是否必填：是
     * 填2.0
     */
    private String version;

    /**
     * 是否必填：是
     * 标识请求的随机数即可(1-36位)
     */
    private String msgid;

    /**
     * 是否必填：是
     * 请求消息发送的系统时间，精确到毫秒，共17位，格式: 20121227180001165
     */
    private String systemtime;

    /**
     * 是否必填：是
     * 暂时填写"0"，填写“1”时，将对服务器IP白名单进行强校验(后续将强制要 求IP强校验)
     */
    private String strictcheck;

    /**
     * 是否必填：是
     * 业务在统一认证申请的应用id
     */
    private String appid;

    /**
     * 是否必填：否
     * 扩展参数
     */
    private String expandparams;

    /**
     * 是否必填：是
     * 需要解析的凭证值
     */
    private String token;

    /**
     * 是否必填：是
     * 当encryptionalgorithm≠"RSA"时，sign = MD5(appid + version + msgid + systemtime + strictcheck + token + APPSecret)(注:“+”号为合并意 思，
     * 不包含在被加密的字符串中)，输出32位大写字母;
     * 当encryptionalgorithm="RSA"，开发者使用在社区配置的验签公钥(应 用公钥1)对应的私钥进行签名(appid+token)
     */
    private String sign;

    /**
     * 是否必填：否
     * 推荐使用。开发者如果需要使用非对称加密算法时，填写“RSA”。(当该值 不设置为“RSA”时，执行MD5签名校验)
     */
    private String encryptionalgorithm;
}
