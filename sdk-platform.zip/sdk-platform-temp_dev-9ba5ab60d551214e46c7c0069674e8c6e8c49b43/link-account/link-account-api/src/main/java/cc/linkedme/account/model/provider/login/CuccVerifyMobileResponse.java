package cc.linkedme.account.model.provider.login;

import lombok.Data;
import org.aspectj.lang.annotation.DeclareAnnotation;

/**
 * @author zhanghaowei
 * @date 2019-6-15 15:57
 * @description
 **/

@Data
public class CuccVerifyMobileResponse {

    private String code;

    private String msg;

    private String data;

    @lombok.Data
    public static class Data {

        private Integer isVerify;
    }
}
