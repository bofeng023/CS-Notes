package cc.linkedme.account.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: liuyunmeng
 * @Date: Create in 20:30 2019-08-13
 * @:Description
 */
public enum RechargeType {

    NORMAL_RECHARGE(1, "正常充值"),
    GIFT_RECHARGE(2, "赠送充值");

    RechargeType(Integer type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    private Integer type;

    private String desc;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    private static final Map<Integer, RechargeType> lookup = new HashMap<>();
    static {
        for (RechargeType rechargeType : EnumSet.allOf(RechargeType.class)) {
            lookup.put(rechargeType.getType(), rechargeType);
        }
    }

    public static RechargeType get(Integer type) {
        return lookup.get(type);
    }

}
