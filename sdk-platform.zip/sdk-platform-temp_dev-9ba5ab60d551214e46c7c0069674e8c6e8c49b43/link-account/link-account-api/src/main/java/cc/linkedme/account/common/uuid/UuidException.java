package cc.linkedme.account.common.uuid;

/**
 * @author yangpeng
 * @date 2019-07-19 17:52
 * @description
 **/
public class UuidException extends RuntimeException {

    public UuidException(String msg) {
        super(msg);
    }

    public UuidException(String msg, Exception e) {
        super(msg, e);
    }
}
