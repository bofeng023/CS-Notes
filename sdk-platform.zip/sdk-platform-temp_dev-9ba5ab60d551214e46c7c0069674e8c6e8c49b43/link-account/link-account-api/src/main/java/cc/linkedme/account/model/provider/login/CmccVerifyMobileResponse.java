package cc.linkedme.account.model.provider.login;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-14 17:53
 * @description
 **/
@Data
public class CmccVerifyMobileResponse {

    private Header header;

    private Body body;

    @Data
    public static class Header {

        private String msgId;

        private String timestamp;

        private String appId;

        private String resultCode;
    }

    @Data
    public static class Body {

        private String resultDesc;

        private String message;

        private String accessToken;

        private String expandParams;
    }
}
