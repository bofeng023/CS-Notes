package cc.linkedme.account.enums.provider.login;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum CtccResponseCode {

    SUCCESS("0", "请求成功"),
    PERMISSION_DENIED("-64", "permission-denied(无权限访问)"),
    INTERFACE_OVERRUN("-65", "调用接口超限"),
    OFFER_NUMBER_FAIL("-10001", "取号失败"),
    PARAM_ERROR("-10002", "参数错误"),
    DECRYPT_FAIL("-10003", "解密失败"),
    IP_LIMIT("-10004", "ip 受限"),
    DIFFERENT_NETWORKS_GET_NUMBER_PARAMS_FAIL("-10005", "异网取号回调参数异常"),
    MDN_GET_NUMBER_FAIL("-10006", "Mdn 取号失败，且属于电信网络"),
    DIFFERENT_NETWORKS_GET_NUMBER("-10007", "重定向到异网取号"),
    OVER_THRESHOLD("-10008", "超过预设取号阈值"),
    TIME_EXPIRES("-10009", "时间戳过期"),
    SIGN_INVALID("-20005", "签名错误"),
    APP_NOT_EXIST("-20006", "应用不存在"),
    PUBLIC_KEY_NOT_EXIST("-20007", "公钥数据不存在"),
    INTERNAL_ANALYSIS_ERROR("-20100", "内部解析错误"),
    PARSE_ENCRYPT_PARAMS_FAIL("-20102", "加密参数解析失败"),
    ILLEGAL_TIMESTAMP("-30001", "时间戳非法"),
    TOP_CLASS_FAIL("-30003", "topClass 失效"),
    PARAMS_EMPTY("51002", "参数为空"),
    GET_PHONE_NUM_FAIL("51114", "无法获取手机号数据");

    private String code;

    private String msg;

    CtccResponseCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }


    private final static Map<String,CtccResponseCode> lookup = new HashMap<>();

    static {
        for (CtccResponseCode ctccResponseCode : EnumSet.allOf(CtccResponseCode.class)) {
            lookup.put(ctccResponseCode.getCode(), ctccResponseCode);
        }
    }

    public static CtccResponseCode get(String code) {
        return lookup.get(code);
    }

}
