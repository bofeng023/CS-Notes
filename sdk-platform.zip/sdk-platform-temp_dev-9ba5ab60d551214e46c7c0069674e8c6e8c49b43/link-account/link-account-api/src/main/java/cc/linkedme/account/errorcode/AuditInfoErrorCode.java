package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface AuditInfoErrorCode extends BaseErrorCode {

    ErrorCode BIZ_TYPE_NULL_ERROR = new ErrorCode(600001, "业务类型不能为空");

    ErrorCode BIZ_TYPE_NOT_EXIST = new ErrorCode(600002, "业务类型不存在");

    ErrorCode BIZ_ID_NULL_ERROR = new ErrorCode(600003, "业务实体ID不能为空");

    ErrorCode TOP_UP_FINANCE_AUDIT_PASSWORD_ERROR = new ErrorCode(600004, "充值财务审核密码错误");

    ErrorCode EXPRESS_COMPANY_NULL_ERROR = new ErrorCode(600005, "快递公司信息不能为空");

    ErrorCode TRACKING_NUMBER_NULL_ERROR = new ErrorCode(600006, "快递单号不能为空");

    ErrorCode UPDATE_BIZ_ENTITY_STATE_ERROR = new ErrorCode(600007, "更新业务信息审核状态失败");
}
