package cc.linkedme.account.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author yangpeng
 * @date 2019-06-17 17:05
 * @description
 **/
@Data
public class AuthConfigInfo {

    private Integer id;

    private Integer appId;

    private String appKey;

    private String appSecret;

    private String publicKey;


    private String ipWhitelist;

    private String accountIpWhitelist;

    private Cmcc cmcc;

    private Ctcc ctcc;

    private Cucc cucc;

    private Date gmtCreate;

    private Date gmtUpdate;
    @Data
    public static class Cmcc {


        private String androidAppId;

        private String androidAppKey;

        private String androidAppSecret;

        private String iosAppId;

        private String iosAppKey;

        private String iosAppSecret;

        private String privateKey;

        private String publicKey;

    }
    @Data
    public static class Ctcc {


        private String appId;

        private String appSecret;

        private String privateKey;

        private String publicKey;
    }
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Cucc {

        private String clientId;

        private String clientSecret;

        private String grantSecret;

        private String privateKey;

        private String publicKey;

        private String androidPackName;

        private String androidPackSign;

        private String iosBundleId;

        public Cucc(String clientId, String clientSecret, String grantSecret, String privateKey, String publicKey) {
            this.clientId = clientId;
            this.clientSecret = clientSecret;
            this.grantSecret = grantSecret;
            this.privateKey = privateKey;
            this.publicKey = publicKey;
        }
    }

}
