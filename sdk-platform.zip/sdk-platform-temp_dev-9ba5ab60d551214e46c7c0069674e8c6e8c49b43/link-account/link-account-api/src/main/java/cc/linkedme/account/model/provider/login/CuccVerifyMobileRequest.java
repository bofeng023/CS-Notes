package cc.linkedme.account.model.provider.login;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.Data;

/**
 * @author zhanghaowei
 * @date 2019-6-15 15:07
 * @description
 **/
@Data
public class CuccVerifyMobileRequest {

    @JsonProperty("headers")
    private Header header;

    private Body body;

    @Data
    public static class Header {

        /**
         * 是否必填：是
         * client_id、client_secret 在申请接入权限时获得
         */
        @JsonProperty("client_id")
        private String clientId;

        /**
         * 是否必填：是
         * 设备类型（1-pc 端，2-Wap，3-移动客户端）
         */
        @JsonProperty("client_type")
        private String clientType;

        /**
         * 是否必填：是
         * Android 提供应用包名，iOS 提供 bundle id
         */
        private String packname;


        /**
         * 是否必填：否
         * Android 提供应用包签名，iOS 可为空
         */
        private String packsign;

        /**
         * 是否必填：否
         * 调用的接口版本号，如 v2.0
         * version
         */
        private String version;

        private String format;
    }

    @Data
    public static class Body {

        /**
         * 是否必填：是
         * 精确到毫秒
         * 最大长度20
         */
        private long timeStamp;

        /**
         * 是否必填：是
         * 最大长度256
         * 访问令牌
         */
        private String accessCode;

        /**
         * 是否必填：否
         * 号码加密方 式
         * 支持 SHA256，明文丌需传 该参数
         * 最大长度10
         */
        private String algorithm;

        /**
         * 是否必填：是
         * 手机号(联通 号码，非联通 号码无法判 断)
         * 最大长度20
         * 可选择加密传输,加密密钥为 client_secret，如加密必须 通过 algorithm 传入对应加 密算法;
         * 如果 algorithm 为 空，则视 mobile 为明文传 输，加密方法见附录 5.3 java 版本加密方式
         */
        private String mobile;
    }
}
