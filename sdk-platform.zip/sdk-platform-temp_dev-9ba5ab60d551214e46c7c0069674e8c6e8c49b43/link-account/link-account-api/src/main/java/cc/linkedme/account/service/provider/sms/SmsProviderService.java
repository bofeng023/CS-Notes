package cc.linkedme.account.service.provider.sms;

import cc.linkedme.account.exception.SmsException;
import cc.linkedme.account.model.sms.SmsInfo;
import cc.linkedme.account.model.sms.VoiceSmsInfo;

/**
 * @author lipeng
 * @date 2019-08-01 21:45
 * @description
 **/
public interface SmsProviderService {

    /**
     * 发送短信文本
     *
     * @param smsInfo 封装发送短信信息
     * @throws SmsException
     */
    void sendText(SmsInfo smsInfo) throws SmsException;

    /**
     * 处理语音短信消息
     *
     * @param voiceSmsInfo
     * @throws SmsException
     */
    void sendVoice(VoiceSmsInfo voiceSmsInfo) throws SmsException;

}
