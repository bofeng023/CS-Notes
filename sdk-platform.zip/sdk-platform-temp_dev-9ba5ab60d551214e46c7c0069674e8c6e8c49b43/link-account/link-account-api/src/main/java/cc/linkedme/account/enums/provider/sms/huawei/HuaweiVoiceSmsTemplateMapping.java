package cc.linkedme.account.enums.provider.sms.huawei;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: liuyunmeng
 * @Date: Create in 15:49 2019-07-22
 * @:Description
 */
public enum HuaweiVoiceSmsTemplateMapping {

    REGISTERED("TTS01","235edb90aae544dfa8a2b98910e33964"),
    LOGIN("TTS02","5ddf30df68454999b1f4a484927e1cab"),
    AUTHENTICATION("TTS03","638579fc50c149cfb1d75207836d009d"),
    VERIFICATION("TTS04","722a26db7f9c4ba091b5473c985feeb9");

    /** 场景ID，用户输入 */
    String sceneId;
    /** 模版ID 调用华为接口使用 */
    String templateId;

    HuaweiVoiceSmsTemplateMapping(String sceneId, String templateId) {
        this.sceneId = sceneId;
        this.templateId = templateId;
    }

    public String getSceneId() {
        return sceneId;
    }

    public void setSceneId(String sceneId) {
        this.sceneId = sceneId;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    private static final Map<String, HuaweiVoiceSmsTemplateMapping> lookup = new HashMap<>();

    static {
        for (HuaweiVoiceSmsTemplateMapping s : EnumSet.allOf(HuaweiVoiceSmsTemplateMapping.class)) {
            lookup.put(s.getSceneId(), s);
        }
    }

    public static HuaweiVoiceSmsTemplateMapping get(String sceneId) {
        return lookup.get(sceneId);
    }
}

