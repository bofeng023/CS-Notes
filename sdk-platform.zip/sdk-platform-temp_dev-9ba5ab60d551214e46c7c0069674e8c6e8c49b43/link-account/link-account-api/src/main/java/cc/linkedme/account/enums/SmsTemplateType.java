package cc.linkedme.account.enums;

/**
 * @Author: liuyunmeng
 * @Date: Create in 19:33 2019-07-29
 * @:Description
 */
public enum SmsTemplateType {

    DATE_TYPE("DATE"),
    TIME_TYPE("TIME"),
    NUM_TYPE("NUM"),
    TXT_TYPE("TXT");

    private String type;

    SmsTemplateType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
