package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:44 2019-08-14
 * @:Description
 */
public class MessageException extends BusinessException {


    public MessageException(ErrorCode errorCode) {
        super(errorCode);
    }
}
