package cc.linkedme.account.service;

import cc.linkedme.account.exception.InvoiceException;
import cc.linkedme.account.model.InvoiceInfo;
import cc.linkedme.account.model.SearchParam;

import java.util.List;

/**
 * 发票
 * @author zhanghaowei
 */
public interface InvoiceService {

    /**
     * 保存发票信息
     * @param invoiceInfo
     * @return
     * @throws InvoiceException
     */
    InvoiceInfo saveInvoiceInfo(InvoiceInfo invoiceInfo) throws InvoiceException;

    /**
     * 更新发票信息
     * @param invoiceInfo
     * @return
     * @throws InvoiceException
     */
    Integer updateInvoiceInfo(InvoiceInfo invoiceInfo) throws InvoiceException;

    /**
     * 查询 发票信息分页
     * @return
     * @throws InvoiceException
     */
    List<InvoiceInfo> listInvoice(SearchParam searchParam) throws InvoiceException;


    /**
     * 获取单个发票信息
     * @param id
     * @return
     * @throws InvoiceException
     */
    InvoiceInfo getInvoiceInfo(Integer id) throws InvoiceException;


//    /**
//     * 查看充值信息,包含审核信息
//     * @param id 充值ID
//     * @return
//     * @throws InvoiceException
//     */
//    InvoiceInfo getInvoiceAndAuditInfo(Integer id) throws InvoiceException;


    Long countInvoice(Integer uid, SearchParam searchParam) throws InvoiceException;

    /**
     * 发票取消
     * @param id 主键
     * @return
     */
    Integer cancelInvoice(Integer id) throws InvoiceException;

    Long countInvoiceAmount(Integer uid);
}
