package cc.linkedme.account.service;

import cc.linkedme.account.model.MessageInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.exception.BusinessException;

import java.util.List;

/**
 * @Author: liuyunmeng
 * @Date: Create in 11:00 2019-08-13
 * @:Description
 */
public interface MessageService {


    /**
     * 发送站内信
     * @param messageInfo
     * @throws BusinessException
     */
    void sendMsg(MessageInfo messageInfo) throws BusinessException;

    /**
     * 根据uid 和 messageId 获取单条消息
     * @param messageId
     * @param uid
     * @return
     * @throws BusinessException
     */
    MessageInfo getMsg(Long messageId, Integer uid) throws BusinessException;

    /**
     * 获取多条消息
     * @param searchParam
     * @return
     * @throws BusinessException
     */
    List<MessageInfo> getMsgList(SearchParam searchParam, Integer messageType, Integer readStatus) throws BusinessException;

    /**
     * 提供方给用户使用
     * @param messageId
     * @param uid
     * @throws BusinessException
     */
    void deleteMsg(Long messageId, Integer uid) throws BusinessException;

    /**
     * 更改阅读状态
     * @param messageId
     * @param uid
     */
    void changeReadStatus(Long messageId, Integer uid) throws BusinessException;
}
