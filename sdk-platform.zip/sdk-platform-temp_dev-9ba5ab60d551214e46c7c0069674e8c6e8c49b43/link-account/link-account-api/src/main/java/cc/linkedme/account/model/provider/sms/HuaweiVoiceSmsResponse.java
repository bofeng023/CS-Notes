package cc.linkedme.account.model.provider.sms;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author zhanghaowei
 * @date 2019-07-24 14:40
 * @description
 **/

@Data
public class HuaweiVoiceSmsResponse {

    /**
     * 请求返回的结果码
     */
    @JsonProperty(value="resultcode")
    private String resultCode;

    /**
     * 请求返回的结果描述
     */
    @JsonProperty(value="resultdesc")
    private String resultDesc;

    /**
     * 会话sessionId，如果请求失败，则sessionId为空
     */
    private String sessionId;

    /**
     * 参数表示平台呼叫端口空闲可用数量，取值范围0~65535
     */
    private Integer idlePort;


}
