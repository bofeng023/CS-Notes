package cc.linkedme.account.common.http;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.ProxyHost;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.Map;
import java.util.stream.Collectors;

public class HttpClientUtil {
    private final static Logger monitorLog = LoggerFactory.getLogger("http-monitor");
    private final static Logger bizLog = LoggerFactory.getLogger(HttpClientUtil.class);
    public final static int DEFAULT_MAX_CONNECTION_PER_HOST = 150;
    public final static int DEFAULT_CONNECTION_TIMEOUT_MS = 6000;
    public final static int DEFAULT_SOCKET_TIMEOUT_MS = 6000;
    public final static int DEFAULT_MAX_SIZE = 1024 * 1024;
    private final static int HTTP_BAD = 400;
    private int maxSize;
    private MultiThreadedHttpConnectionManager connectionManager;
    private HttpClient httpClient;
    private final static String POST_METHOD = "post";
    private final static String GET_METHOD = "get";
    private final static String HTTP_UNICODE = "utf-8";

    public HttpClientUtil() {
        this(DEFAULT_MAX_CONNECTION_PER_HOST, DEFAULT_CONNECTION_TIMEOUT_MS, DEFAULT_SOCKET_TIMEOUT_MS, DEFAULT_MAX_SIZE);
    }

    public HttpClientUtil(int maxConPerHost, int connectionTimeOutMs, int soTimeOutMs, int maxSize) {
        connectionManager = new MultiThreadedHttpConnectionManager();
        HttpConnectionManagerParams params = connectionManager.getParams();
        params.setMaxTotalConnections(600);// 这个值要小于tomcat线程池是800
        params.setDefaultMaxConnectionsPerHost(maxConPerHost);
        params.setConnectionTimeout(connectionTimeOutMs);
        params.setSoTimeout(soTimeOutMs);
        this.maxSize = maxSize;
        httpClient = new HttpClient(connectionManager);

    }

    /**
     * 设置代理
     * @param proxyHost
     */
    public void setProxy(final ProxyHost proxyHost){
        httpClient.getHostConfiguration().setProxyHost(proxyHost);
    }

    /**
     * 设置代理
     * @param proxyHost
     * @param proxyPort
     */
    public void setProxy(final String proxyHost, int proxyPort){
        httpClient.getHostConfiguration().setProxy(proxyHost,proxyPort);
    }

    /**
     * HttpGet请求，返回httpCode 同时用outputStream将response带回给调用方
     * 默认Content-Type是application/json;charset=UTF-8
     *
     * @param url          请求的url
     * @param paramMap     Key->value pairs,which will be automcatically URL encoded and should not have
     *                     been encoded previously.
     * @param outputStream Http response outputStream
     * @return httpCode the http method response code
     */
    public int httpGet(String url, Map<String, String> paramMap, ByteArrayOutputStream outputStream) {
        return httpGet(url, paramMap, null, outputStream);
    }

    /**
     * @param url          请求的url
     * @param paramMap     Key->value pairs,which will be automcatically URL encoded and should not have
     *                     been encoded previously.
     * @param headerMap    Key->value pairs
     * @param outputStream Http response outputStream
     * @return httpCode the http method response code
     */
    public int httpGet(String url, Map<String, String> paramMap, Map<String, String> headerMap, ByteArrayOutputStream outputStream) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(url)) {
            throw new RuntimeException("url param error");
        }
        if (outputStream == null) {
            outputStream = new ByteArrayOutputStream();
        }

        int httpCode = HTTP_BAD;
        try {
            GetMethod getMethod = new GetMethod(url);
            addQueryString(getMethod, paramMap);
            if (headerMap == null || headerMap.isEmpty() || !headerMap.containsKey("Content-Type")) {
                getMethod.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
            }

            addHeader(getMethod, headerMap);
            httpCode = executeMethod(outputStream, getMethod);
            return httpCode;
        } catch (Throwable e) {
            bizLog.error("httpClient get error, url=" + url + "，paramMap=" + paramMap, e);
            throw new RuntimeException("url: " + url, e);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            monitorLog.info("url:{}\tmethod:{}\tcode:{}\ttime:{}", url, GET_METHOD, httpCode, costTime);
        }
    }

    /**
     * 获取 访问URL的数据流
     * @param url
     * @param paramMap
     * @param headerMap
     * @return
     */
    public InputStream httpGet(String url, Map<String, String> paramMap, Map<String, String> headerMap) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(url)) {
            throw new RuntimeException("url param error");
        }

        int httpCode = HTTP_BAD;
        try {
            GetMethod getMethod = new GetMethod(url);
            addQueryString(getMethod, paramMap);
            addHeader(getMethod, headerMap);
            InputStream inputStream = executeMethodPart(getMethod);
            httpCode = HttpURLConnection.HTTP_OK;
            return inputStream;
        } catch (Throwable e) {
            bizLog.error("httpClient get error, url=" + url + "，paramMap=" + paramMap, e);
            throw new RuntimeException("url: " + url, e);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            monitorLog.info("url:{}\tmethod:{}\tcode:{}\ttime:{}", url, GET_METHOD, httpCode, costTime);
        }
    }

    public InputStream httpGet(String url) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(url)) {
            throw new RuntimeException("url param error");
        }
        int httpCode = HTTP_BAD;
        try {
            GetMethod getMethod = new GetMethod(url);
            InputStream inputStream = executeMethod(getMethod);
            httpCode = HttpURLConnection.HTTP_OK;
            return inputStream;
        } catch (Throwable e) {
            bizLog.error("httpClient get error, url:{}", url, e);
            throw new RuntimeException("url: " + url, e);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            monitorLog.info("url:{}\tmethod:{}\tcode:{}\ttime:{}", url, GET_METHOD, httpCode, costTime);
        }
    }


    public int httpGetContentLength(String url, Map<String, String> paramMap, Map<String, String> headerMap) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(url)) {
            throw new RuntimeException("url param error");
        }

        int httpCode = HTTP_BAD;
        try {
            GetMethod getMethod = new GetMethod(url);
            addQueryString(getMethod, paramMap);
            addHeader(getMethod, headerMap);
            int contentLength = getContentLength(getMethod);
            httpCode = HttpURLConnection.HTTP_OK;
            return contentLength;
        } catch (Throwable e) {
            bizLog.error("httpClient get error, url=" + url + "，paramMap=" + paramMap, e);
            throw new RuntimeException("url: " + url, e);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            monitorLog.info("url:{}\tmethod:{}\tcode:{}\ttime:{}", url, GET_METHOD, httpCode, costTime);
        }
    }

    public int httpPost(String url, Map<String, String> paramMap, ByteArrayOutputStream outputStream) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(url)) {
            throw new RuntimeException("url param error");
        }
        if (outputStream == null) {
            outputStream = new ByteArrayOutputStream();
        }

        int httpCode = HTTP_BAD;
        try {
            PostMethod postMethod = new PostMethod(url);
            if (!paramMap.isEmpty()) {
                NameValuePair[] nameValuePairs = new NameValuePair[paramMap.size()];
                paramMap.entrySet().stream().map(entry -> new NameValuePair(entry.getKey(), entry.getValue())).collect(Collectors.toList())
                        .toArray(nameValuePairs);
                postMethod.setRequestBody(nameValuePairs);
            }
            httpCode = executeMethod(outputStream, postMethod);
            return httpCode;
        } catch (Throwable e) {
            bizLog.error("httpClient post error, url=" + url + "，paramMap=" + paramMap, e);
            throw new RuntimeException("url: " + url, e);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            monitorLog.info("url:{}\tmethod:{}\tcode:{}\ttime:{}", url, POST_METHOD, httpCode, costTime);
        }
    }

    public int httpPost(String url, Map<String, String> headerMap, Map<String, String> paramMap, ByteArrayOutputStream outputStream) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(url)) {
            throw new RuntimeException("url param error");
        }
        if (outputStream == null) {
            outputStream = new ByteArrayOutputStream();
        }

        int httpCode = HTTP_BAD;
        try {
            PostMethod postMethod = new PostMethod(url);
            if (headerMap != null) {
                addHeader(postMethod, headerMap);
            }
            if (!paramMap.isEmpty()) {
                NameValuePair[] nameValuePairs = new NameValuePair[paramMap.size()];
                paramMap.entrySet().stream().map(entry -> new NameValuePair(entry.getKey(), entry.getValue())).collect(Collectors.toList())
                        .toArray(nameValuePairs);
                postMethod.setRequestBody(nameValuePairs);
            }
            httpCode = executeMethod(outputStream, postMethod);
            return httpCode;
        } catch (Throwable e) {
            bizLog.error("httpClient post error, url=" + url + "，paramMap=" + paramMap, e);
            throw new RuntimeException("url: " + url, e);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            monitorLog.info("url:{}\tmethod:{}\tcode:{}\ttime:{}", url, POST_METHOD, httpCode, costTime);
        }
    }

    public int httpPost(String url, String requestBody, ByteArrayOutputStream outputStream) {
        return httpPost(url, requestBody, outputStream, "application/json;charset=UTF-8", HTTP_UNICODE);
//        return httpPost(url, requestBody, outputStream, "application/json", HTTP_UNICODE);
    }


    public int httpPost(String url, String requestBody, ByteArrayOutputStream outputStream, String contentType, String charset) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(url)) {
            throw new RuntimeException("url param error");
        }
        if (outputStream == null) {
            outputStream = new ByteArrayOutputStream();
        }

        int httpCode = HTTP_BAD;
        try {
            PostMethod postMethod = new PostMethod(url);
            if (StringUtils.isNotBlank(requestBody)) {
                if (StringUtils.isBlank(charset)) {
                    charset = HTTP_UNICODE;
                }
                postMethod.setRequestEntity(new StringRequestEntity(requestBody, contentType, charset));
            }
            httpCode = executeMethod(outputStream, postMethod);
            return httpCode;
        } catch (Throwable e) {
            bizLog.error("httpClient post error, url=" + url + "，request body=" + requestBody, e);
            throw new RuntimeException("url: " + url, e);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            monitorLog.info("url:{}\tmethod:{}\tcode:{}\ttime:{}", url, POST_METHOD, httpCode, costTime);
        }
    }

    /**
     * Sets the query string of this HTTP method. The pairs are encoded as UTF-8 characters. To use
     * a different charset the parameters can be encoded manually using EncodingUtil and set as a
     * single String.
     *
     * @param method   the {@link HttpMethod HTTP method} to execute.
     * @param paramMap Key->value pairs,which will be automcatically URL encoded and should not have
     *                 been encoded previously.
     * @see HttpMethod#setQueryString(NameValuePair[])
     */
    private static void addQueryString(HttpMethod method, Map<String, String> paramMap) {
        if (paramMap != null && paramMap.size() > 0) {
            NameValuePair[] nameValuePairs = new NameValuePair[paramMap.size()];

            int i = 0;
            for (Map.Entry<String, String> entry : paramMap.entrySet()) {
                nameValuePairs[i++] = new NameValuePair(entry.getKey(), entry.getValue());
            }
            method.setQueryString(nameValuePairs);
        }
    }

    /**
     * Sets the headers of this HTTP method.
     *
     * @param method    the {@link HttpMethod HTTP method} to execute.
     * @param headerMap Key->value pairs,which will be add to http header.
     * @see HttpMethod#setRequestHeader(String, String)
     */
    private static void addHeader(HttpMethod method, Map<String, String> headerMap) {
        if (headerMap != null && headerMap.size() > 0) {
            for (Map.Entry<String, String> entry : headerMap.entrySet()) {
                method.setRequestHeader(entry.getKey(), entry.getValue());
            }
        }
    }

    /**
     * @param outputStream Http response outputStream
     * @param httpMethod   the {@link HttpMethod HTTP method} to execute.
     * @return httpCode the method response code
     * @throws IOException      If an I/O (transport) error occurs. Some transport exceptions can be
     *                          recovered from.
     * @throws RuntimeException If the size of response body is over {@code maxSize} occurs.
     * @see HttpClient#executeMethod(HttpMethod)
     * @see HttpMethod#getResponseBodyAsStream()
     */
    private int executeMethod(ByteArrayOutputStream outputStream, HttpMethod httpMethod) throws IOException, RuntimeException {
        int httpCode = httpClient.executeMethod(httpMethod);
        try (InputStream in = httpMethod.getResponseBodyAsStream()) {
            byte[] b = new byte[1024];
            int len;
            int readLen = 0;
            while ((len = in.read(b)) > 0) {
                outputStream.write(b, 0, len);
                readLen += len;
                if (readLen > maxSize) {
                    throw new RuntimeException("http response body size is too big,size:" + readLen + ",maxSize:" + maxSize);
                }
            }
        } catch (Throwable t) {
            bizLog.error("http execute method failed, httpCode:{}", httpCode, t);
            throw new RuntimeException("http execute method failed, httpCode:" + httpCode);
        }
        return httpCode;
    }

    /**
     * 调用url 返回输入流
     *
     * @param httpMethod
     * @return
     * @throws IOException
     * @throws RuntimeException
     */
    private InputStream executeMethod(HttpMethod httpMethod) throws IOException, RuntimeException {
        int httpCode = httpClient.executeMethod(httpMethod);
        if (httpCode == HttpURLConnection.HTTP_OK) {
            return httpMethod.getResponseBodyAsStream();
        }
        return null;
    }

    private InputStream executeMethodPart(HttpMethod httpMethod) throws IOException, RuntimeException {
        int httpCode = httpClient.executeMethod(httpMethod);
        if (httpCode == HttpURLConnection.HTTP_OK || httpCode == HttpURLConnection.HTTP_PARTIAL) {
            return httpMethod.getResponseBodyAsStream();
        }
        return null;
    }


    /**
     * 获取访问流的长度
     * @param httpMethod
     * @return
     * @throws IOException
     * @throws RuntimeException
     */
    private int getContentLength(HttpMethod httpMethod) throws IOException, RuntimeException {
        int httpCode = httpClient.executeMethod(httpMethod);
        if (httpCode == HttpURLConnection.HTTP_OK) {
            return httpMethod.getResponseBody().length;
        }
        return 0;
    }

    public int httpPost(String url, String requestBody, Map<String, String> headerMap, ByteArrayOutputStream outputStream, String charset) {
        long start = System.currentTimeMillis();
        if (StringUtils.isEmpty(url)) {
            throw new RuntimeException("url param error");
        }
        if (outputStream == null) {
            outputStream = new ByteArrayOutputStream();
        }

        int httpCode = HTTP_BAD;
        try {
            PostMethod postMethod = new PostMethod(url);
            addHeader(postMethod, headerMap);
            if (headerMap == null || headerMap.isEmpty() || !headerMap.containsKey("Content-Type")) {
                postMethod.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
            }
            if (StringUtils.isNotBlank(requestBody)) {
                if (StringUtils.isBlank(charset)) {
                    charset = HTTP_UNICODE;
                }
                String contentType = "application/json;charset=UTF-8";
                if (headerMap != null  && headerMap.size() > 0) {
                    if (headerMap.get("Content_Type") != null) {
                        contentType = headerMap.get("Content_Type");
                    }
                }
                postMethod.setRequestEntity(new StringRequestEntity(requestBody, contentType, charset));
            }

            httpCode = executeMethod(outputStream, postMethod);
            return httpCode;
        } catch (Throwable e) {
            bizLog.error("httpClient post error, url=" + url + "，paramMap=" + requestBody, e);
            throw new RuntimeException("url: " + url, e);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            monitorLog.info("url:{}\tmethod:{}\tcode:{}\ttime:{}", url, POST_METHOD, httpCode, costTime);
        }
    }
}

