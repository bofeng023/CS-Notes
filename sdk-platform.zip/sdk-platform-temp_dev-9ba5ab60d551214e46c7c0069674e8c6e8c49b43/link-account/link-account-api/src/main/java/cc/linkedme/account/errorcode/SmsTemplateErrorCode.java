package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface SmsTemplateErrorCode extends BaseErrorCode {

    ErrorCode NAME_NULL_ERROR = new ErrorCode(300001, "模板名称不能为空");

    ErrorCode CONTENT_NULL_ERROR = new ErrorCode(300002, "模板内容不能为空");

    ErrorCode APPLY_REMARK_NULL_ERROR = new ErrorCode(300003, "申请说明不能为空");

    ErrorCode GLOBAL_DOMAIN_NULL_ERROR = new ErrorCode(300004, "模板使用范围不能为空");

    ErrorCode CODE_NULL_ERROR = new ErrorCode(300005, "模板Code为空");

    ErrorCode TEMPLATE_PARAS_ILLEGAL = new ErrorCode(300006, "参数格式不正确");

    ErrorCode TEMPLATE_ID_ERROR = new ErrorCode(300007, "模版ID不能为空");

    ErrorCode TEMPLATE_NOT_EXIST = new ErrorCode(300008, "模版不存在");

}
