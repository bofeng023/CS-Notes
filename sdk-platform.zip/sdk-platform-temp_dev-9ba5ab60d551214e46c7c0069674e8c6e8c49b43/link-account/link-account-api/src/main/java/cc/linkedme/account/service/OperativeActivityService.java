package cc.linkedme.account.service;

import cc.linkedme.account.model.TopUpInfo;

/**
 * @Author: liuyunmeng
 * @Date: Create in 20:31 2019-08-22
 * @:Description
 */
public interface OperativeActivityService {

    void giftMoney (TopUpInfo topUpInfo);
}
