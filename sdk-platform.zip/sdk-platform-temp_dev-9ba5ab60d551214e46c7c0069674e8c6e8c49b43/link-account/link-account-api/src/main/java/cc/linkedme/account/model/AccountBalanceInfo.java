package cc.linkedme.account.model;

import lombok.Data;

import java.util.Date;

@Data
public class AccountBalanceInfo {

    private Integer id;

    private Integer uid;

    private Integer amount;

    private Integer balance;

    private Date gmtCreate;

    private Date gmtModified;
}
