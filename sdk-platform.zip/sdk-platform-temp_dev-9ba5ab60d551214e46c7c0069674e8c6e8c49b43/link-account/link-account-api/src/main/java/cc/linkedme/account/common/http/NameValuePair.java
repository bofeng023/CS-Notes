package cc.linkedme.account.common.http;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-07-31 10:52
 * @description
 **/
@Data
public class NameValuePair {

    private String name;

    private String value;
}
