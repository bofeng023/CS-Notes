package cc.linkedme.account.enums.provider.sms.huawei;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * 华为短信状态code
 */
public enum HuaweiSmsCallbackStatus {

    SUCCESS("000000", "发送请求成功"),
    SMS_NUMBER_TOO_LARGE("E200015", "待发送短信数量太大"),
    TEMPLATE_VARIABLE_CHECK_FAIL("E200028", "模板变量校验失败"),
    TEMPLATE_TYPE_CHECK_FAIL("E200029", "模板类型校验失败"),
    TEMPLATE_INACTIVATION("E200030", "模板未激活"),
    PROTOCOL_CHECK_FAIL("E200031", "协议校验失败"),
    TEMPLATE_TYPE_INCORRECT("E200033", "模板类型不正确"),
    DELIVRD("DELIVRD", "用户已成功收到短信"),
    EXPIRED("EXPIRED", "短信已超时"),
    DELETED("DELETED", "短信已删除"),
    UNDELIV("UNDELIV", "短信递送失败"),
    ACCEPTD("ACCEPTD", "短信已接收"),
    UNKNOWN("UNKNOWN", "短信状态未知"),
    REJECTD("REJECTD", "短信被拒绝"),
    RTE_ERR("RTE_ERR", "平台内部路由错误"),
    MILIMIT("MILIMIT", "号码达到分钟下发限制"),
    LIMIT("LIMIT", "号码达到下发限制"),
    BEYONDN("BEYONDN", "号码达到下发限制"),
    KEYWORD("KEYWORD", "短信关键字拦截"),
    BLACK("BLACK", "号码黑名单"),
    MBBLACK("MBBLACK", "号码黑名单"),
    PHONE_INVALID("1", "手机号码不合法"),
    PHONE_INCORRECT("24", "手机号码不正确");

    private String code;
    private String msg;

    HuaweiSmsCallbackStatus(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private static final Map<String, HuaweiSmsCallbackStatus> lookup = new HashMap<>();

    static {
        for (HuaweiSmsCallbackStatus huaweiSmsCallbackStatus : EnumSet.allOf(HuaweiSmsCallbackStatus.class)) {
            lookup.put(huaweiSmsCallbackStatus.getCode(), huaweiSmsCallbackStatus);
        }
    }

    public static HuaweiSmsCallbackStatus get(String code) {
        return lookup.get(code);
    }
}
