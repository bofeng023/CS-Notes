package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;
import lombok.Data;

/**
 * @author zhanghaowei
 * @date 2019-6-4 10:46
 * @description
 **/
@Data
public class AccountBalanceException extends BusinessException {
    public AccountBalanceException(ErrorCode errorCode) {
        super(errorCode);
    }
}
