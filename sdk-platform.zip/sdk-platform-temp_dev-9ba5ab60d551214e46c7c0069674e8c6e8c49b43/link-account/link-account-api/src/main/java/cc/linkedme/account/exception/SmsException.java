package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

/**
 * @author zhanghaowei
 * @date 2019-7-16 17:27
 * @description
 **/
public class SmsException extends BusinessException {

    public SmsException (ErrorCode errorCode) {
        super(errorCode);
    }
}
