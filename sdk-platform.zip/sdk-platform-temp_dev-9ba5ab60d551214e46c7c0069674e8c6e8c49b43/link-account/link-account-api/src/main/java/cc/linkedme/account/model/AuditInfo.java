package cc.linkedme.account.model;

import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.BizType;
import lombok.Data;

import javax.persistence.Transient;
import java.util.Date;

/**
 * 审核信息
 * @author zhanghaowei
 */
@Data
public class AuditInfo {
    private Integer id;

    private Integer uid;

    private Integer bizId;

    private BizType bizType;

    private AuditState auditState;

    private String auditRemark;

    /**
     * 审核密码
     */
    @Transient
    private String auditPassword;

    private String auditor;

    private Date gmtCreate;

    private Date gmtModified;

    private String productIdentity;

    private String expressCompany;

    private String trackingNumber;

}