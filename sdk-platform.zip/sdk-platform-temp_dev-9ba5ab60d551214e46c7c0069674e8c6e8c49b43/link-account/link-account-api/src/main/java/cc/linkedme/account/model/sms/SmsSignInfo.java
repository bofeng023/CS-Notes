package cc.linkedme.account.model.sms;

import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class SmsSignInfo implements Serializable {

    private Integer id;

    private Integer uid;

    private Integer appId;

    private String signName;

    private String applyRemark;

    private YesNoEnum isGlobal;

    private String powerAttorney;

    private AuditState certificationState;

    private Date gmtCreate;

    private Date gmtUpdate;

}
