package cc.linkedme.account.service;

import cc.linkedme.account.exception.UserInfoException;
import cc.linkedme.account.model.AppInfo;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.UserInfo;

import java.util.List;
import java.util.Map;

/**
 * 用户信息 service
 * @author zhanghaowei
 */
public interface UserService {

    /**
     * 获取用户信息
     * @param ids 多个id
     * @return userInfoBO
     */
    Map<Integer, UserInfo> batchUserInfoBOByIds(List<Integer> ids) throws UserInfoException;

    Integer updateAccountAudit(UserInfo userInfo) throws UserInfoException;

    UserInfo getUserInfo(Integer uid) throws UserInfoException;

    UserInfo getUserInfoByEmail(String email) throws UserInfoException;

    List<UserInfo> listAccountAuthentication(SearchParam searchParam) throws UserInfoException;

    Long countAccountAuthentication(SearchParam searchParam) throws UserInfoException;

    List<UserInfo> listAccountOpening(SearchParam searchParam) throws UserInfoException;

    Long countAccountOpening(SearchParam searchParam) throws UserInfoException;

    /**
     * 获取token
     * @param userId 用户ID
     * @return String
     */
    String getUserToken(String userId) throws UserInfoException;

    /**
     * id 获取app信息
     * @param appId
     * @return
     */
    AppInfo getAppInfo(Integer appId);

    /**
     * 通过appKey 获取appinfo 信息
     * @param appKey
     * @return
     */
    AppInfo getAppInfoByAppKey (String appKey);

    /**============================ new =============================**/

    /**
     * 根据条件获取用户信息
     * @param searchParam
     * @return
     */
    List<UserInfo> getUserInfoList(SearchParam searchParam) throws UserInfoException;

    UserInfo getUserInfoByUid(Integer uid) throws UserInfoException;


}
