package cc.linkedme.account.constants;

/**
 * @author zhanghaowei
 * @date 2019-6-28 20:14
 * @description
 **/
public class ConsumeCountConstants {

    public static final String CONSUME_COUNT_TASK_LIST = "consume_count_task_list";

}
