package cc.linkedme.account.common.util;

import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanghaowei
 * @date 2019-6-6 13:10
 * @description
 **/
public class CookieUtils {
    public static final int COOKIE_MAX_AGE = 604800;
    public static final int COOKIE_HALF_HOUR = 1800;
    public static final String COOKIE_DOMAIN = ".linkedme.cc";

    public CookieUtils() {
    }

    public static Cookie getCookie(HttpServletRequest request, String name) {
        Cookie[] cookies = request.getCookies();
        if (null != cookies && cookies.length != 0) {
            Cookie cookie = null;
            Cookie[] var4 = cookies;
            int var5 = cookies.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                Cookie c = var4[var6];
                if (name.equals(c.getName())) {
                    cookie = c;
                    break;
                }
            }

            return cookie;
        } else {
            return null;
        }
    }

    public static String getCookieValue(HttpServletRequest request, String name) {
        Cookie cookie = getCookie(request, name);
        return cookie != null ? cookie.getValue() : null;
    }

    public static void removeCookie(HttpServletRequest request, HttpServletResponse response, String name) {
        if (null != name) {
            Cookie cookie = getCookie(request, name);
            if (null != cookie) {
                cookie.setPath("/");
                cookie.setValue("");
                cookie.setMaxAge(0);
                response.addCookie(cookie);
            }

        }
    }

    public static void setCookie(HttpServletResponse response, String name, String value, int maxValue) {
        if (!StringUtils.isBlank(name)) {
            if (null == value) {
                value = "";
            }

            Cookie cookie = new Cookie(name, value);
            cookie.setPath("/");
            cookie.setDomain("linkedme.cc");
            if (maxValue != 0) {
                cookie.setMaxAge(maxValue);
            } else {
                cookie.setMaxAge(1800);
            }

            response.addCookie(cookie);

            try {
                response.flushBuffer();
            } catch (IOException var6) {
                var6.printStackTrace();
            }

        }
    }

    public static void setCookie(HttpServletResponse response, String name, String value) {
        setCookie(response, name, value, 1800);
    }

    public static Map<String, Cookie> getCookieMap(HttpServletRequest request) {
        Map<String, Cookie> cookieMap = new HashMap();
        Cookie[] cookies = request.getCookies();
        if (null != cookies && cookies.length > 0) {
            Cookie[] var3 = cookies;
            int var4 = cookies.length;

            for(int var5 = 0; var5 < var4; ++var5) {
                Cookie cookie = var3[var5];
                cookieMap.put(cookie.getName(), cookie);
            }
        }

        return cookieMap;
    }
}
