package cc.linkedme.account.model;

import cc.linkedme.enums.YesNoEnum;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: liuyunmeng
 * @Date: Create in 10:32 2019-08-14
 * @:Description  msgId 关联message_info_0的主键id
 * ref_problem_id 对应消息的问题id
 * userId   0:所有用户 具体的userId:某一个用户  和message_info_0的receive_id一致
 * readStatus   0:未读消息  1:已读消息
 * readTime     读取时间
 */
@Data
public class UserMessageIndex implements Serializable {

    private Long id;

    private Long msgId;

    private Long refProblemId;

    private Integer userId;

    private YesNoEnum readStatus;

    private String readTime;

}
