package cc.linkedme.account.model.sms;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author zhanghaowei
 * @date 2019-7-15 15:42
 * @description
 **/

@Data
public class SmsInfo implements Serializable {

    private static final long serialVersionUID = -5191186286473069391L;

    private Integer uid;

    private Integer appId;

    /**
     * 短信接收方的号码
     */
    private String recipient;

    /**
     * 签名id
     */
    private Integer signId;

    /**
     * 签名名称
     */
    private String signName;

    /**
     * 模版ID
     */
    private String templateId;

    /**
     * 模版动态值
     */
    private List<String> templateParams;

    /**
     * 回调地址
     */
    private String statusCallbackUrl;

    /**
     * 扩展参数，在状态报告中会原样返回
     */
    private String extend;

    /**
     * 包含签名的短信内容
     */
    private String content;

    private List<SendResult> result;

    @Data
    public static class SendResult {

        private String smsMsgId;

        private String originTo;

        private long createTime;

        private String status;
    }

}