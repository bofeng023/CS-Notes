package cc.linkedme.account.common.uuid;

import com.whalin.MemCached.MemCachedClient;
import com.whalin.MemCached.SockIOPool;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author yangpeng
 * @date 2019-07-19 16:26
 * @description uuid发号器client，不作为通用mc client
 **/

public class UuidClient {

    private static final Logger logger = LoggerFactory.getLogger(UuidClient.class);

    @Setter
    @Getter
    private String server;
    private MemCachedClient mcClient;
    private String poolName;

    private int minSpareConnections = 25;
    private int maxSpareConnections = 35;
    private boolean consistentHashEnable = false;
    /** turn off auto-failover in event of server down */
    private boolean failover = true;
    private boolean sanitizeKeys = true;
    private boolean primitiveAsString = false;
    public static final long DEFAULT_MAX_BUSY_TIME = 1000 * 15;
    public static final int DEFAULT_SOCKET_TIMEOUT = 1000 * 5;
    public static final int DEFAULT_SOCKET_CONNECT_TIMEOUT = 1000 * 5;
    private int hashingAlg = SockIOPool.NEW_COMPAT_HASH;
    private long maxBusyTime = DEFAULT_MAX_BUSY_TIME;
    /** seconds to block on reads */
    private int socketTimeOut = DEFAULT_SOCKET_TIMEOUT;
    /** seconds to block on initial */
    private int socketConnectTimeOut = DEFAULT_SOCKET_CONNECT_TIMEOUT;

    public static final AtomicInteger poolCount = new AtomicInteger();

    public UuidClient() {
        this.poolName = "uuidClient-" + poolCount.incrementAndGet();
        mcClient = new MemCachedClient(poolName);
    }

    public void init() {

        int initialConnections = minSpareConnections;
        /** 30 minutes */
        int maxIdleTime = 1000 * 60 * 30;
        /** 5 seconds */
        long maintThreadSleep = 1000 * 5;
        boolean nagleAlg = true;

        mcClient.setSanitizeKeys(sanitizeKeys);
        mcClient.setPrimitiveAsString(primitiveAsString);
        SockIOPool pool = SockIOPool.getInstance(poolName);
        if (server == null) {
            throw new IllegalArgumentException("mc server port is empty");
        }
        pool.setServers(new String[]{server});
        pool.setInitConn(initialConnections);
        pool.setMinConn(minSpareConnections);
        pool.setMaxConn(maxSpareConnections);
        pool.setMaxIdle(maxIdleTime);
        pool.setMaxBusyTime(maxBusyTime);
        pool.setMaintSleep(maintThreadSleep);
        pool.setSocketTO(socketTimeOut);
        pool.setSocketConnectTO(socketConnectTimeOut);
        pool.setNagle(nagleAlg);
        pool.setHashingAlg(consistentHashEnable ? SockIOPool.CONSISTENT_HASH : hashingAlg);
        pool.setFailover(failover);
        try {
            pool.initialize();
        }
        catch (Exception e) {
            logger.error("mc client init failed, server:{}", server, e);
        }

    }

    /**
     * mc get
     *
     * @param key
     * @return
     */
    public Object get(String key) {
        return mcClient.get(key);
    }

}

