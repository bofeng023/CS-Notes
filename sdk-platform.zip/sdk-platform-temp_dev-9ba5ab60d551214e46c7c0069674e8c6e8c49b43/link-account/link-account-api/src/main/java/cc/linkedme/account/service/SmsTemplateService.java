package cc.linkedme.account.service;

import cc.linkedme.account.exception.SmsTemplateException;
import cc.linkedme.account.model.SearchParam;
import cc.linkedme.account.model.sms.SmsTemplateInfo;
import cc.linkedme.enums.AuditState;

import java.util.List;
import java.util.Map;

public interface SmsTemplateService {

    SmsTemplateInfo saveSmsTemplate(SmsTemplateInfo smsTemplateInfo) throws SmsTemplateException;

    Integer updateSmsTemplate(SmsTemplateInfo smsTemplateInfo) throws SmsTemplateException;

    void removeSmsTemplate(Integer smsTemplateId) throws SmsTemplateException;

    SmsTemplateInfo getSmsTemplate(Integer smsTemplateId, AuditState certificationState) throws SmsTemplateException;

    Map<Integer, SmsTemplateInfo> getBatchSmsTemplate(List<Integer> smsTemplateIdList) throws SmsTemplateException;

    List<SmsTemplateInfo> listSmsTemplate(Integer uid, SearchParam searchParam) throws SmsTemplateException;

    Long countSmsTextTemplate(Integer uid, SearchParam searchParam) throws SmsTemplateException;

    SmsTemplateInfo getSmsTemplateByCode(Integer appId, String smsTemplateCode) throws SmsTemplateException;

    String getVoiceTemplateId(String voiceTemplateId, String... templateParas);

    void checkSmsTemplate(String smsTemplateContent);

}
