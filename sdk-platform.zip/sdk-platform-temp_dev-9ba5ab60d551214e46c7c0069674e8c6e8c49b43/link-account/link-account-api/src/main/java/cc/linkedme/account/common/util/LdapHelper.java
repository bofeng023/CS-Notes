package cc.linkedme.account.common.util;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

import javax.naming.AuthenticationException;
import javax.naming.NamingException;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author zhanghaowei
 * @date 2019-6-6 11:56
 * @description
 **/
public class LdapHelper {
    private static LdapContext ctx;

    public LdapHelper() {
    }

    public static LdapContext getCtx() {
        Control[] connCtls = null;
        String account = "admin";
        String password = "ops-FreeIPA";
        String root = "dc=linkedme,dc=cc";
        Hashtable env = new Hashtable();
        env.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
        env.put("java.naming.provider.url", "ldap://ops-freeipa.linkedme.cc:389");
        env.put("java.naming.security.authentication", "simple");
        env.put("java.naming.security.principal", "uid=admin,cn=users,cn=compat,dc=linkedme,dc=cc");
        env.put("java.naming.security.credentials", password);

        try {
            System.out.print(env);
            ctx = new InitialLdapContext(env, (Control[])connCtls);
            System.out.println("认证成功");
        } catch (AuthenticationException var6) {
            System.out.println("认证失败");
            var6.printStackTrace();
        } catch (Exception var7) {
            System.out.println("认证出错：");
            var7.printStackTrace();
        }

        return ctx;
    }

    public static void closeCtx() {
        try {
            ctx.close();
        } catch (NamingException var1) {
            Logger.getLogger(LdapHelper.class.getName()).log(Level.SEVERE, (String)null, var1);
        }

    }

    public static boolean verifySHA(String ldappw, String inputpw) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        if (ldappw.startsWith("{SSHA}")) {
            ldappw = ldappw.substring(6);
        } else if (ldappw.startsWith("{SHA}")) {
            ldappw = ldappw.substring(5);
        }

        byte[] ldappwbyte = Base64.decode(ldappw);
        byte[] shacode;
        byte[] salt;
        if (ldappwbyte.length <= 20) {
            shacode = ldappwbyte;
            salt = new byte[0];
        } else {
            shacode = new byte[20];
            salt = new byte[ldappwbyte.length - 20];
            System.arraycopy(ldappwbyte, 0, shacode, 0, 20);
            System.arraycopy(ldappwbyte, 20, salt, 0, salt.length);
        }

        md.update(inputpw.getBytes());
        md.update(salt);
        byte[] inputpwbyte = md.digest();
        return MessageDigest.isEqual(shacode, inputpwbyte);
    }

}
