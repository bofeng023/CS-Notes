package cc.linkedme.account.common.crypto;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;

/**
 * @author zhanghaowei
 * @date 2019-6-26 20:42
 * @description
 **/
public class AESHexUtil {

    static Logger logger = LoggerFactory.getLogger(AESHexUtil.class);

    private final static String HEX = "0123456789ABCDEF";
    /**
     * AES 加密
     * @param content
     * @param password
     * @return
     */
    public static String encryptAES(String content, String password) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(password.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            byte[] byteContent = content.getBytes("utf-8");
            byte[] result = cipher.doFinal(byteContent);
            return toHex(result);
        } catch (Exception e) {
            logger.error("encryptAES error, e:{}", e);
        }
        return null;
    }


    /**
     * AES 解密
     * @param content
     * @param password
     * @return
     */
    public static String decryptAES(String content, String password) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(password.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            // 初始化为解密模式的密码器
            byte[] contentByte = hexToBytes(content);
            byte[] result = cipher.doFinal(contentByte);
            return new String(result);
        } catch (Exception e) {
            logger.error("decryptAES error, e:{}", e);
        }
        return null;
    }


    private final static char[] HEX16 = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    /**
     *
     * 将 byte 数组转换为十六进制文本
     *
     * @return
     */
    public static String toHex(byte[] buf) {
        if (buf == null || buf.length == 0) {
            return "";
        }
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < buf.length; i++) {
            out.append(HEX16[(buf[i] >> 4) & 0x0f]).append(HEX16[buf[i] & 0x0f]);
        }
        return out.toString();
    }

    /**
     * 将十六进制文本转换为 byte 数组 * @param str
     *
     * @return
     */
    public static byte[] hexToBytes(String str) {
        if (str == null) {
            return null;
        }
        char[] hex = str.toCharArray();
        int length = hex.length / 2;
        byte[] raw = new byte[length];
        for (int i = 0; i < length; i++) {
            int high = Character.digit(hex[i * 2], 16);
            int low = Character.digit(hex[i * 2 + 1], 16);
            int value = (high << 4) | low;
            if (value > 127)
                value -= 256;
            raw[i] = (byte) value;
        }
        return raw;
    }


    public static byte[] getBytes(String data) {
        String encoding = "UTF-8";
        byte[] bytes = new byte[]{};
        try {
            bytes = data.getBytes(encoding);
        } catch (UnsupportedEncodingException e) {
            logger.error("getBytes error, e:{}", e);
        }
        return bytes;
    }

    public static void main (String args[]) {
        String password = "linkedme2019nble";

        String s = "884FC18E0AE3EB3E9F5C88D5FFCDCEAB09C076E304F0B1B577B689B5D17380D1F37602CC08FD9E17C2A09A49C230D17DA6E09EC519E95F112E1C6BB32D57D52F9FDDDCAB594B2C9942834227657070854C8C6FD2263E9C535804A3A84CF7ECB6A2485905EB93A8EF051376E4044A224AAAADA79692F18F00AE27875D6BE2AEA7657D22E66406C3AA231F3104A935AA61AECFB9516C81618A346ED9342CB16661646C7DB685480862494C3BF95179D635341AED71D686CCE9700789C8AC58E9F7C3325343D79D15790FEA4B19FA1F644346AB14302157B6D2D798FC58F0C1AF8A995764D5426DBB334E2EF72EFE517AE3DCB3514E89CD29C4E36C574AE9096B5CDAE0FD198FFF453AFF0E79A2D1F4263343966536DB922DCE41454738C6D059E769607C7ABD3F618D489AB77282FF2395DC41C42C4346E2FE41F76E9268B6BB82FEF6466333795377DD5805464974D584C2DC0F4078A83921DA8580E61A5A9750 ";
        System.out.println(decryptAES(s, password));
    }

}
