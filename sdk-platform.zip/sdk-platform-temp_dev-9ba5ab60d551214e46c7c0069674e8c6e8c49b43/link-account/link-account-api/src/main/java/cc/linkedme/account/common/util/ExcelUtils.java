package cc.linkedme.account.common.util;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;

/**
 * @author zhanghaowei
 * @date 2019-6-4 16:20
 * @description
 **/
public class ExcelUtils {

    static Logger logger = LoggerFactory.getLogger(ExcelUtils.class);

    /**
     * 回写excel核心代码
     *
     * @param sheetName     表名
     * @param excelHeader   表列名
     * @param excelBody     列数据
     * @throws IOException
     */
    public static ByteArrayOutputStream writeExcelResponse(String sheetName,
                            List<String> excelHeader,
                            List<List<HashMap<String, Object>>> excelBody ) throws IOException {
        //保证表头和表数据一致
        for (List<HashMap<String, Object>> list : excelBody) {
            if (list.size() != excelHeader.size()) {
                logger.info("导出excel数据异常！表头和表数据条数不一致");
                return null;
            }
        }
        //web对象
        HSSFWorkbook workbook = new HSSFWorkbook();
        //创建表头等
        HSSFSheet sheet = workbook.createSheet(sheetName);
        HSSFCellStyle style = workbook.createCellStyle();
        /**
         * 水平居中
         */
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        /**
         * 垂直居中
         */
        style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
        //1.3、创建字体
        HSSFFont font = workbook.createFont();
        /**
         * 字体为Arial
         */
        font.setFontName(HSSFFont.FONT_ARIAL);
        /**
         * 加粗字体
         */
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        /**
         * 设置字体大小
         */
        font.setFontHeightInPoints((short) 10);
        /**
         * 加载字体
         */
        style.setFont(font);

        //表头
        HSSFRow row0 = sheet.createRow(0);
        int headIndex = 0;
        for (String name : excelHeader) {
            HSSFCell cell = row0.createCell(headIndex);
            cell.setCellValue(name);
            cell.setCellStyle(style);
            headIndex++;
        }
        //表数据
        int excelBodyIndex = 1;
        for (List<HashMap<String, Object>> list : excelBody) {
            HSSFRow row = sheet.createRow(excelBodyIndex);
            int cellIndex = 0;
            for (HashMap<String, Object> map : list) {
                HSSFCell cell = row.createCell(cellIndex);
                String type = String.valueOf(map.get("type"));
                Object value = map.get("value");
                if ("long".equalsIgnoreCase(type)) {
                    cell.setCellValue(value != null ? Long.valueOf(String.valueOf(value)) : 0);
                } else if ("double".equalsIgnoreCase(type)) {
                    cell.setCellValue(value != null ? Double.valueOf(String.valueOf(value)) : 0);
                } else if ("-".equalsIgnoreCase(type)) {
                    cell.setCellValue("-");
                } else {
                    cell.setCellValue(value != null ? String.valueOf(value) : "0");
                }
                cellIndex++;
            }
            excelBodyIndex++;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        workbook.write(out);
        return out;
    }
}
