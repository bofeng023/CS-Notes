package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface TopUpErrorCode extends BaseErrorCode {

    ErrorCode AMOUNT_NULL_ERROR = new ErrorCode(500001, "充值金额不能为空");

    ErrorCode RECEIPT_NULL_ERROR = new ErrorCode(500002, "发票信息不能为空");

    ErrorCode EMAIL_NULL_ERROR = new ErrorCode(500003, "客户email不能为空");

    ErrorCode ACCOUNT_TOP_UP_RECEIPT = new ErrorCode(500004, "银行回执单必填");

    ErrorCode ACCOUNT_TOP_UP_EMAIL = new ErrorCode(500005, "充值账号必填");

    ErrorCode ACCOUNT_TOP_UP_EMAIL_NOT_EXIST = new ErrorCode(500005, "账号无效");

    ErrorCode ACCOUNT_NUMBER_AUDIT_FAIL = new ErrorCode(500006, "账号审核失败");

    ErrorCode AUDIT_STATE_INVALID = new ErrorCode(500007, "审核状态无效");

}
