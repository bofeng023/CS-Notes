package cc.linkedme.account.service;

import cc.linkedme.account.enums.Channel;
import cc.linkedme.account.enums.Platform;
import cc.linkedme.account.exception.PhoneNumVerificationException;

public interface PhoneNumVerificationService {

    Long getLoginPhoneNum(Channel channel, Platform platform, String token, String authCode, Integer appId) throws PhoneNumVerificationException;

    Boolean verifyLoginPhoneNum(Channel channel, Platform platform, String token, Long phoneNum, Integer appId) throws PhoneNumVerificationException;
}
