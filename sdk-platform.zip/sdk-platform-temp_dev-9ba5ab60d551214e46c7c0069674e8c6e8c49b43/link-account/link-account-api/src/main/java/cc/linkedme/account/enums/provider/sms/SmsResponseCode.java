package cc.linkedme.account.enums.provider.sms;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: liuyunmeng
 * @Date: Create in 20:35 2019-08-01
 * @:Description
 */
public enum SmsResponseCode {

    SUCCESS("000000", "成功"),
    SEND_FREQUENCY_DAY_LIMIT("1300014", "该号码超出当日发送限制"),
    SEND_FREQUENCY_HOUR_LIMIT("1300015", "该号码超出小时发送限制"),
    SEND_FREQUENCY_MINUTE_LIMIT("1300016", "该号码超出分钟发送限制");

    private String code;
    private String msg;

    SmsResponseCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private static final Map<String, SmsResponseCode> lookup = new HashMap<>();

    static {
        for (SmsResponseCode smsResponseCode : EnumSet.allOf(SmsResponseCode.class)) {
            lookup.put(smsResponseCode.getCode(), smsResponseCode);
        }
    }

    public static SmsResponseCode get(String code) {
        return lookup.get(code);
    }
}
