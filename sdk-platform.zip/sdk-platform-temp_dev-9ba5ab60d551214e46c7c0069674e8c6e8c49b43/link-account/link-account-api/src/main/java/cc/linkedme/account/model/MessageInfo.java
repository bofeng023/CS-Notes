package cc.linkedme.account.model;

import cc.linkedme.account.enums.MessageType;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: liuyunmeng
 * @Date: Create in 17:53 2019-08-13
 * @:Description
 * senderId 消息发送者的userId
 * receiveId 0:所有用户 具体的userId:某一个用户
 * sendTime 消息发送的时间
 * title 消息标题
 * content 消息内容
 * category 0:系统消息 1:问题反馈消息
 * refProblemId 当category为1时，此参数必填，表示对应问题消息的ID
 */
@Data
public class MessageInfo implements Serializable {

    private Long id;

    private Long refProblemId;

    private Integer senderId;

    private Integer receiverId;

    private String sendTime;

    private String title;

    private String content;

    private MessageType messageType;

}
