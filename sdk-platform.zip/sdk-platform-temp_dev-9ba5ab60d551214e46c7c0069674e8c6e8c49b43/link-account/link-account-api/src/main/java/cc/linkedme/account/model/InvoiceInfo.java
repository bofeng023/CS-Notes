package cc.linkedme.account.model;

import cc.linkedme.account.enums.InvoiceType;
import cc.linkedme.enums.AuditState;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 发票
 * @author zhanghaowei
 */
@Data
public class InvoiceInfo implements Serializable {
    private Integer id;

    private Integer uid;

    private InvoiceType invoiceType;

    private String invoiceTitle;

    private String taxpayerIdentification;

    private String contactInfo;

    private String bankAccountInfo;

    private String invoiceItem;

    private Long invoiceAmount;

    private String recipientName;

    private String recipientAddress;

    private String recipientPhone;
    
    private String expressCompany;

    private String trackingNumber;

    private Date sendOutTime;

    private String trackingRemark;

    private AuditState auditState;

    private Date gmtCreate;

    private Date gmtModified;
}