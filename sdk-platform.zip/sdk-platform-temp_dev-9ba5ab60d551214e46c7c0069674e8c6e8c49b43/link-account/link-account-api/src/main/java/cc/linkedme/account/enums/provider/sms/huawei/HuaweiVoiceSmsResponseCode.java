package cc.linkedme.account.enums.provider.sms.huawei;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: liuyunmeng
 * @Date: Create in 16:10 2019-07-23
 * @:Description
 */
public enum HuaweiVoiceSmsResponseCode {

    SUCCESS("0","成功"),
    INTERNAL_SYSTEM_ERROR("1010001","系统错误"),
    PARAMETER_ERROR("1020001","参数错误"),
    INTERNAL_ERROR("1020002","内部错误"),
    THE_APP_KEY_IS_INVALID("1020150","app_key无效"),
    INSUFFICIENT_VOICE_PORTS("1020154","语音端口不足"),
    VOICE_CALL_PORTS_OUT_LIMIT("1020165","超出app_key语音呼叫端口数限制"),
    RESPONSE_TIMEOUT("1023002","响应超时"),
    INVALID_REQUEST("1010002","非法请求"),
    INVALID_APP_KEY("1010003","无效的app_key"),
    INVALID_ACCESS_TOKEN("1010004","access_token无效"),
    EXPIRED_ACCESS_TOKEN("1010005","access_token已过期"),
    INVALID_REST_API("1010006","Rest API无效"),
    APP_KEY_IS_UNAVAILABLE("1010008","app_key不可用"),
    NO_MORE_API("1010009","API达到调用上限"),
    FLOW_CONTROL_UPPER_LIMIT("1010010","平台达到系统流控上限"),
    APP_NOT_ACCESS_COMMERCIAL_ADDRESS("1010011","APP没有访问商用地址的权限"),
    INVALID_DISPLAY_NUMBER("1010023","主显号码不合法"),
    API_NOT_ALLOWED_INVOKED("1010028","此API已禁止调用"),
    APP_KEY_FORBID_INVOKED_API("1010040","app_key没有调用本API的权限"),
    RESOURCE_NOT_APPLIED("1012001","资源未申请"),
    TEMPLATE_ID_NOT_APPROVED("1012002","模板ID审核未通过"),
    TEMPLATE_ID_NOT_EXIST("1012003","模板ID不存在"),
    TEMPLATE_PARAS_MISMATCH_VARIABLES("1012004","templateParas的参数个数与模板的变量个数不一致"),
    TEMPLATE_PARAS_NOT_MEET_TEMPLATE_REQUIREMENTS("1012005","参数templateParas中的%s不符合模板定义的要求"),
    SERVICE_NUMBER_NOT_APPLIED("1012006","业务号码未申请"),
    CALLS_OUT_SP_LIMIT("1013001","呼叫数超过SP的阈值"),
    CALLS_OUT_APP_LIMIT("1013002","呼叫数超过APP的阈值"),
    CALLS_OUT_NUMBER_LIMIT("1013003","呼叫数超过号码的阈值"),
    NUMBER_IN_BLACKLIST("1013004","用户在黑名单里面"),
    CALLEE_NOT_IN_WHITELIST("1013011","被叫用户不在白名单中"),
    APP_ID_NOT_IN_WHITELIST("1020166","对端app IP不在白名单列表中");

    private String code;
    private String msg;

    HuaweiVoiceSmsResponseCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private static final Map<String, HuaweiVoiceSmsResponseCode> lookup = new HashMap<>();

    static {
        for (HuaweiVoiceSmsResponseCode huaweiVoiceSmsResponseCode : EnumSet.allOf(HuaweiVoiceSmsResponseCode.class)) {
            lookup.put(huaweiVoiceSmsResponseCode.getCode(), huaweiVoiceSmsResponseCode);
        }
    }

    public static HuaweiVoiceSmsResponseCode get(String code) {
        return lookup.get(code);
    }
}
