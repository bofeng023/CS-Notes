package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface ConsumeCountErrorCode extends BaseErrorCode {

    ErrorCode START_DATE_NULL_ERROR = new ErrorCode(800001, "开始日期不能为空");

    ErrorCode END_DATE_NULL_ERROR = new ErrorCode(800002, "结束日期不能为空");

    ErrorCode DATA_EXPORT_EXCEL_FAIL = new ErrorCode(800003, "数据生成excel失败");

    ErrorCode BIZ_TYPE_INVALID = new ErrorCode(800004, "业务类型无效");


}
