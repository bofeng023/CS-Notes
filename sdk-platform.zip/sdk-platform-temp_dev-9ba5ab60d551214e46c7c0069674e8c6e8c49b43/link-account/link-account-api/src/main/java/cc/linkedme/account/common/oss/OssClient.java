package cc.linkedme.account.common.oss;

import cc.linkedme.account.util.oss.OssFileUtil;
import com.aliyun.oss.ClientConfiguration;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.PutObjectResult;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URL;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author yangpeng
 * @date 2019-05-28 15:53
 * @description 采用注入的方式使用；支持项目中同时使用多个地区的接入点——北京、深圳、杭州、上海
 **/
@Setter
public class OssClient {

    private final static Logger logger = LoggerFactory.getLogger(OssClient.class);

    /**
     * 账号、密码
     */
    private String accessKeyId;
    private String accessKeySecret;
    /**
     * 下载地址
     */
    private String downloadUrl;

    /**
     *接入点注入，使用哪个注入哪个，可使用多个，阿里云oss通常分布在4个大区域
     */
    private String beijingEndpoint;
    private String hangzhouEndpoint;
    private String shanghaiEndpoint;
    private String shenzhenEndpoint;
    /**
     * OSSClient使用的最大连接数，默认1024
     */
    private Integer maxConnection = 1024;
    /**
     * 设置请求超时时间，默认60000ms
     */
    private Integer socketTimeout = 600000;
    /**
     * 设置失败请求重试次数，默认3次
     */
    private Integer maxRetry = 3;

    private static ClientConfiguration conf;
    private static ConcurrentHashMap<OssEndpointDomain, OSSClient> ossClientMap = new ConcurrentHashMap();

    public void init() {
        try {
            conf = new ClientConfiguration();
            conf.setMaxConnections(maxConnection);
            conf.setSocketTimeout(socketTimeout);
            conf.setMaxErrorRetry(maxRetry);

            if (null != beijingEndpoint) {
                ossClientMap.put(OssEndpointDomain.BEIJING, new OSSClient(beijingEndpoint, accessKeyId, accessKeySecret, conf));
            }
            if (null != hangzhouEndpoint) {
                ossClientMap.put(OssEndpointDomain.HANGZHOU, new OSSClient(hangzhouEndpoint, accessKeyId, accessKeySecret, conf));
            }
            if (null != shanghaiEndpoint) {
                ossClientMap.put(OssEndpointDomain.SHANGHAI, new OSSClient(shanghaiEndpoint, accessKeyId, accessKeySecret, conf));
            }
            if (null != shenzhenEndpoint) {
                ossClientMap.put(OssEndpointDomain.SHENZHEN, new OSSClient(shenzhenEndpoint, accessKeyId, accessKeySecret, conf));
            }
        }
        catch (Throwable throwable) {
            logger.error("oss init failed!", throwable);
        }
    }

    /**
     * 不做client创建的重试，以免传错参数，频繁new client
     * @param endpointDomain
     * @return
     */
    private OSSClient getClient(OssEndpointDomain endpointDomain) {

        OSSClient domainOssClient = ossClientMap.get(endpointDomain);

        return domainOssClient;
    }

    public PutObjectResult uploadMultipartFile(OssEndpointDomain ossEndpointDomain, String bucketName, String fileName, MultipartFile multipartFile) throws OssException {

        logger.info("uploadMultipartFile, ossEndpointDomain:{}, bucketName:{}, fileName:{}", ossEndpointDomain, bucketName, fileName);

        PutObjectResult putObjectResult;
        OSSClient ossClient;

        InputStream multipartFileInputStream = null;
        try {
            multipartFileInputStream = multipartFile.getInputStream();
            ossClient = getClient(ossEndpointDomain);
            putObjectResult = ossClient.putObject(bucketName, fileName, multipartFileInputStream);
        } catch (Exception ex) {
            logger.error("uploadMultipartFile failed, ossEndpointDomain:{}, bucketName:{}, fileName:{}", ossEndpointDomain, bucketName, fileName, ex);
            throw new OssException("oss uploadMultipartFile failed", ex);
        } finally {
            try {
                multipartFileInputStream.close();
            } catch (IOException e) {
                logger.error("uploadMultipartFile close input stream failed, ossEndpointDomain:{}, bucketName:{}, fileName:{}", ossEndpointDomain, bucketName, fileName, e);
            }
        }

        return putObjectResult;

    }

    /**
     * 上传byte格式文件
     * @param ossEndpointDomain
     * @param bucketName
     * @param fileName
     * @param fileContent
     * @return
     */
    public PutObjectResult uploadByteFile(OssEndpointDomain ossEndpointDomain, String bucketName, String fileName, byte[] fileContent) throws OssException {

        logger.info("uploadByteFile, ossEndpointDomain:{}, buckeetName:{}, fileName:{}, fileContent:{}", ossEndpointDomain, bucketName, fileName, fileContent);

        PutObjectResult putObjectResult;
        OSSClient ossClient;

        try {
            ossClient = getClient(ossEndpointDomain);
            putObjectResult = ossClient.putObject(bucketName, fileName, new ByteArrayInputStream(fileContent));
        } catch (Exception ex) {
            logger.error("uploadByteFile failed, ossEndpointDomain:{}, bucketName:{}, fileName:{}, fileContent:{}", ossEndpointDomain, bucketName, fileName, fileContent, ex);
            throw new OssException("oss uploadByteFile failed", ex);
        }
        return putObjectResult;
    }

    /**
     * 上传String格式文件
     * @param ossEndpointDomain
     * @param bucketName
     * @param fileName
     * @param fileContent
     * @return
     */
    public PutObjectResult uploadStringFile(OssEndpointDomain ossEndpointDomain, String bucketName, String fileName, String fileContent) throws OssException {

        logger.info("uploadStringFile, ossEndpointDomain:{}, bucketName:{}, fileName:{}, fileContent:{}", ossEndpointDomain, bucketName, fileName, fileContent);

        PutObjectResult putObjectResult;
        OSSClient ossClient;

        try {
            ossClient = getClient(ossEndpointDomain);
            putObjectResult = ossClient.putObject(bucketName, fileName, new ByteArrayInputStream(fileContent.getBytes()));
        } catch (Exception ex) {
            logger.error("uploadStringFile failed, ossEndpointDomain:{}, bukentName:{}, fileName:{}, fileContent:{}", ossEndpointDomain, bucketName, fileName, fileContent);
            throw new OssException("oss uploadStringFile failed", ex);
        }

        return putObjectResult;
    }

    /**
     * 上传Stream格式文件
     * @param ossEndpointDomain
     * @param bucketName
     * @param fileName
     * @param fileContent
     * @return
     */
    public  PutObjectResult uploadStreamFile(OssEndpointDomain ossEndpointDomain, String bucketName, String fileName, InputStream fileContent) throws OssException {

        logger.info("uploadStreamFile, ossEndpointDomain:{}, bucketName:{}, fileName:{}, fileContent:{}", ossEndpointDomain, bucketName, fileName, fileContent);

        PutObjectResult putObjectResult;
        OSSClient ossClient;

        try {
            ossClient = getClient(ossEndpointDomain);
            putObjectResult = ossClient.putObject(bucketName, fileName, fileContent);
        } catch (Exception ex) {
            logger.error("uploadStreamFile failed, ossEndpointDomain:{}, bucketName:{}, fileName:{}, fileContent:{}", ossEndpointDomain, bucketName, fileContent, ex);
            throw new OssException("oss uploadStreamFile failed", ex);
        }

        return putObjectResult;
    }

    /**
     * 上传本地文件
     * @param ossEndpointDomain
     * @param bucketName
     * @param fileName
     * @param localFileDir
     * @return
     */
    public PutObjectResult uploadLocalFile(OssEndpointDomain ossEndpointDomain, String bucketName, String fileName, String localFileDir) throws OssException {

        logger.info("uploadLocalFile, ossEndpointDomain:{}, bucketName:{}, fileName:{}, localFileDir:{}", ossEndpointDomain, bucketName, fileName, localFileDir);

        PutObjectResult putObjectResult;
        OSSClient ossClient;

        InputStream localFileInputStream = null;
        try {
            ossClient = getClient(ossEndpointDomain);
            localFileInputStream = new FileInputStream(localFileDir);
            putObjectResult = ossClient.putObject(bucketName, fileName, localFileInputStream);
        } catch (Exception ex) {
            logger.error("uploadLocalFile failed, ossEndpointDomain:{}, bucketName:{}, fileName:{}, localFileDir:{}", ossEndpointDomain, bucketName, fileName, localFileDir, ex);
            throw new OssException("oss uploadLocalFile failed", ex);
        } finally {
            try {
                localFileInputStream.close();
            } catch (IOException e) {
                logger.error("uploadLocalFile close input stream failed, ossEndpointDomain:{}, bucketName:{}, fileName:{}, localFileDir:{}", ossEndpointDomain, bucketName, fileName, localFileDir, e);
            }
        }

        return putObjectResult;
    }

    /**
     * 上传网络图片
     * @param ossEndpointDomain
     * @param bucketName
     * @param fileName
     * @param networkFileUrl
     * @return
     */
    public PutObjectResult uploadNetworkFile(OssEndpointDomain ossEndpointDomain, String bucketName, String fileName, String networkFileUrl) throws OssException {

        logger.info("uploadNetworkFile, ossEndpointDomain:{}, bucketName:{}, fileName:{}, networkFileUrl:{}", ossEndpointDomain, bucketName, fileName, networkFileUrl);

        PutObjectResult putObjectResult;
        OSSClient ossClient;

        InputStream networkFileInputStream = null;
        try {
            ossClient = getClient(ossEndpointDomain);
            networkFileInputStream = new URL(networkFileUrl).openStream();
            putObjectResult = ossClient.putObject(bucketName, fileName, networkFileInputStream);
        } catch (Exception ex) {
            logger.error("uploadNetworkFile failed, ossEndpointDomain:{}, bucketName:{}, fileName:{}, networkFileUrl:{}", ossEndpointDomain, bucketName, fileName, networkFileUrl, ex);
            throw new OssException("oss uploadNetworkFile failed", ex);
        } finally {
            try {
                networkFileInputStream.close();
            } catch (IOException e) {
                logger.error("uploadNetworkFile close input stream failed, ossEndpointDomain:{}, bucketName:{}, fileName:{}, networkFileUrl:{}", ossEndpointDomain, bucketName, fileName, networkFileUrl, e);
            }
        }

        return putObjectResult;
    }

    /**
     * 资源下载
     * @param fileUrl
     * @param response
     */
    public void downloadResource(String fileUrl, HttpServletResponse response) {
        ServletOutputStream out = null;
        try {
            out = response.getOutputStream();
            String fileName = fileUrl.substring(fileUrl.lastIndexOf("/") + 1);
            response.setContentType("multipart/form-data");
            response.setHeader("Content-Disposition","attachment;filename=\"" + fileName + "\"");
            OssFileUtil.download(out, downloadUrl, fileUrl);
            out.flush();
        } catch (Exception e) {
            logger.error("oss download error", e);
        } finally {
            if(out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    logger.error("oss download error", e);
                }
            }
        }
    }
}
