package cc.linkedme.account.model.sms;

import lombok.Data;

import java.util.Date;

@Data
public class SmsFrequencyInfo {

    private Integer id;

    private Integer uid;

    private Integer appId;

    private Integer countPerMinute;

    private Integer countPerHour;

    private Integer countPerDay;

    private Date gmtCreate;

    private Date gmtUpdate;
}
