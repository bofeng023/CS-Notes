package cc.linkedme.account.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: liuyunmeng
 * @Date: Create in 17:56 2019-08-13
 * @:Description 站内信消息的类型
 */
public enum MessageType {

    SYSTEM_MSG(0, "系统消息"),
    FEEDBACK_MSG(1, "问题反馈的消息"),
    ALL_MESSAGE(2, "全部消息");

    MessageType(Integer type, String desc) {
        this.type = type;
        this.desc = desc;
    }

    private Integer type;

    private String desc;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    private static final Map<Integer, MessageType> lookup = new HashMap<>();
    static {
        for (MessageType messageType : EnumSet.allOf(MessageType.class)) {
            lookup.put(messageType.getType(), messageType);
        }
    }

    public static MessageType get(Integer type) {
        return lookup.get(type);
    }


}
