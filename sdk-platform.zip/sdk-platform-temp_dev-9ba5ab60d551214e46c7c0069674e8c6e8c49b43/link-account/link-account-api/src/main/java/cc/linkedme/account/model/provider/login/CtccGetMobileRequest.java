package cc.linkedme.account.model.provider.login;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-13 15:55
 * @description
 **/
@Data
public class CtccGetMobileRequest {

    /**
     * 是否必填：是
     * 应用 ID
     * 申请应用时分配的应用 ID
     */
    private String appId;

    /**
     * 是否必填：是
     * 时间戳
     * 毫秒
     */
    private Long timeStamp;

    /**
     * 是否必填：是
     * 返回格式
     * 目前只支持 json
     */
    private String format;

    /**
     * 是否必填：是
     * XXTea 加密
     * params= XXTea((accessCode=value1&aut hCode=value2), appSecret)，其 中 appSecret 是申请应用时平台生
     * 成的应用秘钥，参数拼接无顺序要求
     */
    private String params;

    /**
     * 是否必填：是——在params中
     * 授权 CODE
     * 用户获取用户信息
     */

    private String accessCode;

    /**
     * 是否必填：是——在params中
     * 校验码
     */
    private String authCode;

    /**
     * 是否必填：是
     * 签名
     * 除 sign 外其它参数的 RSA 加密值， 加密算法如下:
     * sign=RSA(appId+format+params+timeStamp,RSA_Private_key)
     * 需要注意参数拼接 key 升序排序。其中 RSA_Private_key 是合作方的 RSA 私钥，合作方需要向开放平台 提供 RSA 公钥，用于访问接口时的 验签
     */
    private String sign;

    @Override
    public String toString() {
        return "appId=" + appId + "&timeStamp=" + timeStamp + "&format=" + format + "&params=" + params + "&sign=" + sign;
    }

}
