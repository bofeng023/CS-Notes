package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

/**
 * @author zhanghaowei
 * @date 2019-6-17 11:27
 * @description
 **/
public interface AuthConfigErrorCode extends BaseErrorCode {

    ErrorCode SECRET_KEY_CREATE_FAIL = new ErrorCode(1000001, "密钥生成失败");

    ErrorCode APP_KEY_NO_VALID = new ErrorCode(1000002, "app key 无效");


}
