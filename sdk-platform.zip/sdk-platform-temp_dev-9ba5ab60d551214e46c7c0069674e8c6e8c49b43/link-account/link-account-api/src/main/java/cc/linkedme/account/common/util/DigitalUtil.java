package cc.linkedme.account.common.util;

import java.math.BigDecimal;

/**
 * @author yangpeng
 * @date 2019-05-31 18:21
 * @description
 **/
public class DigitalUtil {

    /**
     * 金额转化为整数(元-》分)
     * @param money
     * @return
     */
    public static Long moneyConvertToLong(String money) {
        BigDecimal bigDecimal = new BigDecimal(money);
        bigDecimal = bigDecimal.setScale(BigDecimal.ROUND_HALF_DOWN,3);
        return bigDecimal.multiply(new BigDecimal(1000)).longValue();
    }

    /**
     * 金额转化为整数(元-》分)
     * @param money
     * @return
     */
    public static Integer moneyConvertToInteger(String money) {
        BigDecimal bigDecimal = new BigDecimal(money);
        bigDecimal = bigDecimal.setScale(BigDecimal.ROUND_HALF_DOWN,3);
        return bigDecimal.multiply(new BigDecimal(1000)).intValue();
    }

    /**
     * 金额分转元
     * @param money
     * @return
     */
    public static double moneyConverToDouble(Long money) {
        BigDecimal bigDecimal = new BigDecimal(money);
        bigDecimal = bigDecimal.divide(new BigDecimal(1000)).setScale(BigDecimal.ROUND_HALF_DOWN,3);
        return bigDecimal.doubleValue();
    }

    /**
     * 金额分转元
     * @param money
     * @return
     */
    public static double moneyConverToDouble(Integer money) {
        BigDecimal bigDecimal = new BigDecimal(money);
        bigDecimal = bigDecimal.divide(new BigDecimal(1000)).setScale(BigDecimal.ROUND_HALF_DOWN,3);
        return bigDecimal.doubleValue();
    }
}
