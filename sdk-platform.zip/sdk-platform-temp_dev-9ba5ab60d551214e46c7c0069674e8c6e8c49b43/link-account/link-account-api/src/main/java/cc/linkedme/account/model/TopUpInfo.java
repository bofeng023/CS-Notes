package cc.linkedme.account.model;

import cc.linkedme.account.enums.RechargeType;
import cc.linkedme.enums.AuditState;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 充值
 * @author zhanghaowei
 */
@Data
public class TopUpInfo implements Serializable {

    private Integer id;

    private Integer uid;

    private Integer amount;

    private Integer giftAmount;

    private Integer quickLoginOnceAmount;

    private Integer verifyOnceAmount;

    private Integer smsOnceAmount;

    private Integer voiceOnceAmount;

    private Integer globalOnceAmount;

    private String receipt;

    private Byte consumeState;

    private AuditState auditState;

    private Date gmtCreate;

    private Date gmtModified;

    private RechargeType rechargeType;
}
