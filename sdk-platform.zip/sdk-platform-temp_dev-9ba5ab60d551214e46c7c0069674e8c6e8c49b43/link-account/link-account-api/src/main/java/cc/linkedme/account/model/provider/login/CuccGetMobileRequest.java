package cc.linkedme.account.model.provider.login;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zhanghaowei
 * @date 2019-6-15 13:38
 * @description
 **/

@Data
public class CuccGetMobileRequest {

    private Header header;

    private Body body;

    @Data
    @JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Header {

        /**
         * 是否必填：是
         * app id（在申请接入权限时获 得）
         */
        private String clientId;

        /**
         * 是否必填：是
         * 填v2.0
         * 版本号
         */
        private String version;

        /**
         * 是否必填：是
         * 登陆成功获取的 access_token
         */
        private String accessToken;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Body {

        /**
         * 是否必填：是
         * 当前时间时间戳
         */
        private String timeStamp;

        /**
         * 是否必填：是
         * 标识请求随机数
         */
        private String msgid;

        /**
         * 是否必填：是
         * 签名
         * 当参数 crypto≠ RSA 时，sign=MD5(client_id+version+ access_token+ timeStamp+msgid + client_secret)
         * 当参数 crypto=RSA 时，sign=业务 端 RSA 私钥对 (client_id+access_token)的签名,服务端使用业务端提供的公钥验证签 名
         */
        private String sign;

        private String encrypt;
    }

}
