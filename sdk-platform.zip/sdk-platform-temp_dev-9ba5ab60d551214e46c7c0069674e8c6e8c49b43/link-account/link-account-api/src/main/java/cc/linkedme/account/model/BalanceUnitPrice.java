package cc.linkedme.account.model;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-27 16:13
 * @description
 **/
@Data
public class BalanceUnitPrice {

    private Integer contractId;

    private Integer loginUnitPrice;

    private Integer mobileVerifyUnitPrice;

    private Integer textSmsUnitPrice;

    private Integer voiceSmsUnitPrice;

    private Integer globalSmsUnitPrice;
}
