package cc.linkedme.account.model.provider.sms;

import lombok.Data;

import java.util.List;


/**
 * @author zhanghaowei
 * @date 2019-7-16 17:47
 * @description 封装短信发送请求
 **/

@Data
public class HuaweiSmsRequest {

    private Header header;

    private Body body;

    @Data
    public static class Header {

        private String appKey;

        private String appSecret;
    }

    @Data
    public static class Body {

        /**
         * 发送者
         */
        private String from;

        /**
         * 回调地址
         */
        private String statusCallback;

        /**
         * 扩展字段
         */
        private String extend;

        /**
         * 发送短内容
         */
        private List<DiffSms> smsContent;

    }


    @Data
    public static class DiffSms {

        /**
         * 接收者
         */
        private List<String> to;

        /**
         * 发送内容
         */
        private String body;

    }

}
