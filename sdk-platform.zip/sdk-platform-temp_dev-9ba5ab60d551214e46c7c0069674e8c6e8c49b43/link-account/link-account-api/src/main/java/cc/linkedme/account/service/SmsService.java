package cc.linkedme.account.service;

import cc.linkedme.account.exception.SmsException;
import cc.linkedme.account.model.sms.SmsCallbackInfo;
import cc.linkedme.account.model.sms.SmsInfo;
import cc.linkedme.account.model.sms.VoiceSmsCallbackInfo;
import cc.linkedme.account.model.sms.VoiceSmsInfo;
import cc.linkedme.enums.BizType;

/**
 *  短信service
 */
public interface SmsService {

    /**
     * 异步发送文本信息，将消息放入到消息队列中等待系统处理
     *
     * @param smsInfo
     * @throws SmsException
     */
    void asyncSendText(SmsInfo smsInfo) throws SmsException;

    /**
     * 异步处理服务提供商回调的文本短信状态报告
     *
     * @param smsCallbackInfo
     * @throws SmsException
     */
    void asyncHandleProviderTextCallback(SmsCallbackInfo smsCallbackInfo) throws SmsException;

    /**
     * 发送文本短信回调请求通知用户
     *
     * @param smsCallbackInfo
     * @return boolean
     * @throws SmsException
     */
    boolean sendTextCallback(SmsCallbackInfo smsCallbackInfo) throws SmsException;

    /**
     * 异步发送语音信息，将消息放入到消息队列中等待系统处理
     * @param voiceSmsInfo
     * @throws SmsException
     */
    void asyncSendVoice(VoiceSmsInfo voiceSmsInfo) throws SmsException;

    /**
     * 异步处理服务提供商回调的语音短信状态报告
     * @param voiceSmsCallbackInfo
     * @throws SmsException
     */
    void asyncHandleProviderVoiceCallback(VoiceSmsCallbackInfo voiceSmsCallbackInfo) throws SmsException;

    /**
     * 发送语音费用报告回调请求
     * @param voiceSmsCallbackInfo
     * @return
     * @throws SmsException
     */
    boolean sendVoiceCallback(VoiceSmsCallbackInfo voiceSmsCallbackInfo) throws SmsException;

    /**
     * 退款
     *
     * @param key
     * @param count
     * @param uid
     * @param bizType
     */
    void refund(String key, int count, String uid, BizType bizType);

}
