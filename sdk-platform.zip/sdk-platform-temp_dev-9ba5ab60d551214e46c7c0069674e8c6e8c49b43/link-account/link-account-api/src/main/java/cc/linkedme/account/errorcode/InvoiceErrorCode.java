package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface InvoiceErrorCode extends BaseErrorCode {

    ErrorCode TAXPAYER_IDENTIFICATION_NULL_ERROR = new ErrorCode(400001, "纳税人识别号必填");

    ErrorCode CONTACT_INFO_NULL_ERROR = new ErrorCode(400002, "地址、电话必填");

    ErrorCode BANK_ACCOUNT_NULL_ERROR = new ErrorCode(400003, "开户行及账号必填");

    ErrorCode EXCESS_INVOICE_VALUE = new ErrorCode (400004, "已开发票金额超额");

}
