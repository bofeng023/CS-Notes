package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;
import lombok.Data;

@Data
/**
 * 发票异常类
 * @author zhanghaowei
 */
public class InvoiceException extends BusinessException {
    public InvoiceException(ErrorCode errorCode) {
        super(errorCode);
    }
}
