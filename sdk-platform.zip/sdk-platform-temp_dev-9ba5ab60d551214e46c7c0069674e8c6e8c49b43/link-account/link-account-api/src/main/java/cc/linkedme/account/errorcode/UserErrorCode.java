package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface UserErrorCode extends BaseErrorCode {

    ErrorCode USER_RESPONSE_FORMAT_ERROR = new ErrorCode(700001, "用户查询返回结果格式错误");

    ErrorCode APP_RESPONSE_FORMAT_ERROR = new ErrorCode(700002, "应用列表返回结果格式错误");

}
