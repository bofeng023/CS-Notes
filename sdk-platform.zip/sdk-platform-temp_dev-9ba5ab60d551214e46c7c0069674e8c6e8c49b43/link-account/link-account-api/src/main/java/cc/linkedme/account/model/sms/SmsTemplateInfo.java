package cc.linkedme.account.model.sms;

import cc.linkedme.enums.AuditState;
import cc.linkedme.enums.YesNoEnum;
import lombok.Data;

import java.util.Date;

@Data
public class SmsTemplateInfo {
    private Integer id;

    private Integer uid;

    private Integer appId;

    private String templateCode;

    private String aliyunTemplateCode;

    private String templateName;

//    private Byte templateType;

    private YesNoEnum isGlobal;

    private String content;

    private String applyRemark;

    private AuditState certificationState;

    private Date gmtCreate;

    private Date gmtUpdate;
}
