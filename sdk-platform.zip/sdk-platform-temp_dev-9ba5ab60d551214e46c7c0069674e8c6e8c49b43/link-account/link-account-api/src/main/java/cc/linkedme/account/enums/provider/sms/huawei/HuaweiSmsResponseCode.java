package cc.linkedme.account.enums.provider.sms.huawei;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zhanghaowei
 * @date 2019-7-16 18:43
 * @description 华为响应结果code
 **/
public enum HuaweiSmsResponseCode {

    SUCCESS("000000", "发送请求成功"),
    SYSTEM_ERROR("E000000", "系统异常"),
    AUTHORIZATION_INVALID("E000001", "HTTP消息头未找到Authorization字段"),
    REALM_INVALID("E000002", "realm 属性不合法"),
    REALM_DSP_INVALID("E000004", "Authorization中realm属性值应该为SDP"),
    USER_NAME_TOKEN_INVALID("E000005", "Authorization中profile属性值应该为UsernameToken"),
    AUTHORIZATION_TYPE_APP_KEY_INVALID("E000006", "Authorization中type属性值应该为Appkey"),
    TYPE_INVALID("E000007", "Authorization字段中未找到type属性"),
    WSSE_INVALID("E000008", "Authorization中没有携带WSSE"),
    X_WSSE_INVALID("E000020", "HTTP头未找到X-WSSE字段"),
    USERNAME_INVALID("E000021", "X-WSSE字段中未找到UserName属性"),
    NONCE_INVALID("E000022", "X-WSSE字段中未找到Nonce属性"),
    CREATED_INVALID("E000023", "X-WSSE字段中未找到Created属性"),
    PASSWORD_DIGEST_INVALID("E000024", "X-WSSE字段中未找到PasswordDigest属性"),
    CREATED_FORMAT_INVALID("E000025", "Created属性格式错误"),
    USER_NAME_TOKEN_IS_NULL("E000026", "X-WSSE字段中未找到UsernameToken属性"),
    INVALID_REQUEST("E000027", "非法请求"),
    PARAM_FORMAT_ERROR("E000503", "参数格式错误"),
    SMS_SEND_FAIL("E200037", "短信发送失败"),
    SMS_SEND_OVER_LIMIT("E000623", "SP短信发送量达到限额"),
    AUTHENTICATION_FAILED("E000101", "鉴权失败"),
    APP_KEY_INVALID("E000102", "app_key无效"),
    APP_KEY_DISABLED("E000103", "app_key不可用"),
    APP_SECRET_INVALID("E000104", "app_secret无效"),
    DIGEST_INVALID("E000105", "digest无效"),
    APP_KEY_NOT_ALLOWED("E000106", "app_key没有调用本API的权限"),
    USER_DEACTIVATED("E000109", "用户状态未激活"),
    TIME_OUT_LIMIT("E000110", "时间超出限制"),
    USERNAME_PASSWORD_INCCORECT("E000111", "用户名或密码错误"),
    SUBSRIBER_FROZEN("E000112", "用户状态已冻结"),
    APP_IP_NOT_WHITELIST("E000620", "对端appIP不在白名单列表中"),
    VOICE_SEND_SMS_SUCCESS("0", "成功");

    private String code;
    private String msg;

    HuaweiSmsResponseCode(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    private static final Map<String, HuaweiSmsResponseCode> lookup = new HashMap<>();

    static {
        for (HuaweiSmsResponseCode huaweiResponseCode : EnumSet.allOf(HuaweiSmsResponseCode.class)) {
            lookup.put(huaweiResponseCode.getCode(), huaweiResponseCode);
        }
    }

    public static HuaweiSmsResponseCode get(String code) {
        return lookup.get(code);
    }
}
