package cc.linkedme.account.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * 发票类型
 * @author zhanghaowei
 */
public enum InvoiceType {

    COMMON_INCREMENT_INVOICE(0,"普通增值发票"),

    INCREMENT_SPECIAL_USE_INVOICE(1,"增值税专用发票");

    private static final Map<Integer, InvoiceType> lookup = new HashMap<>();

    static {
        for (InvoiceType s : EnumSet.allOf(InvoiceType.class)) {
            lookup.put(s.getCode(), s);
        }
    }

    public static InvoiceType get(Integer index) {
        return lookup.get(index);
    }

    private Integer code ;

    private String name;

    InvoiceType(int code,String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
