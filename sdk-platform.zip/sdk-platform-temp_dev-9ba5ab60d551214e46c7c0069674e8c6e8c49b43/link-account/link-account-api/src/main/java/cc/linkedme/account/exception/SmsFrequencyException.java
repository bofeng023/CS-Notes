package cc.linkedme.account.exception;

import cc.linkedme.errorcode.ErrorCode;
import cc.linkedme.exception.BusinessException;

public class SmsFrequencyException extends BusinessException {
    public SmsFrequencyException(ErrorCode errorCode) {
        super(errorCode);
    }
}
