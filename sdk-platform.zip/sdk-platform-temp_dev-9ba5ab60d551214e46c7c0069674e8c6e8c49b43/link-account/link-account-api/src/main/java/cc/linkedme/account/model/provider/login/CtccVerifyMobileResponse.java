package cc.linkedme.account.model.provider.login;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-14 21:05
 * @description
 **/
@Data
public class CtccVerifyMobileResponse {

    private String result;

    private String msg;

    private String data;

    @lombok.Data
    public static class Data {

        private Integer isVerify;
    }
}
