package cc.linkedme.account.model.provider.login;

import lombok.Data;

/**
 * @author yangpeng
 * @date 2019-06-13 15:01
 * @description
 **/
@Data
public class CmccGetMobileResponse {

    /**
     * 对应的请求消息中的msgid
     */
    private String inresponseto;

    /**
     * 响应消息发送的系统时间，精确到毫秒，共17位，格式:20121227180001165
     */
    private String systemtime;

    /**
     * 返回码
     */
    private String resultCode;

    /**
     * 表示手机号码，如果加密方式为RSA，开发者使用在社区配置的加密公钥(应用公钥2)对 应的私钥进行解密
     */
    private String msisdn;
}
