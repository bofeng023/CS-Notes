package cc.linkedme.account.errorcode;

import cc.linkedme.errorcode.BaseErrorCode;
import cc.linkedme.errorcode.ErrorCode;

public interface PhoneNumVerificationErrorCode extends BaseErrorCode {

    ErrorCode RSA_DECRYPT_ERROR = new ErrorCode(900001, "解密运营商返回结果错误");

    ErrorCode RSA_SIGN_ERROR = new ErrorCode(900002, "加签运营商请求错误");

    ErrorCode XXTEA_PARAMS_ERROR = new ErrorCode(900003, "xxtea加密请求参数错误");

    ErrorCode DESANDBASE64_ENCRYPT_ERROR = new ErrorCode(900004, "运营商参数3DesAndBase64加密错误");

    ErrorCode CHANNEL_ERROR = new ErrorCode(900005, "channel来源渠道参数错误");

    ErrorCode PLATFORM_TYPE_ERROR = new ErrorCode(900006, "platform平台类型参数错误");

    ErrorCode AUTH_CODE_ERROR = new ErrorCode(900007, "authCode校验码参数错误");

    ErrorCode PHONE_ERROR = new ErrorCode(900008, "手机号格式不正确");

    ErrorCode APP_ID_ERROR = new ErrorCode(900009, "appId错误");

    ErrorCode TOKEN_ERROR = new ErrorCode(900010, "token参数错误");

    ErrorCode SIGN_ERROR = new ErrorCode(900011, "验签失败");

    ErrorCode TOKEN_EXPIRED = new ErrorCode(900012, "token失效");

    ErrorCode PERMISSION_DENIED = new ErrorCode(900013, "权限不足");

    ErrorCode APP_NO_AUTHORIZATION = new ErrorCode(900014, "应用未授权");

    ErrorCode PARAM_ERROR = new ErrorCode(900015, "参数异常");

    ErrorCode IP_WHITELIST_ERROR = new ErrorCode(900016, "ip白名单校验失败");

    ErrorCode ENCRYPT_ERROR = new ErrorCode(900017, "加密失败");

    ErrorCode GET_MOBILE_FAILED = new ErrorCode(900018, "无法获取手机号");

    ErrorCode NO_QUOTAS = new ErrorCode(900019, "余额不足");

    ErrorCode OTHER_ERROR = new ErrorCode(900020, "内部错误");

    ErrorCode APP_KEY_NO_VALID = new ErrorCode(900021, "app key 无效");



}
