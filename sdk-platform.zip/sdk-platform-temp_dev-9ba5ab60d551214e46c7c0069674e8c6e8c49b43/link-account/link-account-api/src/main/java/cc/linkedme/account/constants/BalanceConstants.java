package cc.linkedme.account.constants;

/**
 * @author yangpeng
 * @date 2019-06-27 16:27
 * @description
 **/
public class BalanceConstants {

    public static final Integer CREDIT_CACHE_AVATAR_ID = Integer.MAX_VALUE;

    public static final String USER_CONTRACT_BALANCE_PREFIX = "user_contract_amount_balance";

    public static final String USER_CONTRACT_UNIT_PRICE_PREFIX = "user_contract_unit_price";

    public static final String USER_CREDIT_AMOUNT_PREFIX = "user_credit_amount_prefix";
}
