package cc.linkedme.account.web;


import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.ResponseBuilder;
import org.apache.commons.lang.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

public class BaseController {

    Logger logger = LoggerFactory.getLogger(BaseController.class);


    private static final int SUCCESS_CODE = 200;

    private static final int ERROR_CODE = 500;

    private static final String SUCCESS_MSG = "操作成功";

    protected FrameResp buildSuccessResp() {
        return buildSuccessResp(null, true);
    }

    protected FrameResp buildSuccessResp(Object body) {
        return buildSuccessResp(body, true);
    }

    protected FrameResp buildSuccessResp(Object body, boolean alert) {
        return new ResponseBuilder().success(true).alert(alert).code(SUCCESS_CODE).message(SUCCESS_MSG).body(body).build();
    }

    protected FrameResp buildErrorResp(String message) {
        return new ResponseBuilder().success(false).code(ERROR_CODE).message(message).build();
    }



    /**
     * 获取HttpServletRequest请求上下文
     *
     * @return
     */
    protected HttpServletRequest getRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
    }

    protected String getRequestIp() {

        HttpServletRequest request = getRequest();
        String ip = request.getHeader("X-Real-IP");

        if (StringUtils.isEmpty(ip)) {
            ip = request.getHeader("X-Forwarded-For");
        }

        if (ip == null || ip.length() == 0) {
            ip = request.getRemoteAddr();
        }

        return ip;
    }
}
