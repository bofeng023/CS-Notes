package cc.linkedme.account.converter;

import cc.linkedme.account.model.request.HuaweiSmsCallbackRequest;
import cc.linkedme.account.model.sms.SmsCallbackInfo;
import org.springframework.beans.BeanUtils;

/**
 * @author zhanghaowei
 * @date 2019/7/16 15:48
 * @description
 **/
public class HuaweiSmsCallbackVoConverter {


    public static SmsCallbackInfo vo2Bo(HuaweiSmsCallbackRequest huaweiSmsCallbackRequest) {

        if (null == huaweiSmsCallbackRequest) {
            return null;
        }

        SmsCallbackInfo smsCallbackInfo = new SmsCallbackInfo();

        BeanUtils.copyProperties(huaweiSmsCallbackRequest, smsCallbackInfo);
        smsCallbackInfo.setMsgId(huaweiSmsCallbackRequest.getSmsMsgId());
        smsCallbackInfo.setRecipient(huaweiSmsCallbackRequest.getTo());

        return smsCallbackInfo;
    }

}
