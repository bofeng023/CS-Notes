package cc.linkedme.account.converter;

import cc.linkedme.account.enums.provider.sms.huawei.HuaweiVoiceSmsCallBackStatus;
import cc.linkedme.account.model.request.HuaweiVoiceSmsCallbackRequest;
import cc.linkedme.account.model.sms.VoiceSmsCallbackInfo;
import org.springframework.beans.BeanUtils;

/**
 * @Author: liuyunmeng
 * @Date: Create in 19:15 2019-07-24
 * @:Description
 */
public class HuaweiVoiceSmsCallbackVoConverter {

    public static VoiceSmsCallbackInfo vo2Bo(HuaweiVoiceSmsCallbackRequest.FeeInfo feeInfoSource) {

        if (null == feeInfoSource) {
            return null;
        }

        VoiceSmsCallbackInfo voiceSmsCallbackInfo = new VoiceSmsCallbackInfo();
        BeanUtils.copyProperties(feeInfoSource, voiceSmsCallbackInfo);
        voiceSmsCallbackInfo.setExtend(feeInfoSource.getUserData());
        voiceSmsCallbackInfo.setRecipient(feeInfoSource.getCalleeNum());
        voiceSmsCallbackInfo.setMsgId(feeInfoSource.getSessionId());
        voiceSmsCallbackInfo.setHuaweiVoiceSmsCallBackStatus(HuaweiVoiceSmsCallBackStatus.get(feeInfoSource.getUlFailReason()));
        return voiceSmsCallbackInfo;
    }


}
