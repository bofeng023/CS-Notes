package cc.linkedme.account.web;

import cc.linkedme.account.converter.HuaweiSmsCallbackVoConverter;
import cc.linkedme.account.converter.HuaweiVoiceSmsCallbackVoConverter;
import cc.linkedme.account.errorcode.SmsErrorCode;
import cc.linkedme.account.exception.SmsException;
import cc.linkedme.account.model.FrameResp;
import cc.linkedme.account.model.request.HuaweiSmsCallbackRequest;
import cc.linkedme.account.model.request.HuaweiVoiceSmsCallbackRequest;
import cc.linkedme.account.model.sms.SmsCallbackInfo;
import cc.linkedme.account.model.sms.VoiceSmsCallbackInfo;
import cc.linkedme.account.service.SmsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author zhanghaowei
 * @date 2019-7-15 20:41
 * @description
 **/

@RestController
@RequestMapping("/sms/")
public class SmsCallbackController extends BaseController {

    Logger logger = LoggerFactory.getLogger(SmsCallbackController.class);

    @Resource
    private SmsService smsService;

    @RequestMapping("text")
    public FrameResp receiveSmsReport(HuaweiSmsCallbackRequest huaweiSmsCallbackRequest) {

        logger.info("receiveSmsReport, huaweiSmsCallbackRequest:{}", huaweiSmsCallbackRequest);

        SmsCallbackInfo smsCallbackInfo = HuaweiSmsCallbackVoConverter.vo2Bo(huaweiSmsCallbackRequest);
        smsService.asyncHandleProviderTextCallback(smsCallbackInfo);

        return buildSuccessResp();
    }


    @RequestMapping("voice")
    public FrameResp receiveVoiceSmsReport(@RequestBody HuaweiVoiceSmsCallbackRequest huaweiVoiceSmsCallbackRequest) {

        logger.info("receiveVoiceSmsReport, huaweiVoiceSmsCallbackRequest:{}", huaweiVoiceSmsCallbackRequest);

       if (CollectionUtils.isEmpty(huaweiVoiceSmsCallbackRequest.getFeeLst())) {
           throw new SmsException(SmsErrorCode.CALLBACK_CONTENT_ERROR);
       }

        for (HuaweiVoiceSmsCallbackRequest.FeeInfo feeInfo : huaweiVoiceSmsCallbackRequest.getFeeLst()) {
            VoiceSmsCallbackInfo voiceSmsCallbackInfo = HuaweiVoiceSmsCallbackVoConverter.vo2Bo(feeInfo);
            smsService.asyncHandleProviderVoiceCallback(voiceSmsCallbackInfo);
        }
        return buildSuccessResp();
    }

}
