package cc.linkedme.account.model;

public class ResponseBuilder {

    private FrameResp frameResp;

    public  ResponseBuilder() {
        this.frameResp = new FrameResp();
    }

    public ResponseBuilder code(int errorCode) {
        frameResp.getHeader().setCode(errorCode);
        return this;
    }

    public ResponseBuilder message(String msg) {
        frameResp.getHeader().setMsg(msg);
        return this;
    }

    public ResponseBuilder success(boolean success) {
        frameResp.getHeader().setSuccess(success);
        return this;
    }

    public ResponseBuilder alert(boolean alert) {
        frameResp.getHeader().setAlert(alert);
        return this;
    }

    public ResponseBuilder body(Object body) {
        frameResp.setBody(body);
        return this;
    }

    public FrameResp build() {
        return frameResp;
    }
}
