package cc.linkedme.account.model.request;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Author: liuyunmeng
 * @Date: Create in 16:44 2019-07-24
 * @:Description
 */
@Data
public class HuaweiVoiceSmsCallbackRequest implements Serializable {

    /**
     * api 事件通知的类型
     */
    private String eventType;

    /**
     * 呼叫话单事件的信息，参数取值为列表，最大50条,当eventType参数为fee时携带
     */
    private List<FeeInfo> feeLst;


    @Data
    public static class FeeInfo {

        /**
         * 通话的呼叫方向
         */
        private Integer direction;

        /**
         * 客户的云服务账号
         */
        private String spId;

        /**
         * 应用的app_key
         */
        private String appKey;

        /**
         * 呼叫记录的唯一标识
         */
        private String icid;

        /**
         * 发起此次呼叫的CallEnabler业务号码
         */
        private String bindNum;

        /**
         * 通话链路的唯一标识
         */
        private String sessionId;

        /**
         * 主叫号码，号码为全局号码格式（包含国家码）
         */
        private String callerNum;

        /**
         * 被叫号码，号码为全局号码格式（包含国家码）
         */
        private String calleeNum;

        /**
         * 呼叫结束时间。
         * 该参数为UTC时间（+8小时为北京时间），时间格式为“yyyy-MM-dd HH:mm:ss”
         */
        private String callEndTime;

        /**
         * 转接呼叫操作失败的Q850原因值
         */
        private Integer fwdUnaswRsn;

        /**
         * 呼入、呼出的失败时间
         */
        private String failTime;

        /**
         * 通话失败的拆线点
         */
        private Integer ulFailReason;

        /**
         * 呼入、呼出的失败SIP状态码
         */
        private Integer sipStatusCode;

        /**
         * Initcall的呼出开始时间
         */
        private String callOutStartTime;

        /**
         * Initcall的呼出振铃时间
         */
        private String callOutAlertingTime;

        /**
         * Initcall的呼出应答时间
         */
        private String callOutAnswerTime;

        /**
         * Initcall的呼出失败的Q850原因值
         */
        private Integer callOutUnaswRsn;

        /**
         * 自定义动态IVR开始时间
         */
        private String dynIVRStartTime;

        /**
         * 自定义动态IVR按键路径
         */
        private String dynIVRPath;

        /**
         * 该字段用于录音标识，参数值范围如：
         * 0：表示未录音
         * 1：表示有录音
         */
        private Integer recordFlag;

        /**
         * 应用TTS功能时，使用TTS的总次数
         */
        private Integer ttsPlayTimes;

        /**
         * 应用TTS功能时，TTS Server进行TTS转换的总时长。单位为秒
         */
        private Integer ttsTransDuration;

        /**
         * 携带呼叫的业务类型信息，取值范围：
         * 001：语音播放
         */
        private String serviceType;

        /**
         * 该参数用于标识话单生成的服务器设备对应的主机名
         */
        private String hostName;

        /**
         * 用户附属信息，此参数的值与“语音通知API”中的"userData"参数值一致
         */
        private String userData;

    }

}
