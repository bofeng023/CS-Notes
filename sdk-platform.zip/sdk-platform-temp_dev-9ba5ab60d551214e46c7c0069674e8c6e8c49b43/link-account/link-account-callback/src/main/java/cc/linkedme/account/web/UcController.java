package cc.linkedme.account.web;

import cc.linkedme.account.model.FrameResp;
import cc.linkedme.cache.redis.RedisClientUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * @author lvhao
 * @date 2019-09-12
 * @description
 **/
@RestController
@RequestMapping("/uc")
public class UcController extends BaseController {
    @Resource
    private RedisClientUtil tokenRedisClient;

    private static final Logger logger = LoggerFactory.getLogger("ucToken");

    private static final String ucToken = "uc_token";
    /**
     * 有效期一周
     */
    private static final int CACHE_SECONDS = 7 * 24 * 3600;

    @PostMapping("/token")
    public FrameResp ucToken(){
        HttpServletRequest request = getRequest();
        String token = request.getParameter("access_token");
        tokenRedisClient.setex(ucToken, token, CACHE_SECONDS);

        logger.info("token:{}", token);
        return buildSuccessResp(token);
    }

}
